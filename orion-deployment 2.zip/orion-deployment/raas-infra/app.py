#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#
"""Argo Prerequisites App for stack deployment"""

import logging
import os

import aws_cdk as cdk

from raas_infra import configure_app

# Adapt log level if GitHub action run is configured for debug
if os.getenv("RUNNER_DEBUG") is not None:
    logging.basicConfig(level=logging.DEBUG)

app = cdk.App()
configure_app(app)
app.synth()

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test Karpenter stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "karpenter"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template() -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[0]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return Template.from_stack(stack)


def _expected_stack_tags() -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": "addf-core-infra-dev-karpenter",
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_karpenter_sa_role_in_stack() -> None:
    """Test for expected karpenter sa role with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Karpenter Controller.",
            "RoleName": "RaasKarpenterControllerServiceAccountRole-addf-realm-infra-dev-",
            "Tags": _expected_stack_tags(),
        },
    )


def test_helmchart_in_stack() -> None:
    """Test if Helm Chart resource is present in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "karpenter",
            "Namespace": "kube-system",
        },
    )


def test_log_group_in_stack() -> None:
    """Test if CloudWatch Log Group is created"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Logs::LogGroup",
        {
            "LogGroupName": "addf-core-infra-dev-karpenter-logs",
            "RetentionInDays": 731,
        },
    )


def test_iam_policy_for_sa_created() -> None:
    """Test if the IAM Policy for the service account is created"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyName": "karpenter_controller_access_policy",
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "ssm:GetParameter",
                            "ec2:DescribeImages",
                            "ec2:RunInstances",
                            "ec2:DescribeSubnets",
                            "ec2:DescribeSecurityGroups",
                            "ec2:DescribeLaunchTemplates",
                            "ec2:DescribeInstances",
                            "ec2:DescribeInstanceTypes",
                            "ec2:DescribeInstanceTypeOfferings",
                            "ec2:DescribeAvailabilityZones",
                            "ec2:DeleteLaunchTemplate",
                            "ec2:CreateTags",
                            "ec2:CreateLaunchTemplate",
                            "ec2:CreateFleet",
                            "ec2:DescribeSpotPriceHistory",
                            "pricing:GetProducts",
                        ],
                        "Effect": "Allow",
                        "Resource": "*",
                        "Sid": "Karpenter",
                    },
                    {
                        "Action": "ec2:TerminateInstances",
                        "Condition": {
                            "StringLike": {"ec2:ResourceTag/karpenter.sh/nodepool": "*"}
                        },
                        "Effect": "Allow",
                        "Resource": "*",
                        "Sid": "ConditionalEC2Termination",
                    },
                    {
                        "Action": "iam:PassRole",
                        "Effect": "Allow",
                        "Resource": "arn:aws:iam::1234321:role/KarpenterNodeRole-addf-realm-infra-dev-core-eks-cluster",
                        "Sid": "PassNodeIAMRole",
                    },
                    {
                        "Action": "eks:DescribeCluster",
                        "Effect": "Allow",
                        "Resource": "arn:aws:eks:eu-central-1:1234321:cluster/addf-realm-infra-dev-core-eks-cluster",
                        "Sid": "EKSClusterEndpointLookup",
                    },
                    {
                        "Action": "iam:CreateInstanceProfile",
                        "Condition": {
                            "StringEquals": {
                                "aws:RequestTag/kubernetes.io/cluster/addf-realm-infra-dev-core-eks-cluster": "owned",
                                "aws:RequestTag/topology.kubernetes.io/region": "eu-central-1",
                            },
                            "StringLike": {
                                "aws:RequestTag/karpenter.k8s.aws/ec2nodeclass": "*"
                            },
                        },
                        "Effect": "Allow",
                        "Resource": "*",
                        "Sid": "AllowScopedInstanceProfileCreationActions",
                    },
                    {
                        "Action": "iam:TagInstanceProfile",
                        "Condition": {
                            "StringEquals": {
                                "aws:ResourceTag/kubernetes.io/cluster/addf-realm-infra-dev-core-eks-cluster": "owned",
                                "aws:ResourceTag/topology.kubernetes.io/region": "eu-central-1",
                                "aws:RequestTag/kubernetes.io/cluster/addf-realm-infra-dev-core-eks-cluster": "owned",
                                "aws:RequestTag/topology.kubernetes.io/region": "eu-central-1",
                            },
                            "StringLike": {
                                "aws:ResourceTag/karpenter.k8s.aws/ec2nodeclass": "*",
                                "aws:RequestTag/karpenter.k8s.aws/ec2nodeclass": "*",
                            },
                        },
                        "Effect": "Allow",
                        "Resource": "*",
                        "Sid": "AllowScopedInstanceProfileTagActions",
                    },
                    {
                        "Action": [
                            "iam:AddRoleToInstanceProfile",
                            "iam:RemoveRoleFromInstanceProfile",
                            "iam:DeleteInstanceProfile",
                        ],
                        "Condition": {
                            "StringEquals": {
                                "aws:ResourceTag/kubernetes.io/cluster/addf-realm-infra-dev-core-eks-cluster": "owned",
                                "aws:ResourceTag/topology.kubernetes.io/region": "eu-central-1",
                            },
                            "StringLike": {
                                "aws:ResourceTag/karpenter.k8s.aws/ec2nodeclass": "*"
                            },
                        },
                        "Effect": "Allow",
                        "Resource": "*",
                        "Sid": "AllowScopedInstanceProfileActions",
                    },
                    {
                        "Action": "iam:GetInstanceProfile",
                        "Effect": "Allow",
                        "Resource": "*",
                        "Sid": "AllowInstanceProfileReadActions",
                    },
                ],
                "Version": "2012-10-17",
            },
        },
    )


def test_ssm_metadata_parameter_created() -> None:
    """Test if the SSM Parameter is created"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::SSM::Parameter",
        {
            "Name": "/raas-infra/eks-karpenter",
        },
    )


def test_node_role_is_created() -> None:
    """Test if node role is created"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the nodes managed by Karpenter.",
            "RoleName": "KarpenterNodeRole-addf-realm-infra-dev-core-eks-cluster",
            "Tags": _expected_stack_tags(),
        },
    )


# We need 3 Roles for the whole stack: Controller, Node and a separate role for
# lambda executing kubernetes commands for CDK in the background.
def test_number_of_roles_created() -> None:
    """Test if correct number of roles for Karpenter is created"""
    template = stack_template()
    template.resource_count_is("AWS::IAM::Role", 3)

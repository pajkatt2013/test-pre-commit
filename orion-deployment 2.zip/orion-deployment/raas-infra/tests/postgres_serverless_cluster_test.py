#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test the postgres RDS cluster stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "postgres-serverless-clusters"


def get_app(sandbox_name: str | None = None) -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())

    if sandbox_name is not None:
        app.node.set_context("SANDBOX_NAME", sandbox_name)

    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template(
    cluster_name: str | None = None,
    sandbox_name: str | None = None,
    *,
    expecting_atleast_one_stack: bool = True,
) -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app(sandbox_name)
    if cluster_name is not None:
        app.node.set_context("CLUSTER_NAMES", cluster_name)
    stacks = configure_app(app, param_store=MockParameterStore())
    if expecting_atleast_one_stack is True:
        stack = stacks[0]
        assert stack.stack_param.deployment.module_name == get_module_name()
        return Template.from_stack(stack)
    if len(stacks) > 0:
        return stacks[0]
    return None


def _expected_stack_tags(
    cluster_name: str, sandbox_name: str | None = None
) -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": (
                f"addf-postgres-{sandbox_name}-{cluster_name}"
                if sandbox_name is not None
                else f"addf-core-infra-dev-postgres-serverless-clusters-{cluster_name}"
            ),
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_skip_cluster() -> None:
    """Validate if skip configured for cluster is ignored during deployment."""
    template = stack_template(
        "skip_cluster_deployment", expecting_atleast_one_stack=False
    )
    assert template is None


def test_argo_workflow_archive_cluster_in_stack() -> None:
    """Test for expected cluster with properties in the stack"""
    template = stack_template("argo-wf-archive")
    template.has_resource_properties(
        "AWS::RDS::DBCluster",
        {
            "DBClusterIdentifier": "addf-core-infra-dev-argo-wf-archive",
            "DBClusterParameterGroupName": "default.aurora-postgresql13",
            "DeletionProtection": True,
            "EnableIAMDatabaseAuthentication": True,
            "Engine": "aurora-postgresql",
            "EngineVersion": "13.10",
            "MasterUsername": "admin",
            "Port": 5432,
            "StorageEncrypted": True,
            "Tags": _expected_stack_tags("argo-wf-archive"),
        },
    )


def test_argo_workflow_archive_instance_with_tags_in_stack() -> None:
    """Test for expected rds db instance with properties in the stack"""
    template = stack_template("argo-wf-archive")
    template.has_resource_properties(
        "AWS::RDS::DBInstance",
        {
            "PubliclyAccessible": False,
            "AllowMajorVersionUpgrade": True,
            "DBInstanceClass": "db.serverless",
            "DBInstanceIdentifier": "addf-core-infra-dev-argo-wf-archive-wrt-instance",
            "DBParameterGroupName": "default.aurora-postgresql13",
            "EnablePerformanceInsights": True,
            "Engine": "aurora-postgresql",
            "MonitoringInterval": 60,
            "PerformanceInsightsRetentionPeriod": 7,
            "Tags": _expected_stack_tags("argo-wf-archive"),
        },
    )

    template.has_resource_properties(
        "AWS::RDS::DBInstance",
        {
            "PubliclyAccessible": False,
            "AllowMajorVersionUpgrade": True,
            "DBInstanceClass": "db.serverless",
            "DBInstanceIdentifier": "addf-core-infra-dev-argo-wf-archive-rdr-instance",
            "DBParameterGroupName": "default.aurora-postgresql13",
            "EnablePerformanceInsights": True,
            "Engine": "aurora-postgresql",
            "MonitoringInterval": 60,
            "PerformanceInsightsRetentionPeriod": 7,
            "Tags": _expected_stack_tags("argo-wf-archive"),
        },
    )


def test_argo_workflow_archive_lambda_init_scripts_execution_with_tags_in_stack() -> (
    None
):
    """Test for expected init scripts execution lambda function with properties."""
    template = stack_template("argo-wf-archive")
    template.has_resource_properties(
        "AWS::Lambda::Function",
        {
            "Description": (
                "This trigger function is responsible to run the RaaS"
                " argo-wf-archive postgres scripts"
            ),
            "Handler": "postgres_client.handler",
            "Runtime": "python3.10",
            "Tags": _expected_stack_tags("argo-wf-archive"),
            "Timeout": 300,
        },
    )


def test_argo_workflow_archive_roles_with_tags_in_stack() -> None:
    """Test for expected roles with properties in the stack"""
    template = stack_template("argo-wf-archive")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {"Tags": _expected_stack_tags("argo-wf-archive")},
    )


def test_argo_workflow_archive_sandbox_lambda_init_scripts_execution_with_tags_in_stack() -> (
    None
):
    """Test for expected init scripts execution lambda function with properties."""
    template = stack_template("argo-wf-archive", "mysandbox")
    template.resource_properties_count_is(
        "AWS::Lambda::Function",
        {
            "Description": (
                "This trigger function is responsible to run the RaaS"
                " argo-wf-archive postgres scripts"
            ),
            "Handler": "postgres_client.handler",
            "Runtime": "python3.10",
            "Tags": _expected_stack_tags("argo-wf-archive", "mysandbox"),
            "Timeout": 300,
        },
        1,
    )


def test_rds_db_instance_with_tags_in_stack_for_sandbox() -> None:
    """Test for not expected rds db instance with properties for sandbox."""
    template = stack_template("argo-wf-archive", "mysandbox")
    template.resource_count_is(
        "AWS::RDS::DBInstance",
        0,
    )
    template.resource_count_is(
        "AWS::RDS::DBCluster",
        0,
    )

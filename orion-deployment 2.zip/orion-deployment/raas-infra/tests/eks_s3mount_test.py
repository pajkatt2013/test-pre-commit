#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test EKS S3 mount stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "eks-s3mount"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def get_stack(index: int = 0) -> cdk.Stack:
    """Return the stack"""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[index]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return stack


def stack_template(index: int = 0) -> Template:
    """Return the template generated from stack for assertion"""
    stack = get_stack(index)
    return Template.from_stack(stack)


def _expected_stack_tags() -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": "addf-core-infra-dev-eks-s3mount",
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_skip_module() -> None:
    """Test whether skipping a module on deployment level works."""
    app = get_app()
    app.node.set_context(
        "deployment",
        {
            "skipModules": ["eks-s3mount"],
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    stack = configure_app(app, param_store=MockParameterStore())
    assert len(stack) == 1


def test_helmchart_in_stack() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template(1)
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "raas-eks-s3mount",
            "Namespace": "raas-eks-s3mount",
            "Values": '{"aws-mountpoint-s3-csi-driver":{"image":{"repository":"public.ecr.aws/mountpoint-s3-csi-driver/aws-mountpoint-s3-csi-driver","pullPolicy":"IfNotPresent"},"node":{"serviceAccount":{"create":true,"name":"raas-s3mount-driver-sa","annotations":{"eks.amazonaws.com/role-arn":"arn:aws:iam::1234321:role/addf-core-infra-dev-eks-s3mount-Role"}},"create":true,"tolerateAllTaints":true},"readWriteVolumeOptions":["allow-overwrite","allow-delete","debug","debug-crt"],"readOnlyVolumeOptions":["debug","debug-crt","read-only"],"cacheableReadOnlyVolumeOptions":[],"readWriteVolumes":[{"name":"orion-raasv1-dev-asf-high-reprocessed","bucket":"orion-raasv1-dev-asf-high-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-asf-high-reprocessed"},{"name":"orion-raasv1-dev-asf-mid-reprocessed","bucket":"orion-raasv1-dev-asf-mid-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-asf-mid-reprocessed"},{"name":"orion-raasv1-dev-cp60-reprocessed","bucket":"orion-raasv1-dev-cp60-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-cp60-reprocessed"},{"name":"orion-raasv1-dev-cv-buy-reprocessed","bucket":"orion-raasv1-dev-cv-buy-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-cv-buy-reprocessed"},{"name":"orion-raasv1-dev-fasinfo-reprocessed","bucket":"orion-raasv1-dev-fasinfo-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-fasinfo-reprocessed"},{"name":"orion-raasv1-dev-ksbasis-reprocessed","bucket":"orion-raasv1-dev-ksbasis-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-ksbasis-reprocessed"},{"name":"orion-raasv1-dev-l2-high-reprocessed","bucket":"orion-raasv1-dev-l2-high-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-l2-high-reprocessed"},{"name":"orion-raasv1-dev-l2-mid-reprocessed","bucket":"orion-raasv1-dev-l2-mid-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-l2-mid-reprocessed"},{"name":"orion-raasv1-dev-l2p-basic-high-reprocessed","bucket":"orion-raasv1-dev-l2p-basic-high-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-l2p-basic-high-reprocessed"},{"name":"orion-raasv1-dev-l2p-basic-mid-reprocessed","bucket":"orion-raasv1-dev-l2p-basic-mid-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-l2p-basic-mid-reprocessed"},{"name":"orion-raasv1-dev-l2p-hoo-high-reprocessed","bucket":"orion-raasv1-dev-l2p-hoo-high-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-l2p-hoo-high-reprocessed"},{"name":"orion-raasv1-dev-l2p-hoo-mid-reprocessed","bucket":"orion-raasv1-dev-l2p-hoo-mid-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-l2p-hoo-mid-reprocessed"},{"name":"orion-raasv1-dev-l2p-ucc-mid-reprocessed","bucket":"orion-raasv1-dev-l2p-ucc-mid-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-l2p-ucc-mid-reprocessed"},{"name":"orion-raasv1-dev-llp-reprocessed","bucket":"orion-raasv1-dev-llp-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-llp-reprocessed"},{"name":"orion-raasv1-dev-rcw-reprocessed","bucket":"orion-raasv1-dev-rcw-reprocessed","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-raasv1-dev-rcw-reprocessed"},{"name":"addf-core-infra-dev-s3mount-workflows","bucket":"addf-core-infra-dev-s3mount-workflows-1234321","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"addf-core-infra-dev-s3mount-workflows"}],"readOnlyVolumes":[{"name":"orion-collecteddatav1-dev-asf-high-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-asf-high-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-asf-high-collected"},{"name":"orion-collecteddatav1-dev-asf-mid-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-asf-mid-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-asf-mid-collected"},{"name":"orion-collecteddatav1-dev-cp60-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-cp60-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-cp60-collected"},{"name":"orion-collecteddatav1-dev-cv-buy-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-cv-buy-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-cv-buy-collected"},{"name":"orion-collecteddatav1-dev-kspbasis-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-kspbasis-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-kspbasis-collected"},{"name":"orion-collecteddatav1-dev-l2-high-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-l2-high-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-l2-high-collected"},{"name":"orion-collecteddatav1-dev-l2-mid-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-l2-mid-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-l2-mid-collected"},{"name":"orion-collecteddatav1-dev-l2p-basic-high-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-l2p-basic-high-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-l2p-basic-high-collected"},{"name":"orion-collecteddatav1-dev-l2p-basic-mid-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-l2p-basic-mid-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-l2p-basic-mid-collected"},{"name":"orion-collecteddatav1-dev-l2p-hoo-high-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-l2p-hoo-high-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-l2p-hoo-high-collected"},{"name":"orion-collecteddatav1-dev-l2p-hoo-mid-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-l2p-hoo-mid-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-l2p-hoo-mid-collected"},{"name":"orion-collecteddatav1-dev-l2p-ucc-mid-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-l2p-ucc-mid-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-l2p-ucc-mid-collected"},{"name":"orion-collecteddatav1-dev-llp-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-llp-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-llp-collected"},{"name":"orion-collecteddatav1-dev-rcw-collected","bucket":"arn:aws:s3:eu-central-1:960828897031:accesspoint/orion-dev-rcw-collected-orion","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-collecteddatav1-dev-rcw-collected"}],"cacheableReadOnlyVolumes":[{"name":"orion-dev-map-input-data","bucket":"arn:aws:s3:::realm-infra-123456789-map-data","storageCapacity":"1200Gi","claimStorageRequest":"1000Gi","claimNamespace":"raas-pipeline","claimName":"orion-dev-map-input-data"}],"sidecars":{"nodeDriverRegistrar":{"image":{"tag":"testversion"}}}}}',
        },
    )


def test_s3mount_driver_sa_role_in_stack() -> None:
    """Test for expected eks s3 mount driver sa role with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by EKS - S3 Mount CSI Driver.",
            "RoleName": "addf-core-infra-dev-eks-s3mount-Role",
            "Tags": _expected_stack_tags(),
        },
    )


def test_argo_workflow_values_from_dict() -> None:
    """Validate if the cdk context argo workflow helm chart values are considered."""
    stack = get_stack(0)
    assert (
        stack.stack_param.helm_chart.helm_chart.values_dict[
            "aws-mountpoint-s3-csi-driver"
        ]["sidecars"]["nodeDriverRegistrar"]["image"]["tag"]
        == "testversion"
    )

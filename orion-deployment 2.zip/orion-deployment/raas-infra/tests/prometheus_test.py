#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test prometheus stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "prometheus"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template() -> Template:
    """Return the template generated from stack for assertion."""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[0]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return Template.from_stack(stack)


def _expected_stack_tags() -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": "addf-core-infra-dev-prometheus",
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_helmchart_in_stack() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "prometheus",
            "Namespace": "prometheus",
        },
    )


def test_prometheus_sa_role_in_stack() -> None:
    """Test for expected prometheus sa role with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Prometheus.",
            "RoleName": "RaasPrometheusServiceAccountRole",
            "Tags": _expected_stack_tags(),
        },
    )


def test_prometheus_log_group_in_stack() -> None:
    """Test for expected prometheus log group with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Logs::LogGroup",
        {
            "LogGroupName": "addf-core-infra-dev-prometheus-logs",
            "RetentionInDays": 731,
            "Tags": _expected_stack_tags(),
        },
    )


def test_prometheus_workspace_in_stack() -> None:
    """Test for expected prometheus workspace with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::APS::Workspace",
        {
            "Alias": "addf-core-infra-dev-prometheus",
            "Tags": _expected_stack_tags(),
        },
    )

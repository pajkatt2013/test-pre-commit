#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test Argo prerequisites stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import get_app_context, set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "argo-prerequesites"


def get_app(sandbox_name: str | None = None) -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())

    if sandbox_name is not None:
        app.node.set_context("SANDBOX_NAME", sandbox_name)

    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def test_application_namespaces_set_in_helm_chart() -> None:
    """
    Test the application namespaces in the local.env file are considered.

    This is observed while passing them as parameters to helm chart.
    """
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[0]
    actual_app_namespaces = stack.stack_param.helm_chart.values_dict["workflow"][
        "namespaces"
    ]
    app_context = get_app_context()
    expected_raas_pipeline_namespace = app_context["argo"]["prerequisites"][
        "raasPipelineNamespace"
    ]
    assert expected_raas_pipeline_namespace in actual_app_namespaces


def test_sandbox_application_namespaces_set_in_helm_chart() -> None:
    """
    Test the application namespaces in the local.env file are considered for sandboxes.

    This is observed while passing them as parameters to helm chart.
    """
    app = get_app("mysandbox")
    stack = configure_app(app, param_store=MockParameterStore())[0]
    actual_app_namespaces = ",".join(
        stack.stack_param.helm_chart.values_dict["workflow"]["namespaces"]
    )
    app_context = get_app_context()
    expected_raas_pipeline_namespace = app_context["argo"]["prerequisites"][
        "raasPipelineNamespace"
    ]
    expected_raas_pipeline_namespace = f"{expected_raas_pipeline_namespace}-mysandbox"
    assert expected_raas_pipeline_namespace in actual_app_namespaces


def _expected_stack_tags(sandbox_name: str | None) -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": (
                f"addf-core-infra-dev-{sandbox_name}-argo-prerequesites"
                if sandbox_name is not None
                else "addf-core-infra-dev-argo-prerequesites"
            ),
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def stack_template(sandbox_name: str | None = None) -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app(sandbox_name)
    stack = configure_app(app, param_store=MockParameterStore())[0]
    assert stack.stack_param.deployment.module_name == get_module_name()
    template = Template.from_stack(stack)

    template.has_resource_properties(
        "AWS::CloudFormation::Stack",
        {"Tags": _expected_stack_tags(sandbox_name)},
    )
    return template


def test_helmchart_in_stack() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "raas-argo-prerequisites",
            "Namespace": "default",
        },
    )


def test_helmchart_in_stack_for_sandbox() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template("mysandbox")
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "raas-argo-prerequisites-mysandbox",
            "Namespace": "default",
        },
    )

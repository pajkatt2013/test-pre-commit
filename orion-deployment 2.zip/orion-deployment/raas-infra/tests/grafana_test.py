#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test Grafana stack contents."""

import json
import os
from pathlib import Path
from typing import Any

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "grafana"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template() -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[0]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return Template.from_stack(stack)


def _expected_stack_tags() -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {"Key": "Deployment", "Value": "addf-core-infra-dev-grafana"},
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_grafana_sa_role_in_stack() -> None:
    """Test for expected grafana sa role with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Grafana.",
            "RoleName": "RaasGrafanaServiceAccountRole",
            "Tags": _expected_stack_tags(),
        },
    )


def test_grafana_workspace_in_stack() -> None:
    """Test for expected grafana workspace with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Grafana::Workspace",
        {
            "AccountAccessType": "CURRENT_ACCOUNT",
            "AuthenticationProviders": ["AWS_SSO"],
            "DataSources": ["PROMETHEUS"],
            "Description": "This workspace contains dashboards required for RaaS.",
            "Name": "addf-core-infra-dev-grafana",
            "PermissionType": "SERVICE_MANAGED",
        },
    )


def validate_grafana_dashboards_and_datasources(name: str) -> None:
    """
    Scan through the grafana dashboards and datasource files for inconsistencies.

    For the name, identify if there are any datasources used in the dashboards but the
    datasource definition is missing in the datasources folder.
    The Datasource is identified uniquely based on 'type' and 'uid'.
    """
    current_directory = Path(__file__).parent.resolve()
    grafana_directory = (
        current_directory
        / ".."
        / "src"
        / "raas_infra"
        / "constructs"
        / "lambdas"
        / "grafana"
        / name
    )

    datasource_folder_path = grafana_directory / "datasources"
    datasource_files = os.listdir(str(datasource_folder_path))

    dashboard_folder_path = grafana_directory / "dashboards"
    dashboard_files = os.listdir(str(dashboard_folder_path))

    datasources = []

    # adding grafana as a valid datasource
    datasources.append({"type": "datasource", "name": "grafana", "uid": "grafana"})

    # identifying list of datasources as base and considering as valid
    for datasource_file in datasource_files:
        with (datasource_folder_path / datasource_file).open() as fp:
            contents = fp.read()
            datasource_dict = json.loads(contents)
            datasources.append(
                {
                    "type": datasource_dict["type"],
                    "name": datasource_dict["name"],
                    "uid": datasource_dict["uid"],
                }
            )

    dashboards = {}
    # identifying the list of dashboards with datasources referenced
    for dashboard_file in dashboard_files:
        with (dashboard_folder_path / dashboard_file).open() as fp:
            contents = fp.read()
            dashboards_dict = json.loads(contents)
            dashboard_datasources: Any = []
            iterate_read_datasources(dashboards_dict, dashboard_datasources)
            dashboards[dashboard_file] = dashboard_datasources

    # identifying the list of datasources in the dashboards but which are not identified
    # as valid
    invalid_dashboard_datasources = []
    for dashboard_file in dashboards:
        dashboard_datasources = dashboards[dashboard_file]
        for dashboard_datasource in dashboard_datasources:
            valid_datasources = list(
                filter(
                    lambda x: x["type"] == dashboard_datasource["type"]
                    and x["uid"] == dashboard_datasource["uid"],
                    datasources,
                )
            )
            if len(valid_datasources) == 0:
                ds_type = dashboard_datasource["type"]
                ds_uid = dashboard_datasource["uid"]
                print(
                    "Found invalid data source reference in"
                    f" dashboard file : {dashboard_file}. Invalid"
                    f" data source -> type : {ds_type}, uid :"
                    f" {ds_uid}"
                )
                invalid_dashboard_datasources.append(
                    {
                        "type": dashboard_datasource["type"],
                        "uid": dashboard_datasource["uid"],
                        "dashboard_file": dashboard_file,
                    }
                )

    print(
        "Valid datasource's referring to files under the datasource"
        f" folder : {datasource_folder_path}"
    )
    print(datasources)
    assert len(invalid_dashboard_datasources) == 0


def iterate_read_datasources(
    dashboards_dict: Any,  # noqa: ANN401 # TODO(Marco): unclear data structure, author needs to provide types
    dashboard_datasources: Any,  # noqa: ANN401 # TODO(Marco): unclear data structure, author needs to provide types
) -> None:
    """Iterate through the dashboard dictionary and identify the datasource's used"""
    if isinstance(dashboards_dict, dict):
        for key in dashboards_dict:
            if key != "annotations":
                value = dashboards_dict[key]
                if isinstance(value, dict):
                    if key == "datasource":
                        dashboard_datasources.append(
                            {
                                "type": value["type"],
                                "uid": value["uid"],
                            }
                        )
                    else:
                        iterate_read_datasources(value, dashboard_datasources)

                if isinstance(value, list):
                    for item in value:
                        iterate_read_datasources(item, dashboard_datasources)


def test_grafana_raas_dashboards_and_datasources() -> None:
    """Test to validate the raas grafana resources are valid"""
    validate_grafana_dashboards_and_datasources("raas")

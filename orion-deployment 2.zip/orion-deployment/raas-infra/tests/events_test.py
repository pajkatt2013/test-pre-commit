#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test Argo events stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "argo-events"


def get_app(sandbox_name: str | None = None) -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())

    if sandbox_name is not None:
        app.node.set_context("SANDBOX_NAME", sandbox_name)

    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def get_stack(index: int = 0, sandbox_name: str | None = None) -> cdk.Stack:
    """Return the stack"""
    app = get_app(sandbox_name)
    stack = configure_app(app, param_store=MockParameterStore())[index]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return stack


def stack_template(index: int = 0, sandbox_name: str | None = None) -> Template:
    """Return the template generated from stack for assertion"""
    stack = get_stack(index=index, sandbox_name=sandbox_name)
    return Template.from_stack(stack)


def test_argo_events_values_from_dict() -> None:
    """Validate if the cdk context argo events helm chart values are considered."""
    stack = get_stack(0)
    assert (
        stack.stack_param.helm_chart.helm_chart.values_dict["argo-events"]["global"][
            "image"
        ]["pullPolicy"]
        == "Always"
    )


def _expected_stack_tags(sandbox_name: str | None = None) -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": (
                f"addf-core-infra-dev-{sandbox_name}-argo-events"
                if sandbox_name is not None
                else "addf-core-infra-dev-argo-events"
            ),
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_sqs_job_trigger_in_stack() -> None:
    """Test for expected job event sqs with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags(),
            "QueueName": "addf-core-infra-dev-argo-events-job-trigger",
        },
    )

    template.has_resource_properties(
        "AWS::SQS::QueuePolicy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:SendMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                        ],
                        "Effect": "Allow",
                        "Principal": {"Service": "events.amazonaws.com"},
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevargoeventsjobtrigger",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "Queues": ["addf-core-infra-dev-argo-events-job-trigger"],
        },
    )


def test_sqs_job_trigger_in_stack_for_sandbox() -> None:
    """Test for expected job event sqs with properties in the stack"""
    template = stack_template(sandbox_name="mysandbox")
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags("mysandbox"),
            "QueueName": "addf-core-infra-dev-mysandbox-argo-events-job-trigger",
        },
    )

    template.resource_properties_count_is(
        "AWS::SQS::Queue",
        {"QueueName": "addf-core-infra-dev-argo-events-job-trigger"},
        0,
    )

    template.has_resource_properties(
        "AWS::SQS::QueuePolicy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:SendMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                        ],
                        "Effect": "Allow",
                        "Principal": {"Service": "events.amazonaws.com"},
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevmysandboxargoeventsjobtrigger",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "Queues": ["addf-core-infra-dev-mysandbox-argo-events-job-trigger"],
        },
    )


def test_sqs_file_metadata_trigger_in_stack() -> None:
    """Test for expected job event sqs with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags(),
            "QueueName": "addf-core-infra-dev-argo-events-file-metadata-trigger",
        },
    )

    template.has_resource_properties(
        "AWS::SQS::QueuePolicy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:SendMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                        ],
                        "Effect": "Allow",
                        "Principal": {"Service": "events.amazonaws.com"},
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevargoeventsfilemetadatatrigger",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "Queues": ["addf-core-infra-dev-argo-events-file-metadata-trigger"],
        },
    )


def test_sqs_session_metadata_trigger_in_stack() -> None:
    """Test for expected job event sqs with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags(),
            "QueueName": "addf-core-infra-dev-argo-events-session-metadata-trigger",
        },
    )

    template.has_resource_properties(
        "AWS::SQS::QueuePolicy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:SendMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                        ],
                        "Effect": "Allow",
                        "Principal": {"Service": "events.amazonaws.com"},
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevargoeventssessionmetadatatrigger",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "Queues": ["addf-core-infra-dev-argo-events-session-metadata-trigger"],
        },
    )


def test_sqs_map_metadata_trigger_in_stack() -> None:
    """Test for expected job event sqs with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags(),
            "QueueName": "addf-core-infra-dev-argo-events-map-metadata-trigger",
        },
    )

    template.has_resource_properties(
        "AWS::SQS::QueuePolicy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:SendMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                        ],
                        "Effect": "Allow",
                        "Principal": {"Service": "events.amazonaws.com"},
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevargoeventsmapmetadatatrigger",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "Queues": ["addf-core-infra-dev-argo-events-map-metadata-trigger"],
        },
    )


def test_helmchart_in_stack() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template(1)
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "raas-argo-events",
            "Namespace": "raas-argo-events",
        },
    )


def test_helmchart_in_stack_for_sandbox() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template(1, sandbox_name="mysandbox")
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "raas-argo-events-mysandbox",
            "Namespace": "raas-argo-events",
        },
    )


def test_argo_events_eventsource_sa_role_in_stack() -> None:
    """Test for expected argo workflow sa role with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": (
                "Role used by RaaS Argo Workflows SQS Event Source to"
                " subscribe to messages from  Trigger Queue."
            ),
            "RoleName": "addf-core-infra-dev-argo-events-sqstrg-sub-role",
            "Tags": _expected_stack_tags(),
        },
    )


def test_argo_events_session_metadata_sqs_has_eventbridge_rule() -> None:
    """Test for session metadata rule to consume the oao ingest session events"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Events::Rule",
        {
            "Description": (
                "This rule is responsible to route oao ingest session"
                " events to the raas session etl metadata sqs queue."
            ),
            "EventBusName": "realm-infra-dev-dev-eu-central-1-realm-bus",
            "EventPattern": {"detail-type": ["ingest-session-completed"]},
            "Name": "addf-core-infra-dev-argo-events-session-metadata",
            "State": "ENABLED",
        },
    )


def test_argo_events_file_metadata_sqs_has_eventbridge_rule() -> None:
    """Test for file metadata rule to consume the oao ingest session events"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Events::Rule",
        {
            "Description": (
                "This rule is responsible to route oao ingest session"
                " events to the raas file etl metadata sqs queue."
            ),
            "EventBusName": "realm-infra-dev-dev-eu-central-1-realm-bus",
            "EventPattern": {"detail-type": ["ingest-session-completed"]},
            "Name": "addf-core-infra-dev-argo-events-file-metadata",
            "State": "ENABLED",
        },
    )


def test_argo_events_sa_role_in_stack_for_sandbox() -> None:
    """Test for expected argo events sa role with properties in the stack"""
    template = stack_template(sandbox_name="mysandbox")
    template.resource_properties_count_is(
        "AWS::IAM::Role",
        {
            "Description": (
                "Role used by RaaS Argo Workflows SQS Event Source to"
                " subscribe to messages from  Trigger Queue."
            ),
        },
        0,
    )

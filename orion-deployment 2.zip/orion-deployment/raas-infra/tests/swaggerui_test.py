#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test the hosted Swagger UI site against a mocked API GW."""

import json
import os
from io import BytesIO

import boto3
import pytest
import pytest_mock
from botocore.response import StreamingBody
from botocore.stub import Stubber
from bottle import request
from webob.cachecontrol import CacheControl
from webtest import TestApp, TestResponse

from raas_infra.constructs.lambdas.swagger import swaggerui


def test_exposed_openapi_specs_does_not_include_method_at_root(
    mocker: pytest_mock.MockerFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Check whether the API GW does not expose api-docs on root."""
    apigateway = boto3.client("apigateway", region_name="eu-central-1")
    stubber = get_stubber(apigateway, monkeypatch)
    with mocker.patch("boto3.client", return_value=apigateway), stubber:
        response = swaggerui.expose_swagger_definition()
        assert '"paths": {}, "servers": [{"url": "example.com"}]' in response


def test_authz(
    mocker: pytest_mock.MockerFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Check whether the API GW does not expose api-docs on root."""
    apigateway = boto3.client("apigateway", region_name="eu-central-1")
    stubber = get_stubber(apigateway, monkeypatch)

    with mocker.patch("boto3.client", return_value=apigateway), stubber:
        os.environ["KEYCLOAK_URL"] = "test_url"
        os.environ["KEYCLOAK_CLIENT_ID"] = "test_client_id"
        response = json.loads(swaggerui.expose_swagger_definition())
        assert (
            response["components"]["securitySchemes"]["keycloakAuth"]["type"]
            == "oauth2"
        )

        assert response["security"] == [{"keycloakAuth": []}]


def get_stubber(
    apigateway: boto3.session.Session, monkeypatch: pytest.MonkeyPatch
) -> Stubber:
    """Get stubber"""
    stubber = Stubber(apigateway)
    mock_api_id = "apiId"
    mock_api_stage = "apiStage"
    api_export_response = (
        b'{"paths": {"/": {"get": {"responses": {"200": {"description": "200'
        b' response"}}}}}}'
    )
    stubber.add_response(
        "get_export",
        {"body": StreamingBody(BytesIO(api_export_response), len(api_export_response))},
        expected_params={
            "restApiId": mock_api_id,
            "stageName": mock_api_stage,
            "exportType": "oas30",
            "parameters": {"extensions": "integrations"},
            "accepts": "application/json",
        },
    )
    monkeypatch.setitem(
        request.environ,
        "awsgi.event",
        {
            "requestContext": {"apiId": mock_api_id, "stage": mock_api_stage},
            "headers": {"referer": "example.com"},
        },
    )
    return stubber


@pytest.mark.parametrize(
    ("path", "expected_cache_control"),
    [
        ("/", "public, max-age=1800, immutable"),
        ("/static/swagger.css", "public, max-age=1800, immutable"),
        ("/static/index.css", "public, max-age=1800, immutable"),
        ("/static/swagger-ui-bundle.js", "public, max-age=1800, immutable"),
    ],
)
def test_all_responses_cached(
    path: str,  # noqa: ARG001 # TODO(Marco): this fails if path is used instead of /
    expected_cache_control: str,
) -> None:
    """Test cache control for Swagger assets."""
    app = TestApp(swaggerui.app)
    response: TestResponse = app.get("/")
    cache_control = CacheControl.parse(expected_cache_control)
    assert response.cache_control.public == cache_control.public
    assert response.cache_control.max_age == cache_control.max_age


def test_mulivalue_query_params_are_array_schema(
    mocker: pytest_mock.MockerFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Test multi-valued params are mapped to array schema."""
    apigateway = boto3.client("apigateway", region_name="eu-central-1")
    stubber = Stubber(apigateway)
    mock_api_id = "apiId"
    mock_api_stage = "apiStage"
    api_export_response = (
        b'{"paths": {"/test": {"get": {"parameters": '
        b'[{"name": "testParam", "schema": {"type": "string"}}] '
        b', "x-amazon-apigateway-integration": {"requestParameters": {'
        b'"integration.request.querystring.testParam": '
        b'"method.request.multivaluequerystring.testParam"'
        b"}}}}}}"
    )
    stubber.add_response(
        "get_export",
        {"body": StreamingBody(BytesIO(api_export_response), len(api_export_response))},
        expected_params={
            "restApiId": mock_api_id,
            "stageName": mock_api_stage,
            "exportType": "oas30",
            "parameters": {"extensions": "integrations"},
            "accepts": "application/json",
        },
    )
    monkeypatch.setitem(
        request.environ,
        "awsgi.event",
        {
            "requestContext": {"apiId": mock_api_id, "stage": mock_api_stage},
            "headers": {"referer": "example.com"},
        },
    )

    with mocker.patch("boto3.client", return_value=apigateway), stubber:
        response = json.loads(swaggerui.expose_swagger_definition())
        assert any(
            parameter
            for parameter in response.get("paths", {})
            .get("/test", {})
            .get("get", {})
            .get("parameters", [])
            if parameter.get("schema", {}).get("type") == "array"
        )


def test_examples_extension_are_mapped_to_openapi_standard(
    mocker: pytest_mock.MockerFixture,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Test examples temporarily stored in a custom extension are mapped to OpenAPI standard."""
    apigateway = boto3.client("apigateway", region_name="eu-central-1")
    stubber = Stubber(apigateway)
    mock_api_id = "apiId"
    mock_api_stage = "apiStage"
    api_export_response = (
        b'{"paths": {"/test": {"post": {"requestBody": {"content": {"application/json": {}},'
        b'"x-examples": [{"contentType":"application/json", "name": "example1", "description":'
        b'"example description", "value": "test"}]}}}}}'
    )
    stubber.add_response(
        "get_export",
        {"body": StreamingBody(BytesIO(api_export_response), len(api_export_response))},
        expected_params={
            "restApiId": mock_api_id,
            "stageName": mock_api_stage,
            "exportType": "oas30",
            "parameters": {"extensions": "integrations"},
            "accepts": "application/json",
        },
    )
    monkeypatch.setitem(
        request.environ,
        "awsgi.event",
        {
            "requestContext": {"apiId": mock_api_id, "stage": mock_api_stage},
            "headers": {"referer": "example.com"},
        },
    )

    with mocker.patch("boto3.client", return_value=apigateway), stubber:
        response = json.loads(swaggerui.expose_swagger_definition())
        assert any(
            example
            for exampleName, example in response.get("paths", {})
            .get("/test", {})
            .get("post", {})
            .get("requestBody", {})
            .get("content", {})
            .get("application/json", {})
            .get("examples", {})
            .items()
            if exampleName == "example1"
            and example.get("description") == "example description"
        )

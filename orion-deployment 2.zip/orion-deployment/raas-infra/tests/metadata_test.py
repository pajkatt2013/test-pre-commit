#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test ETL metadata stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "etl-metadata"


def get_app(sandbox_name: str | None = None) -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())

    if sandbox_name is not None:
        app.node.set_context("SANDBOX_NAME", sandbox_name)

    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template(sandbox_name: str | None = None) -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app(sandbox_name)
    stack = configure_app(app, param_store=MockParameterStore())[0]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return Template.from_stack(stack)


def _expected_stack_tags(sandbox_name: str | None = None) -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": (
                f"addf-core-infra-dev-{sandbox_name}-etl-metadata"
                if sandbox_name is not None
                else "addf-core-infra-dev-etl-metadata"
            ),
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_role_etl_file_sa_not_in_stack_with_no_workflow_in_ref() -> None:
    """Test for expected role with properties in the stack"""
    app = get_app()
    etl_metadata = app.node.get_context("etl_metadata")
    postgres = etl_metadata["ref"]["postgres"]
    etl_metadata = {
        "ref": {"postgres": postgres},
        "metadataOutputSSMPath": "/qrp-raas-infra/etl-metadata",
    }
    app.node.set_context("etl_metadata", etl_metadata)
    stack = configure_app(app, param_store=MockParameterStore())[0]
    assert stack.stack_param.deployment.module_name == get_module_name()
    template = Template.from_stack(stack)
    template.resource_properties_count_is(
        "AWS::IAM::Role",
        {
            "Description": "Role used for authorizing with RaaS Postgres db.",
            "RoleName": "raas-infra-dev-argo-workflows-etl-file-servicerole",
            "Tags": _expected_stack_tags(),
        },
        0,
    )


def test_sg_with_tags_in_stack() -> None:
    """Test for expected sg with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::EC2::SecurityGroup", {"Tags": _expected_stack_tags()}
    )


def test_roles_with_tags_in_stack() -> None:
    """Test for expected roles with properties in the stack"""
    template = stack_template()
    template.has_resource_properties("AWS::IAM::Role", {"Tags": _expected_stack_tags()})


def test_bastion_host_with_tags_in_stack() -> None:
    """Test for expected bastion host ec2 instances with properties in the stack"""
    template = stack_template()
    tags = _expected_stack_tags()
    tags = tags[0:3]
    tags.append({"Key": "Name", "Value": "raas-bastion-host"})
    tags.append({"Key": "system", "Value": "raas"})
    tags.append({"Key": "task", "Value": "infra"})
    template.has_resource_properties("AWS::EC2::Instance", {"Tags": tags})


def test_rds_db_cluster_with_tags_in_stack() -> None:
    """Test for expected rds db cluster with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::RDS::DBCluster",
        {
            "DatabaseName": "raas_metadata",
            "DBClusterIdentifier": "addf-core-infra-dev-etl-metadata",
            "DBClusterParameterGroupName": "default.aurora-postgresql13",
            "DeletionProtection": True,
            "EnableIAMDatabaseAuthentication": True,
            "Engine": "aurora-postgresql",
            "EngineVersion": "13.10",
            "MasterUsername": "postgres",
            "Port": 5432,
            "StorageEncrypted": True,
            "Tags": _expected_stack_tags(),
        },
    )


def test_rds_db_instance_with_tags_in_stack() -> None:
    """Test for expected rds db instance with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::RDS::DBInstance",
        {
            "PubliclyAccessible": False,
            "AllowMajorVersionUpgrade": True,
            "DBInstanceClass": "db.serverless",
            "DBInstanceIdentifier": "addf-core-infra-dev-etl-metadata-wrt-instance",
            "DBParameterGroupName": "default.aurora-postgresql13",
            "EnablePerformanceInsights": True,
            "Engine": "aurora-postgresql",
            "MonitoringInterval": 60,
            "PerformanceInsightsRetentionPeriod": 7,
            "Tags": _expected_stack_tags(),
        },
    )

    template.has_resource_properties(
        "AWS::RDS::DBInstance",
        {
            "PubliclyAccessible": False,
            "AllowMajorVersionUpgrade": True,
            "DBInstanceClass": "db.serverless",
            "DBInstanceIdentifier": "addf-core-infra-dev-etl-metadata-rdr-instance",
            "DBParameterGroupName": "default.aurora-postgresql13",
            "EnablePerformanceInsights": True,
            "Engine": "aurora-postgresql",
            "MonitoringInterval": 60,
            "PerformanceInsightsRetentionPeriod": 7,
            "Tags": _expected_stack_tags(),
        },
    )


def test_rds_lambda_init_scripts_execution_with_tags_in_stack() -> None:
    """Test for expected init scripts execution lambda function with properties."""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Lambda::Function",
        {
            "Description": (
                "This trigger function is responsible to run the RaaS"
                " ETLMetadata postgres scripts"
            ),
            "Handler": "postgres_client.handler",
            "Runtime": "python3.10",
            "Tags": _expected_stack_tags(),
            "Timeout": 300,
        },
    )


def test_rds_lambda_init_scripts_execution_with_tags_in_stack_for_sandbox() -> None:
    """Test for expected init scripts execution lambda function with properties."""
    template = stack_template("mysandbox")
    template.has_resource_properties(
        "AWS::Lambda::Function",
        {
            "Description": (
                "This trigger function is responsible to run the RaaS"
                " ETLMetadata postgres scripts"
            ),
            "Handler": "postgres_client.handler",
            "Runtime": "python3.10",
            "Tags": _expected_stack_tags("mysandbox"),
            "Timeout": 300,
        },
    )


def test_rds_db_instance_with_tags_in_stack_for_sandbox() -> None:
    """Test for not expected rds db instance with properties in the stack for sandbox"""
    template = stack_template("mysandbox")
    template.resource_count_is(
        "AWS::RDS::DBInstance",
        0,
    )
    template.resource_count_is(
        "AWS::RDS::DBCluster",
        0,
    )


def test_rds_with_proxy_configured() -> None:
    """Test for expected rds db instance with proxy configured"""
    template = stack_template()

    template.resource_count_is(
        "AWS::RDS::DBProxy",
        1,
    )
    template.has_resource_properties(
        "AWS::RDS::DBProxy",
        {
            "DBProxyName": "proxy-addf-core-infra-dev-etl-metadata",
            "Tags": _expected_stack_tags(),
        },
    )

    template.resource_count_is(
        "AWS::RDS::DBProxyTargetGroup",
        1,
    )
    template.resource_count_is(
        "AWS::RDS::DBProxyEndpoint",
        1,
    )
    template.has_resource_properties(
        "AWS::RDS::DBProxyEndpoint",
        {
            "DBProxyEndpointName": "readonly-proxy-addf-core-infra-dev-etl-metadata",
            "Tags": _expected_stack_tags(),
        },
    )

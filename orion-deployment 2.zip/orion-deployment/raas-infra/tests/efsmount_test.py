#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test Argo EFS mount stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "argo-efsmount"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template() -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[0]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return Template.from_stack(stack)


def _expected_stack_tags() -> list[dict[str, str]]:
    return [
        {
            "Key": "Deployment",
            "Value": "addf-core-infra-dev-argo-efsmount",
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_helmchart_in_stack() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "raas-argo-efsmount",
            "Namespace": "raas-argo-efsmount",
        },
    )


def test_cloud_formation_in_stack() -> None:
    """Test for expected cloud formation stack with properties in the stack"""
    template = stack_template()
    tags = _expected_stack_tags()
    tags.insert(0, {"Key": "customer_function", "Value": "common"})
    template.has_resource_properties("AWS::CloudFormation::Stack", {"Tags": tags})


def test_efs_driver_sa_role_in_stack() -> None:
    """Test for expected efs sa role with properties in the stack"""
    template = stack_template()
    tags = _expected_stack_tags()
    tags.insert(0, {"Key": "customer_function", "Value": "common"})
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": (
                "Role used by EKS - EFS Controller Service account to access EFS."
            ),
            "RoleName": "addf-core-infra-dev-argo-efsmount-Role",
            "Tags": tags,
        },
    )


def test_efs_in_stack_for_each_customer_function() -> None:
    """Test for expected efs with properties in the stack"""
    template = stack_template()
    customer_functions = (
        "qrp-low,qrp-mid,qrp-high,avp5-v0-dev,avp5-v1-val,avp5-v1-dev,common".split(",")
    )
    for customer_function in customer_functions:
        tags = _expected_stack_tags()
        tags = tags[0:2]
        tags.append(
            {
                "Key": "Name",
                "Value": f"addf-core-infra-dev-argo-efsmount/{customer_function}-efs",
            }
        )
        tags.append({"Key": "system", "Value": "raas"})
        tags.append({"Key": "task", "Value": "infra"})
        tags.insert(
            0,
            {"Key": "customer_function", "Value": customer_function},
        )

        template.resource_properties_count_is(
            "AWS::EFS::FileSystem",
            {"Encrypted": True, "FileSystemTags": tags},
            count=1,
        )


def test_if_all_efs_in_stack() -> None:
    """Test for all the efs in stack"""
    template = stack_template()
    template.resource_properties_count_is(
        "AWS::EFS::FileSystem", {"Encrypted": True}, count=7
    )

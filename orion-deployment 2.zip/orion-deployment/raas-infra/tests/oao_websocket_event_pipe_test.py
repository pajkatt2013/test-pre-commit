#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Tests the job OAO event pipe lambda"""

import boto3
import pytest
import pytest_mock
from botocore.stub import Stubber

from raas_infra.constructs.lambdas.job_oao_websocket_pipe.pipe_lambda import handler


def test_job_event_with_connection_notifies_gateway(
    mocker: pytest_mock.MockerFixture, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Test that job event with connection notifies gateway."""
    job_id = "abc"
    connection_id = "123"
    monkeypatch.setenv("TABLE_NAME", "foo")
    dynamodb = boto3.client("dynamodb", region_name="us-east-1")
    apigatewaymanagementapi = boto3.client(
        "apigatewaymanagementapi", region_name="us-east-1"
    )
    db_stub = Stubber(dynamodb)
    api_stub = Stubber(apigatewaymanagementapi)

    db_stub.add_response(
        "query",
        {"Items": [{"connectionId": {"S": connection_id}, "jobId": {"S": job_id}}]},
        expected_params={
            "TableName": "foo",
            "KeyConditionExpression": "jobId = :jobId",
            "ExpressionAttributeValues": {":jobId": {"S": job_id}},
        },
    )

    api_stub.add_response(
        "post_to_connection",
        {},
        expected_params={"ConnectionId": connection_id, "Data": b'{"job-id": "abc"}'},
    )

    db_stub.activate()
    api_stub.activate()

    with mocker.patch("boto3.client", side_effect=[dynamodb, apigatewaymanagementapi]):
        handler([{"payload": {"job-id": job_id}}], {})

    db_stub.assert_no_pending_responses()
    api_stub.assert_no_pending_responses()

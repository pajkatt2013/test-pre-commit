#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test ADOT Collector stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Match, Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "adot-collector"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template() -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[0]
    assert stack.stack_param.deployment.module_name == get_module_name()

    return Template.from_stack(stack)


def _expected_stack_tags() -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": "addf-core-infra-dev-adot-collector",
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_adot_collector_sa_role_in_stack() -> None:
    """Test for expected adot collector sa role with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the ADOT Collector",
            "RoleName": "ADOTCollectorSARoleDefault",
            "Tags": _expected_stack_tags(),
        },
    )


def test_helmchart_in_stack() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "adot-collector",
            "Namespace": "adot-collector",
        },
    )


def test_adot_collector_sa_role_xray_policy_in_stack() -> None:
    """Test for expected XRay policy for SA in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "xray:PutTraceSegments",
                            "xray:PutTelemetryRecords",
                            "xray:GetSamplingRules",
                            "xray:GetSamplingTargets",
                            "xray:GetSamplingStatisticSummaries",
                        ]
                    }
                ]
            },
        },
    )


def test_adot_collector_sns_topic_in_stack() -> None:
    """Test for expected SNS alarm topic in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::SNS::Topic",
        {
            "DisplayName": "raas-service-tracing-alarm-topic",
            "Tags": _expected_stack_tags(),
        },
    )


def test_adot_collector_xray_sampling_rule_in_stack() -> None:
    """Test for expected Xray sampling rule in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::XRay::SamplingRule",
        {
            "SamplingRule": {
                "FixedRate": 0,
                "ReservoirSize": 0,
            },
            "Tags": _expected_stack_tags(),
        },
    )


def test_adot_collector_lambda_rule_adjuster_in_stack() -> None:
    """Test for expected Lambda to update XRay sampling rule in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Lambda::Function",
        {
            "Description": "Adapt Xray sampling rules based on CloudWatch alarms for RaaS services",
            "Tags": _expected_stack_tags(),
        },
    )


def test_adot_collector_lambda_adjuster_update_policy_in_stack() -> None:
    """Test for expected Lambda policy to allow updating XRay rule in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {"Statement": [{"Action": "xray:UpdateSamplingRule"}]},
        },
    )


def test_adot_collector_ssm_alert_topic_name_in_stack() -> None:
    """Test for expected SSM parameter in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::SSM::Parameter",
        {
            "Value": {
                "Fn::Join": [
                    Match.any_value(),
                    Match.array_with(
                        [Match.string_like_regexp(r".*tracing_alert_sns_topic_arn.*")]
                    ),
                ],
            },
        },
    )

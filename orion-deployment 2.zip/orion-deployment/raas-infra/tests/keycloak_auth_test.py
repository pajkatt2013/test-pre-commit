#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#


"""Test the custom authorizer."""

import os
from unittest.mock import MagicMock, patch

from raas_infra.constructs.lambdas.apigateway.keycloak_authorizer import (
    authorize_token,
    fetch_public_key,
)

# Mock environment variables
os.environ["KEYCLOAK_URL"] = "http://mock-keycloak-url"
os.environ["KEYCLOAK_REALM"] = "orionadp"
os.environ["KEYCLOAK_CLIENT_ID"] = "mock-client-id"


def _mock_event(resource: str, path: str, http_method: str) -> dict:
    """Generate the mock request event according to the parameters"""
    return {
        "authorizationToken": "mock-id-token",
        "type": "REQUEST",
        "methodArn": f"arn:aws:execute-api:us-east-1:123456789012:abcdef123/test/{http_method}/{resource}",
        "resource": resource,
        "path": path,
        "httpMethod": http_method,
        "queryStringParameters": {"QueryString1": "queryValue1"},
        "pathParameters": {},
        "stageVariables": {"StageVar1": "stageValue1"},
        "requestContext": {
            "path": path,
            "accountId": "123456789012",
            "resourceId": "05c7jb",
            "stage": "test",
            "requestId": "...",
            "identity": {
                "apiKey": "...",
                "sourceIp": "...",
                "clientCert": {
                    "clientCertPem": "CERT_CONTENT",
                    "subjectDN": "www.example.com",
                    "issuerDN": "Example issuer",
                    "serialNumber": "a1:a1:a1:a1:a1:a1:a1:a1:a1:a1:a1:a1:a1:a1:a1:a1",
                    "validity": {
                        "notBefore": "May 28 12:30:02 2019 GMT",
                        "notAfter": "Aug  5 09:36:04 2021 GMT",
                    },
                },
            },
            "resourcePath": resource,
            "apiId": "abcdef123",
        },
        "headers": {
            "X-AMZ-Date": "20170718T062915Z",
            "Accept": "*/*",
            "User-Agent": "...",
        },
    }


@patch("raas_infra.constructs.lambdas.apigateway.keycloak_authorizer.requests.get")
def test_fetch_public_key(mock_get: MagicMock) -> None:
    """Test for expected public key in PEM format"""
    mock_get.return_value.json.return_value = {"public_key": "mock-public-key"}
    mock_get.return_value.raise_for_status = MagicMock()

    public_key = fetch_public_key()
    assert "-----BEGIN PUBLIC KEY-----" in public_key
    assert "-----END PUBLIC KEY-----" in public_key


def test_authorize_token_exact_match() -> None:
    """Test for expected authorization with URL path matching"""
    mock_event = _mock_event(resource="/v1/jobs", path="/v1/jobs", http_method="PUT")
    mock_load_auth_config = {
        "/v1/jobs": [
            {"method": ["GET"], "group": ["read-only"]},
            {"method": ["POST", "DELETE", "PUT"], "group": ["admin"]},
        ],
        "/v1/dummy": [{"method": []}],
    }

    read_only_token = {"sub": "good-guy", "groups-custom": ["/read-only"]}
    invalid_token_payload = {"sub": "bad-guy", "groups-custom": ["/blacklist"]}
    admin_token = {"sub": "god", "groups-custom": ["/admin"]}

    allowed = authorize_token(mock_event, read_only_token, mock_load_auth_config)
    assert allowed is False

    allowed = authorize_token(mock_event, invalid_token_payload, mock_load_auth_config)
    assert allowed is False

    allowed = authorize_token(mock_event, admin_token, mock_load_auth_config)
    assert allowed is True


def test_authorize_token_fuzzy_match() -> None:
    """Test for expected authorization with wildcard matching"""
    mock_event = _mock_event(resource="/v1/jobs", path="/v1/jobs", http_method="PUT")
    mock_load_auth_config = {
        "/v1/*": [
            {"method": ["GET", "PUT"], "group": ["admin"]},
        ],
    }

    read_only_token = {"sub": "good-guy", "groups-custom": ["/read-only"]}
    invalid_token_payload = {"sub": "bad-guy", "groups-custom": ["/blacklist"]}
    admin_token = {"sub": "god", "groups-custom": ["/admin"]}

    allowed = authorize_token(mock_event, read_only_token, mock_load_auth_config)
    assert allowed is False

    allowed = authorize_token(mock_event, invalid_token_payload, mock_load_auth_config)
    assert allowed is False

    allowed = authorize_token(mock_event, admin_token, mock_load_auth_config)
    assert allowed is True


def test_authorize_token_path_variable() -> None:
    """Test for expected authorization with path variable matching"""
    mock_event = _mock_event(
        resource="/v1/jobs/{id}", path="/v1/jobs/123456", http_method="PUT"
    )
    mock_load_auth_config = {
        "/v1/jobs/{id}": [
            {"method": ["GET"], "group": ["read-only"]},
            {"method": ["POST", "DELETE", "PUT"], "group": ["admin"]},
        ]
    }

    read_only_token = {"sub": "good-guy", "groups-custom": ["/read-only"]}
    invalid_token_payload = {"sub": "bad-guy", "groups-custom": ["/blacklist"]}
    admin_token = {"sub": "god", "groups-custom": ["/admin"]}

    allowed = authorize_token(mock_event, read_only_token, mock_load_auth_config)
    assert allowed is False

    allowed = authorize_token(mock_event, invalid_token_payload, mock_load_auth_config)
    assert allowed is False

    allowed = authorize_token(mock_event, admin_token, mock_load_auth_config)
    assert allowed is True

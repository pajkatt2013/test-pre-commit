#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test services stack contents needed by EKS Helm deployments."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "services"


def get_app(sandbox_name: str | None = None) -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())

    if sandbox_name is not None:
        app.node.set_context("SANDBOX_NAME", sandbox_name)

    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template(
    service_name: str,
    sandbox_name: str | None = None,
    *,
    expecting_atleast_one_stack: bool = True,
) -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app(sandbox_name)
    stacks = configure_app(app, param_store=MockParameterStore())
    stacks = list(filter(lambda x: x.stack_param.name == service_name, stacks))
    if expecting_atleast_one_stack is True:
        stack = stacks[0]
        assert stack.stack_param.deployment.module_name == get_module_name()
        return Template.from_stack(stack)
    if len(stacks) > 0:
        return stacks[0]

    return None


def _expected_stack_tags(
    service_name: str, sandbox_name: str | None = None
) -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": (
                f"addf-core-infra-dev-{sandbox_name}-services-{service_name}"
                if sandbox_name is not None
                else f"addf-core-infra-dev-services-{service_name}"
            ),
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_skip_job_management_service() -> None:
    """Test for validating if skip configured service is ignored during deployment"""
    template = stack_template("skip-job-management", expecting_atleast_one_stack=False)
    assert template is None


def test_map_service_sa_role_in_stack() -> None:
    """Test for expected job caching service sa role with properties in the stack"""
    template = stack_template("map-metadata")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Map service.",
            "RoleName": "RaasMapServiceAccountRole",
            "Tags": _expected_stack_tags("map-metadata"),
        },
    )


def test_map_service_sa_role_in_stack_for_sandbox() -> None:
    """Test for expected job caching service sa role with properties in the stack"""
    template = stack_template("map-metadata", sandbox_name="mysandbox")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Map service.",
            "RoleName": "RaasMapServiceAccountRole-mysandbox",
            "Tags": _expected_stack_tags("map-metadata", sandbox_name="mysandbox"),
        },
    )


def test_job_caching_service_sa_role_in_stack() -> None:
    """Test for expected job caching service sa role with properties in the stack"""
    template = stack_template("job-caching")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Job Caching service.",
            "RoleName": "RaasJobCachingServiceAccountRole",
            "Tags": _expected_stack_tags("job-caching"),
        },
    )


def test_job_caching_service_sa_role_in_stack_for_sandbox() -> None:
    """Test for expected job caching service sa role with properties in the stack"""
    template = stack_template("job-caching", sandbox_name="mysandbox")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Job Caching service.",
            "RoleName": "RaasJobCachingServiceAccountRole-mysandbox",
            "Tags": _expected_stack_tags("job-caching", sandbox_name="mysandbox"),
        },
    )


def test_job_management_service_queue_in_stack() -> None:
    """Test for expected job management service queue with properties in the stack"""
    template = stack_template("job-management")
    template.resource_properties_count_is(
        "AWS::SQS::Queue",
        {
            "ContentBasedDeduplication": True,
            "DeduplicationScope": "messageGroup",
            "FifoQueue": True,
            "FifoThroughputLimit": "perMessageGroupId",
            "MessageRetentionPeriod": 120,
            "QueueName": "addf-core-infra-dev-services-job-management-queue1.fifo",
            "VisibilityTimeout": 100,
        },
        1,
    )

    template.resource_properties_count_is(
        "AWS::SQS::Queue",
        {
            "MessageRetentionPeriod": 110,
            "QueueName": "addf-core-infra-dev-services-job-management-queue2",
            "VisibilityTimeout": 60,
        },
        1,
    )

    template.resource_properties_count_is(
        "AWS::SQS::Queue",
        {
            "MessageRetentionPeriod": 1209600,
            "QueueName": "addf-core-infra-dev-services-job-management-queue3-dl",
            "VisibilityTimeout": 12,
        },
        1,
    )

    template.resource_properties_count_is(
        "AWS::SQS::Queue",
        {
            "MessageRetentionPeriod": 110,
            "QueueName": "addf-core-infra-dev-services-job-management-queue3",
            "VisibilityTimeout": 60,
        },
        1,
    )

    template.resource_properties_count_is(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:CancelMessageMoveTask",
                            "sqs:ChangeMessageVisibility",
                            "sqs:DeleteMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                            "sqs:ListMessageMoveTasks",
                            "sqs:ListQueueTags",
                            "sqs:ReceiveMessage",
                            "sqs:SendMessage",
                            "sqs:StartMessageMoveTask",
                        ],
                        "Effect": "Allow",
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevservicesjobmanagementqueue1fifo",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": (
                "addf_core_infra_dev_services_job_management_queue1_fifo_policy"
            ),
        },
        1,
    )

    template.resource_properties_count_is(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:CancelMessageMoveTask",
                            "sqs:ChangeMessageVisibility",
                            "sqs:DeleteMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                            "sqs:ListMessageMoveTasks",
                            "sqs:ListQueueTags",
                            "sqs:ReceiveMessage",
                            "sqs:SendMessage",
                            "sqs:StartMessageMoveTask",
                        ],
                        "Effect": "Allow",
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevservicesjobmanagementqueue2",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": "addf_core_infra_dev_services_job_management_queue2_policy",
        },
        1,
    )


def test_job_management_service_queue_in_stack_for_sandbox() -> None:
    """Test for expected job management service queue with properties in the stack"""
    template = stack_template("job-management", sandbox_name="mysandbox")
    template.resource_properties_count_is(
        "AWS::SQS::Queue",
        {
            "ContentBasedDeduplication": True,
            "DeduplicationScope": "messageGroup",
            "FifoQueue": True,
            "FifoThroughputLimit": "perMessageGroupId",
            "MessageRetentionPeriod": 120,
            "QueueName": (
                "addf-core-infra-dev-mysandbox-services-job-management-queue1.fifo"
            ),
            "VisibilityTimeout": 100,
        },
        1,
    )

    template.resource_properties_count_is(
        "AWS::SQS::Queue",
        {
            "MessageRetentionPeriod": 110,
            "QueueName": "addf-core-infra-dev-mysandbox-services-job-management-queue2",
            "VisibilityTimeout": 60,
        },
        1,
    )
    template.resource_properties_count_is(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:CancelMessageMoveTask",
                            "sqs:ChangeMessageVisibility",
                            "sqs:DeleteMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                            "sqs:ListMessageMoveTasks",
                            "sqs:ListQueueTags",
                            "sqs:ReceiveMessage",
                            "sqs:SendMessage",
                            "sqs:StartMessageMoveTask",
                        ],
                        "Effect": "Allow",
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevmysandboxservicesjobmanagementqueue1fifo",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": (
                "addf_core_infra_dev_mysandbox_services_job_management_queue1_fifo_policy"
            ),
        },
        1,
    )

    template.resource_properties_count_is(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:CancelMessageMoveTask",
                            "sqs:ChangeMessageVisibility",
                            "sqs:DeleteMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                            "sqs:ListMessageMoveTasks",
                            "sqs:ListQueueTags",
                            "sqs:ReceiveMessage",
                            "sqs:SendMessage",
                            "sqs:StartMessageMoveTask",
                        ],
                        "Effect": "Allow",
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevmysandboxservicesjobmanagementqueue2",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": (
                "addf_core_infra_dev_mysandbox_services_job_management_queue2_policy"
            ),
        },
        1,
    )


def test_job_management_service_sa_role_in_stack() -> None:
    """Test for expected job management service sa role with properties in the stack"""
    template = stack_template("job-management")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Job Management service.",
            "RoleName": "RaasJobManagementServiceAccountRole",
            "Tags": _expected_stack_tags("job-management"),
        },
    )


def test_job_management_service_sa_role_in_stack_for_sandbox() -> None:
    """Test for expected job management service sa role with properties in the stack"""
    template = stack_template("job-management", sandbox_name="mysandbox")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Job Management service.",
            "RoleName": "RaasJobManagementServiceAccountRole-mysandbox",
            "Tags": _expected_stack_tags("job-management", sandbox_name="mysandbox"),
        },
    )


def test_rpumetadata_service_sa_role_in_stack() -> None:
    """Test for expected job caching service sa role with properties in the stack"""
    template = stack_template("rpu-metadata")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the RPU Metadata service.",
            "RoleName": "RaasRpuMetadataServiceAccountRole",
            "Tags": _expected_stack_tags("rpu-metadata"),
        },
    )


def test_rpumetadata_service_sa_role_in_stack_for_sandbox() -> None:
    """Test for expected job caching service sa role with properties in the stack"""
    template = stack_template("rpu-metadata", sandbox_name="mysandbox")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the RPU Metadata service.",
            "RoleName": "RaasRpuMetadataServiceAccountRole-mysandbox",
            "Tags": _expected_stack_tags("rpu-metadata", sandbox_name="mysandbox"),
        },
    )


def test_job_request_status_in_stack() -> None:
    """Test for expected job request status with properties in the stack"""
    template = stack_template("job-management")
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags("job-management"),
            "QueueName": "addf-core-infra-dev-job-request-status",
        },
    )

    template.has_resource_properties(
        "AWS::SQS::QueuePolicy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:ReceiveMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                            "sqs:DeleteMessage",
                        ],
                        "Effect": "Allow",
                        "Principal": {"Service": "events.amazonaws.com"},
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevjobrequeststatus",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "Queues": ["addf-core-infra-dev-job-request-status"],
        },
    )


def test_job_request_status_in_stack_for_sandbox() -> None:
    """Test for expected job request status with properties in the stack"""
    template = stack_template("job-management", sandbox_name="mysandbox")
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags("job-management", sandbox_name="mysandbox"),
            "QueueName": "addf-core-infra-dev-mysandbox-job-request-status",
        },
    )

    template.has_resource_properties(
        "AWS::SQS::QueuePolicy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:ReceiveMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                            "sqs:DeleteMessage",
                        ],
                        "Effect": "Allow",
                        "Principal": {"Service": "events.amazonaws.com"},
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevmysandboxjobrequeststatus",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "Queues": ["addf-core-infra-dev-mysandbox-job-request-status"],
        },
    )

    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:StartMessageMoveTask",
                            "sqs:DeleteMessage",
                            "sqs:GetQueueUrl",
                            "sqs:CancelMessageMoveTask",
                            "sqs:ChangeMessageVisibility",
                            "sqs:ListMessageMoveTasks",
                            "sqs:ReceiveMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:ListQueueTags",
                        ],
                        "Effect": "Allow",
                        "Resource": (
                            "arn:aws:sqs:eu-central-1:178345759618:raas-infra-dev-mysandbox-argo-workflows-job-status"
                        ),
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": "sqs_argo_internal_workflow_job_task_status_policy",
        },
    )


def test_job_request_input_oao_with_loggroup_in_stack() -> None:
    """Test for expected oao with target loggroup properties in the stack"""
    template = stack_template("job-caching")
    template.has_resource_properties(
        "AWS::Logs::LogGroup",
        {
            "Tags": _expected_stack_tags("job-caching"),
            "LogGroupName": (
                "addf-core-infra-dev-job-caching-input-oao-event-raw-events"
            ),
            "RetentionInDays": 731,
        },
    )


def test_job_request_input_oao_with_loggroup_sandbox_in_stack() -> None:
    """Test for expected oao with no target loggroup for sandbox in the stack."""
    template = stack_template("job-caching", sandbox_name="mysandbox")
    template.resource_count_is(
        "AWS::Logs::LogGroup",
        0,
    )


def test_rpu_metadata_input_oao_in_stack() -> None:
    """Test for expected rpu subscription with properties in the stack"""
    template = stack_template("rpu-metadata")

    template.has_resource_properties(
        "AWS::Events::Rule",
        {
            "Description": (
                "Rule to route ecr events to sqs queue for rpu-metadata-service."
            ),
            "EventBusName": "default",
            "EventPattern": {"detail-type": ["ECR Image Action"]},
            "Name": "addf-core-infra-dev-rpu-pushed-event",
            "State": "ENABLED",
        },
    )


def test_list_s3buckets_policy() -> None:
    """Test for the list s3 buckets and tafgging in the stack"""
    template = stack_template("job-management")
    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "s3:ListAllMyBuckets",
                            "s3:GetBucketTagging",
                        ],
                        "Effect": "Allow",
                        "Resource": "*",
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": "s3_buckets_policy",
        },
    )


def test_list_s3buckets_policy_for_sandbox() -> None:
    """Test for the list s3 buckets and tafgging in the stack"""
    template = stack_template("job-management", sandbox_name="mysandbox")
    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "s3:ListAllMyBuckets",
                            "s3:GetBucketTagging",
                        ],
                        "Effect": "Allow",
                        "Resource": "*",
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": "s3_buckets_policy",
        },
    )


def test_rds_policy() -> None:
    """Test for the rds access policy in the stack"""
    template = stack_template("job-management")

    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": "rds-db:connect",
                        "Effect": "Allow",
                        "Resource": (
                            "arn:aws:rds-db:eu-central-1:1234321:dbuser:cluster-DHFCQDQHX2LRBQYTDHSYLGBXTM/job_management_service_db_user"
                        ),
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": "rds_postgres_access_policy",
        },
    )


def test_rds_policy_for_sandbox() -> None:
    """Test for the rds access policy in the stack"""
    template = stack_template("job-management", sandbox_name="mysandbox")
    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": "rds-db:connect",
                        "Effect": "Allow",
                        "Resource": (
                            "arn:aws:rds-db:eu-central-1:1234321:dbuser:cluster-DHFCQDQHX2LRBQYTDHSYLGBXTM/job_management_service_db_user"
                        ),
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": "rds_postgres_access_policy",
        },
    )


def test_trigger_tool_worker_sa_role_in_stack() -> None:
    """Test expected trigger tool submit worker sa role with properties in the stack."""
    template = stack_template("trigger-tool-submit-worker")
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Trigger Tool Submit Worker.",
            "RoleName": "RaasTriggerToolSubmitWorkerAccountRole",
            "Tags": _expected_stack_tags("trigger-tool-submit-worker"),
        },
    )


def test_trigger_tool_submit_worker_sqs_in_stack_for_sandbox() -> None:
    """Test for sqs in the trigger tool submit worker stack"""
    template = stack_template("trigger-tool-submit-worker", sandbox_name="mysandbox")
    template.resource_properties_count_is(
        "AWS::SQS::Queue",
        {
            "MessageRetentionPeriod": 120,
            "QueueName": "addf-core-infra-dev-mysandbox-argo-cv-submit-job-queue",
            "VisibilityTimeout": 100,
        },
        1,
    )


def test_trigger_tool_submit_worker_sqs_in_stack() -> None:
    """Test for sqs in the trigger tool submit worker stack"""
    template = stack_template("trigger-tool-submit-worker")
    template.resource_properties_count_is(
        "AWS::SQS::Queue",
        {
            "MessageRetentionPeriod": 120,
            "QueueName": "addf-core-infra-dev-argo-cv-submit-job-queue",
            "VisibilityTimeout": 100,
        },
        1,
    )

    template.resource_properties_count_is(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "sqs:CancelMessageMoveTask",
                            "sqs:ChangeMessageVisibility",
                            "sqs:DeleteMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                            "sqs:ListMessageMoveTasks",
                            "sqs:ListQueueTags",
                            "sqs:ReceiveMessage",
                            "sqs:SendMessage",
                            "sqs:StartMessageMoveTask",
                        ],
                        "Effect": "Allow",
                        "Resource": {
                            "Fn::GetAtt": [
                                "addfcoreinfradevargocvsubmitjobqueue",
                                "Arn",
                            ]
                        },
                    }
                ],
                "Version": "2012-10-17",
            },
            "PolicyName": "addf_core_infra_dev_argo_cv_submit_job_queue_policy",
        },
        1,
    )

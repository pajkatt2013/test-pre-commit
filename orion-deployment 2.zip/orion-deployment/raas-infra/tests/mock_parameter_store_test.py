#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test the SSM mock parameter store used for testing."""

import json
from pathlib import Path
from typing import Any

from raas_infra.utils.ssm import ParamStore


class MockParameterStore(ParamStore):
    """Reading the mocked ssm config param store data"""

    def __init__(self) -> None:
        current_directory = Path(__file__).parent.resolve()
        test_ssm_mock_data_file = current_directory / ".." / "test_ssm_mock_data.json"

        with test_ssm_mock_data_file.open() as fp:
            self.config = json.load(fp)

        test_secrets_mock_data_file = (
            current_directory / ".." / "test_secret_mock_data.json"
        )

        with test_secrets_mock_data_file.open() as fp:
            self.secrets = json.load(fp)

        super().__init__()

    def get_parameter(self, parameter_name: str) -> dict[str, Any] | None:
        """Get parameter name as object."""
        if parameter_name not in self.config:
            return None
        return json.loads(self.config[parameter_name])

    def get_parameter_value(self, parameter_name: str) -> str | None:
        """Get parameter name as uninterpreted string."""
        if parameter_name not in self.config:
            return None
        return self.config[parameter_name]

    def get_secret_value(self, secret_name: str, deployment: dict) -> str | None:
        """Get secret value from mock secrets store."""
        account_region = deployment["account"]["region"]
        account_id = deployment["account"]["id"]
        secret_arn = (
            f"arn:aws:secretsmanager:{account_region}:{account_id}:secret:{secret_name}"
        )
        print(f"fetching secret value for : {secret_arn}")
        if secret_name not in self.secrets:
            return None
        return self.secrets[secret_name]

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test the Metadata Post Stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "etl-metadata-post"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())

    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template() -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[0]
    return Template.from_stack(stack)


def test_etl_metadata_post_with_permissions_configured() -> None:
    """Test for expected rds db instance with permissions for Grafana account"""
    template = stack_template()

    template.has_resource_properties(
        "AWS::EC2::VPCEndpointServicePermissions",
        {
            "AllowedPrincipals": [
                "arn:aws:iam::911639040742:root",
                "arn:aws:iam::239426180731:root",
            ]
        },
    )


def test_etl_metadata_post_with_lb_configured() -> None:
    """Expected LoadBalancer to have the subnets from context config file"""
    template = stack_template()

    template.has_resource_properties(
        "AWS::ElasticLoadBalancingV2::LoadBalancer",
        {
            "Subnets": [
                "subnet-071e942c020768fbe",
                "subnet-01b427261f65ec387",
                "subnet-0d8c698bb62e08a18",
            ]
        },
    )


def test_etl_metadata_post_with_target_group_configured() -> None:
    """Expected TargetGroup to have the Postgres Port and the TCP protocol"""
    template = stack_template()

    template.has_resource_properties(
        "AWS::ElasticLoadBalancingV2::TargetGroup",
        {
            "Name": "tg-infra-dev-etl-metadata",
            "Port": 5432,
            "Protocol": "TCP",
            "TargetType": "ip",
        },
    )


def test_etl_metadata_post_with_role_attached() -> None:
    """Expected Role to have the policies allowing accounts to assume the role"""
    template = stack_template()

    template.has_resource_properties(
        "AWS::IAM::Role", {"RoleName": "vpc-epsvc-infra-dev-etl-metadata-role"}
    )


def test_etl_metadata_post_with_endpoint_service() -> None:
    """Expected Endpoint Service to have the correct configuration"""
    template = stack_template()

    template.has_resource_properties(
        "AWS::EC2::VPCEndpointService",
        {
            "AcceptanceRequired": True,
        },
    )

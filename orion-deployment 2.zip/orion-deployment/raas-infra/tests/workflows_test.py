#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test module argo-workflows."""

import aws_cdk as cdk
from aws_cdk.assertions import Template
from pydantic import ValidationError

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "argo-workflows"


def get_app(sandbox_name: str | None = None) -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())

    if sandbox_name is not None:
        app.node.set_context("SANDBOX_NAME", sandbox_name)

    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def get_stack(index: int = 0, sandbox_name: str | None = None) -> cdk.Stack:
    """Return the stack."""
    app = get_app(sandbox_name)
    stack = configure_app(app, param_store=MockParameterStore())[index]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return stack


def stack_template(index: int = 0, sandbox_name: str | None = None) -> Template:
    """Return the template generated from stack for assertion."""
    stack = get_stack(index=index, sandbox_name=sandbox_name)
    return Template.from_stack(stack)


def test_argo_workflow_values_from_dict() -> None:
    """Test the injection of cdk context helm values to the argo workflow."""
    stack = get_stack(0)
    assert (
        stack.stack_param.helm_chart.helm_chart.values_dict["argo-workflows"][
            "controller"
        ]["parallelism"]
        == "300"
    )
    assert (
        stack.stack_param.helm_chart.helm_chart.values_dict["argo-workflows"]["subnets"]
        == "subnet-071e942c020768fbe, subnet-01b427261f65ec387,"
        " subnet-0d8c698bb62e08a18"
    )


def test_argo_workflow_persistence_values_set_from_dict() -> None:
    """
    Test the injection of cdk context helm values to the argo workflow.

    This test specifically addresses the persistence part.
    """
    stack = get_stack(0)
    actual_argo_wf_archive = stack.stack_param.helm_chart.helm_chart.values_dict[
        "argo-workflows"
    ]["controller"]["persistence"]
    expected_argo_wf_archive = {
        "archive": True,
        "postgresql": {
            "database": "argo_workflow_archive",
            "host": (
                "raas-infra-dev-argo-wf-archive.cluster-c3nnl8ylp4h9.eu-central-1.rds.amazonaws.com"
            ),
            "passwordSecret": {
                "key": "password",
                "name": "argo-workflow-archive-config",
            },
            "port": 5432,
            "tableName": "argo_workflows",
            "userNameSecret": {
                "key": "username",
                "name": "argo-workflow-archive-config",
            },
        },
    }
    assert actual_argo_wf_archive == expected_argo_wf_archive


def test_no_s3_artifacts_bucket_in_stack_for_sandbox() -> None:
    """Test for expected S3 bucket with properties in the stack"""
    template = stack_template(sandbox_name="mysandbox")
    template.resource_count_is(
        "AWS::S3::Bucket",
        0,
    )


def test_s3_artifacts_bucket_in_stack() -> None:
    """Test for expected S3 bucket with properties in the stack"""
    template = stack_template()
    template.resource_properties_count_is(
        "AWS::S3::Bucket",
        {
            "Tags": _expected_stack_tags(),
            "BucketName": "addf-core-infra-dev-argo-workflows-artifacts-1234321",
        },
        1,
    )


def test_raas_argo_workflows_service_account_role_queue_policy_in_stack() -> None:
    """Test for raas-argo-sqs-publish-queues-policy policy"""
    template = stack_template()
    resources = template.to_json()["Resources"]
    policies = list(
        resources["RaaSArgoWorkflowsServiceAccountRoleE793C481"]["Properties"][
            "Policies"
        ]
    )
    sqs_policy = [
        x for x in policies if x["PolicyName"] == "raas-argo-sqs-publish-queues-policy"
    ]
    assert len(sqs_policy) == 1, "No raas-argo-sqs-publish-queues-policy found"
    resource_arn = sqs_policy[0]["PolicyDocument"]["Statement"][0]["Resource"]
    assert resource_arn == [
        "arn:aws:sqs:eu-central-1:1234321:addf-core-infra-dev-argo-workflows-job-status.fifo",
        "arn:aws:sqs:eu-central-1:1234321:addf-core-infra-dev-*-argo-workflows-job-status.fifo",
    ], "ARN for resource not matching"


def _expected_stack_tags(sandbox_name: str | None = None) -> list[dict]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": (
                f"addf-core-infra-dev-{sandbox_name}-argo-workflows"
                if sandbox_name is not None
                else "addf-core-infra-dev-argo-workflows"
            ),
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_sqs_job_status_in_stack() -> None:
    """Test for expected job status sqs with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags(),
            "QueueName": "addf-core-infra-dev-argo-workflows-job-status.fifo",
        },
    )
    template.resource_count_is("AWS::SQS::Queue", 1)


def test_sqs_job_status_with_dlq_in_stack() -> None:
    """Test for expected job status and dlq sqs and with properties in the stack"""
    app = get_app()
    argo_context = app.node.get_context("argo")
    argo_context["workflows"]["jobStatusQueue"] = {
        "dlq": {
            "maxReceiveCount": 3,
            "messageRetentionPeriod": 1800,
            "messageVisibilityTimeout": 100,
        },
        "isFifo": True,
        "messageRetentionPeriod": 1209600,
        "messageVisibilityTimeout": 10800,
        "name": "job-status",
    }
    app.node.set_context(
        "argo",
        argo_context,
    )
    stack = configure_app(app, param_store=MockParameterStore())[0]
    template = Template.from_stack(stack=stack)
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags(),
            "QueueName": "addf-core-infra-dev-argo-workflows-job-status.fifo",
        },
    )
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags(),
            "QueueName": "addf-core-infra-dev-argo-workflows-job-status-dl.fifo",
        },
    )
    assert (
        template.to_json()["Resources"].get(
            "addfcoreinfradevargoworkflowsjobstatusdlfifo", None
        )
        is not None
    )
    assert (
        template.to_json()["Resources"].get(
            "addfcoreinfradevargoworkflowsjobstatusfifo", None
        )
        is not None
    )
    template.resource_count_is("AWS::SQS::Queue", 2)


def test_no_sqs_job_status_in_stack() -> None:
    """Test for expected job status and dlq sqs and with properties in the stack"""
    app = get_app()
    argo_context = app.node.get_context("argo")
    del argo_context["workflows"]["jobStatusQueue"]
    app.node.set_context(
        "argo",
        argo_context,
    )
    try:
        configure_app(app, param_store=MockParameterStore())[0]
    except ValidationError:
        assert True
        return
    msg = "Validation Message for missing job status queue in argo workflow is missing"
    raise AssertionError(msg)


def test_sqs_job_status_in_stack_for_sandbox() -> None:
    """Test for expected job status sqs with properties in the stack"""
    template = stack_template(sandbox_name="mysandbox")
    template.has_resource_properties(
        "AWS::SQS::Queue",
        {
            "Tags": _expected_stack_tags("mysandbox"),
            "QueueName": "addf-core-infra-dev-mysandbox-argo-workflows-job-status.fifo",
        },
    )
    template.resource_count_is("AWS::SQS::Queue", 1)


def test_argo_workflow_sa_role_in_stack() -> None:
    """Test for expected argo workflow sa role with properties in the stack"""
    template = stack_template()
    template.resource_properties_count_is(
        "AWS::IAM::Role",
        {
            "Description": (
                "Role used by RaaS Argo Workflows to store artifact logs to S3 bucket."
            ),
            "RoleName": "addf-core-infra-dev-argo-workflows-sa-role",
            "Tags": _expected_stack_tags(),
        },
        1,
    )


def test_argo_workflow_sa_role_in_stack_for_sandbox() -> None:
    """Test for expected argo workflow sa role with properties in the stack"""
    template = stack_template(sandbox_name="mysandbox")
    template.resource_count_is("AWS::IAM::Role", 0)


def test_helmchart_in_stack() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template(1)
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "raas-argo-workflows",
            "Namespace": "raas-argo-workflows",
        },
    )


def test_helmchart_in_stack_for_sandbox() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template(1, sandbox_name="mysandbox")
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "raas-argo-workflows-mysandbox",
            "Namespace": "raas-argo-workflows",
        },
    )

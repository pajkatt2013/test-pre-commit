#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Check whether CDK apps can be synthesized.

This works with mock data provided by
tests/data/cdk_synth/ssm_mock.json
tests/data/cdk_synth/cdk_context_vpc.json

VPC data gets injected automatically to cdk.contenxt.json contents.
The VPC config can be used for all projects and stages by injecting
the value of merged_cdk_context["deployment"]["account"]["id"] into the
string template tests/data/cdk_synth/cdk_context_vpc.json.

ssm_mock.json might need updating in future, run cdk synth/deploy with
WRITE_SSM_TO_JSON=true prefixed to dump all received versions from SSM
to the file tests/data/cdk_synth/ssm_received.json.
"""

import json
import string
from pathlib import Path

import aws_cdk as cdk
from mock_parameter_store_test import MockParameterStore

from raas_infra import configure_app


class CdkSynthMockParameterStore(MockParameterStore):
    """
    Version of MockParameterStore for cdk synth.

    The goal is to load ssm_mock.json instead of test_ssm_mock_data.json.
    ssm_mock.json contains productive SSM data from the dev account.
    It needs to be maintained properly with raas-infra structural changes that
    reflect in SSM.
    """

    def __init__(self) -> None:
        curr_dir = Path(__file__).parent.resolve()
        json_out_path = curr_dir / "data" / "cdk_synth" / "ssm_mock.json"
        with json_out_path.open("r", encoding="utf-8") as fp:
            self.config = json.load(fp)

        json_out_path = curr_dir.parent / "test_secret_mock_data.json"
        with json_out_path.open("r", encoding="utf-8") as fp:
            self.secrets = json.load(fp)

        # no need to call __init__ of MockParameterStore, this replace it fully
        # super-super class ParamStore does not have an __init__()


def _read_json_template(path: Path, replacements: dict[str, str]) -> dict:
    with path.open("r") as fp:
        data = fp.read()
    template = string.Template(data)
    data_substituted = template.substitute(replacements)
    return json.loads(data_substituted)


def gen_context() -> dict:
    """
    Assemble combined cdk context from merged cdk.context.json and the VPC information.

    Goal is get a context that uses the merged orion-deployment JSONs and enriches this
    with VPC information so no lookups are needed during cdk synth test.
    """
    curr_dir = Path(__file__).parent.resolve()
    path_merged_cdk_context = curr_dir.parent / "cdk.context.json"
    with path_merged_cdk_context.open("r") as fp:
        merged_cdk_context = json.load(fp)
    path_vpc_cdk_context = curr_dir / "data" / "cdk_synth" / "cdk_context_vpc.json"

    # get dynamic params and write to vpc context json file, so one file can be used
    # for all stages
    placeholders = {
        "ACCOUNT_ID": merged_cdk_context["deployment"]["account"]["id"],
        "REGION": merged_cdk_context["deployment"]["account"]["region"],
    }
    vpc_cdk_context = _read_json_template(path_vpc_cdk_context, placeholders)
    out_dict = {}
    out_dict.update(merged_cdk_context)
    out_dict.update(vpc_cdk_context)
    return out_dict


context = gen_context()
app = cdk.App(context=context)
configure_app(app, param_store=CdkSynthMockParameterStore())
app.synth()

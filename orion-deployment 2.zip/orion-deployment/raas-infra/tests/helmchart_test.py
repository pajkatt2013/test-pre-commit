#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test the helmcharts stack contents including cdk.HelmChart constructs."""

import json
from datetime import datetime

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import get_test_folder, set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "helmcharts"


def get_app(sandbox_name: str | None = None) -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())

    if sandbox_name is not None:
        app.node.set_context("SANDBOX_NAME", sandbox_name)

    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template(
    helmchart_name: str | None = None,
    sandbox_name: str | None = None,
    *,
    expecting_atleast_one_stack: bool = True,
) -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app(sandbox_name)
    if helmchart_name is not None:
        app.node.set_context("HELM_CHART_NAMES", helmchart_name)
        existing_helm_charts = app.node.get_context("helmcharts")
        helmchart_names = (
            [x.strip() for x in helmchart_name.split(",")]
            if helmchart_name is not None
            else []
        )
        filtered_helmcharts = {
            k: v for k, v in existing_helm_charts.items() if k in helmchart_names
        }
        app.node.set_context("helmcharts", filtered_helmcharts)
    stacks = configure_app(app, param_store=MockParameterStore())
    if expecting_atleast_one_stack is True:
        stack = stacks[0]
        assert stack.stack_param.deployment.module_name == get_module_name()
        return Template.from_stack(stack)
    if len(stacks) > 0:
        return stacks[0]

    return None


def _expected_stack_tags() -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": "addf-core-infra-dev-helmcharts",
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_skip_helmchart() -> None:
    """Test for validating if skip configured helm chart is ignored during deployment"""
    template = stack_template(
        "skip-values-file-not-found",
        expecting_atleast_one_stack=False,
    )
    assert template is None


def test_job_management_service_helmchart_in_stack() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template("job-management-service")
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "job-management-service",
            "Namespace": "raas-services",
            "Wait": True,
            "Values": (
                '{"service":{"name":"job-management-service"},"config":{"raasDocsUrl":"http://localhost/somedummyurl","jobCachingServiceBasePath":"http://job-caching-service:8081","raasUrl":"http://localhost/testurl","database":{"hostname":"infra-dev-etl-metadata.cluster-c3nnl8ylp4h9.eu-central-1.rds.amazonaws.com:5432","schemaName":"raas"},"jobStatusQueueUrl":"https://sqs.eu-central-1.amazonaws.com/178345759618/raas-infra-dev-argo-workflows-job-status","jobStatusUrl":"https://sqs.eu-central-1.amazonaws.com/178345759618/raas-infra-dev-argo-workflows-job-status","jobTriggerQueueUrl":"https://sqs.eu-central-1.amazonaws.com/178345759618/raas-infra-dev-argo-events-job-trigger"},"deployment":{"image":{"registry":"503803885491.dkr.ecr.eu-central-1.amazonaws.com","repository":"app-dev-eu-central-1-raas/microservices/job-management-service","tag":"V2"}},"ingress":{"host":{"domain":"100100019.Dev.aws.orionadp.com","prefix":"raas-job-management"},"subnets":"subnet-071e942c020768fbe,'
                " subnet-01b427261f65ec387,"
                ' subnet-0d8c698bb62e08a18","subnetsArray":["subnet-071e942c020768fbe","subnet-01b427261f65ec387","subnet-0d8c698bb62e08a18"],"testArray":["value1","value2"]},"serviceAccount":{"roleArn":"arn:aws:iam::178345759618:role/RaasJobManagementServiceAccountRole"}}'
            ),
        },
    )


def test_job_caching_service_with_stack_dependency_helmchart_in_stack() -> None:
    """
    Test for expected helm chart with properties in the stack.

    TODO(Marco Heinemann):  stack_template() generates 2 stacks in order as they appear
                            in cdk.context.json and then returns the stack with index 0.
                            Re-sorting the stacks in cdk.context.json changes the
                            the returned stack which is bad for test stability.
                            The function stack_template() should return all stacks
                            as specified in first param.
    """
    template = stack_template("job-management-service, job-caching-service")
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "job-caching-service",
            "Namespace": "raas-services",
            "Wait": True,
            "Values": '{"config":{"database":{"hostname":"infra-dev-etl-metadata.cluster-c3nnl8ylp4h9.eu-central-1.rds.amazonaws.com:5432"}},"deployment":{"image":{"registry":"503803885491.dkr.ecr.eu-central-1.amazonaws.com","repository":"app-dev-eu-central-1-raas/microservices/job-caching-service","tag":"develop"}},"service":{"name":"job-caching-service"},"serviceAccount":{"roleArn":"arn:aws:iam::178345759618:role/RaasJobCachingServiceAccountRole"}}',
        },
    )


def test_job_caching_service_with_stack_dependency_error() -> None:
    """Test for expected error for helm chart with missing parent in the stack"""
    expected_error_msg = (
        "Cannot deploy helmchart: 'job-caching-service', since stack"
        " not found with parent chart : 'job-management-service' to"
        " add as dependency."
    )
    actual_error_msg = ""
    try:
        template = stack_template("job-caching-service")
        template.has_resource_properties(
            "Custom::AWSCDK-EKS-HelmChart",
            {
                "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
                "Release": "job-management-service",
                "Namespace": "raas-services",
                "Wait": True,
                "Values": (
                    '{"service":{"name":"job-management-service"},"config":{"raasDocsUrl":"http://localhost/somedummyurl","jobCachingServiceBasePath":"http://job-caching-service:8081","raasUrl":"http://localhost/testurl","database":{"hostname":"infra-dev-etl-metadata.cluster-c3nnl8ylp4h9.eu-central-1.rds.amazonaws.com:5432"},"jobTriggerQueueUrl":"https://sqs.eu-central-1.amazonaws.com/178345759618/raas-infra-dev-argo-events-job-trigger","jobStatusQueueUrl":"https://sqs.eu-central-1.amazonaws.com/178345759618/raas-infra-dev-argo-workflows-job-status","jobStatusUrl":"https://sqs.eu-central-1.amazonaws.com/178345759618/raas-infra-dev-argo-workflows-job-status"},"deployment":{"image":{"registry":"503803885491.dkr.ecr.eu-central-1.amazonaws.com","repository":"app-dev-eu-central-1-raas/microservices/job-management-service","tag":"V2"}},"ingress":{"host":{"prefix":"raas-job-management","domain":"100100019.Dev.aws.orionadp.com"},"subnets":"subnet-071e942c020768fbe,'
                    " subnet-01b427261f65ec387,"
                    ' subnet-0d8c698bb62e08a18","subnetsArray":["subnet-071e942c020768fbe","subnet-01b427261f65ec387","subnet-0d8c698bb62e08a18"],"testArray":["value1","value2"]},"serviceAccount":{"roleArn":"arn:aws:iam::178345759618:role/RaasJobManagementServiceAccountRole"}}'
                ),
            },
        )
    except ValueError as error:
        actual_error_msg = str(error)

    assert expected_error_msg == actual_error_msg


def test_values_file_not_exists_helmchart_in_stack() -> None:
    """Test for no values file exists in helm chart construct"""
    expected_error_msg = (
        f"Values file : {get_test_folder()}/data/nofile.yaml not exists."
    )
    actual_error_msg = ""
    try:
        template = stack_template("values-file-not-found")
        template.has_resource_properties(
            "Custom::AWSCDK-EKS-HelmChart",
            {
                "Release": "values-file-not-found",
                "Namespace": "values-file-not-found",
            },
        )
    except ValueError as error:
        actual_error_msg = str(error)

    assert expected_error_msg == actual_error_msg


def test_invalid_json_expression_helmchart_in_stack() -> None:
    """Test for invalid json expression in helm chart"""
    expected_error_msg = (
        "Unable to apply json path expression :"
        " $.sqs_raas_job_trigger_queue_url.no_property on json object"
        " from ssm key : argo_events."
    )
    actual_error_msg = ""
    try:
        template = stack_template("invalid-json-value-expression, invalid-ssm-ref")
        template.has_resource_properties(
            "Custom::AWSCDK-EKS-HelmChart",
            {
                "Release": "invalid-json-value-expression",
                "Namespace": "invalid-json-value-expression",
            },
        )
    except ValueError as error:
        actual_error_msg = str(error)

    assert expected_error_msg == actual_error_msg


def test_invalid_ssm_ref_helmchart_in_stack() -> None:
    """Test for no values file exists in helm chart construct"""
    expected_error_msg = "SSM ref key : argo_events_1 not found."
    actual_error_msg = ""
    try:
        template = stack_template("invalid-ssm-ref", sandbox_name="mysandbox")
        template.has_resource_properties(
            "Custom::AWSCDK-EKS-HelmChart",
            {
                "Release": "invalid-ssm-ref",
                "Namespace": "invalid-ssm-ref",
            },
        )
    except ValueError as error:
        actual_error_msg = str(error)

    assert expected_error_msg == actual_error_msg


def test_job_management_service_helmchart_in_stack_for_sandbox() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template("job-management-service", sandbox_name="mysandbox")
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "job-management-service-mysandbox",
            "Namespace": "raas-services-mysandbox",
            "Wait": True,
            "Values": (
                '{"service":{"name":"job-management-service"},"config":{"raasDocsUrl":"http://localhost/somedummyurl","jobCachingServiceBasePath":"http://job-caching-service:8081","raasUrl":"http://localhost/testurl","database":{"hostname":"infra-dev-etl-metadata.cluster-c3nnl8ylp4h9.eu-central-1.rds.amazonaws.com:5432","schemaName":"raas_mysandbox"},"jobStatusQueueUrl":"https://sqs.eu-central-1.amazonaws.com/178345759618/raas-infra-dev-argo-workflows-job-status","jobStatusUrl":"https://sqs.eu-central-1.amazonaws.com/178345759618/raas-infra-dev-argo-workflows-job-status","jobTriggerQueueUrl":"https://sqs.eu-central-1.amazonaws.com/178345759618/raas-infra-dev-mysandbox-argo-events-job-trigger"},"deployment":{"image":{"registry":"503803885491.dkr.ecr.eu-central-1.amazonaws.com","repository":"app-dev-eu-central-1-raas/microservices/job-management-service","tag":"V2"}},"ingress":{"host":{"domain":"100100019.Dev.aws.orionadp.com","prefix":"raas-job-management-mysandbox"},"subnets":"subnet-071e942c020768fbe,'
                " subnet-01b427261f65ec387,"
                ' subnet-0d8c698bb62e08a18","subnetsArray":["subnet-071e942c020768fbe","subnet-01b427261f65ec387","subnet-0d8c698bb62e08a18"],"testArray":["value1","value2"]},"serviceAccount":{"roleArn":"arn:aws:iam::178345759618:role/RaasJobManagementServiceAccountRole"}}'
            ),
        },
    )


def test_delegate_to_helm_generates_timestamp() -> None:
    """
    Test whether the parameter delegateDeploymentToHelm=True.

    It must lead to a timestamp in the Helm values.
    """
    template = stack_template("delegate-to-helm")
    # convert to a JSON object - the find methods won't work as the injected values are
    # unpreditable timestamps
    template_obj = template.to_json()
    res = None
    for key in template_obj["Resources"]:
        if key.startswith("HelmCharts"):
            res = template_obj["Resources"][key]
    if res is not None:
        values_str: str = res["Properties"]["Values"]
        values = json.loads(values_str)
        assert "delegate_deployment_to_helm_time" in values
        timestamp_str: str = values["delegate_deployment_to_helm_time"]
        assert "enforce-image-pull" in values["deployment"]["annotations"]
        assert (
            values["deployment"]["annotations"]["enforce-image-pull"] == timestamp_str
        )

    # check whether a valid timestamp was written that can be converted back to a
    # datetime object
    datetime.fromisoformat(timestamp_str)

#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test reading of cdk.context.json including refs and ssm."""

import json
from pathlib import Path

import aws_cdk as cdk

from raas_infra.context import (
    VPC,
    EKSArgoPrerequisitesContext,
    EKSCluster,
)
from tests.mock_parameter_store_test import MockParameterStore


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app.node.set_context("ADDF_MODULE_NAME", "context_unit_test")

    app.node.set_context(
        "argo",
        {
            "prerequisites": {
                "raasPipelineNamespace": "raas-pipeline",
                "ref": {
                    "eksCluster": {"ssm": "/addf/realm-infra-dev/core/eks/metadata"},
                    "sharedServicesVpc": {
                        "ssm": (
                            "/orionadp/network/network-account/shared-services-vpc-id"
                        )
                    },
                    "vpc": {
                        "vpcId": {
                            "ssm": "/orionadp/blueprint/vpc/network-onprem-vpc/vpc-id"
                        },
                        "vpcRoutableSubnetIds": {
                            "ssm": (
                                "/orionadp/blueprint/vpc/network-onprem-vpc/routable-private-subnets"
                            )
                        },
                        "vpcNonRoutableSubnetIds": {
                            "ssm": (
                                "/orionadp/blueprint/vpc/network-onprem-vpc/non-routable-private-subnets"
                            )
                        },
                        "isOnPremRouted": "false",
                    },
                },
                "metadataOutputSSMPath": (
                    "/addf/core-infra-dev/argo-prerequesites/metadata"
                ),
            }
        },
    )

    app.node.set_context(
        "deployment",
        {
            "skipModules": ["test"],
            "projectName": "addf_unit_test",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def test_context_ref() -> None:
    """Test whether CDK context refs can be retrieved."""
    app = get_app()
    eks_argo_prerequisites_context = EKSArgoPrerequisitesContext.from_context(
        node=app.node, param_store=MockParameterStore()
    )
    eks_cluster = EKSCluster.from_context(
        eks_argo_prerequisites_context.ref["eksCluster"]
    )
    vpc = VPC.from_context(eks_argo_prerequisites_context.ref["vpc"])
    assert vpc.is_on_prem_routed is False
    assert vpc.id == "vpc-065b81be6c0468825"
    assert eks_cluster.security_group_id == "sg-05f7dbf258768515d"
    routable_subnet_ids = json.loads(vpc.routable_subnet_ids)
    expected_subnet_cnt = 3
    assert len(routable_subnet_ids) == expected_subnet_cnt
    assert eks_argo_prerequisites_context.deployment.project_name == "addf_unit_test"
    assert eks_argo_prerequisites_context.deployment.account.id == "1234321"
    assert eks_argo_prerequisites_context.deployment.module_name == "context_unit_test"
    assert eks_argo_prerequisites_context.deployment.name == "core-infra-dev"


def test_context_default_depname_projname() -> None:
    """Test default context deployment project name."""
    app = get_app()
    app.node.set_context(
        "deployment",
        {
            "environmentName": "test",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    eks_argo_prerequisites_context = EKSArgoPrerequisitesContext.from_context(
        node=app.node, param_store=MockParameterStore()
    )
    assert eks_argo_prerequisites_context.deployment.project_name == "raas"
    assert eks_argo_prerequisites_context.deployment.account.id == "1234321"
    assert eks_argo_prerequisites_context.deployment.module_name == "context_unit_test"
    assert eks_argo_prerequisites_context.deployment.name == "infra-test"


def test_context_global_local_ref() -> None:
    """Test whether the local ref concept works."""
    app = get_app()
    app.node.set_context(
        "ref",
        {
            "hostedZoneId": {
                "ssm": (
                    "/orionadp/platform/dns/hostedzone/default-numeric-entry-2/hostedzone-id"
                )
            },
            "eksCluster1": {"ssm": "/addf/realm-infra-dev/core/eks/metadata"},
        },
    )
    ctx = EKSArgoPrerequisitesContext.from_context(
        node=app.node, param_store=MockParameterStore()
    )
    eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
    eks_cluster1 = EKSCluster.from_context(ctx.ref["eksCluster1"])

    assert eks_cluster.security_group_id == "sg-05f7dbf258768515d"
    assert eks_cluster1.security_group_id == "sg-05f7dbf258768515d"
    assert ctx.ref["hostedZoneId"] == "Z03908841DRE3PXZIZE3R"


def get_test_folder() -> str:
    """Return tests folder as string."""
    current_directory = str(Path(__file__).parent.resolve())
    return current_directory.replace("\\", "/")


def set_app_context(app: cdk.App) -> cdk.App:
    """Return CDK app with context loaded including helm charts folder."""
    current_directory = Path(__file__).parent.resolve()
    cdk_context_json_file = current_directory.parent / "cdk.context.json"

    with cdk_context_json_file.open(mode="r", encoding="utf-8") as fp:
        context = json.load(fp)

    context_json = json.dumps(context)
    context_json = context_json.replace("__tests_folder__", get_test_folder())
    context = json.loads(context_json)

    app.node.set_context("HELM_CHARTS_FOLDER", f"{get_test_folder()}/helmcharts")

    for key in context:
        app.node.set_context(key, context[key])
    return app


def get_app_context() -> dict:
    """Return cdk.context.json as JSON object."""
    current_directory = Path(__file__).parent.resolve()
    cdk_context_json_file = current_directory.parent / "cdk.context.json"
    with cdk_context_json_file.open(mode="r", encoding="utf-8") as fp:
        return json.load(fp)

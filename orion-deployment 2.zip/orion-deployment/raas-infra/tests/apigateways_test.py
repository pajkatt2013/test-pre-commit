#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test API GW stack contents."""

import fnmatch

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "apigateways"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context("OPENAPI_RESOURCES_FOLDER", "tests/data/openapi-specs")
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template() -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app()
    return configure_app(app, param_store=MockParameterStore())


def test_api_gateway_stack_creating_one_stack_param_and_one_skipped() -> None:
    """Check basic apigateway CDK context stack properties."""
    template = stack_template()
    assert len(template) == 1
    assert template[0].id == "apigateway-stack-raas"
    expected_param_list_cnt = 1
    assert len(template[0].stack_param_list) == expected_param_list_cnt
    assert template[0].stack_param_list[0].name == "job-management-service"


def test_api_gateway_stack_creating_one_stack_with_right_output_keys() -> None:
    """Validate if skip configured api gateway is ignored during deployment."""
    expected_output_dict_keys = [
        "raas-api-url",
        "raas-api-id",
        "raas-api-stage",
        "iamauth-raas-api-url",
        "iamauth-raas-api-id",
        "iamauth-raas-api-stage",
        "api_readonly_assume_role_arn",
        "api_fullaccess_assume_role_arn",
    ]

    template = stack_template()

    expected_output_dict_key_cnt = 8
    assert len(template[0].output_dict) == expected_output_dict_key_cnt
    for key in expected_output_dict_keys:
        assert key in template[0].output_dict


def test_api_gateway_stack_creating_right_vpc_links() -> None:
    """Check apigateway stack VpcLink resources."""
    template = stack_template()
    template = Template.from_stack(template[0])
    template.has_resource_properties(
        "AWS::ApiGateway::VpcLink",
        {
            "Description": "Vpc link for job-management-service from api to nlb.",
            "Name": "job-management-service-vpclink",
        },
    )


def test_api_gateway_stack_creating_right_stage_and_roles() -> None:
    """Check apigateway stack stage name and IAM roles."""
    template = stack_template()
    template = Template.from_stack(template[0])
    template.has_resource_properties(
        "AWS::ApiGateway::Stage",
        {
            "StageName": "prod",
        },
    )

    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "RoleName": "apigateway-stack-raas-readonly",
        },
    )
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "RoleName": "apigateway-stack-raas-fullaccess",
        },
    )


# Verify IAM Role for Readonly Access
def test_role_readonly_permission() -> None:
    """Check readonly role permissions."""
    template = stack_template()
    template = Template.from_stack(template[0])

    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "AssumeRolePolicyDocument": {
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Principal": {"AWS": "*"},
                        "Action": "sts:AssumeRole",
                    }
                ]
            }
        },
    )


# Verify IAM Role for Full Access
def test_role_fullaccess_permission() -> None:
    """Check fullaccess role permissions.."""
    template = stack_template()
    template = Template.from_stack(template[0])

    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "AssumeRolePolicyDocument": {
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Principal": {"AWS": "arn:aws:iam::178345759618:root"},
                        "Action": "sts:AssumeRole",
                    }
                ]
            }
        },
    )


# Verify the policy attached to the Readonly Role
def test_role_readonly_policy() -> None:
    """Check readonly role policies.."""
    template = stack_template()
    template = Template.from_stack(template[0])

    # Retrieve the full CloudFormation template as a dictionary
    template_dict = template.to_json()

    # Extract the logical ID of the ApiGateway resource from the CloudFormation template
    api_gateway_logical_id = next(
        logical_id
        for logical_id, resource in template_dict["Resources"].items()
        if fnmatch.fnmatch(logical_id, "iamauthraasapi*")
    )

    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": "execute-api:Invoke",
                        "Effect": "Allow",
                        "Resource": {
                            "Fn::Join": [
                                "",
                                [
                                    "arn:",
                                    {"Ref": "AWS::Partition"},
                                    ":execute-api:eu-central-1:1234321:",
                                    {"Ref": api_gateway_logical_id},
                                    "/*/GET/v1/jobs/*",
                                ],
                            ]
                        },
                    },
                    {
                        "Action": "execute-api:Invoke",
                        "Effect": "Deny",
                        "Resource": [
                            {
                                "Fn::Join": [
                                    "",
                                    [
                                        "arn:",
                                        {"Ref": "AWS::Partition"},
                                        ":execute-api:eu-central-1:1234321:",
                                        {"Ref": api_gateway_logical_id},
                                        "/*/POST/*",
                                    ],
                                ]
                            },
                            {
                                "Fn::Join": [
                                    "",
                                    [
                                        "arn:",
                                        {"Ref": "AWS::Partition"},
                                        ":execute-api:eu-central-1:1234321:",
                                        {"Ref": api_gateway_logical_id},
                                        "/*/PUT/*",
                                    ],
                                ]
                            },
                            {
                                "Fn::Join": [
                                    "",
                                    [
                                        "arn:",
                                        {"Ref": "AWS::Partition"},
                                        ":execute-api:eu-central-1:1234321:",
                                        {"Ref": api_gateway_logical_id},
                                        "/*/PATCH/*",
                                    ],
                                ]
                            },
                            {
                                "Fn::Join": [
                                    "",
                                    [
                                        "arn:",
                                        {"Ref": "AWS::Partition"},
                                        ":execute-api:eu-central-1:1234321:",
                                        {"Ref": api_gateway_logical_id},
                                        "/*/DELETE/*",
                                    ],
                                ]
                            },
                        ],
                    },
                ]
            }
        },
    )


# Verify the policy attached to the full access Role
def test_role_fullaccess_policy() -> None:
    """Check full access role policies.."""
    template = stack_template()
    template = Template.from_stack(template[0])

    # Retrieve the full CloudFormation template as a dictionary
    template_dict = template.to_json()

    # Extract the logical ID of the ApiGateway resource from the CloudFormation template
    api_gateway_logical_id = next(
        logical_id
        for logical_id, resource in template_dict["Resources"].items()
        if fnmatch.fnmatch(logical_id, "iamauthraasapi*")
    )

    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": "execute-api:Invoke",
                        "Effect": "Allow",
                        "Resource": {
                            "Fn::Join": [
                                "",
                                [
                                    "arn:",
                                    {"Ref": "AWS::Partition"},
                                    ":execute-api:eu-central-1:1234321:",
                                    {"Ref": api_gateway_logical_id},
                                    "/*/*/v1/jobs/*",
                                ],
                            ]
                        },
                        "Condition": {
                            "StringLike": {
                                "aws:PrincipalArn": "arn:aws:iam::178345759618:root"
                            }
                        },
                    }
                ]
            }
        },
    )


def test_api_gateway_stack_creating_authorizers() -> None:
    """Check apigateway stack lambda authorizer resources."""
    template = stack_template()
    template = Template.from_stack(template[0])

    template.has_resource_properties(
        "AWS::Lambda::Function", {"Description": "Lambda serving apiGw Auth"}
    )

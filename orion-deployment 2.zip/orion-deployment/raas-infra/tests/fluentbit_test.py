#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test Fluentbit stack contents."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "fluentbit"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def stack_template() -> Template:
    """Return the template generated from stack for assertion"""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[0]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return Template.from_stack(stack)


def _expected_stack_tags() -> list[dict[str, str]]:
    return [
        {"Key": "customer_function", "Value": "common"},
        {
            "Key": "Deployment",
            "Value": "addf-core-infra-dev-fluentbit",
        },
        {"Key": "env", "Value": "dev"},
        {"Key": "system", "Value": "raas"},
        {"Key": "task", "Value": "infra"},
    ]


def test_fluent_bit_sa_role_in_stack() -> None:
    """Test for expected fluentbit sa role with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "Description": "Role used by the Fluentbit.",
            "RoleName": "RaasFluentbitAccountRole",
            "Tags": _expected_stack_tags(),
        },
    )


def test_helmchart_in_stack() -> None:
    """Test for expected helm chart with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "Custom::AWSCDK-EKS-HelmChart",
        {
            "ClusterName": "addf-realm-infra-dev-core-eks-cluster",
            "Release": "amazon-cloudwatch",
            "Namespace": "amazon-cloudwatch",
        },
    )


def test_s3_artifacts_bucket_in_stack() -> None:
    """Test for expected S3 bucket with properties in the stack"""
    template = stack_template()
    template.resource_properties_count_is(
        "AWS::S3::Bucket",
        {
            "Tags": _expected_stack_tags(),
            "BucketName": "addf-core-infra-dev-fluentbit-1234321",
        },
        1,
    )


def test_customer_function_log_groups_in_stack() -> None:
    """Test if customer function log groups are created with the expected tags"""
    template = stack_template()
    customer_functions = MockParameterStore().get_parameter_value(
        "/addf/customer-functions"
    )
    if customer_functions is None:
        customer_functions = ""

    for customer_function in customer_functions.split(","):
        template.resource_properties_count_is(
            "AWS::Logs::LogGroup",
            {
                "Tags": [
                    {"Key": "customer_function", "Value": customer_function}
                    if tag["Key"] == "customer_function"
                    else tag
                    for tag in _expected_stack_tags()
                ],
                "LogGroupName": (
                    "/aws/containerinsights/addf-realm-infra-dev-core-eks-cluster"
                    f"/application/raas/rpu/{customer_function}"
                ),
            },
            1,
        )


def test_app_log_groups_in_stack() -> None:
    """Test if log groups for RaaS and DQ applications are created in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Logs::LogGroup",
        {
            "LogGroupName": (
                "/aws/containerinsights/addf-realm-infra-dev-core-eks-cluster/application/raas/services"
            ),
            "LogGroupClass": "INFREQUENT_ACCESS",
            "RetentionInDays": 60,
        },
    )

    template.has_resource_properties(
        "AWS::Logs::LogGroup",
        {
            "LogGroupName": (
                "/aws/containerinsights/addf-realm-infra-dev-core-eks-cluster/application/data-quality/"
            ),
            "LogGroupClass": ("STANDARD"),
            "RetentionInDays": 60,
        },
    )


def test_opensearch_collection_in_stack() -> None:
    """Test for expected Opensearch collection with properties in the stack"""
    template = stack_template()
    template.resource_properties_count_is(
        "AWS::OpenSearchServerless::Collection",
        {
            "Tags": _expected_stack_tags(),
            "Name": "addf-core-infra-dev-fluentbit-eks",
        },
        1,
    )


def test_opensearch_access_policy_in_stack() -> None:
    """Test for expected Opensearch access policy with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::OpenSearchServerless::AccessPolicy",
        {
            "Name": "raas-opensearch-data-policy",
            "Policy": {
                "Fn::Join": [
                    "",
                    [
                        '[{"Description": "Data Access Policy", "Rules":[{"ResourceType":"index","Resource":["index/addf-core-infra-dev-fluentbit-eks/*"],"Permission":["aoss:*"]}, {"ResourceType":"collection","Resource":["collection/addf-core-infra-dev-fluentbit-eks"],"Permission":["aoss:*"]}],"Principal":["p1","p2","',
                        {
                            "Fn::GetAtt": [
                                "ServiceAccountRole737CA8AD",
                                "Arn",
                            ]
                        },
                        '"]}]',
                    ],
                ]
            },
            "Type": "data",
        },
    )


def test_opensearch_security_policy_in_stack() -> None:
    """Test for expected Opensearch access policy with properties in the stack"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::OpenSearchServerless::SecurityPolicy",
        {
            "Name": "raas-opensearch-nw-policy",
            "Policy": '[{"Rules":[{"ResourceType":"collection","Resource":["collection/addf-core-infra-dev-fluentbit-eks"]},{"ResourceType":"dashboard","Resource":["collection/addf-core-infra-dev-fluentbit-eks"]}],"AllowFromPublic":true}]',
            "Type": "network",
        },
    )

    template.has_resource_properties(
        "AWS::OpenSearchServerless::SecurityPolicy",
        {
            "Name": "raas-opensearch-enc-policy",
            "Policy": '{"Rules":[{"ResourceType":"collection","Resource":["collection/addf-core-infra-dev-fluentbit-eks"]}],"AWSOwnedKey":true}',
            "Type": "encryption",
        },
    )

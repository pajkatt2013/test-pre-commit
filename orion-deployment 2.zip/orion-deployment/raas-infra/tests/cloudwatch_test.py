#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test cloudwatch stack."""

import json

import aws_cdk as cdk
from aws_cdk.assertions import Match, Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "cloudwatch"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()

    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def get_stack(index: int = 0) -> cdk.Stack:
    """Return the stack"""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[index]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return stack


def stack_template(index: int = 0) -> Template:
    """Return the template generated from stack for assertion"""
    stack = get_stack(index=index)
    return Template.from_stack(stack)


def test_synthesizes_properly() -> None:
    """Test template is generated properly"""
    template = stack_template()
    assert template is not None


def test_cloudwatch_metrics_data_refs_from_stack() -> None:
    """Test stack has all the metric data populated"""
    stack = get_stack(0)
    assert stack.metrics_data is not None
    assert stack.metrics is not None
    assert stack.stack_param is not None


def test_cloudwatch_metrics_has_required_values() -> None:
    """Test the context has all the required values for creating metrics"""
    stack = get_stack(0)
    for metric in stack.metrics["custom"]:
        metric_name, metric_config = next(iter(metric.items()))
        metric_data = stack.metrics_data[metric_config["metric_context_ref_path"]]
        metric_dimension_value = json.loads(metric_data)[
            metric_config["alarm_config"][
                "dimension_value_from_metric_context_ref_path"
            ]
        ]
        lambda_folder_path = metric_config["lambda_config"]["lambda_folder_path"]
        lambda_file = metric_config["lambda_config"]["lambda_file"]
        lambda_permissions = metric_config["lambda_config"]["lambda_permissions"]
        namespace = metric_config["namespace"]
        assert metric_name is not None
        assert metric_data is not None
        assert metric_dimension_value is not None
        assert lambda_folder_path is not None
        assert lambda_file is not None
        assert lambda_permissions is not None
        assert namespace is not None


def test_cloudwatch_lambda_for_custom_metrics() -> None:
    """Test cloudwatch lambda"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Lambda::Function",
        {
            "Handler": "efsmetrics.lambda_handler",
            "Runtime": "python3.10",
        },
    )


def test_cloudwatch_metric_resources_expected_for_custom_metrics() -> None:
    """Test cloudwatch lambda has the resources expected"""
    template = stack_template()
    template.resource_count_is("AWS::Lambda::Function", 1)
    template.resource_count_is("AWS::CloudWatch::Alarm", 1)
    template.resource_count_is("AWS::SNS::Topic", 1)
    template.resource_count_is("AWS::IAM::Role", 1)


def test_cloudwatch_lambda_has_necessary_permissions() -> None:
    """Test cloudwatch lambda permissions"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::IAM::Policy",
        Match.object_equals(
            {
                "PolicyName": Match.any_value(),
                "Roles": Match.any_value(),
                "PolicyDocument": {
                    "Statement": [
                        {
                            "Action": "cloudwatch:PutMetricData",
                            "Effect": "Allow",
                            "Resource": "*",
                        },
                        {
                            "Action": "elasticfilesystem:DescribeAccessPoints",
                            "Effect": "Allow",
                            "Resource": "*",
                        },
                    ],
                    "Version": "2012-10-17",
                },
            }
        ),
    )


def test_cloudwatch_lambda_has_customer_function_tag() -> None:
    """Test cloudwatch lambda has the required tags"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::Lambda::Function",
        {"Tags": Match.array_with([{"Key": "customer_function", "Value": "common"}])},
    )


def test_cloudwatch_lambda_trigger_is_scheduled_event() -> None:
    """Test cloudwatch lambda has the trigger defined"""
    stack = get_stack(0)
    for metric in stack.metrics["custom"]:
        metric_name, metric_config = next(iter(metric.items()))
        assert (
            metric_config["lambda_config"]["trigger_config"]["schedule_config"]
            is not None
        )


def test_cloudwatch_alarm_has_customer_function_tag() -> None:
    """Test cloudwatch alarm has the required tags"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::CloudWatch::Alarm",
        {"Tags": Match.array_with([{"Key": "customer_function", "Value": "common"}])},
    )


def test_cloudwatch_alarm_has_actions_defined() -> None:
    """Test cloudwatch alarm has action defined"""
    template = stack_template()
    template.has_resource_properties(
        "AWS::CloudWatch::Alarm",
        Match.object_like(
            {
                "AlarmActions": Match.any_value(),
            }
        ),
    )

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Test stack piping job OAO events to a websocket API."""

import aws_cdk as cdk
from aws_cdk.assertions import Template

from raas_infra import configure_app
from tests.context_test import set_app_context
from tests.mock_parameter_store_test import MockParameterStore


def get_module_name() -> str:
    """Return ADDF_MODULE_NAME cdk context param for all tests."""
    return "job-oao-websocket-pipe"


def get_app() -> cdk.App:
    """Create a valid app with valid context"""
    app = cdk.App()
    app = set_app_context(app=app)
    app.node.set_context("ADDF_MODULE_NAME", get_module_name())
    app.node.set_context(
        "deployment",
        {
            "projectName": "addf",
            "name": "core-infra-dev",
            "environmentName": "dev",
            "account": {
                "id": "1234321",
                "region": "eu-central-1",
                "partition": "aws",
            },
        },
    )
    return app


def get_stack(index: int = 0) -> cdk.Stack:
    """Return the stack"""
    app = get_app()
    stack = configure_app(app, param_store=MockParameterStore())[index]
    assert stack.stack_param.deployment.module_name == get_module_name()
    return stack


def stack_template(index: int = 0) -> Template:
    """Return the template generated from stack for assertion"""
    stack = get_stack(index=index)
    return Template.from_stack(stack)


def test_job_oao_pipe_stack_creating_right_stage() -> None:
    """Check apigateway stack stage name."""
    template = stack_template()
    template.has_resource_properties(
        "AWS::ApiGatewayV2::Stage",
        {
            "StageName": "prod",
        },
    )


def test_execution_permissions() -> None:
    """Check apigateway stack stage name."""
    template = stack_template()

    # API Gateway -> DynamoDB
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "RoleName": "raas-websocket-dynamodb-role",
            "Policies": [
                {
                    "PolicyName": "dynamodb-policy",
                    "PolicyDocument": {
                        "Statement": [
                            {
                                "Action": ["dynamodb:PutItem", "dynamodb:DeleteItem"],
                                "Effect": "Allow",
                            }
                        ]
                    },
                }
            ],
        },
    )

    # Pipe -> SQS/Lambda
    template.has_resource_properties(
        "AWS::IAM::Role",
        {
            "RoleName": "raas-sqs-pipe-role",
            "Policies": [
                {
                    "PolicyName": "sqs-policy",
                    "PolicyDocument": {
                        "Statement": [
                            {
                                "Action": [
                                    "sqs:ReceiveMessage",
                                    "sqs:DeleteMessage",
                                    "sqs:GetQueueAttributes",
                                ],
                                "Effect": "Allow",
                            }
                        ]
                    },
                },
                {
                    "PolicyName": "lambda-policy",
                    "PolicyDocument": {
                        "Statement": [
                            {
                                "Action": "lambda:InvokeFunction",
                                "Effect": "Allow",
                            }
                        ]
                    },
                },
            ],
        },
    )

    # Lambda -> DynamoDB / API Gateway Management API
    template.has_resource_properties(
        "AWS::IAM::Policy",
        {
            "PolicyDocument": {
                "Statement": [
                    {
                        "Action": [
                            "dynamodb:BatchGetItem",
                            "dynamodb:GetItem",
                            "dynamodb:Query",
                            "dynamodb:Scan",
                        ],
                        "Effect": "Allow",
                    },
                    {
                        "Action": "execute-api:ManageConnections",
                        "Effect": "Allow",
                    },
                ]
            }
        },
    )

# Cloud watch

This module is responsible for deploying cloudwatch resources like metrics, logs etc.



Cloudwatch stack deployment comes package with below resources



- Provisioning lambda for publishing metrics
- Provisioning event rules for scheduling lambda
- Provisioning SNS topic for alarm action
- Provisioning CW alarm for the published metrics

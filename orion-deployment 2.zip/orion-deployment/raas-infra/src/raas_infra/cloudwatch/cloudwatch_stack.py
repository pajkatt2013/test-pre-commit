#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
RDS Postgres Deployment CDK stack.

(C) 2024 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from importlib.resources import files
from typing import cast

import aws_cdk.aws_iam as iam
import aws_cdk.aws_lambda as _lambda
from aws_cdk import Duration, Stack, Tags, aws_sns
from aws_cdk import aws_cloudwatch as cloudwatch
from aws_cdk import aws_events as events
from aws_cdk import aws_events_targets as event_target
from aws_cdk import aws_sns_subscriptions as subscriptions
from constructs import Construct, IConstruct

from raas_infra import CloudWatch


class CloudWatchStack(Stack):
    """Deploy Cloudwatch features."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: CloudWatch,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="Deploy cloudwatch metrics etc.,",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param
        self.metrics = stack_param.metrics
        self.metrics_data = stack_param.metrics_data

        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)
        for metric in self.metrics["custom"]:
            metric_name, metric_config = next(iter(metric.items()))
            metric_name = f"{self.id}-{metric_name}"
            metric_data = self.metrics_data[metric_config["metric_context_ref_path"]]
            metric_dimension_value = json.loads(metric_data)[
                metric_config["alarm_config"][
                    "dimension_value_from_metric_context_ref_path"
                ]
            ]
            lambda_folder_path = metric_config["lambda_config"]["lambda_folder_path"]
            lambda_file = metric_config["lambda_config"]["lambda_file"]
            lambda_permissions = metric_config["lambda_config"]["lambda_permissions"]
            namespace = metric_config["namespace"]
            metric_collector_lambda = self.add_metric_lambda(
                metric_name,
                metric_data,
                namespace,
                lambda_folder_path,
                lambda_file,
                lambda_permissions,
            )
            event_bus_name = "default"
            events.EventBus.from_event_bus_name(self, "event-bus", event_bus_name)
            trigger_config = metric_config["lambda_config"]["trigger_config"]
            event_rule = self.add_metric_scheduler(metric_name, trigger_config)
            event_rule.add_target(event_target.LambdaFunction(metric_collector_lambda))
            action_arns = self.add_metric_action(
                metric_name, metric_config["alarm_config"]["notification_config"]
            )
            cloudwatch.CfnAlarm(
                self,
                id=f"{metric_name}-cloudwatch-alarm",
                alarm_name=f"{metric_name}-cloudwatch-alarm",
                alarm_description=f"CW alarm that is used as source for {metric_name}",
                threshold=metric_config["alarm_config"]["threshold"],
                evaluation_periods=metric_config["alarm_config"]["evaluation_periods"],
                datapoints_to_alarm=metric_config["alarm_config"]["datapoints"],
                comparison_operator=metric_config["alarm_config"][
                    "comparison_operator"
                ],
                treat_missing_data=metric_config["alarm_config"]["treat_missing_data"],
                metric_name=f"{metric_name}",
                namespace=namespace,
                statistic=metric_config["alarm_config"]["statistic"],
                period=metric_config["alarm_config"]["period_in_seconds"],
                alarm_actions=action_arns,
                dimensions=[
                    cloudwatch.CfnAlarm.DimensionProperty(
                        name=metric_config["alarm_config"]["dimension_name"],
                        value=f"{metric_dimension_value}",
                    )
                ],
            )

    def add_metric_action(
        self, metric_name: str, notification_config: dict
    ) -> list[str]:
        """Add metric action while the threshold breached."""
        action_arns = []
        for notification, notification_value in notification_config.items():
            if notification == "sns":
                topic = aws_sns.Topic(
                    self, f"{metric_name}-{notification_value['topic_name']}"
                )
                for subscription, subscription_value in notification_value[
                    "subscriptions"
                ].items():
                    if subscription == "email":
                        for recipient in subscription_value["recipients"]:
                            topic.add_subscription(
                                subscriptions.EmailSubscription(recipient)
                            )
                action_arns.append(topic.topic_arn)
        return action_arns

    def add_metric_scheduler(
        self, metric_name: str, trigger_config: dict
    ) -> events.Rule:
        """Add lambda scheduler events rule."""
        if trigger_config["schedule_config"]:
            rate_in_mins = trigger_config["schedule_config"]["rate_in_mins"]
            return events.Rule(
                self,
                f"{metric_name}-event-rule",
                schedule=events.Schedule.rate(Duration.minutes(int(rate_in_mins))),
                event_pattern=events.EventPattern(source=["scheduled.events"]),
                rule_name=f"{self.id}-{trigger_config['name']}",
            )
        return None

    def add_metric_lambda(
        self,
        metric_name: str,
        metric_data: str,
        namespace: str,
        lambda_folder: str,
        lambda_file: str,
        lambda_permissions: list[str],
    ) -> _lambda.Function:
        """Add lambda to publish metrics by monitoring the EFS access points."""
        metric_collector_lambda = _lambda.Function(
            self,
            id=f"{metric_name}-metric-collector-lambda",
            runtime=_lambda.Runtime.PYTHON_3_10,
            code=_lambda.Code.from_asset(
                str(files(f"raas_infra.constructs.lambdas.{lambda_folder}"))
            ),
            environment={
                "METRIC_DATA": metric_data,
                "METRIC_NAME": metric_name,
                "NAMESPACE": namespace,
            },
            handler=f"{lambda_file}.lambda_handler",
            description="Lambda collecting metrics",
        )
        metric_collector_lambda.add_to_role_policy(
            iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=["cloudwatch:PutMetricData"],
                resources=["*"],
            )
        )
        for permission in lambda_permissions:
            metric_collector_lambda.add_to_role_policy(
                iam.PolicyStatement(
                    effect=iam.Effect.ALLOW, actions=[permission], resources=["*"]
                )
            )
        return metric_collector_lambda

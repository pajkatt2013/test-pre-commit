#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Parameters for deploying RaaS Argo WF Archive Stack - CDK stack deployment.

(C) 2024 Qualcomm Technologies, Inc.  All rights reserved.
"""

from raas_infra.context import VPC, CloudWatchContext, ContextModel, Deployment


class CloudWatch(ContextModel):
    """Managing the necessary params for RaaS CloudWatch CDK deployment"""

    id: str
    vpc: VPC
    output_metadata_path: str
    deployment: Deployment
    non_sandbox_id: str
    metrics: dict

    @classmethod
    def from_context(cls, ctx: CloudWatchContext) -> "CloudWatch":
        """Read values from the AWS CDK context."""
        vpc = VPC.from_context(ctx.ref["vpc"])
        id_ = ctx.get_id()
        props = {
            "vpc": vpc,
            "deployment": ctx.deployment,
            "id": id_,
            "output_metadata_path": ctx.metadata_output_ssm_path,
            "metrics": ctx.metrics,
            "metrics_data": ctx.ref,
        }

        props["non_sandbox_id"] = ctx.get_non_sandbox_id()

        return cls.model_validate(props)

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
RDS Postgres Deployment CDK stack.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from typing import cast

import aws_cdk.aws_ssm as ssm
from aws_cdk import Stack, Tags
from constructs import Construct, IConstruct

from raas_infra.constructs.postgres import RaaSPostgres
from raas_infra.postgres_serverless_cluster.postgres_serverless_cluster_param import (
    PostgresServerlessCluster,
)


class PostgresServerlessClusterStack(Stack):
    """Deploy postgres cluster."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: PostgresServerlessCluster,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys serverless postgres cluster.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs)
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        self.raas_postgres = RaaSPostgres(
            scope=self,
            id=f"{stack_param.cluster_name_prefix}",
            name=stack_param.name,
            cluster_name_prefix=stack_param.cluster_name_prefix,
            postgres=stack_param.postgres,
            eks_cluster=stack_param.eks_cluster,
            vpc=stack_param.vpc,
            deployment=stack_param.deployment,
        )

        # Write output to SSM
        self.write_output(stack_param=stack_param)

    def write_output(self, stack_param: PostgresServerlessCluster) -> None:
        """Responsible for capturing the metadata in the SSM."""
        output_dict = {
            "postgres_cluster_name": self.raas_postgres.postgres_cluster_name,
            "postgres_port": str(stack_param.postgres.port),
            "postgres_cluster_arn": self.raas_postgres.postgres_cluster_arn,
            "postgres_writer_instance_name": (
                self.raas_postgres.postgres_writer_instance_name
            ),
            "postgres_cluster_writer_endpoint": (
                self.raas_postgres.postgres_cluster.cluster_endpoint.socket_address
            ),
            "postgres_cluster_writer_endpoint_host_name": (
                self.raas_postgres.postgres_cluster.cluster_endpoint.hostname
            ),
            "postgres_cluster_reader_endpoint": (
                self.raas_postgres.postgres_cluster.cluster_read_endpoint.socket_address
            ),
            "postgres_cluster_reader_endpoint_host_name": (
                self.raas_postgres.postgres_cluster.cluster_read_endpoint.hostname
            ),
            "postgres_cluster_resource_identifier": (
                self.raas_postgres.postgres_cluster_resource_identifier
            ),
            "postgres_security_group_id": (
                self.raas_postgres.postgres_sg.security_group_id
            ),
            "postgres_engine_version": stack_param.postgres.engine_version,
            "postgres_secret_arn": self.raas_postgres.postgres_secret_arn,
        }

        if (
            self.stack_param.postgres.bastion_host is not None
            and True
            and self.stack_param.postgres.bastion_host is not None
            and self.stack_param.postgres.bastion_host is not None
        ):
            output_dict.update(
                {
                    "raas_bastion_host_instance_id": (
                        self.raas_postgres.bastion.instance_id
                    )
                }
            )
            output_dict.update(
                {
                    "raas_bastion_host_instance_ssm_command": (
                        "aws ssm start-session --target"
                        f" {self.raas_postgres.bastion.instance_id} --document-name"
                        " AWS-StartPortForwardingSessionToRemoteHost "
                        " --parameters"
                        f" host='{self.raas_postgres.postgres_cluster.cluster_endpoint.hostname}',portNumber='{stack_param.postgres.port}',localPortNumber='{stack_param.postgres.port}'"
                    )
                }
            )
            if stack_param.postgres.database is not None:
                output_dict.update(
                    {
                        "postgres_ssm_local_psql_connect_command": (
                            "psql -h 127.0.0.1 -p"
                            f" {stack_param.postgres.port} -U"
                            f" {stack_param.postgres.master_user_name} -d"
                            f" {stack_param.postgres.database.name}"
                        )
                    }
                )

        if stack_param.postgres.database is not None:
            output_dict.update({"postgres_db_name": stack_param.postgres.database.name})

        for db_user in self.stack_param.postgres.db_users:
            output_dict.update(
                {f"postgres_{db_user.name}_user_name": db_user.user_name}
            )
            output_dict.update(
                {
                    f"postgres_{db_user.name}_secret_arn": (
                        self.raas_postgres.db_user_credentials[db_user.name][
                            "secret_arn"
                        ]
                    )
                }
            )

        output_value = json.dumps(output_dict)

        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

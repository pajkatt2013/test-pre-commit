#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Parameters for deploying RaaS ETLMetadata Stacl - CDK stack deployment.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSCluster,
    Postgres,
    PostgresServerlessClusterContext,
)


class PostgresServerlessCluster(ContextModel):
    """Managing the necessary params for RaaS ETLMetadata CDK deployment"""

    id: str
    eks_cluster: EKSCluster
    vpc: VPC
    output_metadata_path: str
    deployment: Deployment
    postgres: Postgres
    non_sandbox_id: str
    name: str
    cluster_name_prefix: str

    @classmethod
    def from_context(
        cls, ctx: PostgresServerlessClusterContext
    ) -> "PostgresServerlessCluster":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])
        postgres = ctx.postgres

        id = ctx.get_submodule_id(
            module_name=ctx.deployment.module_name,
            sub_module_name=ctx.name,
        )

        if ctx.deployment.sandbox_name is not None:
            # in case of sandbox deployment, shortening the "id" to avoid issues with
            # length names while deploying sandbox resources.
            deployment = ctx.deployment
            id = f"{deployment.project_name}-postgres-{deployment.sandbox_name}-{ctx.name}"

        cluster_name_prefix = (
            f"{ctx.deployment.project_name}-{ctx.deployment.name}-{ctx.name}"
        )
        props = {
            "eks_cluster": eks_cluster,
            "vpc": vpc,
            "postgres": postgres,
            "deployment": ctx.deployment,
            "id": id,
            "output_metadata_path": ctx.metadata_output_ssm_path,
            "name": ctx.name,
            "cluster_name_prefix": cluster_name_prefix,
        }

        props["non_sandbox_id"] = ctx.get_non_sandbox_id()

        return cls.model_validate(props)

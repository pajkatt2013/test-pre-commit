#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
RDS Postgres Deployment CDK stack.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

from typing import cast

import aws_cdk.aws_ec2 as ec2
from aws_cdk import Stack, Tags
from constructs import Construct, IConstruct

from raas_infra.constructs.postgres_lambda import (
    RaaSPostgresExecuteScripts,
)
from raas_infra.postgres_serverless_cluster.postgres_serverless_cluster_param import (
    PostgresServerlessCluster,
)


class SandboxPostgresServerlessClusterStack(Stack):
    """Execute SQL scripts against sandboxed postgres instances."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: PostgresServerlessCluster,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description=(
                "This stack executes sql scripts in serverless"
                " postgres for sandbox environment."
            ),
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs)
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        self.vpc = ec2.Vpc.from_lookup(self, id="VPC", vpc_id=stack_param.vpc.id)
        # postgres security group lookup
        postgres_sg_name = f"{stack_param.cluster_name_prefix}-sg"
        postgres_sg = ec2.SecurityGroup.from_lookup_by_name(
            self, "postgres-sg", postgres_sg_name, vpc=self.vpc
        )
        account = stack_param.deployment.account

        # look up for the master credentials
        master_secret_partial_arn = f"arn:{account.partition}:secretsmanager:{account.region}:{account.id}:secret:{stack_param.postgres.master_credentials_output_secret_path}"

        # setting the schema name for the sandbox schema
        for postgres_schema_scripts in stack_param.postgres.scripts:
            postgres_schema_scripts.non_sandbox_schema = postgres_schema_scripts.schema
            postgres_schema_scripts.schema = f"{postgres_schema_scripts.schema}_{stack_param.deployment.sandbox_name}"

        # setting the db user credentials
        db_user_credentials = {}
        postgres = stack_param.postgres
        for db_user in postgres.db_users:
            secret_partial_arn = f"arn:{account.partition}:secretsmanager:{account.region}:{account.id}:secret:{db_user.credentials_output_secret_path}"
            db_user_credentials.update(
                {
                    db_user.name: {
                        "secret_arn": secret_partial_arn,
                        "db_user": db_user,
                    }
                }
            )

        self.raas_postgres_exec_scripts = RaaSPostgresExecuteScripts(
            scope=self,
            id=f"{id}-scripts",
            name=stack_param.name,
            lambda_role_name=f"{id}-lambda-scripts",
            vpc=self.vpc,
            postgres_secret_arn=master_secret_partial_arn,
            postgres_port=stack_param.postgres.port,
            postgres_sg=postgres_sg,
            postgres_scripts=stack_param.postgres.scripts,
            db_user_credentials=db_user_credentials,
            access_secrets_arn=f"arn:{account.partition}:secretsmanager:{account.region}:{account.id}:secret:*",
            vpc_metadata=stack_param.vpc,
        )

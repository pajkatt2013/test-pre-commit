#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

import aws_cdk as cdk
from aws_cdk import App, Stack, Tags
from constructs import Construct

from raas_infra.apigateway.apigateway_param import ApiGateway
from raas_infra.apigateway.apigateway_stack import ApiGatewayStack
from raas_infra.cloudwatch.cloudwatch_params import CloudWatch
from raas_infra.cloudwatch.cloudwatch_stack import CloudWatchStack
from raas_infra.context import (
    ADOTCollectorContext,
    ApiGatewaysContext,
    CloudWatchContext,
    EKSArgoEFSMountContext,
    EKSArgoEventsContext,
    EKSArgoPrerequisitesContext,
    EKSArgoWorkflowsContext,
    EKSKarpenterContext,
    EKSS3MountContext,
    ETLMetadataContext,
    FluentbitContext,
    GrafanaContext,
    HelmChartsContext,
    JobOaoWebsocketPipeContext,
    PostgresServerlessClustersContext,
    PrometheusContext,
    ServicesContext,
)
from raas_infra.eks.adot_collector.adot_collector_params import ADOTCollector
from raas_infra.eks.adot_collector.adot_collector_stack import ADOTCollectorStack
from raas_infra.eks.argo.efsmount.efsmount_params import ArgoEFSMount
from raas_infra.eks.argo.efsmount.efsmount_stack import ArgoEFSMountStack
from raas_infra.eks.argo.events.events_params import ArgoEvents
from raas_infra.eks.argo.events.events_stack import ArgoEventsStack
from raas_infra.eks.argo.prerequisites.prerequisites_params import ArgoPrerequisites
from raas_infra.eks.argo.prerequisites.prerequisites_stack import ArgoPrerequisitesStack
from raas_infra.eks.argo.workflows.workflows_params import ArgoWorkFlow
from raas_infra.eks.argo.workflows.workflows_stack import ArgoWorkFlowStack
from raas_infra.eks.fluentbit.fluentbit_params import Fluentbit
from raas_infra.eks.fluentbit.fluentbit_stack import FluentbitStack
from raas_infra.eks.helmcharts.helmchart_param import HelmChart
from raas_infra.eks.helmcharts.helmchart_stack import HelmChartStack
from raas_infra.eks.karpenter.karpenter_params import Karpenter
from raas_infra.eks.karpenter.karpenter_stack import KarpenterStack
from raas_infra.eks.prometheus.prometheus_params import Prometheus
from raas_infra.eks.prometheus.prometheus_stack import PrometheusStack
from raas_infra.eks.s3mount.s3mount_params import EKSS3Mount
from raas_infra.eks.s3mount.s3mount_stack import EKSS3MountStack
from raas_infra.etl_metadata.metadata_params import ETLMetadata
from raas_infra.etl_metadata.metadata_stack import MetadataStack
from raas_infra.etl_metadata.sandbox_metadata_stack import SandboxMetadataStack
from raas_infra.etl_metadata_post.etl_metadata_post_params import ETLMetadataPost
from raas_infra.etl_metadata_post.etl_metadata_post_stack import EtlMetadataPostStack
from raas_infra.grafana.grafana_params import Grafana
from raas_infra.grafana.grafana_stack import GrafanaStack
from raas_infra.job_oao_websocket_pipe import (
    JobOaoWebsocketPipe,
    JobOaoWebsocketPipeStack,
)
from raas_infra.postgres_serverless_cluster.postgres_serverless_cluster_param import (
    PostgresServerlessCluster,
)
from raas_infra.postgres_serverless_cluster.postgres_serverless_cluster_stack import (
    PostgresServerlessClusterStack,
)
from raas_infra.postgres_serverless_cluster.sandbox_postgres_serverless_cluster_stack import (
    SandboxPostgresServerlessClusterStack,
)
from raas_infra.services.service_param import MicroService
from raas_infra.services.service_stack import MicroServiceStack
from raas_infra.utils.ssm import ParamStore, SSMParameterStore


def _argo_prerequesites_stack(
    app: App, param_store: ParamStore
) -> list[ArgoPrerequisitesStack]:
    # preparing the argo prerequisites deployment context
    eks_argo_prerequisites_context = EKSArgoPrerequisitesContext.from_context(
        node=app.node, param_store=param_store
    )

    # Constructing the parameters for the prerequisites
    argo_prereq = ArgoPrerequisites.from_context(ctx=eks_argo_prerequisites_context)

    # Construct for the prerequisites
    return [
        ArgoPrerequisitesStack(
            scope=app,
            id=argo_prereq.id,
            stack_param=argo_prereq,
            env=cdk.Environment(
                account=eks_argo_prerequisites_context.deployment.account.id,
                region=eks_argo_prerequisites_context.deployment.account.region,
            ),
        )
    ]


def _argo_workflow_stack(
    app: App, param_store: ParamStore
) -> list[ArgoWorkFlowStack | HelmChartStack]:
    # preparing the argo workflows deployment context
    eks_argo_workflows_context = EKSArgoWorkflowsContext.from_context(
        node=app.node, param_store=param_store
    )

    # Constructing the parameters for the prerequisites
    argo_workflow = ArgoWorkFlow.from_context(ctx=eks_argo_workflows_context)

    # Construct for the argo workflows
    workflow_stack = ArgoWorkFlowStack(
        scope=app,
        id=argo_workflow.id,
        stack_param=argo_workflow,
        env=cdk.Environment(
            account=eks_argo_workflows_context.deployment.account.id,
            region=eks_argo_workflows_context.deployment.account.region,
        ),
    )

    # for sandbox deployment, skipping the priority class resource deployments
    return [
        workflow_stack,
        HelmChartStack(
            scope=app,
            id=f"{argo_workflow.id}-helmchart",
            stack_param=argo_workflow.helm_chart,
            env=cdk.Environment(
                account=eks_argo_workflows_context.deployment.account.id,
                region=eks_argo_workflows_context.deployment.account.region,
            ),
        ),
    ]


def _argo_events_stack(
    app: App, param_store: ParamStore
) -> list[ArgoEventsStack | HelmChartStack]:
    # preparing the argo workflows deployment context
    eks_argo_events_context = EKSArgoEventsContext.from_context(
        node=app.node, param_store=param_store
    )

    # Constructing the parameters for the argo events construct
    argo_events = ArgoEvents.from_context(ctx=eks_argo_events_context)

    # Construct for the argo events
    events_stack = ArgoEventsStack(
        scope=app,
        id=argo_events.id,
        stack_param=argo_events,
        env=cdk.Environment(
            account=eks_argo_events_context.deployment.account.id,
            region=eks_argo_events_context.deployment.account.region,
        ),
    )

    # for sandbox deployment, installing argo events helm chart partially.
    # sandbox deployment covers only creation of eventsources in argo-events namespace.
    # The created eventsource is mapped to the sandbox sqs resource to allow triggering
    # of argo workflows when an event is sent to the sandbox sqs
    return [
        events_stack,
        HelmChartStack(
            scope=app,
            id=f"{argo_events.id}-helmchart",
            stack_param=argo_events.helm_chart,
            env=cdk.Environment(
                account=eks_argo_events_context.deployment.account.id,
                region=eks_argo_events_context.deployment.account.region,
            ),
        ),
    ]


def _argo_efsmount_stack(app: App, param_store: ParamStore) -> list[ArgoEFSMountStack]:
    # preparing the efs mount deployment context
    eks_argo_efs_mount_context = EKSArgoEFSMountContext.from_context(
        node=app.node, param_store=param_store
    )

    # Skipping deployment for EFS mounts for sandbox deployments
    if eks_argo_efs_mount_context.deployment.sandbox_name is not None:
        return []

    # Constructing the parameters for the efs construct
    argo_efsmount = ArgoEFSMount.from_context(ctx=eks_argo_efs_mount_context)

    # Construct for the efs
    return [
        ArgoEFSMountStack(
            scope=app,
            id=argo_efsmount.id,
            stack_param=argo_efsmount,
            env=cdk.Environment(
                account=eks_argo_efs_mount_context.deployment.account.id,
                region=eks_argo_efs_mount_context.deployment.account.region,
            ),
        )
    ]


def _eks_s3mount_stack(
    app: App, param_store: ParamStore
) -> list[EKSS3MountStack | HelmChartStack]:
    # preparing the s3 mount deployment context
    eks_s3_mount_context = EKSS3MountContext.from_context(
        node=app.node, param_store=param_store
    )

    # Constructing the parameters for the s3 mount construct
    eks_s3mount = EKSS3Mount.from_context(ctx=eks_s3_mount_context)

    # Construct for the eks s3 mount stack
    # for sandbox deployment, creating only the persistent volumes and volume claims in
    # the sandbox namespace
    return [
        EKSS3MountStack(
            scope=app,
            id=eks_s3mount.id,
            stack_param=eks_s3mount,
            env=cdk.Environment(
                account=eks_s3mount.deployment.account.id,
                region=eks_s3mount.deployment.account.region,
            ),
        ),
        HelmChartStack(
            scope=app,
            id=f"{eks_s3mount.id}-helmchart",
            stack_param=eks_s3mount.helm_chart,
            env=cdk.Environment(
                account=eks_s3mount.deployment.account.id,
                region=eks_s3mount.deployment.account.region,
            ),
        ),
    ]


def _etl_metadata_stack(
    app: App, param_store: ParamStore
) -> list[MetadataStack | SandboxMetadataStack]:
    # preparing the metadata stack deployment context
    metadata_context = ETLMetadataContext.from_context(
        node=app.node, param_store=param_store
    )

    # Constructing the parameters for the metadata construct
    metadata = ETLMetadata.from_context(ctx=metadata_context)

    # Construct for the metadata

    # provisions rds cluster and other resources for non-sandbox environment
    if metadata_context.deployment.sandbox_name is None:
        metadata_stack = MetadataStack(
            scope=app,
            id=metadata.id,
            stack_param=metadata,
            env=cdk.Environment(
                account=metadata_context.deployment.account.id,
                region=metadata_context.deployment.account.region,
            ),
        )
    else:
        # executes the sql scripts for sandbox environment
        metadata_stack = SandboxMetadataStack(
            scope=app,
            id=metadata.id,
            stack_param=metadata,
            env=cdk.Environment(
                account=metadata_context.deployment.account.id,
                region=metadata_context.deployment.account.region,
            ),
        )

    return [metadata_stack]


def _etl_metadata_post_stack(
    app: App, param_store: ParamStore
) -> list[EtlMetadataPostStack]:
    # Preparing the metadata post stack deployment context
    metadata_context = ETLMetadataContext.from_context(
        node=app.node, param_store=param_store
    )

    # Constructing the parameters for the etl metadata post construct
    metadata_post = ETLMetadataPost.from_context(ctx=metadata_context)

    metadata_stack = EtlMetadataPostStack(
        scope=app,
        id=metadata_post.id,
        stack_param=metadata_post,
        env=cdk.Environment(
            account=metadata_context.deployment.account.id,
            region=metadata_context.deployment.account.region,
        ),
        param_store=param_store,
    )

    return [metadata_stack]


def _cloudwatch_stack(app: App, param_store: ParamStore) -> list[CloudWatchStack]:
    # preparing the cloudwatch deployment context
    metadata_context = CloudWatchContext.from_context(
        node=app.node, param_store=param_store
    )

    # Constructing the parameters for the metadata construct
    metadata = CloudWatch.from_context(ctx=metadata_context)

    # provisions cloudwatch resources (metrics, alarms, lambda, events)
    # for non sand-box environment
    if metadata_context.deployment.sandbox_name is None:
        return [
            CloudWatchStack(
                scope=app,
                id=metadata.id,
                stack_param=metadata,
                env=cdk.Environment(
                    account=metadata_context.deployment.account.id,
                    region=metadata_context.deployment.account.region,
                ),
            )
        ]
    return []


def _fluentbit_stack(app: App, param_store: ParamStore) -> list[FluentbitStack]:
    # preparing the fluentbit stack deployment context
    fluentbit_context = FluentbitContext.from_context(
        node=app.node, param_store=param_store
    )

    # Skipping deployment of fluentbit for sandbox deployments
    if fluentbit_context.deployment.sandbox_name is not None:
        return []

    # Constructing the parameters for the fluentbit construct
    fluentbit = Fluentbit.from_context(ctx=fluentbit_context)

    # Construct for the fluentbit
    return [
        FluentbitStack(
            scope=app,
            id=fluentbit.id,
            stack_param=fluentbit,
            env=cdk.Environment(
                account=fluentbit_context.deployment.account.id,
                region=fluentbit_context.deployment.account.region,
            ),
        )
    ]


def _services_stack(app: App, param_store: ParamStore) -> list[MicroServiceStack]:
    # preparing the microservices context
    services_context = ServicesContext.from_context(
        node=app.node, param_store=param_store
    )
    microservice_stacks = []

    for service_context in services_context.services:
        if service_context.skip_deployment is False:
            # Constructing the parameters for each microservice
            microservice = MicroService.from_context(ctx=service_context)
            microservice_stack = MicroServiceStack(
                scope=app,
                id=microservice.id,
                stack_param=microservice,
                env=cdk.Environment(
                    account=services_context.deployment.account.id,
                    region=services_context.deployment.account.region,
                ),
            )
            microservice_stacks.append(microservice_stack)
        else:
            print(f"Skipping deployment for service : {service_context.name}")
    return microservice_stacks


def _postgres_serverless_clusters_stack(
    app: App, param_store: ParamStore
) -> list[PostgresServerlessClusterStack | SandboxPostgresServerlessClusterStack]:
    # preparing the postgres serverless clusters context

    cluster_names = app.node.try_get_context("CLUSTER_NAMES")
    deploy_clusters = (
        [x.strip() for x in cluster_names.split(",")]
        if cluster_names is not None
        else []
    )

    postgres_serverless_clusters_context = (
        PostgresServerlessClustersContext.from_context(
            node=app.node, param_store=param_store
        )
    )
    postgres_serverless_clusters_stacks = []

    # Skipping deployment if no clusters are configured
    if (
        len(postgres_serverless_clusters_context.postgres_serverless_clusters) == 0
        or postgres_serverless_clusters_context.deployment is None
    ):
        return [Stack(app)]

    for (
        postgres_serverless_cluster_context
    ) in postgres_serverless_clusters_context.postgres_serverless_clusters:
        if (
            len(deploy_clusters) == 0
            or postgres_serverless_cluster_context.name in deploy_clusters
        ):
            if postgres_serverless_cluster_context.skip_deployment is False:
                # Constructing the parameters for each cluster
                postgres_serverless_cluster = PostgresServerlessCluster.from_context(
                    ctx=postgres_serverless_cluster_context
                )

                if postgres_serverless_cluster.deployment.sandbox_name is None:
                    postgres_serverless_cluster_stack = PostgresServerlessClusterStack(
                        scope=app,
                        id=postgres_serverless_cluster.id,
                        stack_param=postgres_serverless_cluster,
                        env=cdk.Environment(
                            account=postgres_serverless_cluster_context.deployment.account.id,
                            region=postgres_serverless_cluster_context.deployment.account.region,
                        ),
                    )
                else:
                    postgres_serverless_cluster_stack = SandboxPostgresServerlessClusterStack(
                        scope=app,
                        id=postgres_serverless_cluster.id,
                        stack_param=postgres_serverless_cluster,
                        env=cdk.Environment(
                            account=postgres_serverless_cluster_context.deployment.account.id,
                            region=postgres_serverless_cluster_context.deployment.account.region,
                        ),
                    )

                postgres_serverless_clusters_stacks.append(
                    postgres_serverless_cluster_stack
                )
            else:
                print(
                    "Skipping deployment for postgres serverless cluster:"
                    f" {postgres_serverless_cluster_context.name}"
                )
    return postgres_serverless_clusters_stacks


def _helmcharts_stack(app: App, param_store: ParamStore) -> list[HelmChartStack]:
    """Prepare the helmcharts context."""
    helmchart_names = app.node.try_get_context("HELM_CHART_NAMES")
    deploy_helmcharts = (
        [x.strip() for x in helmchart_names.split(",")]
        if helmchart_names is not None
        else []
    )
    helmcharts_folder = app.node.try_get_context("HELM_CHARTS_FOLDER")
    sandbox_name = app.node.try_get_context("SANDBOX_NAME")
    enable_api_gateway = app.node.try_get_context("ENABLE_API_GATEWAY")

    if helmcharts_folder is None:
        msg = "'HELM_CHARTS_FOLDER' is missing in the cdk context."
        raise ValueError(msg)

    helmcharts_context = HelmChartsContext.from_folder_context(
        node=app.node,
        param_store=param_store,
        helmcharts_folder=helmcharts_folder,
    )
    helmchart_stacks = []

    for helmchart_context in helmcharts_context.helmcharts:
        if len(deploy_helmcharts) == 0 or helmchart_context.name in deploy_helmcharts:
            if helmchart_context.skip_deployment is False:
                print(f"Creating stack for helmChart: {helmchart_context.name}")
                helmchart = HelmChart.from_context(ctx=helmchart_context)

                # For sandboxes, we only need this for very specific purposes
                if sandbox_name is not None and enable_api_gateway == "false":
                    print(
                        f"Disabling LoadBalancer and Ingress for sandbox {sandbox_name}, helmChart: {helmchart_context.name}."
                    )
                    helmchart.helm_chart.values_dict.setdefault("loadbalancer", {})[
                        "enabled"
                    ] = False
                    helmchart.helm_chart.values_dict.setdefault("ingress", {})[
                        "enabled"
                    ] = False

                helmchart_stack = HelmChartStack(
                    scope=app,
                    id=helmchart.id,
                    stack_param=helmchart,
                    env=cdk.Environment(
                        account=helmcharts_context.deployment.account.id,
                        region=helmcharts_context.deployment.account.region,
                    ),
                )
                print(f"HelmChart created: {helmchart.helm_chart}")
                helmchart_stacks.append(helmchart_stack)
            else:
                print(f"Skipping deployment for helm chart: {helmchart_context.name}")

    # foreach helm chart checking if there is any parent chart to be deployed first and
    # adding dependency accordingly to the respective stack
    for stack in helmchart_stacks:
        if stack.stack_param.deploy_after is not None:
            for parent_chart in stack.stack_param.deploy_after:
                parent_stacks = list(
                    filter(
                        lambda x: x.stack_param.name == parent_chart,
                        helmchart_stacks,
                    )
                )
                if len(parent_stacks) > 0:
                    parent_stack = parent_stacks[0]
                    stack.add_dependency(parent_stack)
                else:
                    msg = (
                        f"Cannot deploy helmchart: '{stack.stack_param.name}', since"
                        f" stack not found with parent chart : '{parent_chart}' to add"
                        " as dependency."
                    )
                    raise ValueError(msg)

    return helmchart_stacks


def _apigateways_stack(app: App, param_store: ParamStore) -> list[ApiGatewayStack]:
    """
    Prepare the apigateways context.

    This stack gets open api definitions from a local folder, merges definitions and
    creates grouped API gateways.
    """
    apigateways_context = ApiGatewaysContext.from_context(
        node=app.node, param_store=param_store
    )

    apigateway_stacks: list = []

    active_apigateways = [
        context
        for context in apigateways_context.apigateways
        if not context.skip_deployment
    ]
    skip_apigateways = [
        context
        for context in apigateways_context.apigateways
        if context.skip_deployment
    ]
    for skip_apigateway in skip_apigateways:
        print(f"Skipping deployment for api gateway : {skip_apigateway.name}")

    # Constructing the parameters for each api gateway
    apigateways = [
        ApiGateway.from_context(ctx=context) for context in active_apigateways
    ]

    openapi_resources_folder = app.node.try_get_context("OPENAPI_RESOURCES_FOLDER")

    groups = sorted({apigateway.cdk_group_name for apigateway in apigateways})
    for group in groups:
        filtered_apigateways = [
            apigateway
            for apigateway in apigateways
            if apigateway.cdk_group_name == group
        ]
        if filtered_apigateways:
            api_stack_id = f"apigateway-stack-{group}"
            if apigateways_context.deployment.sandbox_name is not None:
                api_stack_id = (
                    f"{api_stack_id}-{apigateways_context.deployment.sandbox_name}"
                )
            apigateway_stacks.append(
                ApiGatewayStack(
                    scope=app,
                    id=api_stack_id,
                    stack_param_list=filtered_apigateways,
                    openapi_resources_folder=openapi_resources_folder,
                    context_group=group,
                    env=cdk.Environment(
                        account=apigateways_context.deployment.account.id,
                        region=apigateways_context.deployment.account.region,
                    ),
                )
            )
    return apigateway_stacks


def _job_oao_websocket_pipe_stack(
    app: App, param_store: ParamStore
) -> list[JobOaoWebsocketPipeStack]:
    metadata_context = JobOaoWebsocketPipeContext.from_context(
        node=app.node, param_store=param_store
    )

    # Constructing the parameters for the metadata construct
    metadata = JobOaoWebsocketPipe.from_context(ctx=metadata_context)

    if (
        metadata_context.deployment.sandbox_name is None
        and not metadata_context.skip_deployment
    ):
        return [
            JobOaoWebsocketPipeStack(
                scope=app,
                id=metadata.id,
                stack_param=metadata,
                env=cdk.Environment(
                    account=metadata_context.deployment.account.id,
                    region=metadata_context.deployment.account.region,
                ),
            )
        ]
    return []


def _prometheus_stack(app: App, param_store: ParamStore) -> list[PrometheusStack]:
    """Prepare the prometheus stack deployment context."""
    prometheus_context = PrometheusContext.from_context(
        node=app.node, param_store=param_store
    )

    # Skipping deployment of prometheus for sandbox deployments
    if prometheus_context.deployment.sandbox_name is not None:
        return []

    # Constructing the parameters for the fluentbit construct
    prometheus = Prometheus.from_context(ctx=prometheus_context)

    # Construct for the fluentbit
    return [
        PrometheusStack(
            scope=app,
            id=prometheus.id,
            stack_param=prometheus,
            env=cdk.Environment(
                account=prometheus_context.deployment.account.id,
                region=prometheus_context.deployment.account.region,
            ),
        )
    ]


def _grafana_stack(app: App, param_store: ParamStore) -> list[GrafanaStack]:
    """Prepare the grafana stack deployment context."""
    grafana_context = GrafanaContext.from_context(
        node=app.node, param_store=param_store
    )

    # Skipping deployment of grafana for sandbox deployments
    if grafana_context.deployment.sandbox_name is not None:
        return []

    # Constructing the parameters for the grafana construct
    grafana = Grafana.from_context(ctx=grafana_context)

    # Construct for the grafana
    return [
        GrafanaStack(
            scope=app,
            id=grafana.id,
            stack_param=grafana,
            env=cdk.Environment(
                account=grafana_context.deployment.account.id,
                region=grafana_context.deployment.account.region,
            ),
        )
    ]


def _karpenter_stack(app: App, param_store: ParamStore) -> list[KarpenterStack]:
    # preparing the karpenter deployment context
    eks_karpenter_context = EKSKarpenterContext.from_context(
        node=app.node, param_store=param_store
    )

    # Constructing the parameters for the prerequisites
    karpenter = Karpenter.from_context(ctx=eks_karpenter_context)

    # Construct for the Karpenter
    return [
        KarpenterStack(
            scope=app,
            id=karpenter.id,
            stack_param=karpenter,
            env=cdk.Environment(
                account=eks_karpenter_context.deployment.account.id,
                region=eks_karpenter_context.deployment.account.region,
            ),
        ),
    ]


def _adot_collector_stack(
    app: App, param_store: ParamStore
) -> list[ADOTCollectorStack]:
    """Prepare the ADOT collector stack deployment context."""
    adot_collector_context = ADOTCollectorContext.from_context(
        node=app.node, param_store=param_store
    )

    # Skipping deployment of ADOT collector for sandbox deployments
    if adot_collector_context.deployment.sandbox_name is not None:
        return []

    # Constructing the parameters for the ADOT collector construct
    adotcollector = ADOTCollector.from_context(ctx=adot_collector_context)

    # Construct for the ADOT Collector
    return [
        ADOTCollectorStack(
            scope=app,
            id=adotcollector.id,
            stack_param=adotcollector,
            env=cdk.Environment(
                account=adot_collector_context.deployment.account.id,
                region=adot_collector_context.deployment.account.region,
            ),
        )
    ]


def _stack(app: App, param_store: ParamStore) -> list[Stack]:
    """Return stack based on the input module name."""
    module_name = app.node.try_get_context("ADDF_MODULE_NAME")

    deployment = app.node.try_get_context("deployment")

    # Skipping deployment if the module is configured to be skipped
    if "skipModules" in deployment and module_name in deployment["skipModules"]:
        return [Stack(app)]

    module_stack_map = {
        "argo-prerequesites": _argo_prerequesites_stack,
        "argo-workflows": _argo_workflow_stack,
        "argo-events": _argo_events_stack,
        "argo-efsmount": _argo_efsmount_stack,
        "etl-metadata": _etl_metadata_stack,
        "etl-metadata-post": _etl_metadata_post_stack,
        "services": _services_stack,
        "fluentbit": _fluentbit_stack,
        "prometheus": _prometheus_stack,
        "grafana": _grafana_stack,
        "adot-collector": _adot_collector_stack,
        "helmcharts": _helmcharts_stack,
        "apigateways": _apigateways_stack,
        "job-oao-websocket-pipe": _job_oao_websocket_pipe_stack,
        "eks-s3mount": _eks_s3mount_stack,
        "postgres-serverless-clusters": _postgres_serverless_clusters_stack,
        "karpenter": _karpenter_stack,
        "cloudwatch": _cloudwatch_stack,
    }
    return module_stack_map[module_name](app, param_store)


def _configure_tags(stacks: Construct) -> None:
    """Configure tags for all stacks created by this app."""
    for stack in stacks:
        if hasattr(stack, "stack_param") and stack.stack_param is not None:
            tags = {
                "system": "raas",
                "task": "infra",
                "env": stack.stack_param.deployment.environment_name,
            }
            for k, v in tags.items():
                Tags.of(stack).add(k, v)


def configure_app(app: App, param_store: ParamStore | None = None) -> list[Stack]:
    """Configure the CDK app by adding stacks."""
    if param_store is None:
        # param_store is commonly passed for tests as MockParameterStore;
        # default should be the real SSM access
        param_store = SSMParameterStore()
    stack = _stack(app, param_store)
    _configure_tags(stack)
    return stack

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Microservice Parameters for CDK stack deployment.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from typing import Any

from raas_infra.context import (
    ContextModel,
    Deployment,
    EKSCluster,
    EventBus,
    KubernetesServiceAccount,
    OAOContext,
    ServiceContext,
)


class MicroService(ContextModel):
    """CDK context configuration for the services' module."""

    name: str
    database_username: str | None = None
    kubernetes_service_account: KubernetesServiceAccount
    eks_cluster: EKSCluster
    postgres_db_name: str | None = None
    postgres_cluster_writer_endpoint: str | None = None
    postgres_cluster_resource_identifier: str | None = None
    deployment: Deployment
    output_metadata_path: str
    # https://docs.pydantic.dev/latest/concepts/models/#fields-with-non-hashable-default-values
    additional_iam_role_policies: dict = {}  # noqa: RUF012 # pydantic wants it so
    event_bus: EventBus
    oao: list[OAOContext] = []  # noqa: RUF012 # pydantic wants it so
    queues: dict
    ref: dict = {}  # noqa: RUF012 # pydantic wants it so

    @classmethod
    def from_context(cls, ctx: ServiceContext) -> "MicroService":
        """Create model from the input dictionary."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])

        # Fetching EKS cluster and Argo prerequisites deployment related metadata
        props = {}
        if "metadata" in ctx.ref:
            metadata = json.loads(ctx.ref["metadata"])
            if "postgres_db_name" in metadata:
                # used for raas (not dq)
                props["postgres_db_name"] = metadata["postgres_db_name"]
            # this can either be metadata postgres (for raas) or dq postgres
            props["postgres_cluster_writer_endpoint"] = metadata[
                "postgres_cluster_writer_endpoint"
            ]
            props["postgres_cluster_resource_identifier"] = metadata[
                "postgres_cluster_resource_identifier"
            ]

        id = ctx.get_submodule_id(
            module_name=ctx.deployment.module_name,
            sub_module_name=ctx.name,
        )

        event_bus = EventBus.from_context(ctx.ref["eventBus"])
        props["id"] = id
        props["name"] = ctx.name
        props["database_username"] = ctx.database_username
        props["kubernetes_service_account"] = ctx.kubernetes_service_account
        props["deployment"] = ctx.deployment
        props["eks_cluster"] = eks_cluster
        props["output_metadata_path"] = ctx.metadata_output_ssm_path
        props["additional_iam_role_policies"] = ctx.additional_iam_role_policies
        props["deployment"] = ctx.deployment
        props["event_bus"] = event_bus
        props["oao"] = ctx.oao
        props["ref"] = ctx.ref

        queues: dict[str, dict[str, Any]] = {}
        if ctx.queues is not None:
            for queue_context in ctx.queues:
                if queue_context.name is None and queue_context.full_name is None:
                    msg = (
                        "Please specify either 'name' or 'fullName'"
                        f" for queues in services.{ctx.name}"
                    )
                    raise ValueError(msg)

                queue_prefix = id
                suffix = None

                # Consider "name" as a suffix to the deployment name and module name
                if queue_context.name is not None:
                    suffix = queue_context.name

                # Consider "full_name" as a suffix to the deployment name
                else:
                    queue_prefix = ctx.get_project_deployment_id(
                        sandbox_name=ctx.deployment.sandbox_name
                    )
                    suffix = queue_context.full_name

                queue_value: dict[str, Any] = {
                    "spec": queue_context,
                }

                if queue_context.dlq is not None:
                    dlq_name = (
                        f"{queue_prefix}-{suffix}-dl.fifo"
                        if queue_context.is_fifo
                        else f"{queue_prefix}-{suffix}-dl"
                    )
                    queue_value.update({"dlq_name": dlq_name})

                queue_name = (
                    f"{queue_prefix}-{suffix}.fifo"
                    if queue_context.is_fifo
                    else f"{queue_prefix}-{suffix}"
                )

                queues.update({str(queue_name): queue_value})

        props["queues"] = queues

        return cls.model_validate(props)

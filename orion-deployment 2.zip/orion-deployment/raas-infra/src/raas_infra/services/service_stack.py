#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
MicroService CDK stack.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
import logging
from typing import cast

import aws_cdk.aws_events as events
import aws_cdk.aws_iam as iam
import aws_cdk.aws_sqs as sqs
import aws_cdk.aws_ssm as ssm
from aws_cdk import RemovalPolicy, Stack, Tags, aws_iam, aws_logs, aws_pipes
from constructs import Construct, IConstruct

from raas_infra.constructs.eventbridge_route_to_sqs_rule import (
    EventBridgeRouteToSqsRule,
)
from raas_infra.constructs.iamrole_kubernetes_serviceaccount import (
    IamRoleForKubernetesServiceAccount,
)
from raas_infra.context import QueueContext
from raas_infra.services.service_param import MicroService


class MicroServiceStack(Stack):
    """Creates the resources needed by MicroServices running in EKS."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: MicroService,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys artifacts related to microservice.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param
        self.oao_subscriber_input_oao_sqs_list: list[sqs.CfnQueue] = []
        self.oao_publisher_output_oao_sqs_list: list[sqs.CfnQueue] = []

        # Create tags (automatically applied to child constructs).
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        self.output_dict = {}

        # Provision publisher and subscriber oao sqs queues and rule
        self.add_oao_eventing()

        # Provision SQS queues
        self.add_sqs()

        # Create an IAM role for the Kubernetes service account
        id_ = f"{stack_param.name}-ServiceAccountRole"
        role_name = stack_param.kubernetes_service_account.iam_role_name
        service_account_name = stack_param.kubernetes_service_account.name
        kubernetes_service_account_namespace = (
            stack_param.kubernetes_service_account.namespace
        )

        if stack_param.deployment and stack_param.deployment.sandbox_name:
            id_ = f"{id_}-{stack_param.deployment.sandbox_name}"
            role_name = f"{role_name}-{stack_param.deployment.sandbox_name}"
            service_account_name = (
                f"{service_account_name}-{stack_param.deployment.sandbox_name}"
            )
            kubernetes_service_account_namespace = f"{kubernetes_service_account_namespace}-{stack_param.deployment.sandbox_name}"

        service_account_role = IamRoleForKubernetesServiceAccount(
            scope=self,
            id_=id_,
            role_name=role_name,
            role_description=stack_param.kubernetes_service_account.iam_role_description,
            kubernetes_service_account_name=service_account_name,
            kubernetes_service_account_namespace=kubernetes_service_account_namespace,
            eks_cluster_metadata=stack_param.eks_cluster,
        )

        role_policies = stack_param.additional_iam_role_policies
        # Add a policy to connect to RDS/Aurora
        if stack_param.postgres_cluster_resource_identifier is not None:
            db_instance_id = stack_param.postgres_cluster_resource_identifier
            db_user = stack_param.database_username

            account = stack_param.deployment.account
            role_policies.update(
                {
                    "rds_postgres_access_policy": {
                        "actions": ["rds-db:connect"],
                        "resources": [
                            f"arn:{account.partition}:rds-db:{account.region}:{account.id}:dbuser:{db_instance_id}/{db_user}"
                        ],
                        "effect": "ALLOW",
                    }
                }
            )

        if stack_param.queues is not None:
            for queue in self.service_queues:
                # Add a policy to write messages to the sqs queue
                policy_name = (
                    queue.queue_name.replace(".", "_").replace("-", "_") + "_policy"
                )
                role_policies.update(
                    {
                        policy_name: {
                            "actions": [
                                "sqs:CancelMessageMoveTask",
                                "sqs:ChangeMessageVisibility",
                                "sqs:DeleteMessage",
                                "sqs:GetQueueAttributes",
                                "sqs:GetQueueUrl",
                                "sqs:ListMessageMoveTasks",
                                "sqs:ListQueueTags",
                                "sqs:ReceiveMessage",
                                "sqs:SendMessage",
                                "sqs:StartMessageMoveTask",
                            ],
                            "resources": [queue.attr_arn],
                            "effect": "ALLOW",
                        }
                    }
                )

        if self.oao_subscriber_input_oao_sqs_list:
            # Add a policy to read messages from the oao subscriber sqs queue
            role_policies.update(
                {
                    "oao_subscriber_sqs_policy": {
                        "actions": [
                            "sqs:StartMessageMoveTask",
                            "sqs:DeleteMessage",
                            "sqs:GetQueueUrl",
                            "sqs:CancelMessageMoveTask",
                            "sqs:ChangeMessageVisibility",
                            "sqs:ListMessageMoveTasks",
                            "sqs:ReceiveMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:ListQueueTags",
                        ],
                        "resources": [
                            oao_subscriber.attr_arn
                            for oao_subscriber in self.oao_subscriber_input_oao_sqs_list
                        ],
                        "effect": "ALLOW",
                    }
                }
            )
        if self.oao_publisher_output_oao_sqs_list:
            # Add a policy to write messages to the oao publisher sqs queue
            role_policies.update(
                {
                    "oao_publisher_sqs_policy": {
                        "actions": [
                            "sqs:StartMessageMoveTask",
                            "sqs:GetQueueUrl",
                            "sqs:CancelMessageMoveTask",
                            "sqs:ChangeMessageVisibility",
                            "sqs:ListMessageMoveTasks",
                            "sqs:SendMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:ListQueueTags",
                        ],
                        "resources": [
                            oao_publisher.attr_arn
                            for oao_publisher in self.oao_publisher_output_oao_sqs_list
                        ],
                        "effect": "ALLOW",
                    }
                }
            )

        for name in role_policies:
            additional_policy = role_policies[name]
            resources = additional_policy["resources"]
            flat_resources = []
            for resource in resources:
                if isinstance(resource, list):
                    flat_resources.extend(resource)
                else:
                    flat_resources.append(resource)

            policy = iam.PolicyDocument(
                statements=[
                    iam.PolicyStatement(
                        actions=additional_policy["actions"],
                        resources=flat_resources,
                        effect=aws_iam.Effect(additional_policy["effect"]),
                    )
                ]
            )
            service_account_role.role.attach_inline_policy(
                iam.Policy(
                    scope=self,
                    id=f"{stack_param.name}-{name}",
                    document=policy,
                    policy_name=name,
                )
            )

        # Outputs
        self.output_dict.update(
            {
                "IamRoleName": service_account_role.role.role_name,
                "IamRoleArn": service_account_role.role.role_arn,
            }
        )
        output_value = json.dumps(self.output_dict)
        logging.debug(
            f"SSM output value for {stack_param.name} service: {output_value}"
        )
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

    def add_sqs_sender_role_permissions(
        self, queue_spec: QueueContext, queue: sqs.CfnQueue
    ) -> None:
        """Add sqs sender permissions to the roles configured."""
        for role_arn_name in queue_spec.add_send_permissions_to_role_arns:
            role_arn = queue_spec.add_send_permissions_to_role_arns[role_arn_name]

            self.queue_send_role = iam.Role.from_role_arn(
                scope=self,
                id=f"{self.stack_param.name}-{role_arn_name}-send-lookup",
                role_arn=role_arn,
            )

            queue_send_policy = iam.PolicyDocument(
                statements=[
                    iam.PolicyStatement(
                        actions=[
                            "sqs:SendMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:GetQueueUrl",
                        ],
                        resources=[queue.attr_arn],
                        effect=aws_iam.Effect.ALLOW,
                    )
                ]
            )
            self.queue_send_role.attach_inline_policy(
                iam.Policy(
                    scope=self,
                    id=f"{self.stack_param.name}-{role_arn_name}-sender-queues",
                    document=queue_send_policy,
                    policy_name=f"{self.stack_param.name}-sqs-sender-policy",
                )
            )

    def add_sqs_receiver_role_permissions(
        self, queue_spec: QueueContext, queue: sqs.CfnQueue
    ) -> None:
        """Add sqs receiver permissions to the roles configured."""
        for role_arn_name in queue_spec.add_receive_permissions_to_role_arns:
            role_arn = queue_spec.add_receive_permissions_to_role_arns[role_arn_name]
            print(f"Role ARN to add receive permissions: {role_arn}")

            self.queue_receiver_role = iam.Role.from_role_arn(
                scope=self,
                id=f"{self.stack_param.name}-{role_arn_name}-receive-lookup",
                role_arn=role_arn,
            )

            queue_receive_policy = iam.PolicyDocument(
                statements=[
                    iam.PolicyStatement(
                        actions=[
                            "sqs:StartMessageMoveTask",
                            "sqs:DeleteMessage",
                            "sqs:GetQueueUrl",
                            "sqs:CancelMessageMoveTask",
                            "sqs:ChangeMessageVisibility",
                            "sqs:ListMessageMoveTasks",
                            "sqs:ReceiveMessage",
                            "sqs:GetQueueAttributes",
                            "sqs:ListQueueTags",
                        ],
                        resources=[queue.attr_arn],
                        effect=aws_iam.Effect.ALLOW,
                    )
                ]
            )
            self.queue_receiver_role.attach_inline_policy(
                iam.Policy(
                    scope=self,
                    id=f"{self.stack_param.name}-{role_arn_name}-receiver-queues",
                    document=queue_receive_policy,
                    policy_name=f"{self.stack_param.name}-sqs-receiver-policy",
                )
            )

    def add_sqs(self) -> None:
        """Add service sqs queues"""
        output_sqs_dict = {}
        self.service_queues = []

        for queue_name, queue_dict in self.stack_param.queues.items():
            queue_spec = queue_dict["spec"]

            redrive_allow_policy = None
            redrive_policy = None

            if queue_spec.dlq is not None:
                dlq_name = queue_dict["dlq_name"]
                dl_queue = self._create_queue(dlq_name, queue_spec)
                dl_queue.message_retention_period = (
                    queue_spec.dlq.message_retention_period
                )
                dl_queue.visibility_timeout = queue_spec.dlq.message_visibility_timeout

                redrive_policy = {
                    "deadLetterTargetArn": dl_queue.attr_arn,
                    "maxReceiveCount": queue_spec.dlq.max_receive_count,
                }
                account = self.stack_param.deployment.account
                redrive_allow_policy = {
                    "redrivePermission": "byQueue",
                    "sourceQueueArns": [
                        f"arn:{account.partition}:sqs:{self.region}:{self.account}:{queue_name}"
                    ],
                }

            queue = self._create_queue(queue_name, queue_spec)
            queue.redrive_policy = redrive_policy
            queue.redrive_allow_policy = redrive_allow_policy

            # Apply sender permissions to the SQS queue for the configured roles
            self.add_sqs_sender_role_permissions(queue_spec=queue_spec, queue=queue)

            # Apply receiver permissions to the SQS queue for the configured roles
            self.add_sqs_receiver_role_permissions(queue_spec=queue_spec, queue=queue)

            self.service_queues.append(queue)

            if queue_spec.pipe_to_event_bridge:
                # create an EventBridge pipe that routes the messages to a
                # target event bus
                pipe_spec = queue_spec.pipe_to_event_bridge

                # generate a pipe name, will also be used for the IAM role and
                # CloudWatch logs
                base_name = self.stack_param.get_id_without_module()
                pipe_name = f"{base_name}-{pipe_spec.pipe_name}"

                target_bus = (
                    "default"
                    if pipe_spec.use_default_event_bus
                    else self.stack_param.event_bus.oao_local
                )
                event_bus = events.EventBus.from_event_bus_name(
                    self, "event-bus", event_bus_name=target_bus
                )

                # create an IAM role that will be used by the pipe;
                # it needs access to both SQS and EventBridge
                iam_role_name = pipe_name
                pipe_role = iam.Role(
                    self,
                    f"{iam_role_name}-role",
                    role_name=iam_role_name,
                    assumed_by=iam.ServicePrincipal("pipes.amazonaws.com"),
                )
                pipe_role_policy_statement_sqs = {
                    "Effect": "Allow",
                    "Action": [
                        "sqs:ReceiveMessage",
                        "sqs:DeleteMessage",
                        "sqs:GetQueueAttributes",
                    ],
                    "Resource": [queue.attr_arn],
                }
                pipe_role.add_to_principal_policy(
                    iam.PolicyStatement.from_json(pipe_role_policy_statement_sqs)
                )
                pipe_role_policy_statement_bus = {
                    "Effect": "Allow",
                    "Action": [
                        "events:PutEvents",
                    ],
                    "Resource": [event_bus.event_bus_arn],
                }
                pipe_role.add_to_principal_policy(
                    iam.PolicyStatement.from_json(pipe_role_policy_statement_bus)
                )

                # no logging is the default
                log_config = aws_pipes.CfnPipe.PipeLogConfigurationProperty(
                    cloudwatch_logs_log_destination=None,
                    level="INFO",
                )
                if pipe_spec.add_cloudwatch_log:
                    pipe_log_group_name = f"/aws/vendedlogs/pipes/{pipe_name}"
                    log_group = aws_logs.LogGroup(
                        self,
                        pipe_log_group_name,
                        log_group_name=pipe_log_group_name,
                        retention=aws_logs.RetentionDays.INFINITE,
                        removal_policy=RemovalPolicy.DESTROY,
                    )
                    log_destination = (
                        aws_pipes.CfnPipe.CloudwatchLogsLogDestinationProperty(
                            log_group_arn=log_group.log_group_arn
                        )
                    )
                    log_config = aws_pipes.CfnPipe.PipeLogConfigurationProperty(
                        cloudwatch_logs_log_destination=log_destination,
                        level="INFO",
                        include_execution_data=["ALL"],
                    )
                aws_pipes.CfnPipe(
                    self,
                    f"{pipe_name}-pipe",
                    name=pipe_name,
                    description=pipe_spec.pipe_description,
                    role_arn=pipe_role.role_arn,
                    source=queue.attr_arn,
                    source_parameters=aws_pipes.CfnPipe.PipeSourceParametersProperty(
                        sqs_queue_parameters=aws_pipes.CfnPipe.PipeSourceSqsQueueParametersProperty(
                            batch_size=1,
                        )
                    ),
                    target=event_bus.event_bus_arn,
                    target_parameters=aws_pipes.CfnPipe.PipeTargetParametersProperty(
                        event_bridge_event_bus_parameters=aws_pipes.CfnPipe.PipeTargetEventBridgeEventBusParametersProperty(
                            detail_type=pipe_spec.detail_type,
                        ),
                        input_template=pipe_spec.transformer,
                    ),
                    log_configuration=log_config,
                )

            if queue_spec.name is not None:
                queue_name_ssm_key = queue_spec.name.replace("-", "_").replace(".", "_")
            if queue_spec.full_name is not None:
                queue_name_ssm_key = queue_spec.full_name.replace("-", "_").replace(
                    ".", "_"
                )

            output_sqs_dict[f"sqs_{queue_name_ssm_key}_arn"] = queue.attr_arn
            output_sqs_dict[f"sqs_{queue_name_ssm_key}_name"] = queue_name
            output_sqs_dict[f"sqs_{queue_name_ssm_key}_url"] = queue.attr_queue_url

        self.output_dict.update(output_sqs_dict)

    def _create_queue(self, queue_name: str, queue_spec: QueueContext) -> sqs.CfnQueue:
        return sqs.CfnQueue(
            self,
            queue_name,
            queue_name=queue_name,
            fifo_queue=True if queue_spec.is_fifo else None,
            content_based_deduplication=(True if queue_spec.is_fifo else None),
            deduplication_scope=("messageGroup" if queue_spec.is_fifo else None),
            fifo_throughput_limit=("perMessageGroupId" if queue_spec.is_fifo else None),
            message_retention_period=queue_spec.message_retention_period,
            visibility_timeout=queue_spec.message_visibility_timeout,
        )

    def add_oao_eventing(self) -> None:
        """Add SQS for subscribing from local oao event bus and publish to SQS"""
        # add job request input oao sqs with required permissions
        for oao in self.stack_param.oao:
            prefix = f"{self.stack_param.deployment.project_name}-{self.stack_param.deployment.name}"

            # append sandbox name for sandbox deployment
            if self.stack_param.deployment.sandbox_name is not None:
                prefix = f"{prefix}-{self.stack_param.deployment.sandbox_name}"

            if oao.subscriber is not None:
                oao_subscriber_input_oao_sqs_name = f"{prefix}-{oao.subscriber.name}"
                self.oao_subscriber_input_oao_sqs = sqs.CfnQueue(
                    self,
                    f"{oao_subscriber_input_oao_sqs_name}-cfnqueue",
                    queue_name=oao_subscriber_input_oao_sqs_name,
                )
                self.oao_subscriber_input_oao_sqs_list.append(
                    self.oao_subscriber_input_oao_sqs
                )
                self.oao_subscriber_input_oao_sqs_policy = sqs.CfnQueuePolicy(
                    self,
                    f"{oao_subscriber_input_oao_sqs_name}-sqs-policy",
                    queues=[oao_subscriber_input_oao_sqs_name],
                    policy_document=iam.PolicyDocument(
                        statements=[
                            iam.PolicyStatement(
                                actions=[
                                    "sqs:SendMessage",
                                    "sqs:GetQueueAttributes",
                                    "sqs:GetQueueUrl",
                                ],
                                resources=[self.oao_subscriber_input_oao_sqs.attr_arn],
                                effect=iam.Effect.ALLOW,
                                principals=[
                                    iam.ServicePrincipal("events.amazonaws.com")
                                ],
                            )
                        ]
                    ),
                )

                ssm_param_subscriber_name = oao.subscriber.name.replace("-", "_")
                # Adding the publisher oao event queue details to metadata output
                self.output_dict.update(
                    {
                        f"sqs_{ssm_param_subscriber_name}_queue_arn": (
                            self.oao_subscriber_input_oao_sqs.attr_arn
                        ),
                        f"sqs_{ssm_param_subscriber_name}_queue_name": (
                            self.oao_subscriber_input_oao_sqs.queue_name
                        ),
                        f"sqs_{ssm_param_subscriber_name}_queue_url": (
                            self.oao_subscriber_input_oao_sqs.attr_queue_url
                        ),
                    }
                )

                # add event bus rule to route oao event to the input sqs
                sqs_queue = sqs.Queue.from_queue_arn(
                    self,
                    f"{oao_subscriber_input_oao_sqs_name}-queue",
                    self.oao_subscriber_input_oao_sqs.attr_arn,
                )
                event_bus_name = (
                    self.stack_param.event_bus.default
                    if oao.subscriber.use_default_event_bus
                    else self.stack_param.event_bus.oao_local
                )

                self.job_request_input_rule = EventBridgeRouteToSqsRule(
                    scope=self,
                    id_=oao_subscriber_input_oao_sqs_name,
                    rule_name=oao_subscriber_input_oao_sqs_name,
                    rule_description=oao.subscriber.rule.description,
                    event_bus_name=event_bus_name,
                    event_pattern=events.EventPattern(
                        detail_type=[oao.subscriber.rule.detail_type]
                    ),
                    target_input_object=None,
                    target_sqs=sqs_queue,
                    attach_log_group_as_target=self.stack_param.deployment.sandbox_name
                    is None
                    and oao.subscriber.append_log_group_as_a_target is True,
                )

            # If oao publisher is configured to send back status/updates to
            # oao event bus
            if oao.publisher is not None:
                # add published sqs with required permissions
                oao_publisher_output_oao_sqs_name = f"{prefix}-{oao.publisher.name}"
                self.oao_publisher_output_oao_sqs = sqs.CfnQueue(
                    self,
                    oao_publisher_output_oao_sqs_name,
                    queue_name=oao_publisher_output_oao_sqs_name,
                )
                self.oao_publisher_output_oao_sqs_list.append(
                    self.oao_publisher_output_oao_sqs
                )
                self.oao_publisher_output_oao_sqs_policy = sqs.CfnQueuePolicy(
                    self,
                    f"{oao_publisher_output_oao_sqs_name}-sqs-policy",
                    queues=[oao_publisher_output_oao_sqs_name],
                    policy_document=iam.PolicyDocument(
                        statements=[
                            iam.PolicyStatement(
                                actions=[
                                    "sqs:ReceiveMessage",
                                    "sqs:GetQueueAttributes",
                                    "sqs:GetQueueUrl",
                                    "sqs:DeleteMessage",
                                ],
                                resources=[self.oao_publisher_output_oao_sqs.attr_arn],
                                effect=iam.Effect.ALLOW,
                                principals=[
                                    iam.ServicePrincipal("events.amazonaws.com")
                                ],
                            )
                        ]
                    ),
                )

                ssm_param_publisher_name = oao.publisher.name.replace("-", "_")
                # Adding the raas job request status queue details to metadata output
                self.output_dict.update(
                    {
                        f"sqs_{ssm_param_publisher_name}_queue_url": (
                            self.oao_publisher_output_oao_sqs.attr_queue_url
                        ),
                        f"sqs_{ssm_param_publisher_name}_queue_arn": (
                            self.oao_publisher_output_oao_sqs.attr_arn
                        ),
                        f"sqs_{ssm_param_publisher_name}_queue_name": (
                            self.oao_publisher_output_oao_sqs.queue_name
                        ),
                    }
                )

# RaaS Services


RaaS microservices such as Job Management, Job Caching, Map Service would require provisioning of IAM roles in AWS, with necessary permissions to access ETLMetadata RDS database.

Modules in this folder are deployed for the same.

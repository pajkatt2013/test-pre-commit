#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Parameters for deploying RaaS ETLMetadata Proxy Network Stack - CDK stack deployment.

(C) 2024 Qualcomm Technologies, Inc.  All rights reserved.
"""

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    ETLMetadataContext,
    Postgres,
)


class ETLMetadataPost(ContextModel):
    """Managing the params for RaaS ETLMetadata Proxy Network CDK deployment"""

    id: str
    vpc: VPC
    deployment: Deployment
    postgres: Postgres
    output_metadata_path: str

    @classmethod
    def from_context(cls, ctx: ETLMetadataContext) -> "ETLMetadataPost":
        """Read values from the AWS CDK context."""
        vpc = VPC.from_context(ctx.ref["vpc"])
        postgres = Postgres.from_context(ctx.ref["postgres"])

        id_ = ctx.get_id()
        props = {
            "id": id_,
            "vpc": vpc,
            "postgres": postgres,
            "deployment": ctx.deployment,
            "output_metadata_path": ctx.metadata_output_ssm_path,
        }

        return cls.model_validate(props)

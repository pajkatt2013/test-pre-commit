#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
RaaS ETLMetadata Proxy Network Stack - CDK stack deployment.

(C) 2024 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
import logging
import socket

import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_elasticloadbalancingv2 as elbv2
import aws_cdk.aws_elasticloadbalancingv2_targets as elbv2_tgt
import aws_cdk.aws_iam as iam
from aws_cdk import Stack
from constructs import Construct

from raas_infra.etl_metadata_post.etl_metadata_post_params import ETLMetadataPost
from raas_infra.utils.ssm import ParamStore

logger = logging.getLogger()
logger.setLevel("INFO")


class EtlMetadataPostStack(Stack):
    """Build the Stack for Network Connection between the RDS Proxy and RDS"""

    def __init__(
        self,
        id: str,
        scope: Construct,
        stack_param: ETLMetadataPost,
        param_store: ParamStore,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="Deploys RDS Postgres Proxy Network connection and RDS.",
            **kwargs,
        )
        self.param_store = param_store

        if not stack_param.postgres.requires_proxy:
            logger.info("Skipping proxy network creation because it is not activated")
            return

        # VPC lookup based on vpc id
        vpc = ec2.Vpc.from_lookup(self, id="VPC", vpc_id=stack_param.vpc.id)

        # List of subnets
        private_subnets = []
        non_routable_subnets = json.loads(stack_param.vpc.non_routable_subnet_ids)
        routable_subnets = json.loads(stack_param.vpc.routable_subnet_ids)
        consider_subnets = (
            routable_subnets
            if stack_param.postgres.use_routable_subnets is True
            else non_routable_subnets
        )

        for idx, subnet_id in enumerate(consider_subnets):
            private_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"subnet{idx}", subnet_id=subnet_id
                )
            )

        ssm_metadata = self._get_rds_metadata(stack_param.output_metadata_path)

        postgres_cluster_name = ssm_metadata.get("postgres_cluster_name")

        proxy_endpoint_url = ssm_metadata.get("proxy_endpoint_url")

        proxy_ips = []
        if proxy_endpoint_url is not None:
            proxy_info = self._get_rds_proxy_info(proxy_endpoint_url)
            logger.debug(f"Proxy Info: {proxy_info}")
            if proxy_info:
                proxy_ips = proxy_info[2]
        logger.debug(f"Target proxy IPs: {proxy_ips}")

        network_targets = []
        for ip in proxy_ips:
            ip_target = elbv2_tgt.IpTarget(ip, stack_param.postgres.port)
            network_targets.append(ip_target)
        logger.debug(f"NetworkTargets length: {len(network_targets)}")

        nlb_id = f"nlb-{postgres_cluster_name}"
        nlb = elbv2.NetworkLoadBalancer(
            scope=self,
            id=nlb_id,
            vpc=vpc,
            load_balancer_name=nlb_id,
            vpc_subnets=ec2.SubnetSelection(subnets=private_subnets),
        )

        nlb_target_id = f"tg-{postgres_cluster_name}"
        nlb_tg = elbv2.NetworkTargetGroup(
            scope=self,
            id=nlb_target_id,
            port=stack_param.postgres.port,
            protocol=elbv2.Protocol.TCP,
            target_group_name=nlb_target_id,
            target_type=elbv2.TargetType.IP,
            vpc=vpc,
            targets=network_targets,
        )

        nlb.add_listener(
            id=f"{nlb_id}-nlb-listener",
            port=stack_param.postgres.port,
            default_target_groups=[nlb_tg],
        )

        # Trusted accounts can assume the role
        vpc_epsvc_trust_accountids = stack_param.postgres.proxy_vpce_trust_accounts

        vpc_endpoint_service_id_name = f"vpc-epsvc-{postgres_cluster_name}"
        ec2.VpcEndpointService(
            scope=self,
            id=vpc_endpoint_service_id_name,
            vpc_endpoint_service_load_balancers=[nlb],
            acceptance_required=True,
            allowed_principals=[
                iam.ArnPrincipal(
                    f"arn:{stack_param.deployment.account.partition}:iam::{vpc_epsvc_trust_accountid}:root"
                )
                for vpc_epsvc_trust_accountid in vpc_epsvc_trust_accountids
            ],
            contributor_insights=True,
        )

        endpoint_service_role = iam.Role(
            scope=self,
            id=f"{vpc_endpoint_service_id_name}-role",
            role_name=f"{vpc_endpoint_service_id_name}-role",
            assumed_by=iam.CompositePrincipal(
                *[
                    iam.AccountPrincipal(vpc_epsvc_trust_accountid)
                    for vpc_epsvc_trust_accountid in vpc_epsvc_trust_accountids
                ]
            ),
        )

        endpoint_service_role_policy_statement_json = {
            "Effect": "Allow",
            "Action": ["ec2:AcceptVpcEndpointConnections"],
            "Resource": "*",
        }

        endpoint_service_role.add_to_principal_policy(
            iam.PolicyStatement.from_json(endpoint_service_role_policy_statement_json)
        )

    def _get_rds_proxy_info(
        self, proxy_ep: str
    ) -> tuple[str, list[str], list[str]] | None:
        try:
            return socket.gethostbyname_ex(proxy_ep)
        except OSError as e:
            logger.warning(
                f"Error getting RDS proxy info from the endpoint {proxy_ep}: {e}"
            )
            return None

    def _get_rds_metadata(self, ssm_metadata_path: str) -> dict[str, str]:
        metadata = self.param_store.get_parameter(parameter_name=ssm_metadata_path)
        if metadata is None:
            logger.warning(
                f"Metadata could not be retrieved from path {ssm_metadata_path}"
            )
            return {}
        return metadata

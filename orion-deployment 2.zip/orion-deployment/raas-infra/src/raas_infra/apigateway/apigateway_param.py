#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#
"""ApiGateway Parameters for CDK stack deployment."""

from raas_infra.context import (
    VPC,
    ApiGatewayContext,
    ApiGatewayIAM,
    ApiGatewayKeycloak,
    ContextModel,
    Deployment,
    NetworkLoadBalancer,
)


class ApiGateway(ContextModel):
    """
    Pydantic class for API Gateway definition.

    It is used by a stack to instantiate API Gateways.
    It enriches ApiGatewayContext information (sourced by cdk.context.json and SSM) with
    raas-infra specific information such as apispec_file_name.
    """

    name: str
    network_load_balancer: NetworkLoadBalancer
    api_paths: list[str]
    stage: str
    rate_limit: int
    burst_limit: int
    iam: ApiGatewayIAM | None = None
    deployment: Deployment
    iam_authorizer_name: str
    keycloak_config: ApiGatewayKeycloak | None = None
    vpc: VPC
    apispec_file_name: str
    apispec_version: str
    cdk_group_name: str
    dns_hosted_zone_name: str
    shared_services_vpc_id: str

    @classmethod
    def from_context(cls, ctx: ApiGatewayContext) -> "ApiGateway":
        """Return a new class instance with data validation by Pydantic."""
        id = ctx.get_submodule_id(module_name="apigateway", sub_module_name=ctx.name)
        vpc = VPC.from_context(ctx.ref["vpc"])
        props: dict = {}
        props["id"] = id
        props["vpc"] = vpc
        props["name"] = ctx.name
        props["network_load_balancer"] = ctx.network_load_balancer
        props["api_paths"] = ctx.api_paths
        props["stage"] = ctx.stage
        props["rate_limit"] = ctx.rate_limit
        props["burst_limit"] = ctx.burst_limit
        props["iam"] = ctx.iam
        props["deployment"] = ctx.deployment
        props["apispec_file_name"] = f"openapi-reprocessing-{ctx.name}.json"
        props["apispec_version"] = ctx.version
        props["iam_authorizer_name"] = "sigv4"
        props["cdk_group_name"] = ctx.group
        props["dns_hosted_zone_name"] = str(ctx.ref["dnsHostedZone"]).lower()
        props["shared_services_vpc_id"] = ctx.ref["sharedServicesVpc"]
        props["keycloak_config"] = ctx.keycloak_config
        return cls.model_validate(props)

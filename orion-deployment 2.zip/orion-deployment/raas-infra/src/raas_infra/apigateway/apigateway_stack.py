#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""ApiGateway CDK stack."""

import copy
import json
import logging
import time
from importlib.resources import files
from pathlib import Path
from typing import Any, cast

import aws_cdk.aws_apigateway as apigateway
import aws_cdk.aws_elasticloadbalancingv2 as elbv2
import aws_cdk.aws_iam as iam
import aws_cdk.aws_lambda as _lambda
import aws_cdk.aws_ssm as ssm
from aws_cdk import (
    Environment,
    RemovalPolicy,
    Stack,
    Tags,
    aws_iam,
)
from constructs import Construct, IConstruct

from raas_infra.apigateway.apigateway_param import ApiGateway

logger = logging.getLogger(__name__)


class ApiGatewayStack(Stack):
    """Creates the api gateway resource."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param_list: list[ApiGateway],
        openapi_resources_folder: str,
        context_group: str,
        env: Environment,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys artifacts related to api gateway.",
            env=env,
        )

        self.id = id
        self.stack_param_list = stack_param_list
        self.deployment = stack_param_list[0].deployment
        self.rate_limit = stack_param_list[0].rate_limit
        self.burst_limit = stack_param_list[0].burst_limit
        self.sandbox_suffix = (
            f"-{self.deployment.sandbox_name}" if self.deployment.sandbox_name else ""
        )

        self.create_tags(id)

        def enrich_apispec(
            api_definition_dict: dict[str, Any],
            vpc_link_id: str,
            nlb_url: str,
            authorizer_name: str | None,
        ) -> None:
            # "discriminator" is not supported by aws api gateway while
            # importing from api spec
            for schema_key, schema in api_definition_dict["components"][
                "schemas"
            ].items():
                if "discriminator" in schema:
                    schema.pop("discriminator")
                    api_definition_dict["components"]["schemas"][schema_key] = schema

            # foreach api, updating the aws api gateway integration
            for api_paths, api_path_definitions in api_definition_dict["paths"].items():
                for api_item_key, api_key_values in api_path_definitions.items():
                    api_key_values["x-amazon-apigateway-integration"] = {
                        "connectionId": vpc_link_id,
                        "uri": f"{nlb_url}{api_paths}",
                        "passthroughBehavior": "when_no_match",
                        "type": "http_proxy",
                        "connectionType": "VPC_LINK",
                        "httpMethod": api_item_key.upper(),
                    }

                    if authorizer_name is not None:
                        api_key_values["security"] = [{authorizer_name: []}]

                    request_parameters_dict = {}
                    if "parameters" in api_key_values:
                        request_parameters = api_key_values["parameters"]

                        for request_parameter in request_parameters:
                            request_parameter_name = request_parameter["name"]
                            # request parameter is in path or query
                            request_parameter_in = request_parameter["in"]

                            # if request parameter is in query, format requires to be
                            # as querystring

                            if request_parameter_in != "query":
                                request_parameters_dict[
                                    f"integration.request.{request_parameter_in}."
                                    f"{request_parameter_name}"
                                ] = f"method.request.{request_parameter_in}.{request_parameter_name}"
                            elif (
                                request_parameter.get("schema", {}).get("type")
                                == "array"
                            ):
                                request_parameters_dict[
                                    f"integration.request.queryst"
                                    f"ring.{request_parameter_name}"
                                ] = f"method.request.multivaluequerystring.{request_parameter_name}"

                        # updating the api method integration
                        api_key_values["x-amazon-apigateway-integration"][
                            "requestParameters"
                        ] = request_parameters_dict

        self.output_dict: dict = {}
        self.default_auth_api_definitions: list[dict[str, Any]] = []
        self.iam_auth_api_definitions: list[dict[str, Any]] = []
        deployment_account = self.deployment.account

        for stack_param in self.stack_param_list:
            # read the api definition from Artifactory
            with Path(
                f"{openapi_resources_folder}/{stack_param.apispec_file_name}"
            ).open() as fp:
                apispec: dict = json.load(fp)

            # looking up for network load balancer based on stack param
            nlb = elbv2.NetworkLoadBalancer.from_lookup(
                self,
                f"{stack_param.name}-nlblookup",
                load_balancer_tags=stack_param.network_load_balancer.tags,
            )

            listener = stack_param.network_load_balancer.listener
            # service url resolved using internal network load balancer dns and
            # listener protocol, port
            url = f"{listener.protocol}://{nlb.load_balancer_dns_name}:{listener.port}"

            # VPC link from api gateway to internal network load balancer
            vpc_link = apigateway.VpcLink(
                self,
                f"{stack_param.name}-vpclink{self.sandbox_suffix}",
                targets=[nlb],
                vpc_link_name=f"{stack_param.name}-vpclink{self.sandbox_suffix}",
                description=f"Vpc link for {stack_param.name} from api to nlb.",
            )

            # Default auth API ---------------------------

            # work on a copy as the dictionary gets modified but is still needed as
            # original for below iam auth

            default_auth_api_spec = copy.deepcopy(apispec)
            authorizer_name = None

            if stack_param.keycloak_config is not None:
                # create lambda func as the custom authorizer to APIGW
                keycloak_lambda = _lambda.Function(
                    self,
                    id=f"{self.id}-{stack_param.name}-lambda-auth",
                    runtime=_lambda.Runtime.PYTHON_3_10,
                    code=_lambda.Code.from_asset(
                        str(files("raas_infra.constructs.lambdas.apigateway"))
                    ),
                    handler="keycloak_authorizer.handler",
                    description="Lambda serving apiGw Auth",
                    environment={
                        "KEYCLOAK_URL": stack_param.keycloak_config.url,
                        "KEYCLOAK_CLIENT_ID": stack_param.keycloak_config.client_id,
                        "M2M_KEYCLOAK_CLIENT_ID": stack_param.keycloak_config.m2m_client_id,
                        "GROUP_ROLE_CONFIG": json.dumps(
                            stack_param.keycloak_config.group_role_config or {}
                        ),
                    },
                )

                # Add permission for API Gateway to invoke the Lambda function
                keycloak_lambda.add_permission(
                    "APIGatewayInvokePermission",
                    principal=iam.ServicePrincipal("apigateway.amazonaws.com"),
                    action="lambda:InvokeFunction",
                    source_arn=f"arn:{self.partition}:execute-api:{self.region}"
                    f":{self.account}:*",
                )

                authorizer_name = "keycloak-" + stack_param.name
                keycloak_security_schemes = {
                    authorizer_name: {
                        "type": "apiKey",
                        "name": "Authorization",
                        "in": "header",
                        "x-amazon-apigateway-authtype": "custom",
                        "x-amazon-apigateway-authorizer": {
                            "type": "request",
                            "identitySource": "method.request.header.Authorization",
                            "authorizerUri": f"arn:"
                            f"{deployment_account.partition}:apigateway:{deployment_account.region}"
                            f":lambda:path/2015-03-31/functions/arn:"
                            f"{deployment_account.partition}:lambda:"
                            f"{deployment_account.region}:"
                            f"{deployment_account.id}:function:"
                            f"{keycloak_lambda.function_name}"
                            f"/invocations",
                            "authorizerResultTtlInSeconds": 0,
                        },
                    }
                }
                default_auth_api_spec["components"]["securitySchemes"] = (
                    keycloak_security_schemes
                )

            enrich_apispec(
                default_auth_api_spec,
                vpc_link.vpc_link_id,
                url,
                authorizer_name,
            )

            self.default_auth_api_definitions.append(default_auth_api_spec)

            # IAM auth API ---------- higher priority, overwrites keycloack (default)
            if stack_param.iam is not None:
                iam_security_schemes = {
                    stack_param.iam_authorizer_name: {
                        "type": "apiKey",
                        "name": "Authorization",
                        "in": "header",
                        "x-amazon-apigateway-authtype": "awsSigv4",
                    }
                }
                iam_auth_apispec = copy.deepcopy(apispec)
                iam_auth_apispec["components"]["securitySchemes"] = iam_security_schemes
                enrich_apispec(
                    iam_auth_apispec,
                    vpc_link.vpc_link_id,
                    url,
                    stack_param.iam_authorizer_name,
                )
                self.iam_auth_api_definitions.append(iam_auth_apispec)

        if len(self.default_auth_api_definitions) != 0:
            # Deploying api gateway with Keycloak auth if configured.
            keycloak_config = stack_param_list[0].keycloak_config

            self.create_api_gateway(
                api_definitions=self.default_auth_api_definitions,
                openapi_version=stack_param_list[0].apispec_version,
                id_prefix=f"{context_group}{self.sandbox_suffix}-",
                stage_name=stack_param_list[0].stage,
                shared_services_vpc_id=stack_param_list[0].shared_services_vpc_id,
                include_swagger_ui=True,
                keycloak_config=keycloak_config.model_dump()
                if keycloak_config is not None
                else None,
            )

        if len(self.iam_auth_api_definitions) != 0:
            self.create_iam_api_gateway(
                context_group,
                self.iam_auth_api_definitions,
                stack_param_list[0].apispec_version,
                stack_param_list[0].stage,
                stack_param_list[0].shared_services_vpc_id,
                deployment_account.partition,
            )

        output_value = json.dumps(self.output_dict)
        ssm.StringParameter(
            scope=self,
            parameter_name=f"/raas-infra/apigateway{self.sandbox_suffix}/{context_group}",
            id=f"/raas-infra/apigateway{self.sandbox_suffix}/{context_group}",
            string_value=output_value,
        )

    def create_tags(self, id: str) -> None:
        """Add tags to self and all subconstructs"""
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

    def create_api_gateway(
        self,
        api_definitions: list[dict[str, Any]],
        openapi_version: str,
        id_prefix: str,
        stage_name: str,
        shared_services_vpc_id: str,
        *,
        include_swagger_ui: bool = False,
        keycloak_config: dict[str, Any] | None = None,
    ) -> apigateway.SpecRestApi:
        """
        Create Api gateway from openapi spec.

        The information is enriched with AWS specifics.
        """
        api_definition = merge(api_definitions)

        if include_swagger_ui:
            # If SwaggerUI integration via Lambda should be included, add it as a
            # OpenAPI method upfront
            self.add_swagger_ui(api_definition, keycloak_config)

        logger.debug("############################################")
        logger.debug("Merged and enriched API Gateway OpenAPI definition:")
        logger.debug(json.dumps(api_definition, indent=2))
        logger.debug("############################################")

        doc_ver = f"v1-{openapi_version}-{time.time()}"

        api = apigateway.SpecRestApi(
            self,
            f"{id_prefix}api",
            rest_api_name=f"{id_prefix}api",
            api_definition=apigateway.ApiDefinition.from_inline(api_definition),
            endpoint_types=[apigateway.EndpointType.PRIVATE],
            retain_deployments=False,
            deploy_options=apigateway.StageOptions(
                stage_name=stage_name,
                throttling_rate_limit=self.rate_limit,
                throttling_burst_limit=self.burst_limit,
                documentation_version=doc_ver,
                tracing_enabled=True,
            ),
            policy=aws_iam.PolicyDocument(
                statements=[
                    aws_iam.PolicyStatement(
                        principals=[aws_iam.AnyPrincipal()],
                        actions=["execute-api:Invoke"],
                        resources=["execute-api:/*"],
                        effect=aws_iam.Effect.DENY,
                        conditions={
                            "StringNotEquals": {"aws:sourceVpc": shared_services_vpc_id}
                        },
                    ),
                    aws_iam.PolicyStatement(
                        principals=[aws_iam.AnyPrincipal()],
                        actions=["execute-api:Invoke"],
                        resources=["execute-api:/*"],
                        effect=aws_iam.Effect.ALLOW,
                    ),
                ]
            ),
        )

        api.node.default_child.add_property_override("Mode", "overwrite")

        documentation_version = apigateway.CfnDocumentationVersion(
            self,
            f"{id_prefix}documentation-version",
            rest_api_id=api.rest_api_id,
            documentation_version=doc_ver,
        )
        documentation_version.apply_removal_policy(RemovalPolicy.DESTROY)
        api.deployment_stage.node.add_dependency(documentation_version)

        api_url = api.deployment_stage.url_for_path()
        api_id = api.rest_api_id
        api_stage = api.deployment_stage.stage_name
        self.output_dict.update({f"{id_prefix}api-url": api_url})
        self.output_dict.update({f"{id_prefix}api-id": api_id})
        self.output_dict.update({f"{id_prefix}api-stage": api_stage})
        return api

    def create_iam_api_gateway(
        self,
        context_group: str,
        iam_auth_api_definitions: list[dict[str, Any]],
        openapi_version: str,
        stage_name: str,
        shared_services_vpc_id: str,
        _aws_partition: str,
    ) -> None:
        """Deploy api gateway with IAM auth if configured."""
        iam_auth_api = self.create_api_gateway(
            api_definitions=iam_auth_api_definitions,
            openapi_version=openapi_version,
            id_prefix=f"iamauth-{context_group}{self.sandbox_suffix}-",
            stage_name=stage_name,
            shared_services_vpc_id=shared_services_vpc_id,
        )

        # collect all arns based on access_type from iam objects
        def collect_trust_arns(iam_list: list, access_type: str) -> set[Any]:
            return {
                arn
                for item in iam_list
                if item is not None
                and getattr(item.permissions, access_type) is not None
                for arn in getattr(item.permissions, access_type)
            }

        def deny_all_write_permissions(role: iam.Role) -> None:
            # Explicitly deny write permission if the role is set to read-only
            role.add_to_principal_policy(
                aws_iam.PolicyStatement(
                    effect=aws_iam.Effect.DENY,
                    actions=["execute-api:Invoke"],
                    resources=[
                        iam_auth_api.arn_for_execute_api(method="POST", path="/*"),
                        iam_auth_api.arn_for_execute_api(method="PUT", path="/*"),
                        iam_auth_api.arn_for_execute_api(method="PATCH", path="/*"),
                        iam_auth_api.arn_for_execute_api(method="DELETE", path="/*"),
                    ],
                )
            )

        # Create role, attach trust relationship and policy statements
        def create_role(
            role_id: str,
            role_name: str,
            principals: list[iam.ArnPrincipal],
            policy_statements: dict[str, list[str]],
            method: str,
        ) -> iam.Role:
            role = iam.Role(
                self,
                id=f"{role_id.lower()}",
                role_name=f"{self.id}-{role_name.lower()}",
                assumed_by=iam.CompositePrincipal(*principals),
            )
            for principle, api_paths in policy_statements.items():
                condition = (
                    {"StringLike": {"aws:PrincipalArn": principle}}
                    if principle != "*"
                    else None
                )
                role.add_to_principal_policy(
                    aws_iam.PolicyStatement(
                        effect=aws_iam.Effect.ALLOW,
                        actions=["execute-api:Invoke"],
                        resources=[
                            iam_auth_api.arn_for_execute_api(method=method, path=path)
                            for path in api_paths
                        ],
                        conditions=condition,
                    )
                )
            if role_name == "Readonly":
                # Explicitly deny write permission if the role is set to read-only
                deny_all_write_permissions(role=role)
            return role

        # Create a dictionary with principal as key and api_paths as values
        def create_access_statement_dict(
            stack_param_list: list[ApiGateway], access_type: str
        ) -> dict[str, list[str]]:
            statement_dict: dict[str, list[str]] = {}
            for item in stack_param_list:
                if (
                    item is not None
                    and item.iam is not None
                    and item.iam.permissions is not None
                    and getattr(item.iam.permissions, access_type) is not None
                ):
                    for principle in getattr(item.iam.permissions, access_type):
                        statement_dict.setdefault(principle, []).extend(item.api_paths)
            return statement_dict

        # Process roles based on role name, access type and method
        def process_role(
            role_id: str, role_name: str, access_type: str, method: str
        ) -> None:
            iam_list = [item.iam for item in self.stack_param_list]
            trust_arns = collect_trust_arns(iam_list, access_type)
            principal_list = [iam.ArnPrincipal(arn) for arn in trust_arns]
            statement_dict = create_access_statement_dict(
                self.stack_param_list, access_type
            )

            role = create_role(
                role_id, role_name, principal_list, statement_dict, method
            )
            self.output_dict.update(
                {f"api_{role_name.lower()}_assume_role_arn": role.role_arn}
            )

        # Process readonly access role
        process_role(
            f"apireadonlyaccessrole{self.sandbox_suffix}",
            "Readonly",
            "read_only_access_assumed_by",
            "GET",
        )

        # Process full access role
        process_role(
            f"apifullaccessrole{self.sandbox_suffix}",
            "FullAccess",
            "full_access_assumed_by",
            "*",
        )

    def add_swagger_ui(
        self, api: dict[str, Any], keycloak_config: dict[str, Any] | None = None
    ) -> None:
        """Add swagger UI lambda function"""
        # If there are no OpenAPI definitions, skip this
        if not api:
            return

        swagger_ui_lambda = self.create_swagger_ui_lambda(keycloak_config)

        lambda_function_uri = (
            f"arn:{self.deployment.account.partition}:apigateway:"
            f"{self.deployment.account.region}:lambda:path/2015-03-31"
            f"/functions/{swagger_ui_lambda.function_arn}/invocations"
        )

        # Manually add a Lambda proxy integration to the API definition according to
        # https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway
        # -set-up-lambda-proxy-integration-on-proxy-resource.html
        api["paths"]["/{proxy+}"] = {
            "parameters": [
                {
                    "name": "proxy",
                    "in": "path",
                    "required": True,
                    "schema": {"type": "string"},
                }
            ],
            "responses": {},
            "x-amazon-apigateway-any-method": {
                "x-amazon-apigateway-integration": {
                    "type": "aws_proxy",
                    "httpMethod": "POST",
                    "uri": lambda_function_uri,
                }
            },
        }

        # And add a default GET method at the root to let browsers resolve the index
        # file presented by the lambda
        api["paths"]["/"] = {
            "get": {
                "responses": {
                    "200": {
                        "description": "Swagger UI",
                        "content": {"text/html": {"schema": {"type": "string"}}},
                    }
                },
                "x-amazon-apigateway-integration": {
                    "type": "aws_proxy",
                    "httpMethod": "POST",
                    "uri": lambda_function_uri,
                },
            }
        }

    def create_swagger_ui_lambda(
        self, keycloak_config: dict[str, Any] | None = None
    ) -> _lambda:
        """Define the Lambda serving SwaggerUI"""
        environment = {}
        if keycloak_config:
            environment = {
                "KEYCLOAK_URL": str(keycloak_config.get("url") or ""),
                "KEYCLOAK_CLIENT_ID": str(keycloak_config.get("client_id") or ""),
                "M2M_KEYCLOAK_CLIENT_ID": str(
                    keycloak_config.get("m2m_client_id") or ""
                ),
            }

        swagger_ui_lambda = _lambda.Function(
            self,
            id=f"{self.id}{self.sandbox_suffix}-swagger-ui-lambda",
            runtime=_lambda.Runtime.PYTHON_3_10,
            code=_lambda.Code.from_asset(
                str(files("raas_infra.constructs.lambdas.swagger"))
            ),
            handler="swaggerui.lambda_handler",
            description="Lambda serving SwaggerUI",
            environment=environment,
        )
        # Role to allow the Lambda to fetch the OpenAPI specs from the GW
        swagger_ui_lambda.add_to_role_policy(
            iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=["apigateway:*"],
                resources=["*"],
            )
        )
        # Allow the Lambda to be called by ApiGW within the account
        swagger_ui_lambda.add_permission(
            "APIGatewayInvokePermission",
            principal=iam.ServicePrincipal("apigateway.amazonaws.com"),
            action="lambda:InvokeFunction",
            source_arn=f"arn:{self.partition}:execute-api:{self.region}"
            f":{self.account}:*",
        )
        return swagger_ui_lambda


def merge(sources: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Deep merge OpenAPI specifications.

    The goal is to offer one API Gateway for multiple services.
    """

    def check_for_duplicates(
        source: dict[str, Any], destination: dict[str, Any], context: str
    ) -> list[str]:
        duplicates = []
        for key, value in source.items():
            if key in destination and value != destination[key]:
                duplicates.append(
                    f"Duplicate key '{key}' found with differing value in {context}."
                )
        return duplicates

    merged = sources[0]  # fully take over the first
    errors = []
    for idx in range(1, len(sources)):
        # Check for duplicates in paths
        errors.extend(
            check_for_duplicates(
                sources[idx]["paths"], merged["paths"], sources[idx]["info"]["title"]
            )
        )

        # Merge schemas and security schemes
        components = sources[idx]["components"]
        merged_components = merged["components"]

        # Check for duplicates and merge schemas
        errors.extend(
            check_for_duplicates(
                components.get("schemas", {}),
                merged_components.get("schemas", {}),
                sources[idx]["info"]["title"],
            )
        )
        merged_components.setdefault("schemas", {}).update(
            components.get("schemas", {})
        )

        # Check for duplicates and merge security schemes
        errors.extend(
            check_for_duplicates(
                components.get("securitySchemes", {}),
                merged_components.get("securitySchemes", {}),
                sources[idx]["info"]["title"],
            )
        )
        merged_components.setdefault("securitySchemes", {}).update(
            components.get("securitySchemes", {})
        )

        # Raise errors if any duplicates were found
        if errors:
            raise ValueError("\n".join(errors))

        # Merge paths
        merged["paths"].update(sources[idx]["paths"])

    return merged

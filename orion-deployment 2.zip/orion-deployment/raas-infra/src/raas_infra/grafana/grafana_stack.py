#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Prometheus CDK stack.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from typing import cast

import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_grafana as grafana
import aws_cdk.aws_iam as iam
import aws_cdk.aws_ssm as ssm
from aws_cdk import CfnJson, Stack, Tags
from constructs import Construct, IConstruct

from raas_infra.constructs.grafana_lambda import RaaSGrafana
from raas_infra.grafana.grafana_params import Grafana


class GrafanaStack(Stack):
    """Creates the resources needed by Grafana running in EKS."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: Grafana,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys artifacts related to Grafana.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs).
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        account = stack_param.deployment.account

        # create role for the grafana service
        self.role = iam.Role(
            self,
            id="ServiceAccountRole",
            role_name=stack_param.iam_role_name,
            description=stack_param.iam_role_description,
            assumed_by=iam.PrincipalWithConditions(
                iam.ServicePrincipal("grafana.amazonaws.com"),
                conditions={
                    "StringEquals": CfnJson(
                        self,
                        "SourceAccount",
                        value={"aws:SourceAccount": account.id},
                    ),
                    "StringLike": CfnJson(
                        self,
                        "SourceArn",
                        value={
                            "aws:SourceArn": f"arn:{account.partition}:grafana:{account.region}:{account.id}:/workspaces/*"
                        },
                    ),
                },
            ),
        )

        aws_managed_prometheus_access_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=[
                        "aps:ListWorkspaces",
                        "aps:DescribeWorkspace",
                        "aps:QueryMetrics",
                        "aps:GetLabels",
                        "aps:GetSeries",
                        "aps:GetMetricMetadata",
                    ],
                    resources=["*"],
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        # add policy to access the raas prometheus service
        self.role.attach_inline_policy(
            iam.Policy(
                scope=self,
                id="aws_managed_prometheus_access_policy",
                document=aws_managed_prometheus_access_policy,
                policy_name="aws_managed_prometheus_access_policy",
            )
        )

        # VPC lookup based on vpc id
        self.vpc = ec2.Vpc.from_lookup(self, id="VPC", vpc_id=stack_param.vpc.id)

        grafana_sg_name = f"{stack_param.id}-sg"
        # Security group associated with grafana
        grafana_sg = ec2.SecurityGroup(
            self,
            grafana_sg_name,
            security_group_name=grafana_sg_name,
            vpc=self.vpc,
            allow_all_outbound=False,
        )

        egress_ports = [443]

        for security_group_rule in stack_param.security_group_rules:
            # look up for postgres security group id
            sg = ec2.SecurityGroup.from_security_group_id(
                self,
                f"AllowTrafficFromGrafana-{security_group_rule.name}",
                security_group_rule.security_group_id,
            )
            # Adding rule to security group to allow access from grafana
            sg.add_ingress_rule(
                grafana_sg,
                ec2.Port.tcp(security_group_rule.ingress.port),
                f"Allow traffic from the grafana security group - {grafana_sg_name}",
            )
            egress_ports.append(security_group_rule.ingress.port)

        egress_ports_set = set(egress_ports)
        for egress_port in egress_ports_set:
            grafana_sg.add_egress_rule(
                ec2.Peer.any_ipv4(),
                ec2.Port.tcp(egress_port),
                f"Port - {egress_port}",
            )

        # provision grafana workspace
        self.grafana_workspace = grafana.CfnWorkspace(
            self,
            id="GrafanaWorkspace",
            name=stack_param.id,
            authentication_providers=["AWS_SSO"],
            permission_type="SERVICE_MANAGED",
            account_access_type="CURRENT_ACCOUNT",
            description="This workspace contains dashboards required for RaaS.",
            role_arn=self.role.role_arn,
            data_sources=["PROMETHEUS"],
            vpc_configuration=grafana.CfnWorkspace.VpcConfigurationProperty(
                security_group_ids=[grafana_sg.security_group_id],
                subnet_ids=json.loads(stack_param.vpc.non_routable_subnet_ids),
            ),
        )

        grafana_workspace_url = f"https://{self.grafana_workspace.attr_endpoint}"

        # settings for the grafana datasource's
        for artifact in stack_param.artifacts:
            name = artifact.name
            datasource_properties = artifact.datasource_properties
            print("applying datasource properties")
            print(datasource_properties)
            # import grafana dashboards
            self.grafana_import_dashboards = RaaSGrafana(
                self,
                id=f"{id}-{name}-dashboards",
                name=name,
                lambda_role_name=f"{id}-{name}-lambda",
                grafana_workspace_id=self.grafana_workspace.attr_id,
                grafana_workspace_url=grafana_workspace_url,
                grafana_datasources_properties_overwrite=datasource_properties,
            )

        # Outputs
        output_dict = {
            "grafana_workspace_name": self.grafana_workspace.name,
            "grafana_workspace_url": grafana_workspace_url,
            "grafana_workspace_id": self.grafana_workspace.attr_id,
        }
        output_value = json.dumps(output_dict)
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

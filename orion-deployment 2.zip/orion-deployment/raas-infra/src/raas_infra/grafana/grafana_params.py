#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Grafana parameters for CDK stack deployment."""

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSCluster,
    GrafanaArtifact,
    GrafanaContext,
    GrafanaSecurityGroupRule,
)


class Grafana(ContextModel):
    """Managing the necessary params for Grafana Infra CDK deployment"""

    eks_cluster: EKSCluster
    deployment: Deployment
    output_metadata_path: str
    iam_role_name: str
    iam_role_description: str
    vpc: VPC
    artifacts: list[GrafanaArtifact]
    security_group_rules: list[GrafanaSecurityGroupRule]

    @classmethod
    def from_context(cls, ctx: GrafanaContext) -> "Grafana":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])
        id = ctx.get_id()
        props: dict = {}
        props["id"] = id
        props["deployment"] = ctx.deployment
        props["eks_cluster"] = eks_cluster
        props["vpc"] = vpc
        props["output_metadata_path"] = ctx.metadata_output_ssm_path
        props["iam_role_name"] = ctx.iam_role_name
        props["iam_role_description"] = ctx.iam_role_description
        props["security_group_rules"] = ctx.security_group_rules
        props["artifacts"] = ctx.artifacts

        return cls.model_validate(props)

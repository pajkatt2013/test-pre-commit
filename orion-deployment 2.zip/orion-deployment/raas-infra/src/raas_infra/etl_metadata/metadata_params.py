#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Parameters for deploying RaaS ETLMetadata Stacl - CDK stack deployment.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSCluster,
    ETLMetadataContext,
    Postgres,
)


class ETLMetadata(ContextModel):
    """Managing the necessary params for RaaS ETLMetadata CDK deployment"""

    id: str
    eks_cluster: EKSCluster
    vpc: VPC
    output_metadata_path: str
    deployment: Deployment
    postgres: Postgres
    non_sandbox_id: str

    @classmethod
    def from_context(cls, ctx: ETLMetadataContext) -> "ETLMetadata":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])
        postgres = Postgres.from_context(ctx.ref["postgres"])

        id_ = ctx.get_id()
        props = {
            "eks_cluster": eks_cluster,
            "vpc": vpc,
            "postgres": postgres,
            "deployment": ctx.deployment,
            "id": id_,
            "output_metadata_path": ctx.metadata_output_ssm_path,
        }

        props["non_sandbox_id"] = ctx.get_non_sandbox_id()

        return cls.model_validate(props)

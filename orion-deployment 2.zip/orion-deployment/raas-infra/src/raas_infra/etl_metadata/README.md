# RaaS ETLMetadata


This module is responsible for deploying ETLMetadata asets such as RDS Postgres Serverless Cluster



ETLMetadata stack deployment comes package with below resources


- Provisioning the Bastion Host for accessing the Postgres server deployed in cloud from Local machine using SSM Session Manager with all permissions configured
- Provisioning the Postgres security group with all necessary ingress and egress rules to allow access from EKS, Bastion Host and Code Build
- Provisioning the Postgres Admin Master Credentials in Secret Manager and Secret Rotation for every 7 days
- Provisioning the RDS Postgres Serverless Cluster and Write Instance
- IAM roles for each ETLMetadata Service Accounts with permissions to specific RDS DB User, Uploading Artifacts to S3 and to send out status message to Job Status SQS

#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Pydantic derived classes that describe the cdk.context.json model.

After pydantic validation, the class instances are used to populate
models in the *_param.py files which contain more information needed
to create the cdk stacks.
"""

import json
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, ClassVar

from constructs import Node
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from raas_infra.utils.ssm import ParamStore
from raas_infra.utils.ssm_resolution import SSMResolver


def _to_camel(string: str) -> str:
    """Convert from camelCase to snake_case."""
    words = string.split("_")

    # Do not capitalize the first word
    if len(words) <= 1:
        return words[0]

    return "".join([words[0]] + [word.capitalize() for word in words[1:]])


class _ContextLoaderMixin(ABC):
    """Mixing used to load parameters from the CDK context."""

    @classmethod
    @abstractmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs: dict[str, Any]
    ) -> BaseModel:
        """
        Create an instance of the class from the AWS CDK context.

        :param node: CDK Node object used to read context values.
        :param kwargs: keyword arguments passed to the underlying class constructor.
        :returns: An instance of the model class.
        :raises: ValueError if the CDK context could not be read for the model.
        :raises: RuntimeError if an expected initializer argument is missing from
            the kwargs.
        """

    @classmethod
    def read_context_values(
        cls, node: Node, json_key_path: str, param_store: ParamStore
    ) -> dict[str, Any]:
        """Read a value from the CDK context."""
        keys = json_key_path.split(".")

        sandbox_name = node.try_get_context("SANDBOX_NAME")

        # setting sandbox name to lowercase
        if sandbox_name is not None:
            sandbox_name = sandbox_name.lower()

        # read the CDK context values starting from the first key in the JSON path
        root: dict[str, Any] = node.try_get_context(keys[0])

        # iterate over remaining keys in the JSON key path
        for key in keys[1:]:
            if key not in root:
                msg = f"Could not find key {key} in {root}"
                raise ValueError(msg)
            root = root[key]

        root["deployment"] = node.try_get_context("deployment")

        # setting default project name
        if "projectName" not in root["deployment"]:
            root["deployment"]["projectName"] = "raas"

        env_name = root["deployment"]["environmentName"]

        # setting default deployment name
        if "name" not in root["deployment"]:
            root["deployment"]["name"] = f"infra-{env_name}"

        root["deployment"]["moduleName"] = node.try_get_context("ADDF_MODULE_NAME")
        root["deployment"]["sandboxName"] = sandbox_name

        global_ref = {}
        node_ref = node.try_get_context("ref")
        if node_ref is not None:
            for ref_key in node_ref:
                global_ref[ref_key] = cls.populate_ref_values(
                    node_ref[ref_key],
                    param_store,
                    root["deployment"],
                    sandbox_name,
                )

        ref = {}
        if "ref" in root:
            for ref_key in root["ref"]:
                ref[ref_key] = cls.populate_ref_values(
                    root["ref"][ref_key],
                    param_store,
                    root["deployment"],
                    sandbox_name,
                )

        global_ref.update(ref)
        root["ref"] = global_ref

        if "metadataOutputSSMPath" in root and sandbox_name is not None:
            root["metadataOutputSSMPath"] = (
                root["metadataOutputSSMPath"] + f"/sandbox-{sandbox_name}"
            )

        return substitute_ssm_ref_values(root)

    @classmethod
    def populate_ref_values(  # noqa: PLR0912 # small function, still good to understand
        cls,
        root: dict[str, Any] | str,
        param_store: ParamStore,
        deployment: dict,
        sandbox_name: str | None = None,
    ) -> str | dict[str, Any]:
        """
        Resolve the 'ref' properties in the context.

        In case there is a key 'ssm' in root, a call to SSM is made to retrieve values
        from AWS System Manager.

        In case the env var WRITE_SSM_TO_JSON is set to 'true', a JSON file is written
        with all received SSM values to simplify the maintenance of the SSM mock file
        tests/data/cdk_synth/ssm_mock.json.
        """
        ref = {}
        if isinstance(root, dict):
            for ref_key in root:
                if ref_key == "ssm":

                    def _write_out_ssm(key: str, value: str | None) -> None:
                        """
                        Write final SSM value to a JSON file.

                        This can be used to populate new or changed values to
                        tests/data/cdk_synth/ssm_mock.json for the cdk synth test.
                        """
                        json_out_path = (
                            Path(__file__).parent.parent.parent.resolve()
                            / "tests"
                            / "data"
                            / "cdk_synth"
                            / "ssm_received.json"
                        )
                        data = {}
                        if json_out_path.exists():
                            with json_out_path.open("r", encoding="utf-8") as fp:
                                data = json.load(fp)
                        data[key] = value
                        with json_out_path.open("w", encoding="utf-8") as fp:
                            json.dump(data, fp, sort_keys=True, indent=2)

                    final_value: str | bytes | bytearray | None = None
                    if sandbox_name is None:
                        ssm_value = param_store.get_parameter_value(root[ref_key])
                        if ssm_value is None:
                            msg = (
                                "Could not retrieve value for"
                                f" parameter {root[ref_key]}"
                            )
                            raise ValueError(msg)
                        final_value = ssm_value
                    else:
                        sandbox_ssm_value = param_store.get_parameter_value(
                            root[ref_key] + f"/sandbox-{sandbox_name}"
                        )
                        ssm_value = param_store.get_parameter_value(root[ref_key])

                        # merge sandbox value into the base value
                        merged_ssm_value = merge_ssm_values(
                            ssm_value, sandbox_ssm_value
                        )
                        if merged_ssm_value is None:
                            msg = (
                                "Could not retrieve value for"
                                f" parameter {root[ref_key]}"
                            )
                            raise ValueError(msg)
                        final_value = merged_ssm_value
                    if os.environ.get("WRITE_SSM_TO_JSON", "false").lower() == "true":
                        _write_out_ssm(root[ref_key], ssm_value)
                    return final_value

                if ref_key == "secret":
                    if sandbox_name is None:
                        ssm_value = param_store.get_secret_value(
                            root[ref_key], deployment
                        )
                        if ssm_value is None:
                            msg = f"Could not retrieve value for secret {root[ref_key]}"
                            raise ValueError(msg)
                        return ssm_value
                else:
                    ref[ref_key] = cls.populate_ref_values(
                        root[ref_key],
                        param_store=param_store,
                        deployment=deployment,
                        sandbox_name=sandbox_name,
                    )
        else:
            return root
        return ref


def merge_ssm_values(parent_value: str | None, child_value: str | None) -> str | None:
    """Merge parent and child ssm values"""
    try:
        if parent_value is None and child_value is None:
            return None

        if child_value is None:
            return parent_value

        # handle if dictionary type values
        parent_obj = json.loads(parent_value) if parent_value is not None else {}
        child_obj = json.loads(child_value) if child_value is not None else {}

        if isinstance(parent_obj, dict):
            parent_obj.update(child_obj)
            return json.dumps(parent_obj)
    except ValueError:
        # if unable to json parse, could be a non-json format string
        return child_value if child_value is not None else parent_value

    return child_value


class ContextModel(BaseModel):
    """Base class for models that represent values read from the CDK context."""

    model_config = ConfigDict(
        extra="allow",
        alias_generator=_to_camel,
        populate_by_name=True,
    )

    def get_id(self) -> str:
        """
        Generate an id with the project, deployment, sandbox and module.

        Example with sandbox:    raas-infra-dev-<sandbox>-services
        Example without sandbox: raas-infra-dev-services
        """
        if self.deployment.sandbox_name is None:
            return (
                f"{self.deployment.project_name}-"
                f"{self.deployment.name}-"
                f"{self.deployment.module_name}"
            )

        return (
            f"{self.deployment.project_name}-"
            f"{self.deployment.name}-"
            f"{self.deployment.sandbox_name}-"
            f"{self.deployment.module_name}"
        )

    def get_sandbox_submodule_id(
        self,
        sandbox_name: str,
        module_name: str,
        sub_module_name: str | None,
    ) -> str:
        """
        Generate an id with the project, deployment, sandbox, module and sub module.

        Example: raas-infra-dev-<sandbox>-services-candidate-service
        """
        return (
            f"{self.deployment.project_name}-"
            f"{self.deployment.name}-"
            f"{sandbox_name}-"
            f"{module_name}-"
            f"{sub_module_name}"
        )

    def get_submodule_id(self, module_name: str, sub_module_name: str | None) -> str:
        """
        Generate an id with the project, deployment, sandbox, module and sub module.

        Example with sandbox:    raas-infra-dev-<sandbox>-services-candidate-service
        Example without sandbox: raas-infra-dev-services-candidate-service
        """
        if self.deployment.sandbox_name is None:
            return (
                f"{self.deployment.project_name}-"
                f"{self.deployment.name}-"
                f"{module_name}-"
                f"{sub_module_name}"
            )
        return (
            f"{self.deployment.project_name}-"
            f"{self.deployment.name}-"
            f"{self.deployment.sandbox_name}-"
            f"{module_name}-"
            f"{sub_module_name}"
        )

    def get_project_deployment_id(self, sandbox_name: str | None) -> str:
        """
        Generate an id with the project, deployment and sandbox.

        Example with sandbox:    raas-infra-dev-<sandbox>
        Example without sandbox: raas-infra-dev
        """
        if sandbox_name is None:
            return f"{self.deployment.project_name}-{self.deployment.name}"
        return f"{self.deployment.project_name}-{self.deployment.name}-{sandbox_name}"

    def get_sandbox_id(self, name: str) -> str:
        """
        Generate an id with the project, deployment, sandbox and module.

        Example:    raas-infra-dev-<sandbox>-services
        """
        return (
            f"{self.deployment.project_name}-"
            f"{self.deployment.name}-"
            f"{name}-"
            f"{self.deployment.module_name}"
        )

    def get_non_sandbox_id(self) -> str:
        """
        Generate an id with the project, deployment and module.

        Example:    raas-infra-dev-services
        """
        return (
            f"{self.deployment.project_name}-"
            f"{self.deployment.name}-"
            f"{self.deployment.module_name}"
        )

    def get_submodule_non_sandbox_id(
        self, module_name: str, sub_module_name: str
    ) -> str:
        """
        Generate an id with the project, deployment, module and sub module.

        Example: raas-infra-dev-services-candidate-service
        """
        return (
            f"{self.deployment.project_name}-"
            f"{self.deployment.name}-"
            f"{module_name}-"
            f"{sub_module_name}"
        )

    def get_id_without_module(self) -> str:
        """
        Generate an id with the project, deployment and sandbox.

        Example with sandbox:    raas-infra-dev-<sandbox>
        Example without sandbox: raas-infra-dev
        """
        if self.deployment.sandbox_name is None:
            return f"{self.deployment.project_name}-{self.deployment.name}"
        return (
            f"{self.deployment.project_name}-"
            f"{self.deployment.name}-"
            f"{self.deployment.sandbox_name}"
        )


class AWSAccount(ContextModel):
    """Details about a Kubernetes service account use by a service."""

    id: str
    region: str
    partition: str


class Deployment(ContextModel):
    """Details about a Kubernetes service account use by a service."""

    account: AWSAccount
    project_name: str
    name: str
    environment_name: str
    module_name: str
    sandbox_name: str | None = None
    skip_modules: list[str] | None = None


class EventBus(ContextModel):
    """Details about eventbuses available."""

    default: str
    oao_local: str

    @classmethod
    def from_context(cls, ref: dict) -> "EventBus":
        """Create model from the input dictionary."""
        return cls.model_validate(ref)


class EKSCluster(ContextModel):
    """Details about a Kubernetes service account use by a service."""

    name: str = Field(alias="EksClusterName")
    kubectl_master_role_arn: str = Field(alias="EksClusterMasterRoleArn")
    security_group_id: str = Field(alias="EksClusterSecurityGroupId")
    open_id_connect_issuer: str = Field(alias="EksClusterOpenIdConnectIssuer")
    oidc_arn: str = Field(alias="EksOidcArn")
    default_nodegroup_name: list[str] = Field(alias="EksNodeGroupIds")

    @classmethod
    def from_context(cls, ref: str) -> "EKSCluster":
        """Create model from the input dictionary."""
        dic = json.loads(ref)
        return cls.model_validate(dic)


class VPC(ContextModel):
    """Details about a Kubernetes service account use by a service."""

    id: str = Field(alias="vpcId")
    routable_subnet_ids: str = Field(alias="vpcRoutableSubnetIds")
    non_routable_subnet_ids: str = Field(alias="vpcNonRoutableSubnetIds")
    is_on_prem_routed: bool

    @classmethod
    def from_context(cls, ref: dict) -> "VPC":
        """Create model from the input dictionary."""
        return cls.model_validate(ref)


class SSLCertificate(ContextModel):
    """Details about a Kubernetes service account use by a service."""

    hosted_zone_id: str = Field(alias="hostedZoneId")
    hosted_zone_name: str = Field(alias="hostedZoneName")
    prefix: str

    @classmethod
    def from_context(cls, ref: dict) -> "SSLCertificate":
        """Create model from the input dictionary."""
        return cls.model_validate(ref)


class BastionHost(ContextModel):
    """Model for an SSH bastion host."""

    name: str


class PostgresDatabase(ContextModel):
    """Model for a postgres DB."""

    name: str


class PostgresDatabaseUser(ContextModel):
    """Model for a postgres DB user."""

    name: str
    user_name: str
    credentials_output_secret_path: str
    user_name_placeholder_in_scripts: str | None
    password_placeholder_in_scripts: str | None


class PostgresScript(ContextModel):
    """Model for a script to execute against a postgres DB."""

    files: list[str]
    schema: str
    non_sandbox_schema: str | None = None


class Postgres(ContextModel):
    """Details about a Postgres Cluster."""

    cluster_name_suffix: str
    port: int
    engine_version: str
    parameter_group: str
    master_user_name: str
    master_credentials_output_secret_path: str
    allow_security_groups: list[str]
    write_instance_name_suffix: str
    reader_instance_name_suffix: str
    use_routable_subnets: bool
    code_build_security_group: str | None = None
    database: PostgresDatabase | None = None
    bastion_host: BastionHost | None = None
    allow_major_version_upgrade: bool
    scripts: list[PostgresScript]
    serverless_min_capacity: float
    serverless_max_capacity: float
    db_users: list[PostgresDatabaseUser] = []
    requires_proxy: bool = False
    proxy_vpce_trust_accounts: list[str] = []

    @classmethod
    def from_context(cls, ref: dict) -> "Postgres":
        """Create model from the input dictionary."""
        return cls.model_validate(ref)


class CentralPrometheus(ContextModel):
    """Details about central prometheus"""

    vpc_endpoint_region_dns_name: str

    @classmethod
    def from_context(cls, ref: dict | None) -> "CentralPrometheus | None":
        """Create model from the input dictionary."""
        if ref is None:
            return None
        return cls.model_validate(ref)


class PipeToEventBridgeContext(ContextModel):
    """
    Load parameters required to route SQS events to an event bus.

    The event bus is located within AWS EventBridge.
    """

    add_cloudwatch_log: bool | None = False
    detail_type: str
    pipe_description: str
    pipe_name: str
    transformer: str
    use_default_event_bus: bool | None = False


class DLQueueContext(ContextModel):
    """Load parameters required to Create Dead Letter Queue."""

    max_receive_count: int
    message_retention_period: int | None
    message_visibility_timeout: int | None


class QueueContext(ContextModel):
    """Load parameters required to Create SQS."""

    name: str | None = None
    is_fifo: bool
    dlq: DLQueueContext | None = None
    max_receive_count: int | None = None
    message_retention_period: int
    message_visibility_timeout: int
    add_send_permissions_to_role_arns: dict = {}
    add_receive_permissions_to_role_arns: dict = {}
    full_name: str | None = None
    pipe_to_event_bridge: PipeToEventBridgeContext | None = None

    @classmethod
    def from_context(cls, ref: str) -> "QueueContext":
        """Create model from the input dictionary."""
        dic = json.loads(ref)
        return cls.model_validate(dic)


class EKSArgoPrerequisitesContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the EKS Argo Prerequisites."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "argo.prerequisites"

    raas_pipeline_namespace: str
    ref: dict
    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    wait_till_healthy: bool | None = True
    delegate_deployment_to_helm: bool | None = False

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "EKSArgoPrerequisitesContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class EKSArgoWorkflowsContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the EKS Argo Workflows."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "argo.workflows"

    ref: dict
    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    argo_docker_tag: str
    argo_docker_registry: str
    job_status_queue: QueueContext
    reprocessed_output_s3_bucket_arn: str
    collected_input_s3_bucket_arns: list[str]
    collected_input_s3_access_point_arns: list[str]
    subdomain_name: str
    enable_ingress: bool
    wait_till_healthy: bool | None = True
    values_dict: dict = {}
    etl_metadata_app_sync_assume_role_arn: str = Field(
        default=None, alias="dataProductsAppSyncAssumeRoleArn"
    )
    delegate_deployment_to_helm: bool | None = False

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "EKSArgoWorkflowsContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class EKSArgoEventsContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the EKS Argo Events."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "argo.events"

    ref: dict
    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    argo_docker_tag: str
    argo_docker_repository: str
    wait_till_healthy: bool | None = True
    values_dict: dict = {}
    delegate_deployment_to_helm: bool | None = False

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "EKSArgoEventsContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class EKSArgoEFSMountContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the EFS Mount."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "argo.efsmount"

    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    pvc_prefix: str | None = ""
    pvc_size: str | None = ""
    pvc_namespace: str | None = ""
    enable_shared_pvcs: bool | None = False
    efs_driver_docker_tag: str
    efs_docker_registry: str
    wait_till_healthy: bool | None = True
    delegate_deployment_to_helm: bool | None = False
    customer_functions: str

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "EKSArgoEFSMountContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class EKSS3MountContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the EKS S3 Mount."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "s3mount"

    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    collected_zone_s3_buckets: dict
    cacheable_read_only_s3_buckets: dict = {}
    readonly_volume_storage_capacity: str
    read_write_volume_storage_capacity: str
    readonly_volume_claim_storage_request: str
    read_write_volume_claim_storage_request: str
    driver_iam_role_policies: dict
    wait_till_healthy: bool | None = True
    read_write_volume_options: list[str] | None = None
    read_only_volume_options: list[str] | None = None
    cacheable_read_only_volume_options: list[str] | None = None
    values_dict: dict = {}
    delegate_deployment_to_helm: bool | None = False

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "EKSS3MountContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class ETLMetadataContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the rds postgres."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "etl_metadata"

    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    ref: dict

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "ETLMetadataContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class KubernetesServiceAccount(ContextModel):
    """Details about a Kubernetes service account use by a service."""

    name: str
    namespace: str
    iam_role_name: str
    iam_role_description: str


class OpensearchCollection(ContextModel):
    """Model of an OpenSearch instance."""

    name: str
    type: str
    principals: list[str] = []


class OutputBucket(ContextModel):
    """Model of a S3 output bucket."""

    name: str
    arn: str


class FluentbitContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the Fluentbit."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "fluentbit"

    ref: dict
    kubernetes_service_account: KubernetesServiceAccount
    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    wait_till_healthy: bool | None = True
    opensearch: OpensearchCollection | None = None
    delegate_deployment_to_helm: bool | None = False
    customer_functions: str = "common"
    rpu_logs_bucket: OutputBucket | None = None

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "FluentbitContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class EKSKarpenterContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the Karpenter"""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "karpenter"

    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    kubernetes_service_account: KubernetesServiceAccount
    wait_till_healthy: bool | None = True
    delegate_deployment_to_helm: bool | None = False
    replicas: int = Field(alias="replicas")
    tenant: str = Field(alias="tenant")
    subnet_discovery_tag_value: str = Field(alias="karpenterSubnetDiscoveryTagValue")
    karpenter_node_role: str = Field(alias="karpenterNodeRole")
    argo_ami_selector_alias: str = Field(alias="argoAMISelectorAlias")
    argo_instance_type: list = Field(alias="argoInstanceType")
    cpu_ami_selector_alias: str = Field(alias="cpuAMISelectorAlias")
    cpu_instance_type: list = Field(alias="cpuInstanceType")
    gpu_ami_selector_alias: str = Field(alias="gpuAMISelectorAlias")
    gpu_instance_type: list = Field(alias="gpuInstanceType")
    gpu_plugin_type: str = Field(alias="gpuPluginType")
    isp_ami_selector_alias: str = Field(alias="ispAMISelectorAlias")
    isp_instance_type: list = Field(alias="ispInstanceType")
    services_ami_selector_alias: str = Field(
        alias="servicesAMISelectorAlias", default=None
    )
    services_instance_type: list = Field(alias="servicesInstanceType", default=None)
    security_group_tag_discovery_value: str = Field(
        alias="securityGroupTagDiscoveryValue"
    )
    customer_functions: str = Field(alias="customerFunctions")

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "EKSKarpenterContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class HelmChartContext(ContextModel):
    """Managing the necessary params for HelmChart Context"""

    create_namespace: bool | None = True
    release_name: str
    deploy_in_namespace: str
    chart_folder_path: str | None = None
    values_dict: dict
    chart_name: str | None = None
    values_files: list[str] | None = None
    name: str | None = None
    deployment: Deployment
    helmcharts_folder: str | None = None
    ref: dict = {}
    deploy_after: list[str] | None = None
    donot_alter_namespace: bool | None = False
    wait_till_healthy: bool | None = True
    skip_deployment: bool | None = False
    delegate_deployment_to_helm: bool | None = True

    @classmethod
    def from_chart_folder_context(
        cls,
        *,
        create_namespace: bool,
        release_name: str,
        deploy_in_namespace: str,
        chart_folder_path: str,
        values_dict: dict,
        wait_till_healthy: bool | None,
        delegate_deployment_to_helm: bool | None,
        deployment: Deployment,
    ) -> "HelmChartContext":
        """Read values from the HelmChart context."""
        props: dict[str, Any] = {}
        props["create_namespace"] = create_namespace
        props["release_name"] = release_name
        props["deploy_in_namespace"] = deploy_in_namespace
        props["chart_folder_path"] = chart_folder_path
        props["values_dict"] = values_dict
        props["wait_till_healthy"] = wait_till_healthy
        props["delegate_deployment_to_helm"] = delegate_deployment_to_helm
        props["deployment"] = deployment
        return cls.model_validate(props)

    @classmethod
    def from_context(cls, ref: dict) -> "Postgres":
        """Create model from the input dictionary."""
        return cls.model_validate(ref)


class HelmChartsContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the HelmCharts."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "helmcharts"

    helmcharts: list[HelmChartContext]
    deployment: Deployment

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "HelmChartsContext":
        """
        Read values from the AWS CDK context.

        The function is currently unused and will produce model violations as
        an empty dictionary is checked.
        """
        del node  # indicate unused - fulfill contract with abstract base method
        del param_store  # indicate unused
        del kwargs  # indicate unused
        return cls.model_validate({})

    @classmethod
    def from_folder_context(
        cls,
        node: Node,
        param_store: ParamStore,
        helmcharts_folder: str,
    ) -> "HelmChartsContext":
        """Read values from the AWS CDK context."""
        root: dict[str, Any] = node.try_get_context("helmcharts")
        deployment: Deployment
        helmchart_contexts: list[HelmChartContext] = []
        # iterate over remaining keys in the JSON key path
        for helmchart in root:
            ctx = cls.read_context_values(
                node=node,
                json_key_path=f"helmcharts.{helmchart}",
                param_store=param_store,
            )
            ctx["name"] = helmchart
            chart_name = ctx["chartName"]
            ctx["chart_folder_path"] = f"{helmcharts_folder}/{chart_name}"
            helmchart_context = HelmChartContext.model_validate(ctx)
            helmchart_contexts.append(helmchart_context)
            deployment = helmchart_context.deployment
        return cls.model_validate(
            {
                "helmcharts": helmchart_contexts,
                "deployment": deployment,
            }
        )


class PostgresServerlessClusterContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the Postgres Serverless Cluster."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "postgres_serverless_clusters"

    name: str
    deployment: Deployment
    postgres: Postgres
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    skip_deployment: bool | None = False

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "PostgresServerlessClusterContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class PostgresServerlessClustersContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the Postgres Serverless Clusters."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "postgres_serverless_clusters"

    postgres_serverless_clusters: list[Any] = []
    deployment: Deployment | None = None

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "PostgresServerlessClustersContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        root: dict[str, Any] = node.try_get_context("postgres_serverless_clusters")
        deployment: Deployment
        postgres_serverless_cluster_contexts: list[
            PostgresServerlessClusterContext
        ] = []
        # iterate over remaining keys in the JSON key path
        for cluster in root:
            ctx = cls.read_context_values(
                node=node,
                json_key_path=f"postgres_serverless_clusters.{cluster}",
                param_store=param_store,
            )
            ctx["name"] = cluster
            postgres_serverless_cluster_context = (
                PostgresServerlessClusterContext.model_validate(ctx)
            )
            postgres_serverless_cluster_contexts.append(
                postgres_serverless_cluster_context
            )
            deployment = postgres_serverless_cluster_context.deployment

        if len(postgres_serverless_cluster_contexts) > 0:
            return cls.model_validate(
                {
                    "postgres_serverless_clusters": (
                        postgres_serverless_cluster_contexts
                    ),
                    "deployment": deployment,
                }
            )

        return cls.model_validate({"postgres_serverless_clusters": []})


class ServicesContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the MicroServices."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "services"

    services: list[Any]
    deployment: Deployment

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "ServicesContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        root: dict[str, Any] = node.try_get_context("services")
        deployment: Deployment
        microservice_contexts: list[ServiceContext] = []
        # iterate over remaining keys in the JSON key path
        for service in root:
            ctx = cls.read_context_values(
                node=node,
                json_key_path=f"services.{service}",
                param_store=param_store,
            )
            ctx["name"] = service
            try:
                microservice_context = ServiceContext.model_validate(ctx)
            except ValidationError as e:
                print(f"Validation error: {e}")
                print(f"For service: {service}")
                print(json.dumps(ctx, indent=4))
                raise
            microservice_contexts.append(microservice_context)
            deployment = microservice_context.deployment
        return cls.model_validate(
            {
                "services": microservice_contexts,
                "deployment": deployment,
            }
        )


class OAOPublisherContext(ContextModel):
    """Load parameters required for OAO Publisher."""

    name: str


class OAORuleContext(ContextModel):
    """Load parameters required for OAO Rule."""

    description: str
    detail_type: str


class OAOSubscriberContext(ContextModel):
    """Load parameters required for OAO Subscriber."""

    name: str
    rule: OAORuleContext
    use_default_event_bus: bool
    append_log_group_as_a_target: bool | None = False


class OAOContext(ContextModel):
    """Load parameters required to OAO Rules and Integration."""

    subscriber: OAOSubscriberContext | None = None
    publisher: OAOPublisherContext | None = None


class ServiceContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the MicroServices."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "services"

    name: str
    ref: dict
    database_username: str | None = None
    kubernetes_service_account: KubernetesServiceAccount
    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    additional_iam_role_policies: dict = {}
    oao_local_event_bus_name: str | None = None
    skip_deployment: bool | None = False
    oao: list[OAOContext] = []
    queues: list[QueueContext] | None = None

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "ServiceContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class NetworkListener(ContextModel):
    """Details about a network listener."""

    port: int
    protocol: str


class NetworkLoadBalancer(ContextModel):
    """Details about a network load balancer."""

    tags: dict
    listener: NetworkListener


class Cognito(ContextModel):
    """Details about cognito integration."""

    userpool_arn: str


class ApiGatewayPermisions(ContextModel):
    """Details about Api Gateway Permissions."""

    read_only_access_assumed_by: list[str] | None = None
    full_access_assumed_by: list[str] | None = None


class ApiGatewayIAM(ContextModel):
    """Details about Api Gateway IAM Auth."""

    permissions: ApiGatewayPermisions


class ApiGatewayKeycloak(ContextModel):
    """Details about Api Gateway Keycloak Auth."""

    __dict__: dict
    url: str | None = None
    client_id: str | None = None
    m2m_client_id: str | None = None
    group_role_config: dict | None = None


class ApiGatewaysContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the Api Gateways."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "apigateways"

    apigateways: list[Any]
    deployment: Deployment

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "ApiGatewaysContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        root: dict[str, Any] = node.try_get_context("apigateways")
        deployment: Deployment
        apigateway_contexts: list[ApiGatewayContext] = []
        # iterate over remaining keys in the JSON key path
        for apigateway in root:
            ctx = cls.read_context_values(
                node=node,
                json_key_path=f"apigateways.{apigateway}",
                param_store=param_store,
            )
            ctx["name"] = apigateway
            apigateway_context = ApiGatewayContext.model_validate(ctx)
            apigateway_contexts.append(apigateway_context)
            deployment = apigateway_context.deployment
        return cls.model_validate(
            {
                "apigateways": apigateway_contexts,
                "deployment": deployment,
            }
        )


class ApiGatewayContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the Api Gateway."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "apigateway"

    name: str
    ref: dict
    network_load_balancer: NetworkLoadBalancer
    api_paths: list[str]
    stage: str
    rate_limit: int
    burst_limit: int
    iam: ApiGatewayIAM | None = None
    keycloak_config: ApiGatewayKeycloak | None = None
    deployment: Deployment
    cognito: Cognito | None = None
    skip_deployment: bool | None = False

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "ApiGatewayContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class JobOaoWebsocketPipeContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the Websocket Api Gateways."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "job-oao-websocket-pipe"

    name: str
    ref: dict
    stage: str
    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    event_batch_size: int = 50
    event_batch_max_window_seconds: int = 10
    lambda_memory_size_mb: int = 256
    job_status_queue_arn: str
    skip_deployment: bool | None = False

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "JobOaoWebsocketPipeContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class PrometheusContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the Prometheus."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "prometheus"

    ref: dict
    deployment: Deployment
    kubernetes_service_account: KubernetesServiceAccount
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    image_registry: str | None = None
    wait_till_healthy: bool | None = True
    delegate_deployment_to_helm: bool | None = False

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "PrometheusContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class GrafanaSecurityGroupRuleIngress(ContextModel):
    """Details about Security Group Rule Ingress for Grafana."""

    port: int


class GrafanaSecurityGroupRule(ContextModel):
    """Details about Security Group Rules for Grafana."""

    name: str
    security_group_id: str
    ingress: GrafanaSecurityGroupRuleIngress


class GrafanaArtifact(ContextModel):
    """Details about Grafana artifacts such as datasource properties."""

    name: str
    datasource_properties: dict


class GrafanaContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the Grafana."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "grafana"

    ref: dict
    deployment: Deployment
    iam_role_name: str
    iam_role_description: str
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    artifacts: list[GrafanaArtifact] = []
    security_group_rules: list[GrafanaSecurityGroupRule] = []

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "GrafanaContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


def substitute_ssm_ref_values(ctx: dict) -> dict:
    """Substitute SSM ref values in the context dictionary."""
    ctx_new_dict = {key: ctx[key] for key in ctx}
    del ctx_new_dict["ref"]
    _substitute_ssm_ref_values(ctx_new_dict, ctx["ref"])
    ctx_new_dict.update({"ref": ctx["ref"]})
    return ctx_new_dict


def _substitute_ssm_ref_values(
    source: dict, ref: dict
) -> None | str | list[str] | bool:
    """
    Substitute any ssm key references in values dictionary with actual values.

    TODO: The function modifies source, but also returns a value. Should not do both.

    :raises ValueError: ref key not found in SSM
    """
    for key in source:
        if key == "ref":
            ssm_value = SSMResolver.resolve_ssm_value_ref(ref=ref, value=source)
            if ssm_value is None:
                ssm_key_ref = source["ref"]
                msg = f"SSM ref key : {ssm_key_ref} not found."
                raise ValueError(msg)
            return ssm_value
        if isinstance(source[key], list):
            for item_index in range(len(source[key])):
                item = source[key][item_index]
                if isinstance(item, dict):
                    resolved_ssm_value = _substitute_ssm_ref_values(item, ref)
                    if resolved_ssm_value is not None:
                        source[key][item_index] = resolved_ssm_value

        elif isinstance(source[key], dict):
            resolved_ssm_value = _substitute_ssm_ref_values(source[key], ref)
            if resolved_ssm_value is not None:
                source[key] = resolved_ssm_value
    return None


class Prometheus(ContextModel):
    """Prometheus details."""

    prometheus_workspace_url: str

    @classmethod
    def from_context(cls, ref: str) -> "Prometheus":
        """Create model from the input dictionary."""
        dic = json.loads(ref)
        return cls.model_validate(dic)


class CloudWatchContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the rds postgres."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "cloudwatch"

    deployment: Deployment
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    ref: dict

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "CloudWatchContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )
        return cls.model_validate(ctx)


class XraySamplingRule(ContextModel):
    """Details about Xray sampling rule to be set."""

    sampling_rate: float
    reservoir_size: int


class ADOTCollectorContext(ContextModel, _ContextLoaderMixin):
    """Load parameters required to deploy the ADOT Collector."""

    _CONTEXT_JSON_KEY_PATH: ClassVar[str] = "adot-collector"

    ref: dict
    deployment: Deployment
    kubernetes_service_account: KubernetesServiceAccount
    metadata_output_ssm_path: str = Field(alias="metadataOutputSSMPath")
    wait_till_healthy: bool | None = True
    delegate_deployment_to_helm: bool | None = False
    adot_contrib_collector_repo: str | None = None
    adot_collector_repo: str | None = None
    trace_alarm_sampling_rule: XraySamplingRule | None = None
    trace_default_sampling_rule: XraySamplingRule | None = None

    @classmethod
    def from_context(
        cls, node: Node, param_store: ParamStore, **kwargs
    ) -> "ADOTCollectorContext":
        """Read values from the AWS CDK context."""
        del kwargs  # indicate unused - fulfill contract with abstract base method
        ctx = cls.read_context_values(
            node=node,
            json_key_path=cls._CONTEXT_JSON_KEY_PATH,
            param_store=param_store,
        )

        print(
            f"[DEBUG] context.py > class:ADOTCollectorContext > func:from_context"
            f" > param_store: {param_store}"
        )

        return cls.model_validate(ctx)

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Parameters for stack to expose job status events to listening websockets"""

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    JobOaoWebsocketPipeContext,
)


class JobOaoWebsocketPipe(ContextModel):
    """Parameters for the stack piping OAO job events to websockets."""

    name: str
    stage: str
    deployment: Deployment
    output_metadata_path: str
    vpc: VPC
    event_batch_size: int = 50
    event_batch_max_window_seconds: int = 10
    job_status_queue_arn: str
    lambda_memory_size_mb: int = 256
    dns_hosted_zone_name: str
    shared_services_vpc_id: str

    @classmethod
    def from_context(cls, ctx: JobOaoWebsocketPipeContext) -> "JobOaoWebsocketPipe":
        """Return a new class instance with data validation by Pydantic."""
        id = ctx.get_submodule_id(
            module_name="job-oao-websocket-pipe", sub_module_name=ctx.name
        )
        vpc = VPC.from_context(ctx.ref["vpc"])
        props: dict = {}
        props["id"] = id
        props["vpc"] = vpc
        props["name"] = ctx.name
        props["stage"] = ctx.stage
        props["deployment"] = ctx.deployment
        props["output_metadata_path"] = ctx.metadata_output_ssm_path
        props["event_batch_size"] = ctx.event_batch_size
        props["event_batch_max_window_seconds"] = ctx.event_batch_max_window_seconds
        props["job_status_queue_arn"] = ctx.job_status_queue_arn
        props["lambda_memory_size_mb"] = ctx.lambda_memory_size_mb
        props["dns_hosted_zone_name"] = str(ctx.ref["dnsHostedZone"]).lower()
        props["shared_services_vpc_id"] = ctx.ref["sharedServicesVpc"]
        return cls.model_validate(props)

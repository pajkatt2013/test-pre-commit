#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Stack for publishing job OAO status events to websockets

The stack creates a new pipe listening for messages on the OAO job status queue
and publishes them to a websocket API Gateway via a Lambda. Connections to the
API gateway are maintained in a DynamoDB table.
"""

from importlib.resources import files

from aws_cdk import (
    CfnOutput,
    Environment,
    Stack,
    Tags,
    aws_apigatewayv2,
    aws_dynamodb,
    aws_iam,
    aws_lambda,
    aws_pipes,
    aws_ssm,
)
from constructs import Construct

from raas_infra.job_oao_websocket_pipe import JobOaoWebsocketPipe


class JobOaoWebsocketPipeStack(Stack):
    """Creates the websocket api gateway resources."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: JobOaoWebsocketPipe,
        env: Environment,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack contains resources for websocket API gateways.",
            env=env,
        )

        self.id = id
        self.stack_param = stack_param

        Tags.of(self).add("customer_function", "common")
        # Interested in how much cost this particular stack is generating.
        # Adding another distinct tag for monitoring this.
        Tags.of(self).add("application_feature", "oao_websocket_pipe")

        self.name_prefix = (
            f"{stack_param.name}"
            if not stack_param.deployment.sandbox_name
            else f"{stack_param.name}-{stack_param.deployment.sandbox_name}"
        )

        (websocket_api, session_table) = self._create_apigateway()
        pipe_lambda = self._create_lambda(websocket_api, session_table)
        self._create_event_pipe(pipe_lambda)

        CfnOutput(
            self,
            id=f"{self.name_prefix}-websocket-api-id",
            value=websocket_api.api_id,
            description="The id of the websocket api.",
        )
        CfnOutput(
            self,
            id=f"{self.name_prefix}-websocket-api-url",
            value=f"{websocket_api.api_endpoint}/{stack_param.stage}",
            description="The url of the websocket api.",
        )

        aws_ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=self.to_json_string(
                obj={
                    "websocketApiId": websocket_api.api_id,
                    "websocketApiUrl": (
                        f"{websocket_api.api_endpoint}/{stack_param.stage}"
                    ),
                }
            ),
        )

    def _create_apigateway(
        self,
    ) -> tuple[aws_apigatewayv2.WebSocketApi, aws_dynamodb.Table]:
        session_table = aws_dynamodb.Table(
            self,
            id=f"{self.name_prefix}-websocket-session-table",
            table_name=f"{self.name_prefix}-websocket-session-table",
            billing_mode=aws_dynamodb.BillingMode.PAY_PER_REQUEST,
            time_to_live_attribute="ttl",
            partition_key=aws_dynamodb.Attribute(
                name="jobId", type=aws_dynamodb.AttributeType.STRING
            ),
            sort_key=aws_dynamodb.Attribute(
                name="connectionId", type=aws_dynamodb.AttributeType.STRING
            ),
        )

        wsapi_dynamodb_role = aws_iam.Role(
            self,
            id=f"{self.name_prefix}-websocket-dynamodb-role",
            assumed_by=aws_iam.ServicePrincipal("apigateway.amazonaws.com"),
            role_name=f"{self.name_prefix}-websocket-dynamodb-role",
            inline_policies={
                "dynamodb-policy": aws_iam.PolicyDocument(
                    statements=[
                        aws_iam.PolicyStatement(
                            actions=[
                                "dynamodb:PutItem",
                                "dynamodb:DeleteItem",
                            ],
                            resources=[session_table.table_arn],
                            effect=aws_iam.Effect.ALLOW,
                        )
                    ]
                )
            },
        )

        wsapi = aws_apigatewayv2.WebSocketApi(
            self,
            id=f"{self.name_prefix}-websocket-api",
            api_name=f"{self.name_prefix}-websocket-api",
            route_selection_expression="$request.body.action",
        )

        # Falling back to L1 constructs here, I'm afraid. But there's no way to specify
        # integration responses and model checks at route level (yet) with L1.
        job_id_payload_model = aws_apigatewayv2.CfnModel(
            self,
            id=f"{self.name_prefix}job-id-payload-model",
            api_id=wsapi.api_id,
            name="JobIdPayloadModel",
            schema={
                "$schema": "http://json-schema.org/draft-04/schema#",
                "type": "object",
                "required": ["jobId"],
                "properties": {"address": {"type": "string"}},
            },
            content_type="application/json",
        )

        subscribe_job_route_integration = aws_apigatewayv2.CfnIntegration(
            self,
            id=f"{self.name_prefix}-websocket-subscribe-job-integration",
            api_id=wsapi.api_id,
            integration_type="AWS",
            connection_type="INTERNET",
            integration_method="POST",
            integration_uri=(
                f"arn:{self.stack_param.deployment.account.partition}:"
                f"apigateway:{self.stack_param.deployment.account.region}:dynamodb:action/PutItem"
            ),
            credentials_arn=wsapi_dynamodb_role.role_arn,
            template_selection_expression=r"\$default",
            request_templates={
                "$default": (
                    f"""
                    #set($ttl = $context.requestTimeEpoch + 86400)
                    {{
                      "TableName": "{session_table.table_name}",
                      "Item": {{
                        "connectionId": {{
                          "S": "$context.connectionId"
                        }},
                        "jobId": {{
                          "S": "$input.path('$.jobId')"
                        }},
                        "ttl": {{
                          "N": "$ttl"
                        }}
                      }}
                    }}
                    """
                )
            },
        )

        aws_apigatewayv2.CfnIntegrationResponse(
            self,
            id=f"{self.name_prefix}-subscribe-job-integration-response-success",
            api_id=wsapi.api_id,
            integration_id=subscribe_job_route_integration.ref,
            integration_response_key=r"/2\d\d/",
            template_selection_expression=r"\$default",
            response_templates={"$default": '{"statusCode": 200}'},
        )

        aws_apigatewayv2.CfnIntegrationResponse(
            self,
            id=f"{self.name_prefix}-subscribe-job-integration-response-error",
            api_id=wsapi.api_id,
            integration_id=subscribe_job_route_integration.ref,
            integration_response_key=r"/4\d\d/",
            template_selection_expression=r"\$default",
            response_templates={
                "$default": (
                    """
                    {
                      "statusCode": 400,
                      "message": "$input.path('$.message')"
                    }
                    """
                )
            },
        )

        subscribe_job_route = aws_apigatewayv2.CfnRoute(
            self,
            id=f"{self.name_prefix}-websocket-subscribe-job-route",
            api_id=wsapi.api_id,
            route_key="subscribeJob",
            target="integrations/" + subscribe_job_route_integration.ref,
            model_selection_expression=r"\$default",
            request_models={
                "$default": job_id_payload_model.name,
            },
        )

        aws_apigatewayv2.CfnRouteResponse(
            self,
            id=f"{self.name_prefix}-subscribe-job-route-response",
            api_id=wsapi.api_id,
            route_id=subscribe_job_route.ref,
            route_response_key="$default",
        )

        unsubscribe_job_route_integration = aws_apigatewayv2.CfnIntegration(
            self,
            id=f"{self.name_prefix}-websocket-unsubscribe-job-integration",
            api_id=wsapi.api_id,
            integration_type="AWS",
            connection_type="INTERNET",
            integration_method="POST",
            integration_uri=(
                f"arn:{self.stack_param.deployment.account.partition}:"
                f"apigateway:{self.stack_param.deployment.account.region}:dynamodb:action/DeleteItem"
            ),
            credentials_arn=wsapi_dynamodb_role.role_arn,
            template_selection_expression=r"\$default",
            request_templates={
                "$default": (
                    f"""
                    {{
                      "TableName": "{session_table.table_name}",
                      "Key": {{
                        "connectionId": {{
                          "S": "$context.connectionId"
                        }},
                        "jobId": {{
                          "S": "$input.path('$.jobId')"
                        }}
                      }}
                    }}
                    """
                )
            },
        )

        aws_apigatewayv2.CfnIntegrationResponse(
            self,
            id=f"{self.name_prefix}-unsubscribe-job-integration-response-success",
            api_id=wsapi.api_id,
            integration_id=unsubscribe_job_route_integration.ref,
            integration_response_key=r"/2\d\d/",
            template_selection_expression=r"\$default",
            response_templates={"$default": '{"statusCode": 200}'},
        )

        aws_apigatewayv2.CfnIntegrationResponse(
            self,
            id=f"{self.name_prefix}-unsubscribe-job-integration-response-error",
            api_id=wsapi.api_id,
            integration_id=unsubscribe_job_route_integration.ref,
            integration_response_key=r"/4\d\d/",
            template_selection_expression=r"\$default",
            response_templates={
                "$default": (
                    """
                    {
                      "statusCode": 400,
                      "message": "$input.path('$.message')"
                    }
                    """
                )
            },
        )

        unsubscribe_job_route = aws_apigatewayv2.CfnRoute(
            self,
            id=f"{self.name_prefix}-websocket-unsubscribe-job-route",
            api_id=wsapi.api_id,
            route_key="unsubscribeJob",
            target="integrations/" + unsubscribe_job_route_integration.ref,
            model_selection_expression=r"\$default",
            request_models={
                "$default": job_id_payload_model.name,
            },
        )

        aws_apigatewayv2.CfnRouteResponse(
            self,
            id=f"{self.name_prefix}-unsubscribe-job-route-response",
            api_id=wsapi.api_id,
            route_id=unsubscribe_job_route.ref,
            route_response_key="$default",
        )

        aws_apigatewayv2.WebSocketStage(
            self,
            id=f"{self.stack_param.name}-websocket-stage",
            stage_name=self.stack_param.stage,
            web_socket_api=wsapi,
            auto_deploy=True,
        )

        return wsapi, session_table

    def _create_lambda(
        self,
        websocket_api: aws_apigatewayv2.WebSocketApi,
        session_table: aws_dynamodb.Table,
    ) -> aws_lambda.Function:
        _lambda = aws_lambda.Function(
            self,
            id=f"{self.stack_param.name}-websocket-pipe-lambda",
            runtime=aws_lambda.Runtime.PYTHON_3_11,
            handler="pipe_lambda.handler",
            description=(
                "Lambda to pipe messages from OAO job status "
                "queue to websocket API Gateway"
            ),
            code=aws_lambda.Code.from_asset(
                str(files("raas_infra.constructs.lambdas.job_oao_websocket_pipe"))
            ),
            # This lambda is rather time-sensitive. Cold start times of Lambda is
            # a thing, and it's been shown that more memory reduces latency drastically.
            # Also, ARM-based Lambdas are a bit quicker (and cheaper) and here we only
            # execute boto3 after all.
            # https://medium.com/@adtanasa/size-is-almost-all-that-matters-for-optimizing-aws-lambda-cold-starts-cad54f65cbb
            # https://www.pluralsight.com/resources/blog/cloud/does-coding-language-memory-or-package-size-affect-cold-starts-of-aws-lambda
            memory_size=self.stack_param.lambda_memory_size_mb,
            architecture=aws_lambda.Architecture.ARM_64,
            environment={
                "TABLE_NAME": session_table.table_name,
                "API_ENDPOINT_URL": f"https://{websocket_api.api_id}.execute-api.{self.stack_param.deployment.account.region}.amazonaws.com/{self.stack_param.stage}",
            },
        )

        _lambda.add_to_role_policy(
            aws_iam.PolicyStatement(
                effect=aws_iam.Effect.ALLOW,
                actions=[
                    "dynamodb:BatchGetItem",
                    "dynamodb:GetItem",
                    "dynamodb:Query",
                    "dynamodb:Scan",
                ],
                resources=[session_table.table_arn],
            )
        )

        _lambda.add_to_role_policy(
            aws_iam.PolicyStatement(
                effect=aws_iam.Effect.ALLOW,
                actions=[
                    "execute-api:ManageConnections",
                ],
                resources=[
                    f"arn:{self.stack_param.deployment.account.partition}:execute-api:{self.stack_param.deployment.account.region}:{self.stack_param.deployment.account.id}:{websocket_api.api_id}/{self.stack_param.stage}/POST/@connections/*"
                ],
            )
        )

        return _lambda

    def _create_event_pipe(self, pipe_lambda: aws_lambda.Function) -> None:
        pipe_role = aws_iam.Role(
            self,
            f"{self.name_prefix}-sqs-pipe-role",
            role_name=f"{self.name_prefix}-sqs-pipe-role",
            assumed_by=aws_iam.ServicePrincipal("pipes.amazonaws.com"),
            inline_policies={
                "sqs-policy": aws_iam.PolicyDocument(
                    statements=[
                        aws_iam.PolicyStatement(
                            actions=[
                                "sqs:ReceiveMessage",
                                "sqs:DeleteMessage",
                                "sqs:GetQueueAttributes",
                            ],
                            resources=[self.stack_param.job_status_queue_arn],
                            effect=aws_iam.Effect.ALLOW,
                        )
                    ]
                ),
                "lambda-policy": aws_iam.PolicyDocument(
                    statements=[
                        aws_iam.PolicyStatement(
                            actions=[
                                "lambda:InvokeFunction",
                            ],
                            resources=[pipe_lambda.function_arn],
                            effect=aws_iam.Effect.ALLOW,
                        )
                    ]
                ),
            },
        )

        aws_pipes.CfnPipe(
            self,
            id=f"{self.name_prefix}-websocket-event-pipe",
            name=f"{self.name_prefix}-websocket-event-pipe",
            role_arn=pipe_role.role_arn,
            source=self.stack_param.job_status_queue_arn,
            source_parameters=aws_pipes.CfnPipe.PipeSourceParametersProperty(
                sqs_queue_parameters=aws_pipes.CfnPipe.PipeSourceSqsQueueParametersProperty(
                    batch_size=self.stack_param.event_batch_size,
                    maximum_batching_window_in_seconds=self.stack_param.event_batch_max_window_seconds,
                )
            ),
            target=pipe_lambda.function_arn,
            target_parameters=aws_pipes.CfnPipe.PipeTargetParametersProperty(
                input_template='{"payload":<$.body.detail.additional-details>}'
            ),
        )

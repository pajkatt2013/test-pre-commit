#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Helper utilities."""

from raas_infra.context import AWSAccount


class Helper:
    """
    Hold static methods.

    TODO(Marco): the static methods can just be top level functions
    """

    @staticmethod
    def get_oidc_provider(region: str, oidc_provider_id: str) -> str:
        """Get oidc provider"""
        if region == "cn-north-1":
            return f"oidc.eks.{region}.amazonaws.com.cn/id/{oidc_provider_id}"
        return f"oidc.eks.{region}.amazonaws.com/id/{oidc_provider_id}"

    @staticmethod
    def get_ecr_registry_url(account: str, region: str) -> str:
        """Return ecr url."""
        registry = f"https://{account}.dkr.ecr.{region}.amazonaws.com"
        if region == "cn-north-1":
            registry = registry + ".cn"
        return registry

    @staticmethod
    def get_iam_role_arn(account: AWSAccount, role_name: str) -> str:
        """Return the aws role arn format based on given account and role name."""
        return f"arn:{account.partition}:iam::{account.id}:role/{role_name}"

    @staticmethod
    def dictionary_deep_merge(target: dict, source: dict) -> None:
        """Deep merge given dictionaries including hierarchy."""
        for key in source:
            if isinstance(source[key], dict):
                if key not in target:
                    target[key] = source[key]
                elif isinstance(target[key], dict):
                    Helper.dictionary_deep_merge(target[key], source[key])
                else:
                    target[key] = source[key]
            else:
                target[key] = source[key]

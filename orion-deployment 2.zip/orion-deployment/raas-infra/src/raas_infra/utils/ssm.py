#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
RaaS Services SSM module.

Provides models for fetching and storing parameters from AWS SSM parameters.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from typing import Any

import boto3
from botocore.exceptions import ClientError

_CLIENT = None
_SECRETS_CLIENT = None


class ParamStore:
    """
    Base class to serve parameters, mainly from SSM.

    It is mainly used for typing.
    TODO(Marco): the methods should be abstract, not return random values.
    """

    def get_parameter(self, parameter_name: str) -> dict[str, Any] | None:
        """Get a parameter as JSON object."""
        del parameter_name  # indicate unused - serves as example for the interface
        return {"test": "test"}

    def get_parameter_value(self, parameter_name: str) -> str | None:
        """Get a parameter as string (containing a JSON object)."""
        del parameter_name  # indicate unused - serves as example for the interface
        return ""

    def get_secret_value(self, secret_name: str, deployment: dict) -> str | None:
        """Return a secret from secrets manager as string."""
        del secret_name  # indicate unused - serves as example for the interface
        del deployment  # indicate unused - serves as example for the interface
        return ""


class SSMParameterStore(ParamStore):
    """Implementation of ParamStore for AWS SSM."""

    def get_parameter(self, parameter_name: str) -> dict[str, Any] | None:
        """Get an SSM parameter as ."""
        global _CLIENT  # noqa: PLW0603 # used to lazily create a singleton
        if not _CLIENT:
            _CLIENT = boto3.client("ssm")

        try:
            print(f"fetching ssm parameter value for : {parameter_name}")
            resp = _CLIENT.get_parameter(Name=parameter_name)
            if not resp or "Parameter" not in resp or "Value" not in resp["Parameter"]:
                return None

            return json.loads(resp["Parameter"]["Value"])
        except _CLIENT.exceptions.ParameterNotFound:
            print(f"ssm parameter not found : {parameter_name}")
            return None

    def get_parameter_value(self, parameter_name: str) -> str | None:
        """Get an SSM parameter."""
        global _CLIENT  # noqa: PLW0603 # used to lazily create a singleton
        if not _CLIENT:
            _CLIENT = boto3.client("ssm")
        try:
            print(f"fetching ssm parameter value for : {parameter_name}")
            resp = _CLIENT.get_parameter(Name=parameter_name)
            if not resp or "Parameter" not in resp or "Value" not in resp["Parameter"]:
                return None

            return resp["Parameter"]["Value"]
        except _CLIENT.exceptions.ParameterNotFound:
            print(f"ssm parameter not found : {parameter_name}")
            return None

    def get_secret_value(self, secret_name: str, deployment: dict) -> str | None:
        """Get an Secret Value."""
        global _SECRETS_CLIENT  # noqa: PLW0603 # used to lazily create a singleton
        if not _SECRETS_CLIENT:
            _SECRETS_CLIENT = boto3.client("secretsmanager")
        try:
            account_partition = deployment["account"]["partition"]
            account_region = deployment["account"]["region"]
            account_id = deployment["account"]["id"]
            secret_arn = f"arn:{account_partition}:secretsmanager:{account_region}:{account_id}:secret:{secret_name}"
            print(f"fetching secret value for : {secret_arn}")
            resp = _SECRETS_CLIENT.get_secret_value(SecretId=secret_arn)
            if not resp or "SecretString" not in resp:
                return None

            return resp["SecretString"]

        except ClientError as e:
            if e.response["Error"]["Code"] == "ResourceNotFoundException":
                print(f"The requested secret {secret_arn} was not found")
            elif e.response["Error"]["Code"] == "InvalidRequestException":
                print("The request was invalid due to:", e)
            elif e.response["Error"]["Code"] == "InvalidParameterException":
                print("The request had invalid params:", e)
            else:
                print(f"Unable to fetch secret {secret_arn}", e)
            return None

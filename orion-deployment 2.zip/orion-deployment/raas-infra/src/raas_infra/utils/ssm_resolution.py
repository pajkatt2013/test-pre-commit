#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Return SSM value ref possibly running a jsonpath expression."""

import json

from jsonpath_ng import parse


class SSMResolver:
    """
    Host for a single static method.

    TODO(Marco): should be refactored to a plain method.
    """

    @staticmethod
    def resolve_ssm_value_ref(ref: dict, value: dict) -> str | bool | list[str] | None:
        """Return the value resolving from the referenced SSM parameter"""
        ssm_key_ref = value["ref"]

        if ssm_key_ref not in ref:
            ssm_value = None
        else:
            ssm_value = ref[ssm_key_ref]

            if "jsonPathExpression" in value:
                ssm_value = json.loads(ssm_value)
                jsonpath_expression = value["jsonPathExpression"]
                expression = parse(jsonpath_expression)
                match = expression.find(ssm_value)
                if match:
                    ssm_values = [
                        str(match.value) for match in expression.find(ssm_value)
                    ]
                    if len(ssm_values) == 1:
                        ssm_value = ssm_values[0]
                    elif "valuesJoinDelimiter" in value:
                        values_join_delimiter = value["valuesJoinDelimiter"]
                        ssm_value = values_join_delimiter.join(ssm_values)
                    else:
                        ssm_value = ssm_values
                else:
                    msg = (
                        "Unable to apply json path expression :"
                        f" {jsonpath_expression} on json object from"
                        f" ssm key : {ssm_key_ref}."
                    )
                    raise ValueError(msg)

        return ssm_value

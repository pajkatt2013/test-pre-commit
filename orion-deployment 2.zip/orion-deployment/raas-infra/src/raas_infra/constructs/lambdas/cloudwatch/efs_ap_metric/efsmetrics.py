#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""lambda for publishing the metrics on EFS access point threshold breached"""

import json
import logging
import os

import boto3

logger = logging.getLogger()
logger.setLevel("INFO")
efs = boto3.client("efs")
cw = boto3.client("cloudwatch")


def lambda_handler(
    event: dict | list | str | float | None,
    context: object,
) -> None:
    """Add lambda to publish metrics by monitoring the EFS access points."""
    metrics_json = os.environ.get("METRIC_DATA", "")
    namespace = os.environ.get("NAMESPACE", "")
    metric_name = os.environ.get("METRIC_NAME", "")
    metrics_data = json.loads(metrics_json)
    filesystemid = metrics_data["common-efs_file_system_id"]
    logger.info(event)
    logger.info(context)
    ap_count = len(
        efs.describe_access_points(MaxResults=1000, FileSystemId=filesystemid)[
            "AccessPoints"
        ]
    )

    cw.put_metric_data(
        Namespace=namespace,
        MetricData=[
            {
                "MetricName": metric_name,
                "Value": ap_count,
                "Dimensions": [{"Name": "FileSystemId", "Value": filesystemid}],
            }
        ],
    )

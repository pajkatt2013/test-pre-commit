#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Lambda handler to pipe job status events to connected websockets."""

import asyncio
import json
import logging
import os

import boto3

logging.getLogger().setLevel(logging.INFO)

api_client = None
db_client = None


def _get_api_gateway_client() -> boto3.client:
    global api_client  # noqa: PLW0603 need to use this method to properly stub in test
    if api_client is None:
        api_client = boto3.client(
            "apigatewaymanagementapi",
            endpoint_url=os.getenv("API_ENDPOINT_URL"),
        )
    return api_client


def _get_dynamodb_client() -> boto3.client:
    global db_client  # noqa: PLW0603 need to use this method to properly stub in test
    if db_client is None:
        db_client = boto3.client("dynamodb")
    return db_client


async def _pipe_job_event_to_websocket_conn(connection_id: str, event: dict) -> None:
    logging.debug(
        f"Piping event to connection ID {connection_id} with payload: {event}"
    )
    _get_api_gateway_client().post_to_connection(
        ConnectionId=connection_id, Data=json.dumps(event).encode()
    )


def _get_connection_ids(job_id: str) -> list[str]:
    logging.debug(f"Searching API connections for job ID {job_id}")
    response = _get_dynamodb_client().query(
        TableName=os.getenv("TABLE_NAME"),
        KeyConditionExpression="jobId = :jobId",
        ExpressionAttributeValues={":jobId": {"S": job_id}},
    )
    logging.debug(f"DynamoDB response: {response}")
    return [item["connectionId"]["S"] for item in response["Items"]]


async def _async_handler(events: list) -> None:
    logging.debug(f"Received event: {events}")
    connection_notification_tasks = []

    for event in events:
        job_event = event["payload"]
        job_id = job_event["job-id"]

        # We don't want to block for every API gateway notification call.
        # All of them are done in background.
        connection_notification_tasks.extend(
            [
                asyncio.create_task(
                    _pipe_job_event_to_websocket_conn(connection_id, job_event)
                )
                for connection_id in _get_connection_ids(job_id)
            ]
        )

    if connection_notification_tasks:
        await asyncio.wait(connection_notification_tasks)


def handler(
    events: list[dict],
    context: dict,  # noqa: ARG001
) -> None:
    """
    Lambda handler to pipe job status events to connected websockets.

    :param events: the list of batched OAO events containing job objects
    :param context: the Lambda execution context
    :return:
    """
    asyncio.get_event_loop().run_until_complete(_async_handler(events))

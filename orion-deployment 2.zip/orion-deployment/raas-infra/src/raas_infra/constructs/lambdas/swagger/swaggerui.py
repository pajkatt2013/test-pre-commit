#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Lambda handler serving Swagger UI."""

import json
import logging
import os
import re
from copy import deepcopy
from typing import Any

import awsgi
import boto3
from bottle import Bottle, request, response, static_file
from swagger_ui import api_doc

logger = logging.getLogger()
logger.setLevel("INFO")
app = Bottle()

KEYCLOAK_CLIENT_ID = os.getenv("KEYCLOAK_CLIENT_ID", "")
# Custom styling to the SwaggerUI will be available with
# https://github.com/PWZER/swagger-ui-py/pull/45
swaggerui = api_doc(
    app,
    config_rel_url="/api-docs",
    url_prefix="",
    parameters={
        "deepLinking": "true",
        "syntaxHighlight": '{"theme": "idea"}',
        "tagsSorter": '"alpha"',
        "docExpansion": '"none"',
        "layout": '"BaseLayout"',
        "presets": "[SwaggerUIBundle.presets.apis]",
    },
    oauth2_config={
        "clientId": f'"{KEYCLOAK_CLIENT_ID}"',
    },
)


@app.route("/oauth2-redirect.html")
def redirect_to_root() -> str:
    """Redirect endpoint from '/oauth2-redirect.html' to root URL '/'."""
    return static_file("oauth2-redirect.html", root="swagger_ui/static/")


@app.route("/api-docs")
def expose_swagger_definition() -> str:
    """Serve OpenAPI definitions retrieved from the GW instance."""
    logger.info("Fetching OpenAPI definitions from Lambda")
    api_identifier = request.environ["awsgi.event"]["requestContext"]["apiId"]
    api_stage = request.environ["awsgi.event"]["requestContext"]["stage"]

    export = boto3.client("apigateway").get_export(
        restApiId=api_identifier,
        stageName=api_stage,
        exportType="oas30",
        accepts="application/json",
        parameters={"extensions": "integrations"},
    )

    # Drop any method located at the root, this should not be allowed and is likely
    # only a workaround to get the Swagger UI integration running
    openapi_def = json.loads(export["body"].read().decode("utf-8"))
    if "/" in openapi_def["paths"]:
        del openapi_def["paths"]["/"]
    if "/{proxy+}" in openapi_def["paths"]:
        del openapi_def["paths"]["/{proxy+}"]

    # Specifically set the server to the referring host name, otherwise this will
    # be the API GW execution URL
    referring_host = next(
        request.environ["awsgi.event"]["headers"][header]
        for header in ["referer", "Referer"]
        if request.environ["awsgi.event"]["headers"][header]
    )
    openapi_def["servers"] = [{"url": referring_host}]

    # 1. If examples have been added via a custom extension `x-examples`, map them back
    # 2. If multiValueQueryString parameters are found in the AWS integration extension,
    #    map them to array type schema in OpenAPI
    # to OpenAPI standard.
    for path in openapi_def["paths"]:
        for method in openapi_def["paths"][path]:
            request_body = openapi_def["paths"][path][method].get("requestBody", {})
            if request_body:
                if "x-examples" in request_body:
                    for example in request_body.get("x-examples", []):
                        if example.get("contentType", "") in request_body.get(
                            "content", {}
                        ):
                            if (
                                "examples"
                                not in request_body["content"][example["contentType"]]
                            ):
                                request_body["content"][example["contentType"]][
                                    "examples"
                                ] = {}
                            request_body["content"][example["contentType"]]["examples"][
                                example["name"]
                            ] = {
                                "description": example["description"],
                                "value": example["value"],
                            }

                    del openapi_def["paths"][path][method]["requestBody"]["x-examples"]
                    openapi_def["paths"][path][method].pop("security", None)

                openapi_def["paths"][path][method]["requestBody"] = request_body

            if (
                "x-amazon-apigateway-integration"
                not in openapi_def["paths"][path][method]
            ):
                continue

            integration = openapi_def["paths"][path][method][
                "x-amazon-apigateway-integration"
            ]

            for param in [
                re.sub(r"integration\.request\.[^.]+\.", "", p)
                for p in integration.get("requestParameters", {})
                if integration["requestParameters"][p].startswith(
                    "method.request.multivaluequerystring"
                )
            ]:
                api_param = next(
                    p
                    for p in openapi_def["paths"][path][method]["parameters"]
                    if p["name"] == param
                )

                api_param["schema"] = {
                    "type": "array",
                    # keep original data type
                    "items": deepcopy(api_param["schema"]),
                }

            # Once done, remove the AWS integration extension
            del openapi_def["paths"][path][method]["x-amazon-apigateway-integration"]
            openapi_def["paths"][path][method].pop("security", None)

    # Add security scheme with type "keycloakAuth" to the global
    # components/securitySchemes section
    keycloak_url = os.getenv("KEYCLOAK_URL", "")
    keycloak_realm = os.getenv("KEYCLOAK_REALM", "orionadp")
    # overwrite existing securitySchemes fetched from apigw
    openapi_def.setdefault("components", {}).setdefault("securitySchemes", {}).clear()
    openapi_def.setdefault("components", {}).setdefault("securitySchemes", {}).update(
        {
            "keycloakAuth": {
                "type": "oauth2",
                "description": "!!! Use client_id: " + KEYCLOAK_CLIENT_ID,
                "flows": {
                    "implicit": {
                        "authorizationUrl": f"{keycloak_url}/realms/"
                        f"{keycloak_realm}/protocol/openid-connect/auth",
                        "scopes": {},
                    }
                },
            }
        }
    )

    openapi_def["security"] = [{"keycloakAuth": []}]

    response.content_type = "application/json"
    return json.dumps(openapi_def)


@app.hook("after_request")
def custom_headers() -> None:
    """Make browsers cache any response"""
    response.add_header("Cache-Control", "public, max-age=1800, immutable")


def lambda_handler(
    event: dict | list | str | float | None,
    context: object,
) -> dict[str, Any]:
    """
    Lambda entry point.

    API gateway will pass a proxy payload object which is unwrapped by `awsgi`.
    It will include the details on API gateway to serve the OpenAPI definitions for.
    See https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop
    -integrations-lambda.html

    Types for parameters from https://docs.aws.amazon.com/lambda/latest/dg/python
    -handler.html.
    """
    logger.info(f"Handling request for Swagger lambda with event: {event}")
    return awsgi.response(app, event, context, base64_content_types=["image/png"])


# For local testing and running the app
if __name__ == "__main__":
    app.run()

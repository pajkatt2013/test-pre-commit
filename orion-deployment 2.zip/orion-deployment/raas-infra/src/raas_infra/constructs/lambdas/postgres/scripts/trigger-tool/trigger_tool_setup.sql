-- Create schemas
CREATE SCHEMA IF NOT EXISTS [SCHEMA];

DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'trigger_tool_db_user') THEN

      RAISE NOTICE 'Role "trigger_tool_db_user" already exists. Skipping.';
   ELSE
      BEGIN
         CREATE USER trigger_tool_db_user;
      EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "trigger_tool_db_user" was just created by a concurrent transaction. Skipping.';
      END;
   END IF;
END
$do$;
GRANT rds_iam TO trigger_tool_db_user;
ALTER SCHEMA [SCHEMA] OWNER TO trigger_tool_db_user;
GRANT USAGE ON SCHEMA [SCHEMA] TO trigger_tool_db_user;
ALTER USER trigger_tool_db_user SET SEARCH_PATH = '[NON_SANDBOX_SCHEMA]';

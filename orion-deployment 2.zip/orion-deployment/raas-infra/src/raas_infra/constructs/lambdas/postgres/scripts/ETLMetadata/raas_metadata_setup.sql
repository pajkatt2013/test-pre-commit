-- Create schemas
CREATE SCHEMA IF NOT EXISTS [SCHEMA];

-- Set 'raas' schema to default. NOTE: Avoid using public.
ALTER DATABASE raas_metadata SET search_path TO raas;

-- Below extension is used to generate random uuid (gen_random_uuid) in the file_metadata migration scripts
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Create ETL users and grant permissions
DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'raas_argo_etl_file_sa') THEN

      RAISE NOTICE 'Role "raas_argo_etl_file_sa" already exists. Skipping.';
   ELSE
      BEGIN
         CREATE USER raas_argo_etl_file_sa;
      EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "raas_argo_etl_file_sa" was just created by a concurrent transaction. Skipping.';
      END;
   END IF;
END
$do$;
GRANT rds_iam TO raas_argo_etl_file_sa;
GRANT USAGE ON SCHEMA [SCHEMA] TO raas_argo_etl_file_sa;

DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'raas_argo_etl_session_sa') THEN

      RAISE NOTICE 'Role "raas_argo_etl_session_sa" already exists. Skipping.';
   ELSE
      BEGIN
         CREATE USER raas_argo_etl_session_sa;
      EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "raas_argo_etl_session_sa" was just created by a concurrent transaction. Skipping.';
      END;
   END IF;
END
$do$;
GRANT rds_iam TO raas_argo_etl_session_sa;
GRANT USAGE ON SCHEMA [SCHEMA] TO raas_argo_etl_session_sa;

DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'raas_argo_etl_rpu_sa') THEN

      RAISE NOTICE 'Role "raas_argo_etl_rpu_sa" already exists. Skipping.';
   ELSE
      BEGIN
         CREATE USER raas_argo_etl_rpu_sa;
      EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "raas_argo_etl_rpu_sa" was just created by a concurrent transaction. Skipping.';
      END;
   END IF;
END
$do$;
GRANT rds_iam TO raas_argo_etl_rpu_sa;
GRANT USAGE ON SCHEMA [SCHEMA] TO raas_argo_etl_rpu_sa;

DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'job_management_service_db_user') THEN
      RAISE NOTICE 'Role "job_management_service_db_user" already exists. Skipping.';
   ELSE
      BEGIN
         CREATE USER job_management_service_db_user;
      EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "job_management_service_db_user" was just created by a concurrent transaction. Skipping.';
      END;
   END IF;
END
$do$;
GRANT rds_iam TO job_management_service_db_user;
ALTER SCHEMA [SCHEMA] OWNER TO job_management_service_db_user;

DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'interval_based_file_metadata_user') THEN
      RAISE NOTICE 'Role "interval_based_file_metadata_user" already exists. Skipping.';
ELSE
BEGIN
         CREATE USER interval_based_file_metadata_user;
EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "interval_based_file_metadata_user" was just created by a concurrent transaction. Skipping.';
END;
END IF;
END
$do$;
GRANT rds_iam TO interval_based_file_metadata_user;
GRANT CONNECT ON DATABASE raas_metadata TO interval_based_file_metadata_user;
GRANT USAGE ON SCHEMA [SCHEMA] TO interval_based_file_metadata_user;

DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'job_caching_service_db_user') THEN
      RAISE NOTICE 'Role "job_caching_service_db_user" already exists. Skipping.';
   ELSE
      BEGIN
         CREATE USER job_caching_service_db_user;
      EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "job_caching_service_db_user" was just created by a concurrent transaction. Skipping.';
      END;
   END IF;
END
$do$;
GRANT rds_iam TO job_caching_service_db_user;
GRANT USAGE ON SCHEMA [SCHEMA] TO job_caching_service_db_user;

DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'raas_admin_role') THEN
      RAISE NOTICE 'Role "raas_admin_role" already exists. Skipping.';
   ELSE
      BEGIN
         CREATE USER raas_admin_role;
      EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "raas_admin_role" was just created by a concurrent transaction. Skipping.';
      END;
   END IF;
END
$do$;


GRANT ALL ON DATABASE raas_metadata TO raas_admin_role;


DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = 'raas_admin') THEN
      RAISE NOTICE 'Role "raas_admin" already exists. Skipping.';
   ELSE
      BEGIN
         CREATE USER raas_admin;
      EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "raas_admin" was just created by a concurrent transaction. Skipping.';
      END;
   END IF;
END
$do$;


grant rds_iam to raas_admin;
grant raas_admin_role to raas_admin;

DO
$do$
BEGIN
   IF EXISTS (
      SELECT FROM pg_catalog.pg_roles
      WHERE  rolname = '[GRAFANA_USER_NAME]') THEN

      RAISE NOTICE 'Role "[GRAFANA_USER_NAME]" already exists. Skipping.';
   ELSE
      BEGIN
         CREATE USER [GRAFANA_USER_NAME] WITH PASSWORD '[GRAFANA_USER_PASSWORD]';
      EXCEPTION
         WHEN duplicate_object THEN
            RAISE NOTICE 'Role "[GRAFANA_USER_NAME]" was just created by a concurrent transaction. Skipping.';
      END;
   END IF;
END
$do$;
GRANT USAGE ON SCHEMA [SCHEMA] TO [GRAFANA_USER_NAME];
GRANT SELECT ON ALL TABLES IN SCHEMA [SCHEMA] TO [GRAFANA_USER_NAME];

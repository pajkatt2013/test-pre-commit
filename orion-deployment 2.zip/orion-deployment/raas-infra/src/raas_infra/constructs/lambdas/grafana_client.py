#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Update Grafana data sources and dashboards."""

import json
import os
from pathlib import Path
from typing import Any

import boto3
import requests

HTTP_CODE_OK = 200


def lambda_handler(
    event: dict | list | str | float | None,
    context: object,
) -> dict[str, Any]:
    """Lambda entry point."""
    del context  # indicate unused
    print(f"request: {json.dumps(event)}")
    grafana_workspace_url = os.environ["GRAFANA_WORKSPACE_URL"]
    grafana_workspace_id = os.environ["GRAFANA_WORKSPACE_ID"]
    dashboards_folder_path = os.environ["DASHBOARDS_FOLDER_PATH"]
    grafana_workspace_api_key_name = os.environ["GRAFANA_WORKSPACE_API_KEY_NAME"]
    datasources_folder_path = os.environ["DATASOURCES_FOLDER_PATH"]

    grafana_datasources_properties_overwrite_json = os.environ[
        "GRAFANA_DATASOURCES_PROPERTIES_OVERWRITE_JSON"
    ]
    grafana_datasources_properties_overwrite = json.loads(
        grafana_datasources_properties_overwrite_json
    )

    # generating the grafana api  key
    grafana_api_key = get_grafana_api_key(
        grafana_workspace_id=grafana_workspace_id,
        grafana_workspace_api_key_name=grafana_workspace_api_key_name,
    )

    # create or update grafana datasources in the target grafana workspace.
    # the call returns the map of the grafana datasource reference uids as key and value
    # as the target grafana datasource uid
    grafana_datasource_uids = create_or_update_data_sources(
        grafana_api_key=grafana_api_key,
        grafana_workspace_url=grafana_workspace_url,
        datasources_folder_path=datasources_folder_path,
        grafana_datasources_properties_overwrite=grafana_datasources_properties_overwrite,
    )

    print("upserted grafana datasorces")
    print(grafana_datasource_uids)

    # create or update grafana dashboards.
    # dashboard definition which may contain the grafana datasource reference uids,
    # will be replaced with the target grafana datasource uid
    import_grafana_dashboards(
        grafana_api_key=grafana_api_key,
        grafana_workspace_url=grafana_workspace_url,
        dashboards_folder_path=dashboards_folder_path,
        grafana_datasource_uids=grafana_datasource_uids,
    )
    return {
        "statusCode": HTTP_CODE_OK,
        "headers": {"Content-Type": "text/plain"},
        "body": "Successfully imported grafana datasources and dashboards",
    }


def get_existing_data_source(
    grafana_api_key: str,
    grafana_workspace_url: str,
    datasource_name: str,
) -> None | dict:
    """Fetch existing datasource id if exists"""
    url = f"{grafana_workspace_url}/api/datasources/name/{datasource_name}"
    headers = {
        "Content-type": "application/json",
        "Authorization": f"Bearer {grafana_api_key}",
    }

    print(f"trying to fetch existing datasource id if exists. url : {url}")
    response = requests.get(url, headers=headers, timeout=30)

    existing_datasource = None
    # if the response status code is 200, it indicates the grafana datasource already
    # exists with the given name
    if response.status_code == HTTP_CODE_OK:
        existing_datasource = response.json()
        datasource_id = existing_datasource["id"]
        print(
            f"found existing datasource : {datasource_name} with id : {datasource_id}"
        )
    else:
        print(
            f"there is no datasource : {datasource_name} found in"
            f" grafana workspace. response : {response}"
        )

    return existing_datasource


def set_datasource_properties(
    grafana_datasource: dict, datasource_properties: dict
) -> dict:
    """Set the grafana datasource properties"""
    # updating the grafana datasource definition properties
    for key in datasource_properties:
        if key in grafana_datasource:
            datasource_property_value = datasource_properties[key]
            print(
                f"setting datasource property -> key : {key} with"
                f" value : {datasource_property_value}"
            )
            grafana_datasource[key] = datasource_property_value

    return grafana_datasource


def create_or_update_data_sources(
    grafana_api_key: str,
    grafana_workspace_url: str,
    datasources_folder_path: str,
    grafana_datasources_properties_overwrite: dict,
) -> dict:
    """Create or update datasources in grafana workspace"""
    print(f"applying datasources in grafana workspace : {grafana_workspace_url}")
    print(grafana_datasources_properties_overwrite)

    grafana_datasource_uids = {}

    datasource_files = os.listdir(datasources_folder_path)

    # foreach grafana dashboard definition, create or update the grafana dashboard
    for datasource_file_name in datasource_files:
        datasource_file = datasources_folder_path + "/" + datasource_file_name
        print(f"reading datasource definition from file : {datasource_file}")

        with Path(datasource_file).open() as fp:
            contents = fp.read()
            grafana_datasource = json.loads(contents)

            # saving the existing datasource uid as reference to replace in the
            # dashboards with the actual uids from the target grafana datasource
            # post creation
            datasource_ref_uid = grafana_datasource["uid"]
            datasource_name = grafana_datasource["name"]

            # overriding the datasource properties if provided
            if datasource_name in grafana_datasources_properties_overwrite:
                print(
                    "overwriting properties for datasource :"
                    f" {datasource_name}. file : {datasource_file}"
                )
                grafana_datasource = set_datasource_properties(
                    grafana_datasource=grafana_datasource,
                    datasource_properties=grafana_datasources_properties_overwrite[
                        datasource_name
                    ],
                )
            else:
                print(
                    "no overwriting properties found for datasource :"
                    f" {datasource_name}. file : {datasource_file}"
                )

            print(
                "trying to create/update datasource :"
                f" {datasource_name} in grafana from file :"
                f" {datasource_file}"
            )

            url = f"{grafana_workspace_url}/api/datasources"
            headers = {
                "Content-type": "application/json",
                "Authorization": f"Bearer {grafana_api_key}",
            }

            # checking if the datasource already exists
            existing_data_source = get_existing_data_source(
                grafana_api_key=grafana_api_key,
                grafana_workspace_url=grafana_workspace_url,
                datasource_name=datasource_name,
            )

            # setting the uid, id to null. datasource is referenced in api using "name"
            grafana_datasource["uid"] = None
            grafana_datasource["id"] = None

            # if there is no existing dashboard, then invoking the post for creation
            if existing_data_source is None:
                print(
                    f"create datasource : {datasource_name} in"
                    f" grafana. post url : {url}"
                )
                response = requests.post(
                    url,
                    data=json.dumps(grafana_datasource),
                    headers=headers,
                    timeout=30,
                )
                print(f"create datasource : {datasource_name} response : {response}")

                if response.status_code == HTTP_CODE_OK:
                    print(
                        "successfully created datasource :"
                        f" {datasource_name} in grafana from file :"
                        f" {datasource_file}"
                    )
                else:
                    msg = (
                        "failed to create datasource :"
                        f" {datasource_name} in grafana from file :"
                        f" {datasource_file}. response : {response}"
                    )
                    raise ValueError(msg)

            else:
                # if there is an existing dashboard, then invoking the put for update

                existing_data_source_id = existing_data_source["id"]
                url = (
                    f"{grafana_workspace_url}/api/datasources/{existing_data_source_id}"
                )
                print(
                    f"update datasource : {datasource_name} in grafana put url : {url}"
                )
                grafana_datasource["id"] = existing_data_source_id
                response = requests.put(
                    url,
                    data=json.dumps(grafana_datasource),
                    headers=headers,
                    timeout=30,
                )
                print(f"update datasource : {datasource_name} response : {response}")

                if response.status_code == HTTP_CODE_OK:
                    print(
                        "successfully updated datasource :"
                        f" {datasource_name} in grafana from file :"
                        f" {datasource_file} and id :"
                        f" {existing_data_source_id}"
                    )
                else:
                    msg = (
                        "failed to update datasource :"
                        f" {datasource_name} in grafana from file :"
                        f" {datasource_file} and url : {url}."
                        f" response : {response}"
                    )
                    raise ValueError(msg)

            existing_data_source = get_existing_data_source(
                grafana_api_key=grafana_api_key,
                grafana_workspace_url=grafana_workspace_url,
                datasource_name=datasource_name,
            )

            if existing_data_source is not None:
                grafana_datasource_uids.update(
                    {datasource_ref_uid: existing_data_source["uid"]}
                )

    return grafana_datasource_uids


def import_grafana_dashboards(
    grafana_api_key: str,
    grafana_workspace_url: str,
    dashboards_folder_path: str,
    grafana_datasource_uids: dict,
) -> None:
    """Import grafana dashboards to the target grafana workspace"""
    dashboard_files = os.listdir(dashboards_folder_path)

    # foreach grafana dashboard definition, create or update the grafana dashboard
    for dashboard_file in dashboard_files:
        import_grafana_dashboard(
            grafana_workspace_url=grafana_workspace_url,
            grafana_api_key=grafana_api_key,
            dasboard_file_path=dashboards_folder_path + "/" + dashboard_file,
            grafana_datasource_uids=grafana_datasource_uids,
        )


def set_datasource_uids_in_dashboard(
    grafana_dashboard: dict, grafana_datasource_uids: dict
) -> dict:
    """Replace ref uid in the dashboard with the target grafana datasource uid."""
    grafana_dashboard_json = json.dumps(grafana_dashboard)

    for datasource_ref_uid in grafana_datasource_uids:
        datasource_uid = grafana_datasource_uids[datasource_ref_uid]
        print(
            "replacing datasource ref uid :"
            f" {datasource_ref_uid} with {datasource_uid} in the"
            " dashboard definition"
        )
        grafana_dashboard_json = grafana_dashboard_json.replace(
            datasource_ref_uid, datasource_uid
        )

    return json.loads(grafana_dashboard_json)


def import_grafana_dashboard(
    grafana_workspace_url: str,
    grafana_api_key: str,
    dasboard_file_path: str,
    grafana_datasource_uids: dict,
) -> None:
    """Import grafana dashboard to the target grafana workspace"""
    print(f"trying to import grafana dashboard from file : {dasboard_file_path}")
    with Path(dasboard_file_path).open() as fp:
        contents = fp.read()
        grafana_dashboard = json.loads(contents)

        # replacing the grafana datasource reference uids with the actual uids from the
        # target grafana datasource
        grafana_dashboard = set_datasource_uids_in_dashboard(
            grafana_dashboard=grafana_dashboard,
            grafana_datasource_uids=grafana_datasource_uids,
        )

        # setting the uid, id to null. dashbpard is referenced in api using "name"
        grafana_dashboard["uid"] = None
        grafana_dashboard["id"] = None

        request_body = {
            "dashboard": grafana_dashboard,
            "overwrite": True,
        }
        url = f"{grafana_workspace_url}/api/dashboards/db"
        headers = {
            "Content-type": "application/json",
            "Authorization": f"Bearer {grafana_api_key}",
        }

        print(f"create/update grafana dashboard post url : {url}")
        response = requests.post(
            url, data=json.dumps(request_body), headers=headers, timeout=30
        )
        print(f"import grafana dashboard response : {response}")

        if response.status_code == HTTP_CODE_OK:
            print(
                "successfully imported grafana dashboard from file :"
                f" {dasboard_file_path}"
            )
        else:
            msg = (
                "failed to import grafana dashboard from file :"
                f" {dasboard_file_path}. response status code :"
                f" {response.status_code}"
            )
            raise ValueError(msg)


def get_grafana_api_key(
    grafana_workspace_id: str, grafana_workspace_api_key_name: str
) -> str:
    """Generate grafana workspace api key."""
    grafana_client = boto3.client("grafana")

    # trying to delete the api key if already exists with the given key name
    try:
        api_delete_workspace_key_response = grafana_client.delete_workspace_api_key(
            keyName=grafana_workspace_api_key_name,
            workspaceId=grafana_workspace_id,
        )
        print(
            "deleted grafana workspace api key with name :"
            f" {grafana_workspace_api_key_name}.\n"
            f" {api_delete_workspace_key_response}"
        )
    except grafana_client.exceptions.ResourceNotFoundException:
        print(
            "grafana workspace api key with name :"
            f" {grafana_workspace_api_key_name} doesn't exist."
        )

    # creating a new api key with the given key name
    api_create_workspace_key_response = grafana_client.create_workspace_api_key(
        keyName=grafana_workspace_api_key_name,
        keyRole="ADMIN",
        secondsToLive=20 * 60,
        workspaceId=grafana_workspace_id,
    )
    print(
        "created grafana workspace api key with name :"
        f" {grafana_workspace_api_key_name}"
    )
    return api_create_workspace_key_response["key"]

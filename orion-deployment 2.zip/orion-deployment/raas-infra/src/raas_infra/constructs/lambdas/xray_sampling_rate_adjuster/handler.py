#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Lambda function to adjust X-Ray sampling rate based on CloudWatch Alarm state."""

import json
import logging
import os

import boto3

xray = boto3.client("xray")
XRAY_RULE_ARN = os.environ["XRAY_RULE_ARN"]
DEFAULT_SAMPLING_RATE = os.environ["DEFAULT_SAMPLING_RATE"]
DEFAULT_SAMPLING_RESERVOIR_SIZE = os.environ["DEFAULT_SAMPLING_RESERVOIR_SIZE"]
ALARM_SAMPLING_RATE = os.environ["ALARM_SAMPLING_RATE"]
ALARM_SAMPLING_RESERVOIR_SIZE = os.environ["ALARM_SAMPLING_RESERVOIR_SIZE"]


def lambda_handler(event: dict, context: dict) -> None:
    """
    Adjust X-Ray sampling rate based on CloudWatch Alarm state.

    :param event: the event received from the SNS trigger
    :param context: the context this function is running in
    :return:
    """
    logging.debug(f"Event: {event}")
    logging.debug(f"Context: {context}")
    alarm_state = _get_alarm_state(event)
    if alarm_state == "ALARM":
        _adjust_sampling_rate(
            fixed_rate=float(ALARM_SAMPLING_RATE),
            reservoir_size=int(ALARM_SAMPLING_RESERVOIR_SIZE),
        )
    elif alarm_state == "OK":
        _adjust_sampling_rate(
            fixed_rate=float(DEFAULT_SAMPLING_RATE),
            reservoir_size=int(DEFAULT_SAMPLING_RESERVOIR_SIZE),
        )


def _get_alarm_state(event: dict) -> str:
    alarm_state = "INSUFFICIENT_DATA"
    records = event.get("Records", [])
    if records:
        alarm_state = json.loads(records[0]["Sns"]["Message"])["NewStateValue"]

    return alarm_state


def _adjust_sampling_rate(fixed_rate: float, reservoir_size: int) -> None:
    xray.update_sampling_rule(
        SamplingRuleUpdate={
            "RuleARN": XRAY_RULE_ARN,
            "FixedRate": fixed_rate,
            "ReservoirSize": reservoir_size,
        }
    )

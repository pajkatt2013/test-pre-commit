#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Lambda handler to execute postgres SQL scripts."""

import json
import os
from pathlib import Path

import boto3
import psycopg2


def handler(event: dict | list | str | float | None, context: object) -> dict:
    """Lambda entry point."""
    del context  # indicate unused
    print(f"request: {json.dumps(event)}")
    postgres_secret_arn = os.environ["POSTGRES_SECRET_ARN"]
    scripts_folder_path = os.environ["SCRIPTS_FOLDER_PATH"]
    postgres_scripts_path = os.environ["POSTGRES_SCRIPTS"]
    db_user_credentials_path = os.environ["DB_USER_CREDENTIALS"]
    postgres_scripts = json.loads(postgres_scripts_path)
    db_user_credentials = json.loads(db_user_credentials_path)
    execute_scripts(
        scripts_folder_path=scripts_folder_path,
        postgres_secret_arn=postgres_secret_arn,
        postgres_scripts=postgres_scripts,
        db_user_credentials=db_user_credentials,
    )
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "text/plain"},
        "body": (
            "Successfully executed postgres scripts. Database secret"
            f" : {postgres_secret_arn}\n"
        ),
    }


def execute_scripts(
    scripts_folder_path: str,
    postgres_secret_arn: str,
    postgres_scripts: list,
    db_user_credentials: dict,
) -> None:
    """Execute script files from scripts folder and SSM postgres connection info."""
    secrets_manager = boto3.client("secretsmanager")
    master_secret_response = secrets_manager.get_secret_value(
        SecretId=postgres_secret_arn
    )
    master_secret = json.loads(master_secret_response["SecretString"])

    database_host = master_secret["host"]
    port = master_secret["port"]
    database_name = master_secret["dbname"]
    master_username = master_secret["username"]
    master_password = master_secret["password"]

    secrets = []
    script_content_placeholders = {}
    for db_user_credential in db_user_credentials.values():
        secret_response = secrets_manager.get_secret_value(
            SecretId=db_user_credential["secret_arn"]
        )
        secret = json.loads(secret_response["SecretString"])
        password = secret["password"]
        username = secret["username"]
        script_content_placeholders.update(
            {
                db_user_credential["db_user"][
                    "user_name_placeholder_in_scripts"
                ]: username
            }
        )
        script_content_placeholders.update(
            {db_user_credential["db_user"]["password_placeholder_in_scripts"]: password}
        )
        secrets.append(password)

    script_files = os.listdir(scripts_folder_path)
    print(f"postgres_scripts : {postgres_scripts}")

    for postgres_schema_scripts in postgres_scripts:
        schema_name = postgres_schema_scripts["schema"]
        non_sandbox_schema = postgres_schema_scripts["non_sandbox_schema"]
        schema_script_files = postgres_schema_scripts["files"]
        print(f"start executing scripts for schema : {schema_name}")
        print(f"scripts : {schema_script_files}")
        for schema_script_file in schema_script_files:
            if schema_script_file not in script_files:
                msg = (
                    f"cannot execute script : {schema_script_file}."
                    f" {schema_script_file} is not found to execute"
                    f" in schema : {schema_name}."
                )
                raise ValueError(msg)

            print(f"executing script : {schema_script_file} in schema : {schema_name}")
            script_file_full_name = scripts_folder_path + "/" + schema_script_file
            with Path(script_file_full_name).open() as fp:
                contents = fp.read()
                contents = contents.replace("[SCHEMA]", schema_name)
                contents = contents.replace("[NON_SANDBOX_SCHEMA]", non_sandbox_schema)

                for (
                    name,
                    value,
                ) in script_content_placeholders.items():
                    contents = contents.replace(name, value)

                execute_sql_using_credentials(
                    database_host=database_host,
                    port=port,
                    database_name=database_name,
                    username=master_username,
                    password=master_password,
                    name=schema_script_file,
                    sql=contents,
                    secrets=secrets,
                )


def execute_sql_using_credentials(
    database_host: str,
    port: str,
    database_name: str,
    username: str,
    password: str,
    name: str,
    sql: str,
    secrets: list[str],
) -> None:
    """Execute the given sql statement in the postgres database."""
    print("Executing sql statement in postgres using credentials")

    print(f"Database Host : {database_host}")
    print(f"Port : {port}")
    print(f"Database Name : {database_name}")
    print(f"User Name : {username}")
    print(f"Name : {name}")
    print("Sql Statement")
    santized_sql = sql
    for secret in secrets:
        santized_sql = santized_sql.replace(secret, "*******")

    print(santized_sql)

    conn = psycopg2.connect(
        host=database_host,
        database=database_name,
        port=port,
        user=username,
        password=password,
    )

    cur = conn.cursor()
    cur.execute(sql)
    conn.commit()
    conn.close()
    cur.close()

    print("Completed executing sql statement in postgres")

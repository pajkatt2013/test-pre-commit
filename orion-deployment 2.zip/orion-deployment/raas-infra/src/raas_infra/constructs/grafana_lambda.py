#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Construct for Grafana data source creation and dashboard import."""

import json
from importlib.resources import files
from pathlib import Path

import aws_cdk.aws_iam as iam
from aws_cdk import Aws, Duration, triggers
from aws_cdk import aws_lambda as lambda_
from constructs import Construct


class RaaSGrafana(Construct):
    """RaaS Grafana construct to create data source and import dashboards."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        name: str,
        lambda_role_name: str,
        grafana_workspace_id: str,
        grafana_workspace_url: str,
        grafana_datasources_properties_overwrite: dict,
        **kwargs,
    ) -> None:
        super().__init__(scope, id, **kwargs)

        dashboards_folder_path = f"grafana/{name}/dashboards"
        datasources_folder_path = f"grafana/{name}/datasources"
        code_file_path = str(files("raas_infra.constructs.lambdas"))

        dashboards_full_folder_path = str(
            files("raas_infra.constructs.lambdas").joinpath(dashboards_folder_path)
        )

        # Checking if there is a dashboards to be imported for the given name
        if not Path(dashboards_full_folder_path).exists():
            return

        grafana_access_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=["grafana:*"],
                    resources=["*"],
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        inline_policies = {"grafana_access_policy": grafana_access_policy}

        # creating role for lambda function to access the grafana workspace
        lambda_role = iam.Role(
            self,
            id=f"{id}-role",
            role_name=lambda_role_name,
            description=(
                "This role is used to invoke the lambda function for"
                f" running the {name} related grafana actions."
            ),
            inline_policies=inline_policies,
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
        )

        lambda_role.add_managed_policy(
            iam.ManagedPolicy.from_managed_policy_arn(
                id="AWSLambdaBasicExecutionRole",
                scope=self,
                managed_policy_arn=f"arn:{Aws.PARTITION}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole",
            )
        )

        lambda_role.add_managed_policy(
            iam.ManagedPolicy.from_managed_policy_arn(
                id="AWSLambdaVPCAccessExecutionRole",
                scope=self,
                managed_policy_arn=f"arn:{Aws.PARTITION}:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
            )
        )

        grafana_datasources_properties_overwrite_json = json.dumps(
            grafana_datasources_properties_overwrite
        )

        # triggering the lambda function to import the grafana dashboards
        self.trigger_grafana_actions = triggers.TriggerFunction(
            self,
            id=f"{id}-trigger-import-grafana-dashboards",
            code=lambda_.Code.from_asset(code_file_path),
            runtime=lambda_.Runtime.PYTHON_3_10,
            timeout=Duration.seconds(600),
            handler="grafana_client.handler",
            environment={
                "GRAFANA_WORKSPACE_ID": grafana_workspace_id,
                "DASHBOARDS_FOLDER_PATH": dashboards_folder_path,
                "GRAFANA_WORKSPACE_API_KEY_NAME": "raas-infra-grafana-admin",
                "GRAFANA_WORKSPACE_URL": grafana_workspace_url,
                "DATASOURCES_FOLDER_PATH": datasources_folder_path,
                "GRAFANA_DATASOURCES_PROPERTIES_OVERWRITE_JSON": (
                    grafana_datasources_properties_overwrite_json
                ),
            },
            role=lambda_role,
            description=(
                "This trigger function is responsible to run the"
                f" RaaS {name} related grafana actions."
            ),
            execute_after=[scope],
        )

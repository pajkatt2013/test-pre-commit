#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Lambda handler to execute scripts against raas postgres DB."""

import json
from importlib.resources import files
from pathlib import Path

import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_iam as iam
from aws_cdk import Aws, Duration, triggers
from aws_cdk import aws_lambda as lambda_
from constructs import Construct

from raas_infra.context import VPC, PostgresScript


class RaaSPostgresExecuteScripts(Construct):
    """RaaS Helm Chart construct to deploy raas postgres init scripts using AWS CDK"""

    def __init__(
        self,
        scope: Construct,
        id: str,
        name: str,
        lambda_role_name: str,
        vpc: ec2.Vpc,
        postgres_secret_arn: str,
        db_user_credentials: dict,
        postgres_sg: ec2.SecurityGroup,
        postgres_port: int,
        postgres_scripts: list[PostgresScript],
        access_secrets_arn: str,
        vpc_metadata: VPC,
        **kwargs,
    ) -> None:
        super().__init__(scope, id, **kwargs)

        scripts_folder_path = f"postgres/scripts/{name}"

        code_file_path = str(files("raas_infra.constructs.lambdas"))

        scripts_full_folder_path = str(
            files("raas_infra.constructs.lambdas").joinpath(scripts_folder_path)
        )

        # Checking if there is a init scripts to be executed for the given name
        if Path(scripts_full_folder_path).exists() is False:
            return

        secrets_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=["secretsmanager:GetSecretValue"],
                    resources=[access_secrets_arn],
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        inline_policies = {"postgres-db-secrets": secrets_policy}

        # creating role for lambda function to access secrets to fetch
        # postgres credentials
        lambda_role = iam.Role(
            self,
            id=f"{id}-role",
            role_name=lambda_role_name,
            description=(
                "This role is used to invoke the lambda function for"
                f" running the {name} postgres scripts"
            ),
            inline_policies=inline_policies,
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
        )

        lambda_role.add_managed_policy(
            iam.ManagedPolicy.from_managed_policy_arn(
                id="AWSLambdaBasicExecutionRole",
                scope=self,
                managed_policy_arn=f"arn:{Aws.PARTITION}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole",
            )
        )

        lambda_role.add_managed_policy(
            iam.ManagedPolicy.from_managed_policy_arn(
                id="AWSLambdaVPCAccessExecutionRole",
                scope=self,
                managed_policy_arn=f"arn:{Aws.PARTITION}:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",
            )
        )

        lambda_sg_name = f"{id}-lambda-sg"
        lambda_sg = ec2.SecurityGroup(
            self,
            f"{id}-lambda_sg_name",
            security_group_name=lambda_sg_name,
            vpc=vpc,
            allow_all_outbound=True,
        )
        # updating postgres sg to allow connection from lambda function
        postgres_sg.add_ingress_rule(
            lambda_sg,
            ec2.Port.tcp(postgres_port),
            f"Allow traffic from the {name} lambda function to"
            f" execute scripts - security group - {lambda_sg_name}",
        )

        # List of subnets
        self.private_subnets = []
        non_routable_subnets = json.loads(vpc_metadata.non_routable_subnet_ids)
        for idx, subnet_id in enumerate(non_routable_subnets):
            self.private_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"subnet{idx}", subnet_id=subnet_id
                )
            )

        postgres_scripts_map = [
            {
                "schema": x.schema,
                "non_sandbox_schema": (
                    x.non_sandbox_schema
                    if x.non_sandbox_schema is not None
                    else x.schema
                ),
                "files": x.files,
            }
            for x in postgres_scripts
        ]

        # triggering the lambda function to run the init scripts
        self.trigger_exec_postgres_scripts = triggers.TriggerFunction(
            self,
            id=f"{id}-trigger-execute-scripts",
            code=lambda_.Code.from_asset(code_file_path),
            runtime=lambda_.Runtime.PYTHON_3_10,
            vpc=vpc,
            vpc_subnets=ec2.SubnetSelection(subnets=self.private_subnets),
            timeout=Duration.seconds(300),
            handler="postgres_client.handler",
            environment={
                "POSTGRES_SECRET_ARN": postgres_secret_arn,
                "SCRIPTS_FOLDER_PATH": scripts_folder_path,
                "POSTGRES_SCRIPTS": json.dumps(postgres_scripts_map),
                "DB_USER_CREDENTIALS": json.dumps(
                    db_user_credentials, default=lambda k: k.__dict__
                ),
            },
            role=lambda_role,
            security_groups=[lambda_sg],
            description=(
                "This trigger function is responsible to run the"
                f" RaaS {name} postgres scripts"
            ),
            execute_after=[scope],
        )

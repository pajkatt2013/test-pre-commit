#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Build an eks.HelmChart construct.

cdk creates a Lambda handler for this that calls helm to deploy to EKS.
"""

import json
from datetime import datetime, timezone
from pathlib import Path

import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_eks as eks
import aws_cdk.aws_s3_assets as s3_assets
import yaml
from aws_cdk import Duration
from constructs import Construct

from raas_infra.context import (
    VPC,
    Deployment,
    EKSCluster,
    HelmChartContext,
)
from raas_infra.utils.helper import Helper


class RaaSHelmChart(Construct):
    """eks.HelmChart construct."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        eks_cluster: EKSCluster,
        vpc: VPC,
        helm_chart: HelmChartContext,
        deployment: Deployment,
        **kwargs,
    ) -> None:
        """RaaS Helm Chart construct to deploy custom helm chart using AWS CDK"""
        super().__init__(scope, id, **kwargs)

        # Fetch VPC resource using look up based on VPC Id.
        self.vpc = ec2.Vpc.from_lookup(self, id="VPC", vpc_id=vpc.id)

        # Fetch EKS Cluster based on VPC, Subnets, Name and Master role
        self.cluster = eks.Cluster.from_cluster_attributes(
            self,
            id=f"EKS-{helm_chart.release_name}",
            cluster_name=eks_cluster.name,
            kubectl_role_arn=eks_cluster.kubectl_master_role_arn,
            kubectl_private_subnet_ids=(
                None
                if vpc.is_on_prem_routed is False
                else json.loads(vpc.routable_subnet_ids)
            ),
            kubectl_security_group_id=eks_cluster.security_group_id,
            vpc=self.vpc,
        )

        # Helm chart construct to deploy from helm chart from folder
        if helm_chart.chart_folder_path is not None:
            self.values_dict = self.get_values_dict(helm_chart)

            # in case of sandbox deployment setting the sandbox name as suffix
            # as applicable
            if deployment.sandbox_name is not None:
                # specific set of helm chart value properties to suffix the sandbox name
                # during the deployment
                sandbox_name = deployment.sandbox_name
                sandbox_properties = {
                    "ingress.host.prefix": f"-{sandbox_name}",
                    "config.database.schemaName": f"_{sandbox_name}",
                    "config.database.schemaScenarioClassifier": f"_{sandbox_name}",
                    "config.database.schemaQuality": f"_{sandbox_name}",
                    "config.database.schemaCandidateService": f"_{sandbox_name}",
                    "fileMetadataSensor.name": f"-{sandbox_name}",
                    "sessionMetadataSensor.name": f"-{sandbox_name}",
                    "mapMetadataSensor.name": f"-{sandbox_name}",
                    "raasPipelineSensor.name": f"-{sandbox_name}",
                    "fileMetadataSensor.eventSourceName": f"-{sandbox_name}",
                    "sessionMetadataSensor.eventSourceName": f"-{sandbox_name}",
                    "mapMetadataSensor.eventSourceName": f"-{sandbox_name}",
                    "raasPipelineSensor.eventSourceName": f"-{sandbox_name}",
                    "fileMetadataSensor.raasPipelineTrigger.namespace": (
                        f"-{sandbox_name}"
                    ),
                    "sessionMetadataSensor.raasPipelineTrigger.namespace": (
                        f"-{sandbox_name}"
                    ),
                    "mapMetadataSensor.raasPipelineTrigger.namespace": (
                        f"-{sandbox_name}"
                    ),
                    "raasPipelineSensor.raasPipelineTrigger.namespace": (
                        f"-{sandbox_name}"
                    ),
                    "raasPipelineQRPCVSensor.raasPipelineTrigger.namespace": (
                        f"-{sandbox_name}"
                    ),
                    "raasPipelineQRPCVSensor.name": f"-{sandbox_name}",
                    "raasPipelineQRPCVEventSource.sqs.name": f"-{sandbox_name}",
                    "configmap.argoWorkflowsNamespace": f"-{sandbox_name}",
                    # JobScheduling Related
                    "config.workflowEngineNamespace": f"-{sandbox_name}",
                }

                for (
                    property_name,
                    property_value_suffix,
                ) in sandbox_properties.items():
                    apply_sandbox_suffix(
                        property_name=property_name,
                        property_value_suffix=property_value_suffix,
                        values_dict=self.values_dict,
                    )

            # Storage location to stage the chart artifacts for deployment.
            self.asset = s3_assets.Asset(
                self,
                id=f"Asset-{helm_chart.release_name}",
                path=helm_chart.chart_folder_path,
            )

            self.chart = eks.HelmChart(
                self,
                id=f"Artf-{helm_chart.release_name}",
                namespace=helm_chart.deploy_in_namespace,
                cluster=self.cluster,
                chart_asset=self.asset,
                release=helm_chart.release_name,
                values=self.values_dict,
                create_namespace=helm_chart.create_namespace,
                wait=helm_chart.wait_till_healthy,
                timeout=Duration.minutes(15),
            )

    def get_values_dict(self, helm_chart: HelmChartContext) -> dict:
        """
        Return the helm values dictionary composing from multiple sources.

        Sources are given values, value files and resolving if there are any
        references to ssm.
        """
        target_values_dict: dict = {}

        if helm_chart.values_files is not None:
            for helm_values_file in helm_chart.values_files:
                path_helm_values_file = Path(helm_values_file)
                if not path_helm_values_file.exists():
                    msg = f"Values file : {helm_values_file} not exists."
                    raise ValueError(msg)
                with path_helm_values_file.open(encoding="utf-8") as fp:
                    helmchart_values_dict = yaml.safe_load(fp)
                    Helper.dictionary_deep_merge(
                        target_values_dict, helmchart_values_dict
                    )

        if helm_chart.values_dict is not None:
            Helper.dictionary_deep_merge(target_values_dict, helm_chart.values_dict)

        if helm_chart.delegate_deployment_to_helm:
            # Inject a unique property that lets cdk.HelmChart always see a diff.
            # This delegates the deployment decision effectively to helm.
            # Helm will check any diffs between its controlled EKS resourced and
            # the chart. Any manual modifications on EKS will be detected.
            # Depending on the Kubernetes imagePullPolicy also image updates with an
            # unchanged tag name (:latest) will lead to a deployment.
            # For this to work the unique property is also written to
            # the deployment annotations as "enforce-image-pull".
            now_iso_str = datetime.now(tz=timezone.utc).isoformat()
            target_values_dict["delegate_deployment_to_helm_time"] = now_iso_str
            if "deployment" in target_values_dict:
                if "annotations" not in target_values_dict["deployment"]:
                    target_values_dict["deployment"]["annotations"] = {}
                target_values_dict["deployment"]["annotations"][
                    "enforce-image-pull"
                ] = now_iso_str
        return target_values_dict


def apply_sandbox_suffix(
    property_name: str, property_value_suffix: str, values_dict: dict
) -> None:
    """Apply sandbox name suffix for the respective property in the helm values dict."""
    current_value = None
    parts = property_name.split(".")
    if parts[0] in values_dict:
        current_value = values_dict[parts[0]]
        for part in parts[1:-1]:
            if part in current_value:
                current_value = current_value[part]
            else:
                current_value = None
                break

    if current_value is not None and parts[-1] in current_value:
        existing_value = current_value[parts[-1]]
        new_value = f"{existing_value}{property_value_suffix}"
        current_value[parts[-1]] = new_value


def set_property_value(
    property_name: str, property_value: bool | str, values_dict: dict
) -> None:
    """Set values for the respective property in the helm values dictionary."""
    current_value = None
    parts = property_name.split(".")
    if parts[0] in values_dict:
        current_value = values_dict[parts[0]]
        for part in parts[1:-1]:
            if part in current_value:
                current_value = current_value[part]
            else:
                current_value = None
                break

    if current_value is not None and parts[-1] in current_value:
        current_value[parts[-1]] = property_value

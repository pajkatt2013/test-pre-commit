#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Construct for Kubernetes service account IAM role."""

import aws_cdk.aws_iam as iam
from aws_cdk import CfnJson
from constructs import Construct

from raas_infra.context import EKSCluster


class IamRoleForKubernetesServiceAccount(Construct):
    """Creates an AWS IAM role that can be assumed by a Kubernetes service account."""

    def __init__(
        self,
        scope: Construct,
        id_: str,
        *,
        role_name: str,
        role_description: str,
        kubernetes_service_account_name: str,
        kubernetes_service_account_namespace: str,
        eks_cluster_metadata: EKSCluster,
    ) -> None:
        """
        Create a Kubernetes service account AWS IAM role for OIDC authentication.

        :param scope: See `Construct` documentation.
        :param id_: See `Construct` documentation.
        :param role_name: The AWS IAM role name.
        :param role_description: The AWS IAM role description.
        :param kubernetes_service_account_name: The Kubernetes service account name that
            will assume this role.
        :param kubernetes_service_account_namespace: The namespace the Kubernetes
            service account was created in.
        """
        super().__init__(scope=scope, id=id_)

        # Get the OIDC provider name and ID
        eks_oidc_provider_arn = eks_cluster_metadata.oidc_arn
        oidc_provider = eks_cluster_metadata.open_id_connect_issuer

        self.role = iam.Role(
            self,
            id=id_,
            role_name=role_name,
            description=role_description,
            assumed_by=iam.CompositePrincipal(
                iam.PrincipalWithConditions(
                    iam.WebIdentityPrincipal(eks_oidc_provider_arn),
                    conditions={
                        "StringEquals": CfnJson(
                            self,
                            "ServiceAccountRoleTrustPolicy",
                            value={
                                f"{oidc_provider}:sub": f"system:serviceaccount:{kubernetes_service_account_namespace}:{kubernetes_service_account_name}",
                                f"{oidc_provider}:aud": "sts.amazonaws.com",
                            },
                        ),
                    },
                ),
                iam.PrincipalWithConditions(
                    iam.WebIdentityPrincipal(eks_oidc_provider_arn),
                    conditions={
                        "StringLike": CfnJson(
                            self,
                            "UserNamespaceServiceAccountRoleTrustPolicy",
                            value={
                                f"{oidc_provider}:sub": f"system:serviceaccount:{kubernetes_service_account_namespace}-*:{kubernetes_service_account_name}",
                                f"{oidc_provider}:aud": "sts.amazonaws.com",
                            },
                        ),
                    },
                ),
            ),
        )

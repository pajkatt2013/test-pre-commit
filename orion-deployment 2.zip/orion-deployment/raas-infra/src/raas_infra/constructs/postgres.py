#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Construct to deploy Postgres cluster"""

import json
import logging
import typing

import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_iam as iam
import aws_cdk.aws_secretsmanager as secrets
import jsii
from aws_cdk import Duration, RemovalPolicy
from aws_cdk import aws_rds as rds
from aws_cdk.aws_rds import AuroraPostgresEngineVersion
from constructs import Construct

from raas_infra.constructs.postgres_lambda import (
    RaaSPostgresExecuteScripts,
)
from raas_infra.context import VPC, Deployment, EKSCluster, Postgres

logger = logging.getLogger()
logger.setLevel("INFO")


class RaaSPostgres(Construct):
    """RaaS Helm Chart construct to deploy raas postgres using AWS CDK"""

    def __init__(
        self,
        scope: Construct,
        id: str,
        name: str,
        cluster_name_prefix: str,
        postgres: Postgres,
        vpc: VPC,
        eks_cluster: EKSCluster,
        deployment: Deployment,
        **kwargs,
    ) -> None:
        super().__init__(scope, id, **kwargs)

        self.postgres_cluster_name = (
            f"{cluster_name_prefix}{postgres.cluster_name_suffix}"
        )
        self.postgres_writer_instance_name = (
            f"{cluster_name_prefix}{postgres.write_instance_name_suffix}"
        )
        self.postgres_reader_instance_name = (
            f"{cluster_name_prefix}{postgres.reader_instance_name_suffix}"
        )
        self.postgres_cluster_arn = f"arn:{deployment.account.partition}:rds:{deployment.account.region}:{deployment.account.id}:cluster:{self.postgres_cluster_name}"
        postgres_sg_name = f"{cluster_name_prefix}-sg"

        code_build_security_group_names = None
        if postgres.code_build_security_group is not None:
            code_build_security_group_names = json.loads(
                postgres.code_build_security_group
            )
            code_build_security_group_names = list(
                filter(
                    lambda x: x.strip() not in [""],
                    code_build_security_group_names,
                )
            )
            code_build_security_group_names = list(set(code_build_security_group_names))

        # List of security groups to provide access to RDS. Ex:- EKS Security group,
        # Bastion host security group
        postgres_allow_security_group_names = postgres.allow_security_groups
        postgres_allow_security_group_names = list(
            filter(
                lambda x: x.strip() not in [""],
                postgres_allow_security_group_names,
            )
        )
        postgres_allow_security_group_names.append(eks_cluster.security_group_id)
        postgres_allow_security_group_names = list(
            set(postgres_allow_security_group_names)
        )

        # VPC lookup based on vpc id
        self.vpc = ec2.Vpc.from_lookup(self, id="VPC", vpc_id=vpc.id)

        # List of subnets
        self.private_subnets = []
        non_routable_subnets = json.loads(vpc.non_routable_subnet_ids)
        routable_subnets = json.loads(vpc.routable_subnet_ids)
        consider_subnets = (
            routable_subnets
            if postgres.use_routable_subnets is True
            else non_routable_subnets
        )

        logger.info(f"considering subnets : {consider_subnets} for postgres : {name}")
        for idx, subnet_id in enumerate(consider_subnets):
            self.private_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"subnet{idx}", subnet_id=subnet_id
                )
            )

        # Security group associated with postgres
        self.postgres_sg = ec2.SecurityGroup(
            self,
            postgres_sg_name,
            security_group_name=postgres_sg_name,
            vpc=self.vpc,
            allow_all_outbound=False,
        )

        # If bastion host is provided in the configuration
        if postgres.bastion_host is not None:
            # Bastion host construct. Bastion host helps to connect remotely to the
            # postgres database from local machine to access database and run any
            # postgres commands.

            bastion_sg_name = f"{postgres.bastion_host.name}-sg"
            # Bastion host security group construct
            bastion_sg = ec2.SecurityGroup(
                self,
                bastion_sg_name,
                security_group_name=bastion_sg_name,
                vpc=self.vpc,
                allow_all_outbound=False,
            )

            bastion_sg.add_ingress_rule(
                ec2.Peer.any_ipv4(),
                ec2.Port.tcp(postgres.port),
                "Postgres Access",
            )

            # Setting the security group rules to allow access to Postgres and SSM
            bastion_sg.add_egress_rule(
                ec2.Peer.any_ipv4(),
                ec2.Port.tcp(postgres.port),
                "Postgres Access",
            )
            bastion_sg.add_egress_rule(
                ec2.Peer.any_ipv4(), ec2.Port.tcp(443), "SSM Access"
            )

            self.bastion = ec2.BastionHostLinux(
                self,
                "BastionHostLinux",
                instance_type=ec2.InstanceType("t2.small"),
                vpc=self.vpc,
                security_group=bastion_sg,
                instance_name=postgres.bastion_host.name,
            )

            # Adding rule to postgres security group to allow access bastion host
            self.postgres_sg.add_ingress_rule(
                bastion_sg,
                ec2.Port.tcp(postgres.port),
                "Allow traffic from the bastion host security group -"
                f" {bastion_sg_name}",
            )

        logger.info(
            f"Private subnet CIDR Block {self.vpc.vpc_cidr_block} as source to the SG"
        )
        self.postgres_sg.add_ingress_rule(
            ec2.Peer.ipv4(self.vpc.vpc_cidr_block),
            ec2.Port.tcp(postgres.port),
            "Allow traffic from within the VPC",
        )

        # Adding rule to allow access to postgres from EKS security group
        if eks_cluster.security_group_id is not None:
            self.postgres_sg.add_ingress_rule(
                ec2.SecurityGroup.from_security_group_id(
                    self,
                    "AllowTrafficFromEKS",
                    eks_cluster.security_group_id,
                ),
                ec2.Port.tcp(postgres.port),
                "Allow traffic from the eks security group",
            )

        # Adding rule to allow access to postgres from code build security group
        if code_build_security_group_names is not None:
            for index, security_group_name in enumerate(
                code_build_security_group_names
            ):
                self.postgres_sg.add_ingress_rule(
                    ec2.SecurityGroup.from_security_group_id(
                        self,
                        f"AllowTrafficFromCodeBuild-{index}",
                        security_group_name,
                    ),
                    ec2.Port.tcp(postgres.port),
                    "Allow traffic from the code build security"
                    f" group - {security_group_name}",
                )

        # Adding rule to allow access to a list of given security groups
        if postgres_allow_security_group_names is not None:
            for index, security_group_name in enumerate(
                postgres_allow_security_group_names
            ):
                self.postgres_sg.add_ingress_rule(
                    ec2.SecurityGroup.from_security_group_id(
                        self,
                        f"AllowTrafficFrom-SecurityGroup-{index}",
                        security_group_name,
                    ),
                    ec2.Port.tcp(postgres.port),
                    f"Allow traffic from the security group - {security_group_name}",
                )

        # Defining parameter group for postgres
        parameter_group = rds.ParameterGroup.from_parameter_group_name(
            self, "ParameterGroup", postgres.parameter_group
        )

        # Postgres cluster write instance construct
        writer_instance = rds.ClusterInstance.serverless_v2(
            id="writer-severlessv2",
            allow_major_version_upgrade=postgres.allow_major_version_upgrade,
            instance_identifier=self.postgres_writer_instance_name,
            parameter_group=parameter_group,
            enable_performance_insights=True,
        )

        # Postgres cluster write instance construct
        reader_instance = rds.ClusterInstance.serverless_v2(
            id="reader-severlessv2",
            allow_major_version_upgrade=postgres.allow_major_version_upgrade,
            instance_identifier=self.postgres_reader_instance_name,
            parameter_group=parameter_group,
            enable_performance_insights=True,
            scale_with_writer=True,
        )
        # Master credentials to access postgres as admin
        credentials = rds.Credentials.from_generated_secret(
            username=postgres.master_user_name,
            secret_name=postgres.master_credentials_output_secret_path,
        )

        # Enabling monitoring for the postgres
        monitoring_role_name = f"{self.postgres_cluster_name}-monitoring-role"
        monitoring_role = iam.Role(
            self,
            f"pg-monitoring-{monitoring_role_name}",
            role_name=monitoring_role_name,
            description="Role used for monitoring RaaS Postgres Cluster.",
            assumed_by=iam.ServicePrincipal("monitoring.rds.amazonaws.com"),
        )
        monitoring_role.add_managed_policy(
            iam.ManagedPolicy.from_managed_policy_arn(
                id="AmazonRDSEnhancedMonitoringRole",
                scope=self,
                managed_policy_arn=f"arn:{deployment.account.partition}:iam::aws:policy/service-role/AmazonRDSEnhancedMonitoringRole",
            )
        )

        # Postgres database cluster construct
        self.postgres_cluster = rds.DatabaseCluster(
            self,
            self.postgres_cluster_name,
            engine=rds.DatabaseClusterEngine.aurora_postgres(
                version=typing.cast(
                    "AuroraPostgresEngineVersion",
                    jsii.sget(
                        AuroraPostgresEngineVersion,
                        postgres.engine_version,
                    ),
                )
            ),
            credentials=credentials,
            cluster_identifier=self.postgres_cluster_name,
            parameter_group=parameter_group,
            default_database_name=(
                postgres.database.name if postgres.database is not None else None
            ),
            security_groups=[self.postgres_sg],
            vpc=self.vpc,
            vpc_subnets=ec2.SubnetSelection(subnets=self.private_subnets),
            removal_policy=RemovalPolicy.DESTROY,
            iam_authentication=True,
            writer=writer_instance,
            readers=[reader_instance],
            serverless_v2_min_capacity=postgres.serverless_min_capacity,
            serverless_v2_max_capacity=postgres.serverless_max_capacity,
            deletion_protection=True,
            storage_encrypted=True,
            monitoring_interval=Duration.seconds(60),
            monitoring_role=monitoring_role,
            port=postgres.port,
            enable_data_api=True,
        )

        # Adding the postgres master credentials
        self.postgres_cluster.add_rotation_single_user(
            automatically_after=Duration.days(7)
        )

        self.postgres_secret_arn = self.postgres_cluster.secret.secret_arn

        self.postgres_cluster_resource_identifier = (
            self.postgres_cluster.cluster_resource_identifier
        )

        self.db_user_credentials = {}

        for db_user in postgres.db_users:
            db_user_secret = secrets.Secret(
                self,
                db_user.name,
                secret_name=db_user.credentials_output_secret_path,
                generate_secret_string=secrets.SecretStringGenerator(
                    secret_string_template=json.dumps({"username": db_user.user_name}),
                    generate_string_key="password",
                    exclude_characters=",'\"",
                ),
            )

            if db_user.name == "grafana":
                self.grafana_read_only_user_secret = db_user_secret

            self.db_user_credentials.update(
                {
                    db_user.name: {
                        "secret_arn": db_user_secret.secret_arn,
                        "db_user": db_user,
                    }
                }
            )

        self._create_proxy(postgres, routable_subnets)

        {script.schema: script.files for script in postgres.scripts}
        account = deployment.account

        # Executing if there are any init scripts after provisioning the cluster
        self.raas_postgres_exec_scripts = RaaSPostgresExecuteScripts(
            scope=self,
            id=f"{id}-scripts",
            name=name,
            lambda_role_name=f"{id}-lambda-scripts",
            vpc=self.vpc,
            postgres_secret_arn=self.postgres_secret_arn,
            db_user_credentials=self.db_user_credentials,
            postgres_port=postgres.port,
            postgres_sg=self.postgres_sg,
            postgres_scripts=postgres.scripts,
            access_secrets_arn=f"arn:{account.partition}:secretsmanager:{account.region}:{account.id}:secret:*",
            vpc_metadata=vpc,
        )

    def _create_proxy(self, postgres: Postgres, vpc_subnet_ids: list[str]) -> None:
        """

        Create the components to allow the exposure of the Postgres database to Grafana.

        See: https://confluence.cc.bmwgroup.net/display/orioncn/Postgres+SQL+as+Data+Source+for+Central+Grafana

        :param postgres: Instance of the Postgres database
        :param vpc_subnet_ids: Subnet IDs of the VPC
        """
        if postgres.requires_proxy:
            self.db_proxy = rds.DatabaseProxy(
                scope=self,
                id=f"proxy-{self.postgres_cluster_name}",
                proxy_target=rds.ProxyTarget.from_cluster(self.postgres_cluster),
                secrets=[self.grafana_read_only_user_secret],
                vpc=self.vpc,
                security_groups=[self.postgres_sg],
            )

            self.db_proxy_endpoint = rds.CfnDBProxyEndpoint(
                scope=self,
                id="Proxy_Endpoint",
                db_proxy_endpoint_name=f"readonly-proxy-{self.postgres_cluster_name}",
                db_proxy_name=self.db_proxy.db_proxy_name,
                vpc_subnet_ids=vpc_subnet_ids,
                target_role="READ_ONLY",
                vpc_security_group_ids=[self.postgres_sg.security_group_id],
            )

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""CDK construct for an EventBridge rule that routes to an SQS queue."""

from typing import Any

import aws_cdk.aws_events as events
import aws_cdk.aws_events_targets as targets
import aws_cdk.aws_logs as logs
import aws_cdk.aws_sqs as sqs
from constructs import Construct


class EventBridgeRouteToSqsRule(Construct):
    """Creates a rule in the event bus to route messages to sqs."""

    def __init__(
        self,
        scope: Construct,
        id_: str,
        *,
        target_sqs: sqs.Queue,
        event_bus_name: str,
        rule_name: str,
        rule_description: str,
        event_pattern: events.EventPattern,
        target_input_object: Any | None = None,  # noqa: ANN401 # forwarded to events.RuleTargetInput.from_object
        attach_log_group_as_target: bool = False,
    ) -> None:
        """Create the AWS Rule in Event bus routing messages to sqs."""
        super().__init__(scope=scope, id=id_)

        event_bus = events.EventBus.from_event_bus_name(self, rule_name, event_bus_name)
        self.rule = events.Rule(
            self,
            id="rule",
            event_bus=event_bus,
            event_pattern=event_pattern,
            rule_name=rule_name,
            description=rule_description,
        )

        if target_input_object is not None:
            # adding rule input transformation
            rule_target_input = events.RuleTargetInput.from_object(target_input_object)
            rule_target_sqs = targets.SqsQueue(
                queue=target_sqs, message=rule_target_input
            )
        else:
            rule_target_sqs = targets.SqsQueue(queue=target_sqs)

        self.rule.add_target(rule_target_sqs)

        # There is limitation of 10 LogGroup resource policies for the aws account.
        # Creation of log group policies will fail when the limit is exceeded.
        # Below option makes log groups optional which is useful for e.g. sandboxes.
        if attach_log_group_as_target is True:
            # adding log group as target to persist the raw events
            log_group = logs.LogGroup(
                self,
                "log-group",
                log_group_name=f"{rule_name}-raw-events",
            )
            rule_target_cloud_watch_logs = targets.CloudWatchLogGroup(
                log_group=log_group
            )

            self.rule.add_target(rule_target_cloud_watch_logs)

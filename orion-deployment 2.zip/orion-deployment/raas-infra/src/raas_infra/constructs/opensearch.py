#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Construct to deploy open search."""

import aws_cdk.aws_opensearchserverless as ops
from constructs import Construct


class RaaSOpenSearch(Construct):
    """RaaS open search construct to deploy raas open search using AWS CDK"""

    def __init__(
        self,
        scope: Construct,
        id: str,
        name: str,
        opensearch_type: str,
        principals_list: list[str],
        **kwargs,
    ) -> None:
        super().__init__(scope, id, **kwargs)

        self.ops_collection = ops.CfnCollection(
            self, id="opscollection", name=name, type=opensearch_type
        )

        principals = '","'.join(principals_list)
        principals = f'"{principals}"'

        policy = (
            '[{"Description": "Data Access Policy",'
            ' "Rules":[{"ResourceType":"index","Resource":["index/'
            + name
            + '/*"],"Permission":["aoss:*"]},'
        )
        policy = (
            policy
            + ' {"ResourceType":"collection","Resource":["collection/'
            + name
            + '"],"Permission":["aoss:*"]}],'
        )
        policy = policy + '"Principal":[' + principals + "]}]"
        ops.CfnAccessPolicy(
            self,
            id="datapolicy",
            name=f"{id}-data-policy",
            policy=policy,
            type="data",
        )

        policy = (
            '[{"Rules":[{"ResourceType":"collection","Resource":["collection/'
            + name
            + '"]},'
        )
        policy = (
            policy
            + '{"ResourceType":"dashboard","Resource":["collection/'
            + name
            + '"]}],"AllowFromPublic":true}]'
        )

        ops_net_policy = ops.CfnSecurityPolicy(
            self,
            id="networkpolicy",
            name=f"{id}-nw-policy",
            policy=policy,
            type="network",
        )

        self.ops_collection.add_dependency(ops_net_policy)

        policy = (
            '{"Rules":[{"ResourceType":"collection","Resource":["collection/'
            + name
            + '"]}],"AWSOwnedKey":true}'
        )

        ops_encryption_policy = ops.CfnSecurityPolicy(
            self,
            id="encryptionpolicy",
            name=f"{id}-enc-policy",
            policy=policy,
            type="encryption",
        )

        self.ops_collection.add_dependency(ops_encryption_policy)

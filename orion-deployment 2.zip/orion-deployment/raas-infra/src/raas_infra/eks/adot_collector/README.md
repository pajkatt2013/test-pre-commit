#  Deployment of AWS Distro for OpenTelemetry Collector


## Introduction
This module is responsible for deploying ADOT Collector stack into RaaS EKS cluster
ADOT Collector is used to collect raas metrics in Cloudwatch


##  What is does?
* Deploy the ADOT Collector stack helm chart

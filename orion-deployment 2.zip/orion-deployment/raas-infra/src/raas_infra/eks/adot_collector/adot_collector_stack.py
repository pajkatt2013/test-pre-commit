#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""ADOT Collector CDK stack."""

import json
from importlib.resources import files
from typing import cast

import aws_cdk.aws_iam as iam
import aws_cdk.aws_lambda as _lambda
import aws_cdk.aws_lambda_event_sources as event_sources
import aws_cdk.aws_sns as sns
import aws_cdk.aws_ssm as ssm
import aws_cdk.aws_xray as xray
from aws_cdk import Stack, Tags
from constructs import Construct, IConstruct

from raas_infra.constructs.helmchart import RaaSHelmChart
from raas_infra.constructs.iamrole_kubernetes_serviceaccount import (
    IamRoleForKubernetesServiceAccount,
)
from raas_infra.eks.adot_collector.adot_collector_params import ADOTCollector


class ADOTCollectorStack(Stack):
    """Creates the resources needed by ADOT Collector running in EKS."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: ADOTCollector,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys artifacts related to ADOT Collector.",
            **kwargs,
        )

        self.id = id
        self.stack_param = stack_param

        id_prefix = stack_param.deployment.name

        # Create tags (automatically applied to child constructs).
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        sa_iam_role_id_name = (
            f"{stack_param.kubernetes_service_account.iam_role_name}-"
            f"{stack_param.deployment.name}"
        )
        if (
            hasattr(stack_param.deployment, "sfns")
            and stack_param.deployment.sfns is not None
        ):
            sa_iam_role_id_name = (
                sa_iam_role_id_name + "-" + stack_param.deployment.sfns
            )
        print(f"[DEBUG] sa_iam_role_id_name: {sa_iam_role_id_name}")
        print(
            f"[DEBUG] stack_param.kubernetes_service_account.namespace: "
            f"{stack_param.kubernetes_service_account.namespace}"
        )

        self.service_account_role = IamRoleForKubernetesServiceAccount(
            scope=self,
            id_=sa_iam_role_id_name,
            role_name=stack_param.kubernetes_service_account.iam_role_name,
            role_description=stack_param.kubernetes_service_account.iam_role_description,
            kubernetes_service_account_name=stack_param.kubernetes_service_account.name,
            kubernetes_service_account_namespace=stack_param.kubernetes_service_account.namespace,
            eks_cluster_metadata=stack_param.eks_cluster,
        )

        self.service_account_role.role.add_managed_policy(
            iam.ManagedPolicy.from_managed_policy_arn(
                id="CloudWatchAgentServerPolicy",
                scope=self,
                managed_policy_arn=f"arn:{stack_param.deployment.account.partition}:iam::aws:policy/CloudWatchAgentServerPolicy",
            )
        )

        # For fetching Xray sampling rates
        self.service_account_role.role.attach_inline_policy(
            iam.Policy(
                scope=self,
                id="XrayPolicy",
                statements=[
                    iam.PolicyStatement(
                        actions=[
                            "xray:PutTraceSegments",
                            "xray:PutTelemetryRecords",
                            "xray:GetSamplingRules",
                            "xray:GetSamplingTargets",
                            "xray:GetSamplingStatisticSummaries",
                        ],
                        resources=["*"],
                    )
                ],
            )
        )

        stack_param.helm_chart.values_dict["adotCollector"]["daemonSet"][
            "serviceAccount"
        ]["annotations"] = {
            "eks.amazonaws.com/role-arn": self.service_account_role.role.role_arn
        }

        raashc_id_name = f"RaaSHelm-{stack_param.helm_chart.release_name}"
        if (
            hasattr(stack_param.deployment, "sfns")
            and stack_param.deployment.sfns is not None
        ):
            raashc_id_name = raashc_id_name + "-" + stack_param.deployment.sfns

        # This SNS topic will receive triggers from configured alarms (in downstream stacks)
        tracing_alarm_topic = sns.Topic(
            scope=self,
            id=f"{id_prefix}-tracing-alarm-topic",
            display_name="raas-service-tracing-alarm-topic",
        )

        # Add a sampling rule respected by the collector config and a Lambda to update it
        sampling_rule = xray.CfnSamplingRule(
            scope=self,
            id=f"{id_prefix}-xray-global-sampling-rule",
            sampling_rule=xray.CfnSamplingRule.SamplingRuleProperty(
                rule_name="RaasServiceIncidentSamplingRule",
                resource_arn="*",
                fixed_rate=stack_param.trace_default_sampling_rule.sampling_rate,
                reservoir_size=stack_param.trace_default_sampling_rule.reservoir_size,
                priority=100,
                service_name="*",
                service_type="*",
                host="*",
                http_method="*",
                url_path="*",
                version=1,
            ),
        )

        sampling_rule_update_lambda = _lambda.Function(
            scope=self,
            id=f"{id_prefix}-xray-global-sampling-rule-adjuster",
            runtime=_lambda.Runtime.PYTHON_3_11,
            architecture=_lambda.Architecture.ARM_64,
            environment={
                "XRAY_RULE_ARN": sampling_rule.attr_rule_arn,
                "DEFAULT_SAMPLING_RATE": str(
                    stack_param.trace_default_sampling_rule.sampling_rate
                ),
                "DEFAULT_SAMPLING_RESERVOIR_SIZE": str(
                    stack_param.trace_default_sampling_rule.reservoir_size
                ),
                "ALARM_SAMPLING_RATE": str(
                    stack_param.trace_alarm_sampling_rule.sampling_rate
                ),
                "ALARM_SAMPLING_RESERVOIR_SIZE": str(
                    stack_param.trace_alarm_sampling_rule.reservoir_size
                ),
            },
            handler="handler.lambda_handler",
            description=(
                "Adapt Xray sampling rules based on CloudWatch alarms for RaaS services"
            ),
            code=_lambda.Code.from_asset(
                str(files("raas_infra.constructs.lambdas.xray_sampling_rate_adjuster"))
            ),
            events=[event_sources.SnsEventSource(topic=tracing_alarm_topic)],
        )

        sampling_rule_update_lambda.add_to_role_policy(
            iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=[
                    "xray:UpdateSamplingRule",
                ],
                resources=[sampling_rule.attr_rule_arn],
            )
        )

        self.helm_chart = RaaSHelmChart(
            scope=self,
            id=raashc_id_name,
            eks_cluster=stack_param.eks_cluster,
            vpc=stack_param.vpc,
            helm_chart=stack_param.helm_chart,
            deployment=stack_param.deployment,
        )

        print(f"[DEBUG] stack_param: {stack_param}")

        output_dict = {
            "service_account_role_arn": self.service_account_role.role.role_arn,
            "service_account_role_name": self.service_account_role.role.role_name,
            "helm-chart-name": raashc_id_name,
            "tracing_alert_sns_topic_arn": tracing_alarm_topic.topic_arn,
        }

        output_value = json.dumps(output_dict)
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

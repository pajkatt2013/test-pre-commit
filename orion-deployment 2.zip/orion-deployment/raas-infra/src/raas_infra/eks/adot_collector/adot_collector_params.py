#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""ADOT Collector parameters for CDK stack deployment."""

from importlib.resources import files
from pathlib import Path

import yaml

from raas_infra.context import (
    VPC,
    ADOTCollectorContext,
    ContextModel,
    Deployment,
    EKSCluster,
    HelmChartContext,
    KubernetesServiceAccount,
    XraySamplingRule,
)


class ADOTCollector(ContextModel):
    """Managing the necessary params for ADOT collector Infra CDK deployment"""

    eks_cluster: EKSCluster
    deployment: Deployment
    output_metadata_path: str
    helm_chart: HelmChartContext
    kubernetes_service_account: KubernetesServiceAccount
    trace_alarm_sampling_rule: XraySamplingRule
    trace_default_sampling_rule: XraySamplingRule
    vpc: VPC

    @classmethod
    def from_context(cls, ctx: ADOTCollectorContext) -> "ADOTCollector":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])

        id = ctx.get_id()
        props: dict = {}
        props["id"] = id
        props["deployment"] = ctx.deployment
        props["eks_cluster"] = eks_cluster
        props["vpc"] = vpc
        props["output_metadata_path"] = ctx.metadata_output_ssm_path
        props["kubernetes_service_account"] = ctx.kubernetes_service_account

        # Loading Helm chart based on the input environment
        helm_values_file = str(
            files("raas_infra.eks.adot_collector.helm").joinpath("values.yaml")
        )
        helmchart_folderpath = Path(helm_values_file).parent
        with Path(helm_values_file).open() as fp:
            helmchart_values_dict = yaml.safe_load(fp)

        if ctx.adot_contrib_collector_repo is not None:
            helmchart_values_dict["adotContribCollector"]["image"]["repository"] = (
                ctx.adot_contrib_collector_repo
            )

        if ctx.adot_collector_repo is not None:
            helmchart_values_dict["adotCollector"]["image"]["repository"] = (
                ctx.adot_collector_repo
            )

        helm_chart = HelmChartContext.from_chart_folder_context(
            create_namespace=True,
            deploy_in_namespace=ctx.kubernetes_service_account.namespace,
            release_name=ctx.kubernetes_service_account.namespace,
            values_dict=helmchart_values_dict,
            chart_folder_path=str(helmchart_folderpath),
            wait_till_healthy=ctx.wait_till_healthy,
            delegate_deployment_to_helm=ctx.delegate_deployment_to_helm,
            deployment=ctx.deployment,
        )

        props["helm_chart"] = helm_chart
        props["trace_alarm_sampling_rule"] = ctx.trace_alarm_sampling_rule
        props["trace_default_sampling_rule"] = ctx.trace_default_sampling_rule

        return cls.model_validate(props)

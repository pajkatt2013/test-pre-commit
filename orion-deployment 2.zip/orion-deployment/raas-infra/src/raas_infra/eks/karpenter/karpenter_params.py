#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Karpenter parameters for CDK stack deployment."""

from importlib.resources import files
from pathlib import Path

import yaml

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSCluster,
    EKSKarpenterContext,
    HelmChartContext,
    KubernetesServiceAccount,
)


class Karpenter(ContextModel):
    """Managing the necessary params for Karpenter Infra CDK deployment"""

    eks_cluster: EKSCluster
    deployment: Deployment
    output_metadata_path: str
    helm_chart: HelmChartContext
    kubernetes_service_account: KubernetesServiceAccount
    vpc: VPC

    @classmethod
    def from_context(cls, ctx: EKSKarpenterContext) -> "Karpenter":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])

        id = ctx.get_id()
        props: dict = {}
        props["id"] = id
        props["deployment"] = ctx.deployment
        props["eks_cluster"] = eks_cluster
        props["vpc"] = vpc
        props["output_metadata_path"] = ctx.metadata_output_ssm_path
        props["kubernetes_service_account"] = ctx.kubernetes_service_account
        props["replicas"] = ctx.replicas
        props["tenant"] = ctx.tenant
        props["subnet_discovery_tag_value"] = ctx.subnet_discovery_tag_value
        props["karpenter_node_role"] = ctx.karpenter_node_role
        props["argo_ami_selector_alias"] = ctx.argo_ami_selector_alias
        props["argo_instance_type"] = ctx.argo_instance_type
        props["cpu_ami_selector_alias"] = ctx.cpu_ami_selector_alias
        props["cpu_instance_type"] = ctx.cpu_instance_type
        props["gpu_ami_selector_alias"] = ctx.gpu_ami_selector_alias
        props["gpu_instance_type"] = ctx.gpu_instance_type
        props["gpu_plugin_type"] = ctx.gpu_plugin_type
        props["isp_ami_selector_alias"] = ctx.isp_ami_selector_alias
        props["isp_instance_type"] = ctx.isp_instance_type
        props["services_ami_selector_alias"] = ctx.services_ami_selector_alias
        props["services_instance_type"] = ctx.services_instance_type
        props["security_group_tag_discovery_value"] = (
            ctx.security_group_tag_discovery_value
        )
        props["customer_functions"] = ctx.customer_functions

        # Loading Helm chart based on the input environment
        helm_values_file = str(
            files("raas_infra.eks.karpenter.helm").joinpath("values.yaml")
        )
        helmchart_folderpath = Path(helm_values_file).parent
        with Path(helm_values_file).open() as fp:
            helmchart_values_dict = yaml.safe_load(fp)

        helm_chart = HelmChartContext.from_chart_folder_context(
            create_namespace=True,
            deploy_in_namespace=ctx.kubernetes_service_account.namespace,
            release_name=ctx.kubernetes_service_account.name,
            values_dict=helmchart_values_dict,
            chart_folder_path=str(helmchart_folderpath),
            wait_till_healthy=ctx.wait_till_healthy,
            delegate_deployment_to_helm=ctx.delegate_deployment_to_helm,
            deployment=ctx.deployment,
        )

        props["helm_chart"] = helm_chart

        return cls.model_validate(props)

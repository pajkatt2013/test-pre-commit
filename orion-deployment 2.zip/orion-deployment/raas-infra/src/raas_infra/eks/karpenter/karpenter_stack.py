#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Karpenter CDK stack."""

import json
from typing import cast

import aws_cdk.aws_iam as iam
import aws_cdk.aws_logs as logs
import aws_cdk.aws_ssm as ssm
from aws_cdk import CfnOutput, RemovalPolicy, Stack, Tags
from constructs import Construct, IConstruct

from raas_infra.constructs.helmchart import RaaSHelmChart
from raas_infra.constructs.iamrole_kubernetes_serviceaccount import (
    IamRoleForKubernetesServiceAccount,
)
from raas_infra.eks.karpenter.karpenter_params import Karpenter


def gen_list_str(inlist: list[str]) -> str:
    """
    Convert a list of strings into a formatted string representation.

    Args:
        inlist (list): A list of strings to format.

    Returns:
        str: A string representation of the input list.

    """
    if inlist is not None:
        return str(inlist).replace("'", '"')
    return None


class KarpenterStack(Stack):
    """Creates the resources needed by Karpenter running in EKS."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: Karpenter,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys artifacts related to karpenter.",
            **kwargs,
        )

        self.id = id

        aws_partition = stack_param.deployment.account.partition
        aws_account_id = stack_param.deployment.account.id

        environment = stack_param.deployment.environment_name

        cluster_name = stack_param.eks_cluster.name
        aws_region = stack_param.deployment.account.region
        nonroutable_subnet_ids = stack_param.vpc.non_routable_subnet_ids
        eks_default_nodegroup = stack_param.eks_cluster.default_nodegroup_name[0].split(
            "/"
        )[1]
        self.stack_param = stack_param
        self.controller_role_name = (
            stack_param.kubernetes_service_account.iam_role_name + "-" + cluster_name
        )

        replicas = stack_param.replicas
        tenant = stack_param.tenant
        subnet_discovery_tag_value = stack_param.subnet_discovery_tag_value

        karpenter_node_role = stack_param.karpenter_node_role
        argo_ami_selector_alias = stack_param.argo_ami_selector_alias
        argo_instance_type = stack_param.argo_instance_type
        cpu_ami_selector_alias = stack_param.cpu_ami_selector_alias
        cpu_instance_type = stack_param.cpu_instance_type
        gpu_ami_selector_alias = stack_param.gpu_ami_selector_alias
        gpu_instance_type = stack_param.gpu_instance_type
        gpu_plugin_type = stack_param.gpu_plugin_type
        isp_ami_selector_alias = stack_param.isp_ami_selector_alias
        isp_instance_type = stack_param.isp_instance_type
        services_ami_selector_alias = stack_param.services_ami_selector_alias
        services_instance_type = stack_param.services_instance_type
        security_group_tag_discovery_value = (
            stack_param.security_group_tag_discovery_value
        )

        customer_functions = stack_param.customer_functions.split(",")

        self.controller_role_name = self.controller_role_name[:63]
        self.node_role_name = "KarpenterNodeRole-" + cluster_name

        # Create tags (automatically applied to child constructs).
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        # Create Service Account for Controller
        self.service_account_role = IamRoleForKubernetesServiceAccount(
            scope=self,
            id_="ServiceAccountRole",
            role_name=self.controller_role_name,
            role_description=stack_param.kubernetes_service_account.iam_role_description,
            kubernetes_service_account_name=stack_param.kubernetes_service_account.name,
            kubernetes_service_account_namespace=stack_param.kubernetes_service_account.namespace,
            eks_cluster_metadata=stack_param.eks_cluster,
        )

        karpenter_controller_access_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    sid="Karpenter",
                    actions=[
                        "ssm:GetParameter",
                        "ec2:DescribeImages",
                        "ec2:RunInstances",
                        "ec2:DescribeSubnets",
                        "ec2:DescribeSecurityGroups",
                        "ec2:DescribeLaunchTemplates",
                        "ec2:DescribeInstances",
                        "ec2:DescribeInstanceTypes",
                        "ec2:DescribeInstanceTypeOfferings",
                        "ec2:DescribeAvailabilityZones",
                        "ec2:DeleteLaunchTemplate",
                        "ec2:CreateTags",
                        "ec2:CreateLaunchTemplate",
                        "ec2:CreateFleet",
                        "ec2:DescribeSpotPriceHistory",
                        "pricing:GetProducts",
                    ],
                    resources=["*"],
                    effect=iam.Effect.ALLOW,
                ),
                iam.PolicyStatement(
                    sid="ConditionalEC2Termination",
                    actions=[
                        "ec2:TerminateInstances",
                    ],
                    conditions={
                        "StringLike": {"ec2:ResourceTag/karpenter.sh/nodepool": "*"}
                    },
                    resources=["*"],
                    effect=iam.Effect.ALLOW,
                ),
                iam.PolicyStatement(
                    sid="PassNodeIAMRole",
                    actions=[
                        "iam:PassRole",
                    ],
                    resources=[
                        f"arn:{aws_partition}:iam::{aws_account_id}:role/{self.node_role_name}"
                    ],
                    effect=iam.Effect.ALLOW,
                ),
                iam.PolicyStatement(
                    sid="EKSClusterEndpointLookup",
                    actions=[
                        "eks:DescribeCluster",
                    ],
                    resources=[
                        f"arn:{aws_partition}:eks:{aws_region}:{aws_account_id}:cluster/{cluster_name}"
                    ],
                    effect=iam.Effect.ALLOW,
                ),
                iam.PolicyStatement(
                    sid="AllowScopedInstanceProfileCreationActions",
                    actions=[
                        "iam:CreateInstanceProfile",
                    ],
                    resources=["*"],
                    effect=iam.Effect.ALLOW,
                    conditions={
                        "StringEquals": {
                            f"aws:RequestTag/kubernetes.io/cluster/{cluster_name}": "owned",
                            "aws:RequestTag/topology.kubernetes.io/region": f"{aws_region}",
                        },
                        "StringLike": {
                            "aws:RequestTag/karpenter.k8s.aws/ec2nodeclass": "*"
                        },
                    },
                ),
                iam.PolicyStatement(
                    sid="AllowScopedInstanceProfileTagActions",
                    actions=[
                        "iam:TagInstanceProfile",
                    ],
                    resources=["*"],
                    effect=iam.Effect.ALLOW,
                    conditions={
                        "StringEquals": {
                            f"aws:ResourceTag/kubernetes.io/cluster/{cluster_name}": "owned",
                            "aws:ResourceTag/topology.kubernetes.io/region": f"{aws_region}",
                            f"aws:RequestTag/kubernetes.io/cluster/{cluster_name}": "owned",
                            "aws:RequestTag/topology.kubernetes.io/region": f"{aws_region}",
                        },
                        "StringLike": {
                            "aws:ResourceTag/karpenter.k8s.aws/ec2nodeclass": "*",
                            "aws:RequestTag/karpenter.k8s.aws/ec2nodeclass": "*",
                        },
                    },
                ),
                iam.PolicyStatement(
                    sid="AllowScopedInstanceProfileActions",
                    actions=[
                        "iam:AddRoleToInstanceProfile",
                        "iam:RemoveRoleFromInstanceProfile",
                        "iam:DeleteInstanceProfile",
                    ],
                    resources=["*"],
                    effect=iam.Effect.ALLOW,
                    conditions={
                        "StringEquals": {
                            f"aws:ResourceTag/kubernetes.io/cluster/{cluster_name}": "owned",
                            "aws:ResourceTag/topology.kubernetes.io/region": f"{aws_region}",
                        },
                        "StringLike": {
                            "aws:ResourceTag/karpenter.k8s.aws/ec2nodeclass": "*"
                        },
                    },
                ),
                iam.PolicyStatement(
                    sid="AllowInstanceProfileReadActions",
                    actions=["iam:GetInstanceProfile"],
                    resources=["*"],
                    effect=iam.Effect.ALLOW,
                ),
            ]
        )

        self.service_account_role.role.attach_inline_policy(
            iam.Policy(
                scope=self,
                id="karpenter_controller_access_policy",
                document=karpenter_controller_access_policy,
                policy_name="karpenter_controller_access_policy",
            )
        )

        # Create Role for Nodes
        node_policies_list = [
            "AmazonEKSWorkerNodePolicy",
            "AmazonEKS_CNI_Policy",
            "AmazonEC2ContainerRegistryReadOnly",
            "AmazonSSMManagedInstanceCore",
        ]
        self.noderole = iam.Role(
            self,
            id=id,
            role_name=self.node_role_name,
            description="Role used by the nodes managed by Karpenter.",
            assumed_by=iam.ServicePrincipal(service="ec2.amazonaws.com"),
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name(policy)
                for policy in node_policies_list
            ],
        )

        self.log_group = logs.LogGroup(
            self,
            "log-group",
            log_group_name=f"{id}-logs",
            removal_policy=RemovalPolicy.DESTROY,
        )

        # Setting the remaining Helm Chart values
        stack_param.helm_chart.values_dict["karpenter"]["settings"]["clusterName"] = (
            cluster_name
        )
        stack_param.helm_chart.values_dict["karpenter"]["serviceAccount"][
            "annotations"
        ] = {"eks.amazonaws.com/role-arn": (self.service_account_role.role.role_arn)}

        stack_param.helm_chart.values_dict["karpenter"]["affinity"] = {
            "nodeAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": {
                    "nodeSelectorTerms": [
                        {
                            "matchExpressions": [
                                {
                                    "key": "karpenter.sh/nodepool",
                                    "operator": "DoesNotExist",
                                },
                                {
                                    "key": "eks.amazonaws.com/nodegroup",
                                    "operator": "In",
                                    "values": [f"{eks_default_nodegroup}"],
                                },
                            ]
                        }
                    ]
                }
            },
            "podAntiAffinity": {
                "requiredDuringSchedulingIgnoredDuringExecution": [
                    {"topologyKey": "kubernetes.io/hostname"}
                ]
            },
        }

        stack_param.helm_chart.values_dict["tenant"] = tenant
        stack_param.helm_chart.values_dict["environment"] = environment
        stack_param.helm_chart.values_dict["karpenter"]["replicas"] = replicas
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"] = {}
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "karpenterNodeRole"
        ] = karpenter_node_role
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "argoAMISelectorAlias"
        ] = argo_ami_selector_alias
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "argoInstanceType"
        ] = gen_list_str(argo_instance_type)
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "cpuAMISelectorAlias"
        ] = cpu_ami_selector_alias
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"]["cpuInstanceType"] = (
            gen_list_str(cpu_instance_type)
        )
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "gpuAMISelectorAlias"
        ] = gpu_ami_selector_alias
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"]["gpuInstanceType"] = (
            gen_list_str(gpu_instance_type)
        )
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"]["gpuPluginType"] = (
            gpu_plugin_type
        )
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "ispAMISelectorAlias"
        ] = isp_ami_selector_alias
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"]["ispInstanceType"] = (
            gen_list_str(isp_instance_type)
        )
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "servicesAMISelectorAlias"
        ] = services_ami_selector_alias
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "servicesInstanceType"
        ] = gen_list_str(services_instance_type)
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "subnetTagDiscoveryValue"
        ] = subnet_discovery_tag_value
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "securityGroupTagDiscoveryValue"
        ] = security_group_tag_discovery_value
        stack_param.helm_chart.values_dict["karpenterRaaSConfig"][
            "customerFunctions"
        ] = customer_functions

        # Outputs
        output_dict = {
            "karpenter_controller_role_arn": self.service_account_role.role.role_arn,
        }

        # Create helm chart for deploying the argo workflow artifacts.
        self.helm_chart = RaaSHelmChart(
            scope=self,
            id=f"RaaSHelm-{stack_param.helm_chart.release_name}",
            eks_cluster=stack_param.eks_cluster,
            vpc=stack_param.vpc,
            helm_chart=stack_param.helm_chart,
            deployment=stack_param.deployment,
        )

        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=f"{output_dict}",
        )
        list_of_nonroutable_subnet_ids = json.loads(nonroutable_subnet_ids)

        CfnOutput(
            self,
            id="metadata",
            value=self.to_json_string(
                {
                    "karpenterNodeRoleArn": self.noderole.role_arn,
                    "clusterSecurityGroupId": stack_param.eks_cluster.security_group_id,
                    "clusterSubnetsIds": list_of_nonroutable_subnet_ids,
                    "clusterName": cluster_name,
                    "karpenterSubnetDiscoveryTagValue": subnet_discovery_tag_value,
                }
            ),
        )

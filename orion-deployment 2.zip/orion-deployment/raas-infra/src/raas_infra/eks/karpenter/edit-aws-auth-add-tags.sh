#! /bin/env bash
#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

set -x

# Function to parse named arguments
parse_arguments() {
  while [ $# -gt 0 ]; do
    case "$1" in
    --environment=*)
      export environment="${1#*=}"
      ;;
    --region=*)
      export region="${1#*=}"
      ;;
    *)
      printf "Invalid argument: %s\n" "$1"
      exit 1
      ;;
    esac
    shift
  done
}

# Function to install required packages
install_packages() {
  sudo apt-get install -y jq wget || sudo apt-get install -y jq wget
  sudo wget https://github.com/mikefarah/yq/releases/download/v4.44.3/yq_linux_amd64.tar.gz -O - | sudo tar xz && sudo mv yq_linux_amd64 /usr/bin/yq
  sudo pip3 install awscli --upgrade --user || sudo pip install awscli --upgrade --user
}

# Function to update kubeconfig based on environment
update_kubeconfig() {
  case $environment in
  dev)
    aws eks update-kubeconfig --name "addf-realm-infra-dev-core-eks-cluster" --region "${region}"
    ;;
  int)
    aws eks update-kubeconfig --name "addf-realm-infra-int-core-eks-cluster" --region "${region}"
    ;;
  prod)
    aws eks update-kubeconfig --name "addf-realm-infra-prod-core-eks-cluster" --region "${region}"
    ;;
  *)
    echo "Cannot determine which cluster and environment to use!"
    exit 1
    ;;
  esac
}

# Function to export environment variables
export_env_vars() {
  # update environment value "prod" to "prd", which is needed to match the stack name
  if [ "$environment" = "prod" ]; then
    stage="prd"
  else
    stage="$environment"
  fi
  echo "stage is: ${stage}"

  # shellcheck disable=SC2155
  export KARPENTER_NODE_ROLE_ARN=$(jq -r '."raas-infra-'"$stage"'-karpenter".metadata | fromjson | .karpenterNodeRoleArn' cdk-exports.json)
  # shellcheck disable=SC2155
  export CLUSTER_SECURITYGROUP_ID=$(jq -r '."raas-infra-'"$stage"'-karpenter".metadata | fromjson | .clusterSecurityGroupId' cdk-exports.json)
  # shellcheck disable=SC2155
  export CLUSTER_SUBNETS_IDS=$(jq -r '."raas-infra-'"$stage"'-karpenter".metadata | fromjson | .clusterSubnetsIds' cdk-exports.json)
  # shellcheck disable=SC2155
  export CLUSTER_NAME=$(jq -r '."raas-infra-'"$stage"'-karpenter".metadata | fromjson | .clusterName' cdk-exports.json)
  # shellcheck disable=SC2155
  export SUBNET_DISCOVERY_TAG_VALUE=$(jq -r '."raas-infra-'"$stage"'-karpenter".metadata | fromjson | .karpenterSubnetDiscoveryTagValue' cdk-exports.json)
}

# Function to create yq expression
create_yq_expression() {
  # Single quote is required for the expression to work
  # shellcheck disable=SC2016
  echo '. += [{"groups": ["system:bootstrappers", "system:nodes"], "rolearn": "${KARPENTER_NODE_ROLE_ARN}" | envsubst, "username": "system:node:{{EC2PrivateDNSName}}"}] | unique_by(.rolearn) | {"data": {"mapAccounts": "[]", "mapRoles": ., "mapUsers": "[]"}}' >/tmp/yq_expression
  cat /tmp/yq_expression
}

# Function to patch aws-auth configmap
patch_aws_auth() {
  kubectl get cm aws-auth -n kube-system -o 'jsonpath={.data.mapRoles}' | yq -P --from-file /tmp/yq_expression >/tmp/aws-auth-patch.yaml
  sed -i 's/mapRoles:/mapRoles: |/' /tmp/aws-auth-patch.yaml
  cat /tmp/aws-auth-patch.yaml
  kubectl patch configmap aws-auth -n kube-system --patch-file /tmp/aws-auth-patch.yaml
  kubectl get configmap aws-auth -n kube-system -o yaml
}

# Function to tag resources
tag_resources() {
  echo "Tagging Cluster's security group"
  aws ec2 create-tags --tags "Key=karpenter.sh/discovery,Value=${CLUSTER_NAME}" --resources "${CLUSTER_SECURITYGROUP_ID}"

  echo "Tagging subnets"
  for subnet in $(echo "$CLUSTER_SUBNETS_IDS" | jq -r '.[]'); do
    echo "Tagging subnet: ${subnet}"
    aws ec2 create-tags --tags "Key=karpenter.sh/discovery,Value=${SUBNET_DISCOVERY_TAG_VALUE}" --resources "${subnet}"
  done
}

# Main script execution
parse_arguments "$@"
install_packages
export_env_vars
create_yq_expression
update_kubeconfig
patch_aws_auth
tag_resources

# Karpenter Deployment


## Introduction

This module is responsible for deploying Karpenter stack into RaaS EKS cluster.
Karpenter Stack is used to autoscale cluster nodes.


##  What it does?
* deploy the karpenter stack helm chart

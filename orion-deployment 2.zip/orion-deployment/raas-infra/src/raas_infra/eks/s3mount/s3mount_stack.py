#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
S3 Mount Deployment CDK stack.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

from typing import cast

import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_iam as iam
import aws_cdk.aws_s3 as s3
import aws_cdk.aws_ssm as ssm
import cdk_nag
from aws_cdk import CfnJson, RemovalPolicy, Stack, Tags, aws_iam
from constructs import Construct, IConstruct

from raas_infra.eks.s3mount.s3mount_params import EKSS3Mount
from raas_infra.utils.helper import Helper


class EKSS3MountStack(Stack):
    """Resources for EKS to mount s3 creating persistent volume resources."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: EKSS3Mount,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys S3 mount points in EKS.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs)
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        # Skipping role creation for s3 mount point role for sandbox deployment
        if self.stack_param.deployment.sandbox_name is None:
            ec2.Vpc.from_lookup(self, id="VPC", vpc_id=stack_param.vpc.id)

            # Create an S3 bucket for workflow to use during runtime execution for
            # exchanging files like config etc. between nodes in the dag
            self.raas_argo_workflows_runtime_s3_bucket = self.create_bucket(
                stack_param.raas_argo_workflows_runtime_s3_bucket_name,
                "ArgoWorkflowsRuntimeStore",
            )

            # IAM role to access S3 buckets or access points from EKS to create
            # mount points
            self.role = self.create_role(
                eks_oidc_provider_arn=stack_param.eks_cluster.oidc_arn,
                raas_s3mount_driver_role_name=stack_param.raas_s3mount_driver_role_name,
                raas_s3mount_driver_sa=stack_param.raas_s3mount_driver_sa,
            )

            # Write output to SSM
            self.write_output(stack_param=stack_param)

    def create_bucket(
        self, raas_argo_workflows_runtime_s3_bucket_name: str, id: str
    ) -> s3.Bucket:
        """Create the S3 bucket."""
        bucket: s3.Bucket = s3.Bucket(
            self,
            id=id,
            bucket_name=raas_argo_workflows_runtime_s3_bucket_name,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            versioned=False,
            enforce_ssl=True,
            encryption=s3.BucketEncryption.S3_MANAGED,
            removal_policy=RemovalPolicy.DESTROY,
        )

        cdk_nag.NagSuppressions.add_resource_suppressions(
            bucket,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-S1",
                    reason="Bucket access logs not required.",
                )
            ],
        )

        return bucket

    def create_role(
        self,
        eks_oidc_provider_arn: str,
        raas_s3mount_driver_role_name: str,
        raas_s3mount_driver_sa: str,
    ) -> iam.Role:
        """Create a role for EKS to allow S3 Mount point have necessary access"""
        oidc_provider_id = eks_oidc_provider_arn.split("/")[-1]
        oidc_provider = Helper.get_oidc_provider(
            region=self.stack_param.deployment.account.region,
            oidc_provider_id=oidc_provider_id,
        )

        # IAM Role construct with trust relationship and required permissions.
        role = iam.Role(
            self,
            "EKSS3MountControllerServiceAccountRole",
            role_name=raas_s3mount_driver_role_name,
            description="Role used by EKS - S3 Mount CSI Driver.",
            # Setting the eks service account to allow access EKS for creating S3
            # mount points.
            assumed_by=iam.PrincipalWithConditions(
                iam.WebIdentityPrincipal(eks_oidc_provider_arn),
                conditions={
                    "StringLike": CfnJson(
                        self,
                        "ServiceAccountRoleTrustPolicy-server-serviceaccount",
                        value={
                            f"{oidc_provider}:sub": (
                                f"system:serviceaccount:*:{raas_s3mount_driver_sa}"
                            ),
                            f"{oidc_provider}:aud": "sts.amazonaws.com",
                        },
                    ),
                },
            ),
        )

        # Adding defined driver iam role policies
        role_policies = self.stack_param.driver_iam_role_policies
        for name in role_policies:
            additional_policy = role_policies[name]
            policy = iam.PolicyDocument(
                statements=[
                    iam.PolicyStatement(
                        actions=additional_policy["actions"],
                        resources=additional_policy["resources"],
                        effect=aws_iam.Effect(additional_policy["effect"]),
                    )
                ]
            )
            role.attach_inline_policy(
                iam.Policy(
                    scope=self,
                    id=name,
                    document=policy,
                    policy_name=name,
                )
            )
        return role

    def write_output(self, stack_param: EKSS3Mount) -> None:
        """Responsible for capturing the metadata in the SSM"""
        # Saving the output of the s3 mount deployment to SSM
        output_dict = {
            "runtime_volume_claim_name": (
                self.stack_param.raas_argo_workflows_runtime_volume_claim_name
            ),
            "cacheable_readonly_volume_claim_names": (
                self.stack_param.raas_s3mount_cacheable_readonly_volume_claim_names
            ),
            "readonly_volume_claim_names": (
                self.stack_param.raas_s3mount_readonly_volume_claim_names
            ),
            "readwrite_volume_claim_names": (
                self.stack_param.raas_s3mount_readwrite_volume_claim_names
            ),
        }

        output_value = self.to_json_string(output_dict)
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

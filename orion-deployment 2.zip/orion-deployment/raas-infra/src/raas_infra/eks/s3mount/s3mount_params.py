#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Parameters for deploying S3 Mount to EKS - CDK stack deployment.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from importlib.resources import files
from pathlib import Path

import yaml

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSCluster,
    EKSS3MountContext,
    HelmChartContext,
)
from raas_infra.eks.helmcharts.helmchart_param import HelmChart
from raas_infra.utils.helper import Helper


class EKSS3Mount(ContextModel):
    """Managing the necessary params for EKS S3 Mount CDK deployment"""

    id: str
    eks_cluster: EKSCluster
    vpc: VPC
    output_metadata_path: str
    deployment: Deployment
    readonly_buckets: dict
    read_write_buckets: dict
    raas_s3mount_driver_role_name: str
    raas_s3mount_driver_sa: str
    raas_argo_workflows_runtime_s3_bucket_name: str
    raas_argo_workflows_runtime_volume_claim_name: str
    raas_s3mount_cacheable_readonly_volume_claim_names: list[str]
    raas_s3mount_readonly_volume_claim_names: list[str]
    raas_s3mount_readwrite_volume_claim_names: list[str]
    helm_chart: HelmChart
    # https://docs.pydantic.dev/latest/concepts/models/#fields-with-non-hashable-default-values
    driver_iam_role_policies: dict = {}  # noqa: RUF012 # pydantic wants it so

    @classmethod
    def from_context(cls, ctx: EKSS3MountContext) -> "EKSS3Mount":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])

        # Fetching the application namespaces deployed during prerequisites
        # module deployment
        prerequisites = json.loads(ctx.ref["prerequisites"])

        # Reprocessed output s3 buckets metadata
        output_s3buckets_metadata = json.loads(ctx.ref["output_s3buckets_metadata"])
        output_s3buckets_names = output_s3buckets_metadata["buckets_names"]
        read_write_buckets = {
            bucket_name: bucket_name for bucket_name in output_s3buckets_names.values()
        }

        readonly_buckets = ctx.collected_zone_s3_buckets
        cacheable_readonly_buckets = ctx.cacheable_read_only_s3_buckets

        id_ = ctx.get_id()
        props = {
            "eks_cluster": eks_cluster,
            "vpc": vpc,
            "deployment": ctx.deployment,
            "id": id_,
            "output_metadata_path": ctx.metadata_output_ssm_path,
            "readonly_buckets": readonly_buckets,
            "read_write_buckets": read_write_buckets,
            "cacheable_readonly_buckets": cacheable_readonly_buckets,
            "driver_iam_role_policies": ctx.driver_iam_role_policies,
        }

        # Service account for accessing the EFS and the required IAM role with
        # permissions
        raas_s3mount_driver_role_name = f"{id_}-Role"
        props["raas_s3mount_driver_role_name"] = raas_s3mount_driver_role_name

        # S3 bucket name for workflow to use during runtime execution for exchanging
        # files like config etc
        raas_argo_workflows_runtime_volume_claim_name = (
            ctx.get_submodule_non_sandbox_id("s3mount", "workflows")
        )
        props["raas_argo_workflows_runtime_volume_claim_name"] = (
            raas_argo_workflows_runtime_volume_claim_name
        )

        raas_argo_workflows_runtime_s3_bucket_name = f"{raas_argo_workflows_runtime_volume_claim_name}-{ctx.deployment.account.id}"

        props["raas_argo_workflows_runtime_s3_bucket_name"] = (
            raas_argo_workflows_runtime_s3_bucket_name
        )

        raas_s3mount_driver_sa = "raas-s3mount-driver-sa"
        props["raas_s3mount_driver_sa"] = raas_s3mount_driver_sa
        raas_s3mount_driver_role_arn = Helper.get_iam_role_arn(
            account=ctx.deployment.account,
            role_name=raas_s3mount_driver_role_name,
        )

        raas_s3mount_driver_namespace_name = "raas-eks-s3mount"

        # Loading Helm chart based on the input environment
        helm_values_file = str(
            files("raas_infra.eks.s3mount.helm").joinpath("values.yaml")
        )
        helmchart_folderpath = Path(helm_values_file).parent
        with Path(helm_values_file).open() as fp:
            helmchart_values_dict = yaml.safe_load(fp)

        # Merging the configured argo woriflow values with the current loaded
        # helm values
        Helper.dictionary_deep_merge(helmchart_values_dict, ctx.values_dict)

        # In case of sandbox based deployment, deploying the sandbox helm chart.
        # sandbox helm chart deploys only the s3 mount persistent volumes and claims
        if ctx.deployment.sandbox_name is not None:
            helm_chart_file = str(
                files("raas_infra.eks.s3mount.sandbox_helm").joinpath("Chart.yaml")
            )
            helmchart_folderpath = Path(helm_chart_file).parent

        # Setting the service account with annotation referring to the IAM role for
        # accessing the EFS
        helmchart_values_dict["aws-mountpoint-s3-csi-driver"]["node"][
            "serviceAccount"
        ] = {
            "create": True,
            "name": raas_s3mount_driver_sa,
            "annotations": {"eks.amazonaws.com/role-arn": raas_s3mount_driver_role_arn},
        }

        # Deploying Persistent Volume Claims to the raas pipeline namespace
        raas_pipeline_namespace = prerequisites["raas_pipeline_namespace"]

        # Setting to tolerate all taints, which will allow the pod to be scheduled in
        # all nodes.
        helmchart_values_dict["aws-mountpoint-s3-csi-driver"]["node"][
            "tolerateAllTaints"
        ] = True

        # Constructing list of read only volumes to create PV and PVC's
        readonly_volumes = [
            {
                # in case of sandbox deployment suffixing the sandbox name to the
                # volume name
                "name": (
                    volume_name
                    if ctx.deployment.sandbox_name is None
                    else (f"{volume_name}-{ctx.deployment.sandbox_name}")
                ),
                "bucket": readonly_buckets[volume_name],
                "storageCapacity": ctx.readonly_volume_storage_capacity,
                "claimStorageRequest": ctx.readonly_volume_claim_storage_request,
                "claimNamespace": raas_pipeline_namespace,
                "claimName": volume_name,
            }
            for volume_name in readonly_buckets
        ]

        # Constructing list of read write volumes to create PV and PVC's
        read_write_volumes = [
            {
                # in case of sandbox deployment suffixing the sandbox name to the
                # volume name
                "name": (
                    volume_name
                    if ctx.deployment.sandbox_name is None
                    else (f"{volume_name}-{ctx.deployment.sandbox_name}")
                ),
                "bucket": read_write_buckets[volume_name],
                "storageCapacity": ctx.read_write_volume_storage_capacity,
                "claimStorageRequest": ctx.read_write_volume_claim_storage_request,
                "claimNamespace": raas_pipeline_namespace,
                "claimName": volume_name,
            }
            for volume_name in read_write_buckets
        ]
        read_write_volumes.append(
            {
                # in case of sandbox deployment suffixing the sandbox name to the
                # volume name
                "name": (
                    raas_argo_workflows_runtime_volume_claim_name
                    if ctx.deployment.sandbox_name is None
                    else f"{raas_argo_workflows_runtime_volume_claim_name}-{ctx.deployment.sandbox_name}"
                ),
                "bucket": raas_argo_workflows_runtime_s3_bucket_name,
                "storageCapacity": ctx.read_write_volume_storage_capacity,
                "claimStorageRequest": ctx.read_write_volume_claim_storage_request,
                "claimNamespace": raas_pipeline_namespace,
                "claimName": raas_argo_workflows_runtime_volume_claim_name,
            }
        )

        # Constructing list of read only volumes to create PV and PVC's
        cacheable_readonly_volumes = [
            {
                # in case of sandbox deployment suffixing the sandbox name to the
                # volume name
                "name": (
                    volume_name
                    if ctx.deployment.sandbox_name is None
                    else (f"{volume_name}-{ctx.deployment.sandbox_name}")
                ),
                "bucket": cacheable_readonly_buckets[volume_name],
                "storageCapacity": ctx.readonly_volume_storage_capacity,
                "claimStorageRequest": ctx.readonly_volume_claim_storage_request,
                "claimNamespace": raas_pipeline_namespace,
                "claimName": volume_name,
            }
            for volume_name in cacheable_readonly_buckets
        ]

        helmchart_values_dict["aws-mountpoint-s3-csi-driver"]["readOnlyVolumes"] = (
            readonly_volumes
        )
        helmchart_values_dict["aws-mountpoint-s3-csi-driver"]["readWriteVolumes"] = (
            read_write_volumes
        )
        helmchart_values_dict["aws-mountpoint-s3-csi-driver"][
            "cacheableReadOnlyVolumes"
        ] = cacheable_readonly_volumes

        # List of s3 mounted bucket names
        props["raas_s3mount_readonly_volume_claim_names"] = [
            volume["claimName"] for volume in readonly_volumes
        ]
        props["raas_s3mount_readwrite_volume_claim_names"] = [
            volume["claimName"] for volume in read_write_volumes
        ]
        props["raas_s3mount_cacheable_readonly_volume_claim_names"] = [
            volume["claimName"] for volume in cacheable_readonly_volumes
        ]

        # Setting readonly volume mountoptions
        helmchart_values_dict["aws-mountpoint-s3-csi-driver"][
            "readOnlyVolumeOptions"
        ] = ctx.read_only_volume_options

        # Force S3 Mountpoints "--read-only" parameter for RO volumes
        if (
            "read-only"
            not in helmchart_values_dict["aws-mountpoint-s3-csi-driver"][
                "readOnlyVolumeOptions"
            ]
        ):
            helmchart_values_dict["aws-mountpoint-s3-csi-driver"][
                "readOnlyVolumeOptions"
            ].append("read-only")

        # Setting readwrite volume mountoptions
        helmchart_values_dict["aws-mountpoint-s3-csi-driver"][
            "readWriteVolumeOptions"
        ] = ctx.read_write_volume_options

        # Setting (additional) options for cacheable readonly volumes
        helmchart_values_dict["aws-mountpoint-s3-csi-driver"][
            "cacheableReadOnlyVolumeOptions"
        ] = ctx.cacheable_read_only_volume_options

        helm_chart = HelmChartContext.from_chart_folder_context(
            create_namespace=True,
            deploy_in_namespace=(
                raas_s3mount_driver_namespace_name
                if ctx.deployment.sandbox_name is None
                else f"{raas_s3mount_driver_namespace_name}-{ctx.deployment.sandbox_name}"
            ),
            release_name=(
                raas_s3mount_driver_namespace_name
                if ctx.deployment.sandbox_name is None
                else f"{raas_s3mount_driver_namespace_name}-{ctx.deployment.sandbox_name}"
            ),
            values_dict=helmchart_values_dict,
            chart_folder_path=str(helmchart_folderpath),
            wait_till_healthy=ctx.wait_till_healthy,
            delegate_deployment_to_helm=ctx.delegate_deployment_to_helm,
            deployment=ctx.deployment,
        )

        helm_chart.ref = ctx.ref
        helm_chart.name = "eks-s3mount"
        helm_chart.deployment = ctx.deployment
        helmchart = HelmChart.from_context(
            helm_chart,
            apply_sandbox_suffix_for_release_and_namespace_if_applicable=False,
        )
        props["helm_chart"] = helmchart

        return cls.model_validate(props)

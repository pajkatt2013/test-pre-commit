# Fluent Bit Deployment


## Introduction

This module is responsible for deploying Fluent Bit into RaaS EKS cluster
Fluent Bit is used here to stream container logs from EKS to Amazon CloudWatch.
Amazon CloudWatch enables querying capabilities on top of aggregated logs


## Related Documentation

the fluent bit chart was created based on AWS instructions found [here](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Container-Insights-setup-logs-FluentBit.html):

Additional documentation can be found in BMW wiki:
[RaaS Logging](https://asc.bmwgroup.net/wiki/display/ORIONPRODUCTS/RaaS+Logging)
[Fluent Bit configuration highlights](https://asc.bmwgroup.net/wiki/display/ORIONPRODUCTS/4.+Fluent+Bit+configuration+highlights)
[how to stream EKS containers logs to AWS CloudWatch](https://asc.bmwgroup.net/wiki/display/ORIONPRODUCTS/how+to+stream+EKS+containers+logs+to+AWS+CloudWatch)
[Raas Fluentbit config](https://asc.bmwgroup.net/wiki/display/ORIONPRODUCTS/Raas+Fluentbit+config)



##  What is does?
* create an AWS role and policy required to stream data cloudwatch
* deploy the designated Raas fluent bit configuration to the EKS cluster
* the fluent bit service account will assume the role created in step 1


Notes:

you should find fluent bit deployment in namespace amazon-cloudwatch

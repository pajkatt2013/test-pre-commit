#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Fluentbit CDK stack.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from typing import cast

import aws_cdk.aws_iam as iam
import aws_cdk.aws_logs as logs
import aws_cdk.aws_s3 as s3
import aws_cdk.aws_ssm as ssm
import cdk_nag
from aws_cdk import RemovalPolicy, Stack, Tags
from constructs import Construct, IConstruct

from raas_infra.constructs.helmchart import RaaSHelmChart
from raas_infra.constructs.iamrole_kubernetes_serviceaccount import (
    IamRoleForKubernetesServiceAccount,
)
from raas_infra.constructs.opensearch import RaaSOpenSearch
from raas_infra.eks.fluentbit.fluentbit_params import Fluentbit


class FluentbitStack(Stack):
    """Creates the resources needed by Fluentbit running in EKS."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: Fluentbit,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys artifacts related to fluentbit.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs).
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        # Create an IAM role for the Kubernetes service account
        self.service_account_role = IamRoleForKubernetesServiceAccount(
            scope=self,
            id_="ServiceAccountRole",
            role_name=stack_param.kubernetes_service_account.iam_role_name,
            role_description=stack_param.kubernetes_service_account.iam_role_description,
            kubernetes_service_account_name=stack_param.kubernetes_service_account.name,
            kubernetes_service_account_namespace=stack_param.kubernetes_service_account.namespace,
            eks_cluster_metadata=stack_param.eks_cluster,
        )

        # Create an S3 bucket for routing the output fluentbit logs
        self.fluentbit_logs_s3_bucket = self.create_bucket(
            stack_param.logs_s3_bucket_name, "FluentbitLogsStore"
        )

        self.service_account_role.role.add_managed_policy(
            iam.ManagedPolicy.from_managed_policy_arn(
                id="CloudWatchAgentServerPolicy",
                scope=self,
                managed_policy_arn=f"arn:{stack_param.deployment.account.partition}:iam::aws:policy/CloudWatchAgentServerPolicy",
            )
        )

        s3_artifacts_policy = iam.PolicyStatement(
            actions=["s3:ListBucket", "s3:*Object"],
            resources=[
                f"{self.fluentbit_logs_s3_bucket.bucket_arn}*",
                f"{self.fluentbit_logs_s3_bucket.bucket_arn}*/*",
            ],
            effect=iam.Effect.ALLOW,
        )

        self.service_account_role.role.add_to_policy(s3_artifacts_policy)

        # add access policies if RPU logging to S3 is enabled
        self.rpuLoggingToS3 = stack_param.helm_chart.values_dict.get("rpuLoggingToS3")
        if self.rpuLoggingToS3 is not None:
            self.rpuLoggingBucketArn = self.rpuLoggingToS3["bucketArn"]
            rpu_logging_policy = iam.PolicyStatement(
                actions=["s3:ListBucket", "s3:*Object"],
                resources=[
                    f"{self.rpuLoggingBucketArn}*",
                    f"{self.rpuLoggingBucketArn}*/*",
                ],
                effect=iam.Effect.ALLOW,
            )
            self.service_account_role.role.add_to_policy(rpu_logging_policy)

        # setting the provisioned role arn to the fluentbit service account
        stack_param.helm_chart.values_dict["fluentBitServiceAccount"]["name"] = (
            stack_param.kubernetes_service_account.name
        )

        stack_param.helm_chart.values_dict["fluentBitServiceAccount"]["annotations"][
            "eks.amazonaws.com/role-arn"
        ] = self.service_account_role.role.role_arn

        # Create RPU log groups for each customer function with respective tags
        # for cost allocation
        for customer_function in stack_param.customer_functions:
            log_group_name = (
                f"/aws/containerinsights/{stack_param.eks_cluster.name}"
                f"/application/raas/rpu/{customer_function}"
            )
            customer_function_rpu_log_group = logs.LogGroup(
                self,
                f"LogGroup-{customer_function}",
                log_group_name=log_group_name,
                removal_policy=RemovalPolicy.DESTROY,
                retention=logs.RetentionDays.TWO_WEEKS,
            )
            Tags.of(customer_function_rpu_log_group).add(
                "customer_function", customer_function
            )

        # Create log group for RaaS services
        logs.LogGroup(
            self,
            "raas-log-group",
            log_group_name=f"/aws/containerinsights/{stack_param.eks_cluster.name}/application/raas/services",
            removal_policy=RemovalPolicy.DESTROY,
            retention=logs.RetentionDays.TWO_MONTHS,
            # use the same log class as RPU logs to save costs.
            log_group_class=logs.LogGroupClass.INFREQUENT_ACCESS,
        )

        # Create log group for DQ services
        logs.LogGroup(
            self,
            "dq-log-group",
            log_group_name=f"/aws/containerinsights/{stack_param.eks_cluster.name}/application/data-quality/",
            removal_policy=RemovalPolicy.DESTROY,
            retention=logs.RetentionDays.TWO_MONTHS,
            # The "INFREQUENT ACCESS" storage class for the CloudWatch Log Group on DQ services blocks CW Metrics , hence upgrading to STANDARD class.
            log_group_class=logs.LogGroupClass.STANDARD,
        )

        # Outputs
        output_dict = {
            "IamRoleName": self.service_account_role.role.role_name,
            "IamRoleArn": self.service_account_role.role.role_arn,
        }

        if stack_param.opensearch is not None:
            opensearch_name = f"{id}-{stack_param.opensearch.name}"
            opensearch_principals = stack_param.opensearch.principals
            opensearch_principals.append(self.service_account_role.role.role_arn)
            self.raas_opensearch = RaaSOpenSearch(
                self,
                "raas-opensearch",
                name=opensearch_name,
                opensearch_type=stack_param.opensearch.type,
                principals_list=opensearch_principals,
            )

            # setting the opensearch host name
            opensearch_attr_collection_endpoint = (
                self.raas_opensearch.ops_collection.attr_collection_endpoint
            )
            stack_param.helm_chart.values_dict["opensearch"] = {
                "host": opensearch_attr_collection_endpoint
            }

            # assigning permissions for the fluentbit role to ingest data to opensearch
            opensearch_collection_endpoint_arn = (
                self.raas_opensearch.ops_collection.attr_arn
            )
            opensearch_policy = iam.PolicyStatement(
                actions=["aoss:*"],
                resources=[
                    opensearch_collection_endpoint_arn,
                ],
                effect=iam.Effect.ALLOW,
            )

            self.service_account_role.role.add_to_policy(opensearch_policy)
            stack_param.helm_chart.values_dict["output"]["opensearchServerless"][
                "enable"
            ] = "true"

            output_dict.update(
                {
                    "Opensearch_Collection_Endpoint": (
                        opensearch_attr_collection_endpoint
                    ),
                    "Opensearch_Dashboard_Endpoint": (
                        self.raas_opensearch.ops_collection.attr_dashboard_endpoint
                    ),
                    "Opensearch_Collection_Endpoint_Arn": (
                        opensearch_collection_endpoint_arn
                    ),
                }
            )
        else:
            print(
                "Skipping deployment for opensearch serverless."
                " Disable fluentbit output to opensearch serverless"
            )
            stack_param.helm_chart.values_dict["output"]["opensearchServerless"][
                "enable"
            ] = "false"

        # Create helm chart for deploying the argo workflow artifacts.
        self.helm_chart = RaaSHelmChart(
            scope=self,
            id=f"RaaSHelm-{stack_param.helm_chart.release_name}",
            eks_cluster=stack_param.eks_cluster,
            vpc=stack_param.vpc,
            helm_chart=stack_param.helm_chart,
            deployment=stack_param.deployment,
        )

        output_value = json.dumps(output_dict)
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

    def create_bucket(self, fluentbit_log_s3_bucket_name: str, id: str) -> s3.Bucket:
        """Create the S3 bucket."""
        bucket: s3.Bucket = s3.Bucket(
            self,
            id=id,
            bucket_name=fluentbit_log_s3_bucket_name,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            versioned=False,
            enforce_ssl=True,
            encryption=s3.BucketEncryption.S3_MANAGED,
            removal_policy=RemovalPolicy.DESTROY,
        )

        cdk_nag.NagSuppressions.add_resource_suppressions(
            bucket,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-S1",
                    reason="Bucket access logs not required.",
                )
            ],
        )

        return bucket

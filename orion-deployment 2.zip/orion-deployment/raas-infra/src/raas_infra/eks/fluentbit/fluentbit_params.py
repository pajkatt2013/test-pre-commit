#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Map Service Parameters for CDK stack deployment.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

from importlib.resources import files
from pathlib import Path

import yaml

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSCluster,
    FluentbitContext,
    HelmChartContext,
    KubernetesServiceAccount,
    OpensearchCollection,
)


class Fluentbit(ContextModel):
    """Managing the necessary params for Fluentbit Infra CDK deployment"""

    kubernetes_service_account: KubernetesServiceAccount
    eks_cluster: EKSCluster
    deployment: Deployment
    output_metadata_path: str
    helm_chart: HelmChartContext
    logs_s3_bucket_name: str
    vpc: VPC
    opensearch: OpensearchCollection | None = None
    customer_functions: list[str]

    @classmethod
    def from_context(cls, ctx: FluentbitContext) -> "Fluentbit":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])

        id = ctx.get_id()
        props: dict = {}
        props["id"] = id
        props["kubernetes_service_account"] = ctx.kubernetes_service_account
        props["deployment"] = ctx.deployment
        props["eks_cluster"] = eks_cluster
        props["vpc"] = vpc
        props["output_metadata_path"] = ctx.metadata_output_ssm_path
        props["opensearch"] = ctx.opensearch
        props["customer_functions"] = ctx.customer_functions.split(",")

        logs_s3_bucket_name = f"{id}-{ctx.deployment.account.id}"

        props["logs_s3_bucket_name"] = logs_s3_bucket_name

        # Loading Helm chart based on the input environment
        helm_values_file = str(
            files("raas_infra.eks.fluentbit.helm").joinpath("values.yaml")
        )
        helmchart_folderpath = Path(helm_values_file).parent
        with Path(helm_values_file).open() as fp:
            helmchart_values_dict = yaml.safe_load(fp)

        helmchart_values_dict["fluentBitClusterInfo"]["clusterName"] = eks_cluster.name
        helmchart_values_dict["fluentBitClusterInfo"]["logsRegion"] = (
            ctx.deployment.account.region
        )

        # setting the s3 bucket name to write the output logs
        helmchart_values_dict["s3bucket"] = {"name": logs_s3_bucket_name}

        if ctx.rpu_logs_bucket is not None:
            helmchart_values_dict["rpuLoggingToS3"] = {
                "enabled": "true",
                "bucketArn": ctx.rpu_logs_bucket.arn,
                "bucketName": ctx.rpu_logs_bucket.name,
            }

        helm_chart = HelmChartContext.from_chart_folder_context(
            create_namespace=True,
            deploy_in_namespace=ctx.kubernetes_service_account.namespace,
            release_name=ctx.kubernetes_service_account.namespace,
            values_dict=helmchart_values_dict,
            chart_folder_path=str(helmchart_folderpath),
            wait_till_healthy=ctx.wait_till_healthy,
            delegate_deployment_to_helm=ctx.delegate_deployment_to_helm,
            deployment=ctx.deployment,
        )

        props["helm_chart"] = helm_chart

        return cls.model_validate(props)

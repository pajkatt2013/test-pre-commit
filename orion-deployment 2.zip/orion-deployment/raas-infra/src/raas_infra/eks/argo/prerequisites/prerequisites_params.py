#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Argo Prerequisites Parameters for CDK stack deployment.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

from importlib.resources import files
from pathlib import Path

import yaml

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSArgoPrerequisitesContext,
    EKSCluster,
    HelmChartContext,
)


class ArgoPrerequisites(ContextModel):
    """Managing the necessary params for Argo Prequesites CDK deployment"""

    id: str
    eks_cluster: EKSCluster
    vpc: VPC
    output_metadata_path: str
    deployment: Deployment
    helm_chart: HelmChartContext
    raas_pipeline_namespace: str

    @classmethod
    def from_context(cls, ctx: EKSArgoPrerequisitesContext) -> "ArgoPrerequisites":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])
        props = {
            "eks_cluster": eks_cluster,
            "vpc": vpc,
            "deployment": ctx.deployment,
            "id": ctx.get_id(),
            "output_metadata_path": ctx.metadata_output_ssm_path,
        }

        helm_values_file = str(
            files("raas_infra.eks.argo.prerequisites.helm").joinpath("values.yaml")
        )
        helmchart_folderpath = Path(helm_values_file).parent

        with Path(helm_values_file).open() as fp:
            helmchart_values_dict = yaml.safe_load(fp)

        # Setting the list of namespaces to be created in the EKS with all the
        # prerequisites.
        workflow_application_namespaces = [
            ctx.raas_pipeline_namespace,
        ]
        if ctx.deployment.sandbox_name is None:
            helmchart_values_dict["workflow"]["namespaces"] = (
                workflow_application_namespaces
            )
        else:
            helmchart_values_dict["workflow"]["namespaces"] = [
                f"{x}-{ctx.deployment.sandbox_name}"
                for x in workflow_application_namespaces
            ]

            # skipping crd resource installation
            helmchart_values_dict["crds"]["install"] = False

        props["raas_pipeline_namespace"] = (
            ctx.raas_pipeline_namespace
            if ctx.deployment.sandbox_name is None
            else f"{ctx.raas_pipeline_namespace}-{ctx.deployment.sandbox_name}"
        )

        helm_chart = HelmChartContext.from_chart_folder_context(
            create_namespace=True,
            deploy_in_namespace="default",
            release_name=(
                "raas-argo-prerequisites"
                if ctx.deployment.sandbox_name is None
                else f"raas-argo-prerequisites-{ctx.deployment.sandbox_name}"
            ),
            values_dict=helmchart_values_dict,
            chart_folder_path=str(helmchart_folderpath),
            wait_till_healthy=ctx.wait_till_healthy,
            delegate_deployment_to_helm=ctx.delegate_deployment_to_helm,
            deployment=ctx.deployment,
        )

        props["helm_chart"] = helm_chart
        return cls.model_validate(props)

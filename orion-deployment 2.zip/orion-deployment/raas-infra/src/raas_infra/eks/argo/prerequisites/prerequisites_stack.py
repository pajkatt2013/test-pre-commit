#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Argo Prerequisites CDK stack.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

from typing import cast

import aws_cdk.aws_ssm as ssm
from aws_cdk import Stack, Tags
from constructs import Construct, IConstruct

from raas_infra import ArgoPrerequisites
from raas_infra.constructs.helmchart import RaaSHelmChart


class ArgoPrerequisitesStack(Stack):
    """CDK stack for deploying the Prerequisites for Argo setup."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: ArgoPrerequisites,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys Prerequisites for Argo such as CRDs.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs).
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        # Create helm chart for deploying the prerequisites.
        self.helm_chart = RaaSHelmChart(
            scope=self,
            id=f"RaaSHelm-{stack_param.helm_chart.release_name}",
            eks_cluster=stack_param.eks_cluster,
            vpc=stack_param.vpc,
            helm_chart=stack_param.helm_chart,
            deployment=stack_param.deployment,
        )

        # Write output to SSM
        self.write_output(stack_param=stack_param)

    def write_output(self, stack_param: ArgoPrerequisites) -> None:
        """Responsible for capturing the metadata in the SSM"""
        # Saving the output of the prerequisites deployment to SSM

        output_value = self.to_json_string(
            {
                "raas_pipeline_namespace": stack_param.raas_pipeline_namespace,
                "raas_argos_events_namespace_name": "raas-argo-events",
                "raas_argos_workflows_namespace_name": "raas-argo-workflows",
                "raas_efs_driver_namespace_name": "raas-argo-efsmount",
            }
        )
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

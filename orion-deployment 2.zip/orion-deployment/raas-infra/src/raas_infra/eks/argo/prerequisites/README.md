# RaaS Argo Prerequisites

This module is responsible for deploying the pre-requisite for argo workflows and argo events.



RaaS-Argo-Prerequisites comes package with below resources.

- Custom Resource Definitions - EventBus, EventSource, Sensor
- Creates the configured list of application namespaces in the EKS Cluster

Custom Resource Definitions (CRD) are the mandatory pre-requisites, for any argo related deployments.
Without CRD the other argo deployments might fail in a fresh environment

During development and testing, Application Namespaces in EKS allows to deploy developer specific changes for testing.
The list of Application Namespaces can be configured in the [environment file](https://github.com/qcc-collab-006/orion-deployment/blob/main/dev-eu-central-1/raas-infra/.env), value set to parameter : **ADDF_PARAMETER_RAAS_ARGO_WORKFLOWS_APPLICATION_NAMESPACES**

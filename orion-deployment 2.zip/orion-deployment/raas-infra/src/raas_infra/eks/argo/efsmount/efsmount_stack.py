#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
EFS Deployment CDK stack.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import copy
import json
from typing import cast

import aws_cdk.aws_ec2 as ec2
import aws_cdk.aws_efs as efs
import aws_cdk.aws_iam as iam
import aws_cdk.aws_ssm as ssm
from aws_cdk import CfnJson, Stack, Tags
from constructs import Construct, IConstruct

from raas_infra.constructs.helmchart import RaaSHelmChart
from raas_infra.eks.argo.efsmount.efsmount_params import ArgoEFSMount
from raas_infra.utils.helper import Helper


class ArgoEFSMountStack(Stack):
    """Create resources needed by EKS to mount using EFS creating persistent volumes."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: ArgoEFSMount,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys EFS and mount in EKS.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs)
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        vpc = ec2.Vpc.from_lookup(self, id="VPC", vpc_id=stack_param.vpc.id)

        # Security group to access EFS
        efs_sg = ec2.SecurityGroup(
            self,
            stack_param.efs_sg_name,
            security_group_name=stack_param.efs_sg_name,
            vpc=vpc,
            allow_all_outbound=False,
        )

        # EFS SG ingress rule to allow EKS access for creating mount points
        efs_sg.add_ingress_rule(
            ec2.SecurityGroup.from_security_group_id(
                self,
                "AllowTrafficFrom",
                stack_param.eks_cluster.security_group_id,
            ),
            ec2.Port.tcp(2049),
            "Allow traffic from the specified security group",
        )

        # IAM role to access EFS from EKS to create mount points
        self.role = self.create_role(
            stack_param.eks_cluster.oidc_arn,
            stack_param.raas_efs_csi_controller_role_name,
            stack_param.raas_efs_csi_controller_sa,
        )

        # Settings the provisioned EFS Id in the helm chart for bootstrapping with EKS
        # to create persistent volumes
        template_storage_class = stack_param.helm_chart.values_dict[
            "aws-efs-csi-driver"
        ]["storageClasses"][0]
        storage_classes = []
        self.customer_functions_efs = {}
        self.customer_functions_efs_storage_class_names = []
        storage_params = []
        for customer_function in stack_param.customer_functions:
            storage_param = {}
            sanitized_customer_function = customer_function.replace("_", "-")
            customer_function_storage_class = copy.deepcopy(template_storage_class)
            customer_function_storage_class["name"] = (
                f"{sanitized_customer_function}-efs-sc"
            )
            self.customer_functions_efs_storage_class_names.append(
                customer_function_storage_class["name"]
            )

            if stack_param.enable_shared_pvcs:
                storage_param["pvc"] = (
                    f"{stack_param.pvc_prefix}-{sanitized_customer_function}"
                )
            storage_param["storageClass"] = customer_function_storage_class["name"]
            storage_params.append(storage_param)

            # EFS construct
            customer_function_efs = efs.FileSystem(
                self,
                id=f"{sanitized_customer_function}-efs",
                vpc=vpc,
                encrypted=True,
                security_group=efs_sg,
                throughput_mode=efs.ThroughputMode.ELASTIC,
            )
            Tags.of(customer_function_efs).add("customer_function", customer_function)
            customer_function_storage_class["parameters"]["fileSystemId"] = (
                customer_function_efs.file_system_id
            )
            storage_classes.append(customer_function_storage_class)
            self.customer_functions_efs.update(
                {customer_function: customer_function_efs.file_system_id}
            )

        stack_param.helm_chart.values_dict["aws-efs-csi-driver"]["storageClasses"] = (
            storage_classes
        )
        if stack_param.enable_shared_pvcs:
            stack_param.helm_chart.values_dict["enableSharedPvcs"] = True
            stack_param.helm_chart.values_dict["storage"] = storage_params
            stack_param.helm_chart.values_dict["pvcSize"] = stack_param.pvc_size
            stack_param.helm_chart.values_dict["pvcNamespace"] = (
                stack_param.pvc_namespace
            )

        self.helm_chart = RaaSHelmChart(
            scope=self,
            id=f"RaaSHelm-{stack_param.helm_chart.release_name}",
            eks_cluster=stack_param.eks_cluster,
            vpc=stack_param.vpc,
            helm_chart=stack_param.helm_chart,
            deployment=stack_param.deployment,
        )

        # Write output to SSM
        self.write_output(stack_param=stack_param)

    def create_role(
        self,
        eks_oidc_provider_arn: str,
        raas_efs_csi_controller_role_name: str,
        raas_efs_csi_controller_service_accout_name: str,
    ) -> iam.Role:
        """Create a role for EKS to access EFS"""
        oidc_provider_id = eks_oidc_provider_arn.split("/")[-1]
        oidc_provider = Helper.get_oidc_provider(
            region=self.stack_param.deployment.account.region,
            oidc_provider_id=oidc_provider_id,
        )

        # IAM Role construct with trust relationship and required permissions.
        role = iam.Role(
            self,
            "EKSEFSControllerServiceAccountRole",
            role_name=raas_efs_csi_controller_role_name,
            description=(
                "Role used by EKS - EFS Controller Service account to access EFS."
            ),
            # Setting the eks service account to allow access EFS for creating
            # mount points.
            assumed_by=iam.PrincipalWithConditions(
                iam.WebIdentityPrincipal(eks_oidc_provider_arn),
                conditions={
                    "StringLike": CfnJson(
                        self,
                        "ServiceAccountRoleTrustPolicy-server-serviceaccount",
                        value={
                            f"{oidc_provider}:sub": f"system:serviceaccount:*:{raas_efs_csi_controller_service_accout_name}",
                            f"{oidc_provider}:aud": "sts.amazonaws.com",
                        },
                    ),
                },
            ),
        )

        role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    "elasticfilesystem:*",
                    "ec2:DescribeAvailabilityZones",
                ],
                resources=["*"],
                effect=iam.Effect.ALLOW,
            )
        )

        return role

    def write_output(self, stack_param: ArgoEFSMount) -> None:
        """Responsible for capturing the metadata in the SSM"""
        # Saving the output of the efs deployment to SSM

        output_dict = {
            f"{x}-efs_file_system_id": self.customer_functions_efs[x]
            for x in self.customer_functions_efs
        }
        output_dict.update(
            {"efs_storage_class_names": self.customer_functions_efs_storage_class_names}
        )
        output_value = json.dumps(output_dict)
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

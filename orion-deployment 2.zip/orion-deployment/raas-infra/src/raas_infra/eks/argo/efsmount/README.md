# RaaS EFS


This module is responsible for deploying EFS and boostraping to EKS with required permissions.


Please follow [aws-efs-csi-driver](https://github.com/kubernetes-sigs/aws-efs-csi-driver) for more details about the default setup.

RaaS EFS comes package with below resources on top of the default AWS EFS Driver public helm chart.


- Provisioning EFS with security group allowing EKS security group to allow mounting as Persistent Volumes to the PODs
- Provisioned EFS Identity is set to the helm chart for updating the storage class configurations in EKS
- IAM role to access EFS for mounting new volumes
- IAM role mapped to Driver Controller Service Account
- Helm Chart to deploy EFS Driver




Each environment has the designated **values.[env].yaml** which can be used to configure environment specific settings if any.
Ex:- If Dev environment requires any specific settings, can be managed in [values.dev.yaml](helm/values.dev.yaml)

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#
"""Parameters for deploying EFS and Mounting EFS to EKS - CDK stack deployment."""

from importlib.resources import files
from pathlib import Path

import yaml

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSArgoEFSMountContext,
    EKSCluster,
    HelmChartContext,
)
from raas_infra.utils.helper import Helper


class ArgoEFSMount(ContextModel):
    """Managing the necessary params for EFS CDK deployment"""

    id: str
    eks_cluster: EKSCluster
    vpc: VPC
    output_metadata_path: str
    deployment: Deployment
    helm_chart: HelmChartContext
    raas_efs_csi_controller_role_name: str
    raas_efs_csi_controller_sa: str
    efs_sg_name: str
    pvc_prefix: str
    pvc_size: str
    pvc_namespace: str
    customer_functions: list[str]

    @classmethod
    def from_context(cls, ctx: EKSArgoEFSMountContext) -> "ArgoEFSMount":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])

        id_ = ctx.get_id()
        props = {
            "eks_cluster": eks_cluster,
            "vpc": vpc,
            "deployment": ctx.deployment,
            "id": id_,
            "output_metadata_path": ctx.metadata_output_ssm_path,
            "efs_sg_name": f"{id_}-sg",
            "enable_shared_pvcs": ctx.enable_shared_pvcs,
            "pvc_prefix": ctx.pvc_prefix,
            "pvc_size": ctx.pvc_size,
            "pvc_namespace": ctx.pvc_namespace,
        }

        # Input "customer_functions" are comma separated. converting comma separated
        # values to list.
        customer_functions = [x.strip() for x in ctx.customer_functions.split(",")]
        props.update({"customer_functions": customer_functions})

        # Service account for accessing the EFS and the required IAM role with
        # permissions
        raas_efs_csi_controller_role_name = f"{id_}-Role"
        props["raas_efs_csi_controller_role_name"] = raas_efs_csi_controller_role_name

        raas_efs_csi_controller_sa = "efs-csi-controller-sa"
        props["raas_efs_csi_controller_sa"] = raas_efs_csi_controller_sa
        raas_efs_csi_controller_role_arn = Helper.get_iam_role_arn(
            account=ctx.deployment.account,
            role_name=raas_efs_csi_controller_role_name,
        )

        # Loading Helm chart based on the input environment
        helm_values_file = str(
            files("raas_infra.eks.argo.efsmount.helm").joinpath("values.yaml")
        )
        helmchart_folderpath = Path(helm_values_file).parent
        with Path(helm_values_file).open() as f:
            helmchart_values_dict = yaml.safe_load(f)

        # Setting the service account with annotation referring to the IAM role for
        # accessing the EFS
        helmchart_values_dict["aws-efs-csi-driver"]["controller"] = {
            "deleteAccessPointRootDir": True,
            "serviceAccount": {
                "name": raas_efs_csi_controller_sa,
                "annotations": {
                    "eks.amazonaws.com/role-arn": raas_efs_csi_controller_role_arn
                },
            },
        }

        # Setting the argo helm chart registries
        helmchart_values_dict["aws-efs-csi-driver"]["image"]["repository"] = (
            ctx.efs_docker_registry + "/aws-efs-csi-driver"
        )
        helmchart_values_dict["aws-efs-csi-driver"]["sidecars"]["livenessProbe"][
            "image"
        ]["repository"] = ctx.efs_docker_registry + "/livenessprobe"
        helmchart_values_dict["aws-efs-csi-driver"]["sidecars"]["nodeDriverRegistrar"][
            "image"
        ]["repository"] = ctx.efs_docker_registry + "/csi-node-driver-registrar"
        helmchart_values_dict["aws-efs-csi-driver"]["sidecars"]["csiProvisioner"][
            "image"
        ]["repository"] = ctx.efs_docker_registry + "/csi-provisioner"

        # Setting the argo helm chart versions
        helmchart_values_dict["aws-efs-csi-driver"]["image"]["tag"] = (
            ctx.efs_driver_docker_tag
        )

        raas_efs_driver_namespace_name = "raas-argo-efsmount"

        helm_chart = HelmChartContext.from_chart_folder_context(
            create_namespace=True,
            deploy_in_namespace=raas_efs_driver_namespace_name,
            release_name=raas_efs_driver_namespace_name,
            values_dict=helmchart_values_dict,
            chart_folder_path=str(helmchart_folderpath),
            wait_till_healthy=ctx.wait_till_healthy,
            delegate_deployment_to_helm=ctx.delegate_deployment_to_helm,
            deployment=ctx.deployment,
        )

        props["helm_chart"] = helm_chart

        return cls.model_validate(props)

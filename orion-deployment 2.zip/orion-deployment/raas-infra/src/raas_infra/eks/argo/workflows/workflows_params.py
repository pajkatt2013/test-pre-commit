#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Argo workflow Parameters for CDK stack deployment.

(C) 2024 Qualcomm Technologies, Inc.  All rights reserved.
"""

import base64
import json
from importlib.resources import files
from pathlib import Path

import yaml

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSArgoWorkflowsContext,
    EKSCluster,
    HelmChartContext,
    QueueContext,
)
from raas_infra.eks.helmcharts.helmchart_param import HelmChart
from raas_infra.utils.helper import Helper


class ArgoWorkFlow(ContextModel):
    """Managing the necessary params for Argo Workflows CDK deployment"""

    id: str
    eks_cluster: EKSCluster
    vpc: VPC
    output_metadata_path: str
    reprocessed_output_s3_bucket_arn: str
    collected_input_s3_bucket_arns: list[str]
    collected_input_s3_access_point_arns: list[str]
    deployment: Deployment
    job_status_queue: QueueContext
    job_status_dl_queue: QueueContext | None
    helm_chart: HelmChart
    raas_argo_service_account_role_name: str
    raas_argo_workflows_service_account_name: str
    raas_argo_workflows_server_service_account_name: str
    raas_argo_artifacts_s3_bucket_name: str
    job_status_queues_policy_arn: str
    job_status_queues_sandbox_policy_arn: str

    @classmethod
    def from_context(cls, ctx: EKSArgoWorkflowsContext) -> "ArgoWorkFlow":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])
        hosted_zone_name = ctx.ref["hostedZoneName"].lower()

        id_ = ctx.get_id()
        props = {
            "eks_cluster": eks_cluster,
            "vpc": vpc,
            "deployment": ctx.deployment,
            "job_status_queue": ctx.job_status_queue,
            "id": id_,
            "output_metadata_path": ctx.metadata_output_ssm_path,
            "collected_input_s3_bucket_arns": ctx.collected_input_s3_bucket_arns,
            "collected_input_s3_access_point_arns": (
                ctx.collected_input_s3_access_point_arns
            ),
            "reprocessed_output_s3_bucket_arn": ctx.reprocessed_output_s3_bucket_arn,
            "etl_metadata_app_sync_assume_role_arn": (
                ctx.etl_metadata_app_sync_assume_role_arn
            ),
        }

        account = ctx.deployment.account
        eks_routable_private_subnet_ids = json.loads(vpc.routable_subnet_ids)

        # Fetching the application namespaces deployed during prerequisites
        # module deployment
        prerequisites = json.loads(ctx.ref["prerequisites"])

        raas_pipeline_namespace = prerequisites["raas_pipeline_namespace"]
        argo_workflows_application_namespaces = [
            raas_pipeline_namespace,
        ]

        # S3 bucket name for storing argo workflow artifacts such as logs
        raas_argo_artifacts_s3_bucket_name = f"{id_}-artifacts-{account.id}"
        props["raas_argo_artifacts_s3_bucket_name"] = raas_argo_artifacts_s3_bucket_name

        # IAM role name and arn which will have access to write to S3 artifacts
        # storage account and access to send status messages to SQS.
        raas_argo_service_account_role_name = f"{ctx.get_non_sandbox_id()}-sa-role"
        raas_argo_artifacts_access_role_arn = Helper.get_iam_role_arn(
            account=ctx.deployment.account,
            role_name=raas_argo_service_account_role_name,
        )

        props["raas_argo_service_account_role_name"] = (
            raas_argo_service_account_role_name
        )

        # Argo workflows namespace (this namespace will host argo workflow controller,
        # server and respective service accounts)
        raas_argos_workflows_namespace_name = prerequisites[
            "raas_argos_workflows_namespace_name"
        ]

        # Service accounts for argo workflow controller, server, running
        # etl metadata pipelines
        raas_argo_workflows_controller_service_account_name = (
            "raas-argo-workflows-controller-sa"
        )
        raas_argo_workflows_server_service_account_name = (
            "raas-argo-workflows-server-sa"
        )
        raas_argo_workflows_service_account_name = "raas-argo-workflows-sa"

        props["raas_argo_workflows_service_account_name"] = (
            raas_argo_workflows_service_account_name
        )
        props["raas_argo_workflows_server_service_account_name"] = (
            raas_argo_workflows_server_service_account_name
        )

        # Loading Helm chart based on the input environment

        helm_values_file = str(
            files("raas_infra.eks.argo.workflows.helm").joinpath("values.yaml")
        )

        with Path(helm_values_file).open() as fp:
            helmchart_values_dict = yaml.safe_load(fp)
        # populate helm values with ssm parameters
        # so that the template will make use of them
        helmchart_values_dict["ref"] = {}
        helmchart_values_dict["ref"]["archivedb"] = json.loads(ctx.ref["archivedb"])
        helmchart_values_dict["ref"]["prerequisites"] = json.loads(
            ctx.ref["prerequisites"]
        )
        # Merging the configured argo woriflow values with the current loaded
        # helm values
        Helper.dictionary_deep_merge(helmchart_values_dict, ctx.values_dict)

        helmchart_folderpath = Path(helm_values_file).parent

        # In case of sandbox based deployment, deploying the sandbox helm chart.
        # sandbox helm chart deploys only the workflow service account, role and role
        if ctx.deployment.sandbox_name is not None:
            helm_chart_file = str(
                files("raas_infra.eks.argo.workflows.sandbox_helm").joinpath(
                    "Chart.yaml"
                )
            )
            helmchart_folderpath = Path(helm_chart_file).parent

        # Setting the ingress subnets to the routable private subnet ids for ingress
        helmchart_values_dict["argo-workflows"]["server"]["ingress"] = {
            "enabled": ctx.enable_ingress,
            "hosts": [f"{ctx.subdomain_name}.{hosted_zone_name}"],
            "annotations": {
                "kubernetes.io/ingress.class": "alb",
                "alb.ingress.kubernetes.io/scheme": "internal",
                "alb.ingress.kubernetes.io/target-type": "ip",
                "alb.ingress.kubernetes.io/backend-protocol": "HTTP",
                "alb.ingress.kubernetes.io/listen-ports": (
                    '[{"HTTP": 80}, {"HTTPS": 443}]'
                ),
                "alb.ingress.kubernetes.io/subnets": ", ".join(
                    eks_routable_private_subnet_ids
                ),
            },
        }

        # Setting the argo workflow server service account and IAM role arn
        helmchart_values_dict["argo-workflows"]["server"]["serviceAccount"] = {
            "name": raas_argo_workflows_server_service_account_name,
            "annotations": {
                "eks.amazonaws.com/role-arn": raas_argo_artifacts_access_role_arn
            },
        }

        # Setting the argo workflow default service account and IAM role arn
        helmchart_values_dict["argo-workflows"]["workflow"] = {
            "serviceAccount": {
                "name": raas_argo_workflows_service_account_name,
                "annotations": {
                    "eks.amazonaws.com/role-arn": raas_argo_artifacts_access_role_arn
                },
            }
        }

        # Setting application namespace to create required service accounts,
        # role bindings etc
        helmchart_values_dict["argo-workflows"]["controller"]["workflowNamespaces"] = (
            argo_workflows_application_namespaces
        )

        # Setting the argo workflow controller service account and IAM role arn
        helmchart_values_dict["argo-workflows"]["controller"]["serviceAccount"] = {
            "name": raas_argo_workflows_controller_service_account_name,
            "annotations": {
                "eks.amazonaws.com/role-arn": raas_argo_artifacts_access_role_arn
            },
        }

        # Setting the argo workflow default service account and IAM role arn
        helmchart_values_dict["argo-workflows"]["controller"]["workflowDefaults"] = {
            "spec": {
                "serviceAccountName": raas_argo_workflows_service_account_name,
            },
        }

        # Setting the argo workflow artifacts repository to S3 arn
        helmchart_values_dict["argo-workflows"]["artifactRepository"]["s3"] = {
            "bucket": raas_argo_artifacts_s3_bucket_name,
            "region": account.region,
        }

        # Setting the argo helm chart registries for the controller, executor and serer
        helmchart_values_dict["argo-workflows"]["controller"]["image"]["registry"] = (
            ctx.argo_docker_registry
        )
        helmchart_values_dict["argo-workflows"]["executor"]["image"]["registry"] = (
            ctx.argo_docker_registry
        )
        helmchart_values_dict["argo-workflows"]["server"]["image"]["registry"] = (
            ctx.argo_docker_registry
        )

        # Setting the argo helm chart versions for the controller, executor and serer
        helmchart_values_dict["argo-workflows"]["controller"]["image"]["tag"] = (
            ctx.argo_docker_tag
        )
        helmchart_values_dict["argo-workflows"]["executor"]["image"]["tag"] = (
            ctx.argo_docker_tag
        )
        helmchart_values_dict["argo-workflows"]["server"]["image"]["tag"] = (
            ctx.argo_docker_tag
        )
        # Checking if argo workflow archive persistence is enabled, setting the
        # username and password
        if ctx.deployment.sandbox_name is None and (
            "persistence" in helmchart_values_dict["argo-workflows"]["controller"]
            and helmchart_values_dict["argo-workflows"]["controller"]["persistence"][
                "archive"
            ]
            is True
        ):
            # fetching postgres sql configuration
            postgres_sql = helmchart_values_dict["argo-workflows"]["controller"][
                "persistence"
            ]["postgresql"]

            # fetching credentials based on reference
            db_credentials_ref = postgres_sql["db_credentials"]["secret_ref"]
            db_credentials_json = ctx.ref[db_credentials_ref]

            # deserializing the secrets json and setting the credentials for argo
            # workflow template values
            db_credentials = json.loads(db_credentials_json)
            username = db_credentials["username"]
            password = db_credentials["password"]

            # converting to base64 format while creating secrets
            username_base64 = (base64.b64encode(bytes(username, "utf-8"))).decode(
                "utf-8"
            )
            password_base64 = (base64.b64encode(bytes(password, "utf-8"))).decode(
                "utf-8"
            )

            # setting the secret name for workflow controller to reference to the
            # secrets
            archive_config_name = "argo-workflow-archive-config"
            helmchart_values_dict["argo-workflows"]["controller"]["wf-archive"] = {
                "config-name": archive_config_name,
                "username": username_base64,
                "password": password_base64,
            }
            postgres_sql["passwordSecret"] = {
                "key": "password",
                "name": archive_config_name,
            }
            postgres_sql["userNameSecret"] = {
                "key": "username",
                "name": archive_config_name,
            }

            # removing the unused keys
            del postgres_sql["db_credentials"]

        # In case of sandbox based deployment, setting value to the "sandbox" property
        if ctx.deployment.sandbox_name is not None:
            helmchart_values_dict["sandbox"] = helmchart_values_dict["argo-workflows"]

        helm_chart = HelmChartContext.from_chart_folder_context(
            create_namespace=True,
            deploy_in_namespace=raas_argos_workflows_namespace_name,
            release_name=(
                raas_argos_workflows_namespace_name
                if ctx.deployment.sandbox_name is None
                else f"{raas_argos_workflows_namespace_name}-{ctx.deployment.sandbox_name}"
            ),
            values_dict=helmchart_values_dict,
            chart_folder_path=str(helmchart_folderpath),
            wait_till_healthy=ctx.wait_till_healthy,
            delegate_deployment_to_helm=ctx.delegate_deployment_to_helm,
            deployment=ctx.deployment,
        )
        helm_chart.ref = ctx.ref
        helm_chart.name = "argo-workflows"
        helm_chart.deployment = ctx.deployment
        helmchart = HelmChart.from_context(
            helm_chart,
            apply_sandbox_suffix_for_release_and_namespace_if_applicable=False,
        )
        props["helm_chart"] = helmchart
        # Provisioning the sqs queues. In this case provisioning the "job-status" queue
        # to send the status notifications back to JMS.
        (
            props["job_status_dl_queue"],
            props["job_status_queues_policy_arn"],
            props["job_status_queues_sandbox_policy_arn"],
        ) = ArgoWorkFlow.queue_context(ctx)

        return cls.model_validate(props)

    @classmethod
    def queue_context(
        cls, ctx: EKSArgoWorkflowsContext
    ) -> tuple[QueueContext | None, str, str]:
        """Create context for job-status queue."""
        jsq = ctx.job_status_queue
        is_fifo = ctx.job_status_queue.is_fifo
        queue_name = "job-status" if jsq.name is None else jsq.name
        account = ctx.deployment.account
        job_status_dl_queue = None
        id_ = ctx.get_id()
        jsq.full_name = f"""{id_}-{queue_name}{'.fifo'
                                            if is_fifo else ''}"""
        # If the job_status queue has dlq define then we create a dlq object
        if jsq.dlq is not None:
            props = {
                "name": queue_name + "-dl",
                "max_receive_count": jsq.dlq.max_receive_count,
                "is_fifo": jsq.is_fifo,
                "full_name": f"""{id_}-{queue_name}-dl{'.fifo'
                      if is_fifo else ''}""",
                "message_retention_period": jsq.message_retention_period
                if jsq.dlq.message_retention_period is None
                else jsq.dlq.message_retention_period,
                "message_visibility_timeout": jsq.message_visibility_timeout
                if jsq.dlq.message_visibility_timeout is None
                else jsq.dlq.message_visibility_timeout,
            }
            job_status_dl_queue = QueueContext.from_context(json.dumps(props))

        # resource arns for the job status sqs to create policy that works for both
        # sandbox and normal environments
        job_status_queues_sandbox_policy_arn = (
            f"arn:{account.partition}:sqs:{account.region}"
            f":{account.id}:{ctx.get_sandbox_id('*')}-"
            f"{queue_name}"
            f"{'.fifo' if is_fifo else ''}"
        )
        job_status_queues_policy_arn = (
            f"arn:{account.partition}:sqs:{account.region}"
            f":{account.id}:{jsq.full_name}"
        )
        return (
            job_status_dl_queue,
            job_status_queues_policy_arn,
            job_status_queues_sandbox_policy_arn,
        )

# RaaS Argo Workflows


This module is responsible for deploying Argo Workflows Helm Chart in EKS along with necessary EKS resources for workflow orchestrations.


Please follow [argo-workflows-helm-chart](https://github.com/argoproj/argo-helm/tree/main/charts/argo-workflows) for more details about the default setup Argo provides.

RaaS-Argo-Workflows comes package with below resources on top of the default Argo-Workflows public helm chart.

- For Eaach Application Namespace created during the [Prerequisites](../prerequisites/README.md) deployment, below EKS resources are provisioned
    - Role Bindings to run the Argo Workflows
    - Service Account mapped to the Role Bindings and other necessary permissions
- Ingress and Service Resource to access Argo UI using DNS via Application Load Balancer
- Priority class definitions to assign to PODs while running the workflows
- S3 account to store the Argo Workflow Artifacts
- SSL Certificate for the Argo UI
- Creating Service Account for each ETLMetadata Process
- IAM role for reading and writing objects to S3 and publish access to send out status message to Job Status SQS
- IAM role mapped to Argo Server and Workflow Service Accounts to access S3
- Helm Chart to deploy RaaS-Argo-Workflows




Each environment has the designated **values.[env].yaml** which can be used to configure environment specific settings if any.
Ex:- If Dev environment requires any specific settings, can be managed in [values.dev.yaml](helm/values.dev.yaml)

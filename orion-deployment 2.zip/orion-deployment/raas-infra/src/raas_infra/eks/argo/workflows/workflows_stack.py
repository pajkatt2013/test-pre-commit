#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Argo workflow Parameters for CDK stack deployment.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from typing import Any, cast

import aws_cdk.aws_iam as iam
import aws_cdk.aws_s3 as s3
import aws_cdk.aws_sqs as sqs
import aws_cdk.aws_ssm as ssm
import cdk_nag
from aws_cdk import CfnJson, RemovalPolicy, Stack, Tags
from constructs import Construct, IConstruct

from raas_infra import ArgoWorkFlow
from raas_infra.context import QueueContext
from raas_infra.utils.helper import Helper


class ArgoWorkFlowStack(Stack):
    """Creates the resources needed by ArgoWorkflows running in EKS."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: ArgoWorkFlow,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys artifacts related to argo workflows.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        self.output_dict: dict[str, Any] = {}

        # Create tags (automatically applied to child constructs)
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        # List of SQS queues to be provisioned.
        # Provisioning the workflow job status queue as fifo, to control sequential
        # processing of messages and also one time processing.
        # https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-fifo-queues.html
        # https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/FIFO-queues-exactly-once-processing.html
        # Extracting the partition from stack_param to handle different AWS regions and partitions
        aws_partition = stack_param.deployment.account.partition
        # Create the dead letter queue (DLQ)
        self.dl_sqs_queue = self.create_sqs(queue_param=stack_param.job_status_dl_queue)
        dlq_attr_arn = None if self.dl_sqs_queue is None else self.dl_sqs_queue.attr_arn
        # Initialize variables for redrive policy and redrive allow policy
        redrive_policy = None
        redrive_allow_policy = None
        # Check if both DLQ and dlq_attr_arn are provided
        if stack_param.job_status_dl_queue is not None and dlq_attr_arn is not None:
            dlq = stack_param.job_status_dl_queue
            # Set redrive policy
            redrive_policy = {
                "deadLetterTargetArn": dlq_attr_arn,
                "maxReceiveCount": dlq.max_receive_count,
            }
            ## Define redrive allow policy (controls which queues can push messages to the DLQ)
            redrive_allow_policy = {
                "redrivePermission": "byQueue",
                "sourceQueueArns": [
                    f"arn:{aws_partition}:sqs:{self.region}:{self.account}:{stack_param.job_status_queue.full_name}"
                ],
            }
        self.sqs_queue = self.create_sqs(
            queue_param=stack_param.job_status_queue,
            redrive_policy=redrive_policy,
            redrive_allow_policy=redrive_allow_policy,
        )

        # raas_argo_sqs_publish_queue_arns : This parameter contains the list of
        # sqs queues created in current stack.
        # Metadata stack while creating role for each etl service account will provide
        # "sendmessage" permissions to this sqs queues.
        self.output_dict = {}
        if self.sqs_queue is not None:
            self.output_dict = {
                "raas_argo_sqs_publish_queue_arns": [self.sqs_queue.attr_arn],
            }

        # provisioning s3 buckets, roles for non-sandbox environments
        if stack_param.deployment.sandbox_name is None:
            # Create an S3 bucket for workflow artifacts and logs storage
            self.raas_argo_artifacts_s3_bucket = self.create_bucket(
                stack_param.raas_argo_artifacts_s3_bucket_name,
                "ArgoWorkflowsArtifactAndLogsS3Bucket",
            )

            self.output_dict.update(
                {
                    "raas_argo_artifacts_s3_bucket_arn": (
                        self.raas_argo_artifacts_s3_bucket.bucket_arn
                    )
                }
            )
            self.output_dict.update(
                {
                    "raas_argo_artifacts_s3_bucket_name": (
                        stack_param.raas_argo_artifacts_s3_bucket_name
                    )
                }
            )

            # Create a role for Argo Workflows service account
            if stack_param.deployment.sandbox_name is None:
                self.role = self.create_role(
                    raas_argo_artifacts_s3_bucket=self.raas_argo_artifacts_s3_bucket,
                    reprocessed_output_s3_bucket_arn=stack_param.reprocessed_output_s3_bucket_arn,
                    collected_input_s3_bucket_arns=stack_param.collected_input_s3_bucket_arns,
                    collected_input_s3_access_point_arns=stack_param.collected_input_s3_access_point_arns,
                    eks_oidc_provider_arn=stack_param.eks_cluster.oidc_arn,
                    role_name=stack_param.raas_argo_service_account_role_name,
                    argo_workflows_service_account_name=stack_param.raas_argo_workflows_service_account_name,
                    argo_workflows_server_service_account_name=stack_param.raas_argo_workflows_server_service_account_name,
                    job_status_queue_arns=[
                        stack_param.job_status_queues_policy_arn,
                        stack_param.job_status_queues_sandbox_policy_arn,
                    ],
                )

                self.output_dict.update(
                    {
                        "raas_argo_workflows_service_account_role_arn": (
                            self.role.role_arn
                        ),
                    }
                )

        # Write output to SSM
        self.write_output(stack_param=stack_param)

    def create_role(
        self,
        raas_argo_artifacts_s3_bucket: s3.Bucket,
        reprocessed_output_s3_bucket_arn: str,
        collected_input_s3_bucket_arns: list[str],
        collected_input_s3_access_point_arns: list[str],
        eks_oidc_provider_arn: str,
        role_name: str,
        argo_workflows_service_account_name: str,
        argo_workflows_server_service_account_name: str,
        job_status_queue_arns: list[str],
    ) -> iam.Role:
        """
        Create a role for Argo Workflows service accounts to assume.

        Required for storing logs and artifacts in S3 buckets.
        """
        # OIDC provider for the setting the trust relationship in the IAM role to allow
        # EKS service account assume the role
        oidc_provider_id = eks_oidc_provider_arn.split("/")[-1]
        oidc_provider = Helper.get_oidc_provider(
            region=self.stack_param.deployment.account.region,
            oidc_provider_id=oidc_provider_id,
        )

        # S3 artifacts raas_argo_artifacts_s3_bucket with appropriate permissions.
        # Argo workflow and server service account should have necessary permissions to
        # access the Argo artifacts S3 bucket to upload and read the logs.
        s3_artifacts_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=["s3:ListBucket", "s3:*Object"],
                    resources=[
                        f"{raas_argo_artifacts_s3_bucket.bucket_arn}*",
                        f"{raas_argo_artifacts_s3_bucket.bucket_arn}*/*",
                    ],
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        # Publish SQS send message permissions
        # Ex:- Argo workflow service account should have permissions to send the
        # workflow status messages to the
        # raas-infra-[env]-argo-workflows-job-status.fifoqueue.
        sqs_publish_queues_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=["sqs:SendMessage"],
                    resources=job_status_queue_arns,
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        # S3 reprocessed output bucket with appropriate permissions.
        # To upload the generated reprocessed files, argo workflow service account
        # should have necessary permissions to the reprocessed S3 buckets.
        s3_reprocessed_output_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=["s3:ListBucket", "s3:*Object"],
                    resources=[
                        f"{reprocessed_output_s3_bucket_arn}*",
                        f"{reprocessed_output_s3_bucket_arn}*/*",
                    ],
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        # Collected data S3 access points permissions
        s3_input_policy_arns = [f"{x}/*" for x in collected_input_s3_bucket_arns]
        s3_input_policy_arns.extend(collected_input_s3_bucket_arns)

        s3_input_policy_arns.extend(
            [f"{x}/*" for x in collected_input_s3_access_point_arns]
        )
        s3_input_policy_arns.extend(collected_input_s3_access_point_arns)

        # The collected or raw input files which are in a different realm
        # (collected zone), argo workflow service account should have necessary
        # permissions to list the bucket and get the objects.
        s3_collected_input_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=["s3:ListBucket", "s3:GetObject"],
                    resources=s3_input_policy_arns,
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        inline_policies = {
            "raas-collected-input-s3-policy": s3_collected_input_policy,
            "raas-reprocessed-output-s3-policy": s3_reprocessed_output_policy,
            "raas-argo-workflows-artifacts-s3-policy": s3_artifacts_policy,
            "raas-argo-sqs-publish-queues-policy": sqs_publish_queues_policy,
        }

        # IAM Role construct with trust relationship and required permissions.
        role = iam.Role(
            self,
            "RaaSArgoWorkflowsServiceAccountRole",
            role_name=role_name,
            description=(
                "Role used by RaaS Argo Workflows to store artifact logs to S3 bucket."
            ),
            inline_policies=inline_policies,
            assumed_by=iam.CompositePrincipal(
                # Adding the argo workflow server account to allow users view logs from
                # server-ui.
                iam.PrincipalWithConditions(
                    iam.WebIdentityPrincipal(eks_oidc_provider_arn),
                    conditions={
                        "StringLike": CfnJson(
                            self,
                            "ServiceAccountRoleTrustPolicy-server-serviceaccount",
                            value={
                                f"{oidc_provider}:sub": f"system:serviceaccount:*:{argo_workflows_server_service_account_name}",
                                f"{oidc_provider}:aud": "sts.amazonaws.com",
                            },
                        ),
                    },
                ),
                # Adding the argo workflow service account to allow write logs after
                # the node execution is completed.
                iam.PrincipalWithConditions(
                    iam.WebIdentityPrincipal(eks_oidc_provider_arn),
                    conditions={
                        "StringLike": CfnJson(
                            self,
                            "ServiceAccountRoleTrustPolicy-workflow-serviceaccount",
                            value={
                                f"{oidc_provider}:sub": f"system:serviceaccount:*:{argo_workflows_service_account_name}",
                                f"{oidc_provider}:aud": "sts.amazonaws.com",
                            },
                        ),
                    },
                ),
            ),
        )

        cdk_nag.NagSuppressions.add_resource_suppressions(
            role,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-IAM5",
                    reason=(
                        "Wildcard permissions used to match any"
                        " namespace for Argo Workflows service"
                        " account role."
                    ),
                )
            ],
            apply_to_children=True,
        )

        return role

    def create_bucket(self, argo_artifacts_s3_bucket_name: str, id: str) -> s3.Bucket:
        """Create the S3 bucket."""
        # Name must be unique across all accounts
        bucket_name = argo_artifacts_s3_bucket_name

        bucket: s3.Bucket = s3.Bucket(
            self,
            id=id,
            bucket_name=bucket_name,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            versioned=False,
            enforce_ssl=True,
            encryption=s3.BucketEncryption.S3_MANAGED,
            removal_policy=RemovalPolicy.DESTROY,
        )

        cdk_nag.NagSuppressions.add_resource_suppressions(
            bucket,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-S1",
                    reason="Bucket access logs not required.",
                )
            ],
        )

        return bucket

    def create_etl_role(
        self,
        role_name: str,
        artifacts_bucket_arn: str,
        sqs_publish_queue_arns: list[str],
        trust: iam.PrincipalWithConditions,
        cluster_resource_db_user: str,
        additional_policies: dict,
    ) -> iam.Role:
        """Role based on the etl metadata service account and required permissions."""
        # S3 artifacts bucket with appropriate permissions.
        s3_artifacts_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=["s3:ListBucket", "s3:*Object"],
                    resources=[
                        artifacts_bucket_arn,
                        f"{artifacts_bucket_arn}/*",
                    ],
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        # RDS Postgres db access permissions.
        rds_db_connect_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=["rds-db:connect"],
                    resources=[cluster_resource_db_user],
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        # Permissions to send status messages to status queue
        sqs_publish_queues_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=["sqs:SendMessage"],
                    resources=sqs_publish_queue_arns,
                    effect=iam.Effect.ALLOW,
                )
            ]
        )

        inline_policies = {
            "postgres-db-connect-policy": rds_db_connect_policy,
            "raas-argo-workflows-artifacts-s3-policy": s3_artifacts_policy,
            "raas-argo-sqs-publish-queues-policy": sqs_publish_queues_policy,
        }

        # Adding additional policies if any set for the specific etl metadata
        # service account
        for policy_name, policy_value in additional_policies.items():
            policy = iam.PolicyDocument(
                statements=[
                    iam.PolicyStatement(
                        actions=policy_value["actions"],
                        resources=policy_value["resources"],
                        effect=iam.Effect.ALLOW,
                    )
                ]
            )
            inline_policies.update({policy_name: policy})

        # IAM Role construct with trust relationship and required permissions.
        return iam.Role(
            self,
            f"pg-{role_name}",
            role_name=role_name,
            description="Role used for authorizing with RaaS Postgres db.",
            assumed_by=trust,
            inline_policies=inline_policies,
        )

    def write_output(self, stack_param: ArgoWorkFlow) -> None:
        """Responsible for capturing the metadata in the SSM"""
        # Saving the output of the argo workflows deployment to SSM

        sqs_publish_queues = {
            f"sqs_{stack_param.job_status_queue.name}_queue_name".replace(
                "-", "_"
            ): stack_param.job_status_queue.full_name
        }
        if stack_param.job_status_dl_queue is not None:
            sqs_publish_queues.update(
                {
                    f"sqs_{stack_param.job_status_dl_queue.name}_queue_name".replace(
                        "-", "_"
                    ): stack_param.job_status_dl_queue.full_name
                }
            )
        sqs_publish_queue_urls = {}
        if self.sqs_queue is not None:
            sqs_publish_queue_urls = {
                f"sqs_{stack_param.job_status_queue.name}_queue_url".replace(
                    "-", "_"
                ): self.sqs_queue.attr_queue_url
            }
        if (
            self.dl_sqs_queue is not None
            and stack_param.job_status_dl_queue is not None
        ):
            sqs_publish_queue_urls.update(
                {
                    f"sqs_{stack_param.job_status_dl_queue.name}_queue_url".replace(
                        "-", "_"
                    ): self.dl_sqs_queue.attr_queue_url
                }
            )

        self.output_dict.update(sqs_publish_queues)
        self.output_dict.update(sqs_publish_queue_urls)
        output_value = json.dumps(self.output_dict)
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

    def create_sqs(
        self,
        queue_param: QueueContext | None,
        redrive_policy: dict | None = None,
        redrive_allow_policy: dict | None = None,
    ) -> sqs.CfnQueue | None:
        """Create sqs resources."""
        if queue_param is None:
            return None
        return sqs.CfnQueue(
            self,
            queue_param.full_name,
            queue_name=queue_param.full_name,
            fifo_queue=queue_param.is_fifo,
            content_based_deduplication=True if queue_param.is_fifo else None,
            deduplication_scope="messageGroup" if queue_param.is_fifo else None,
            fifo_throughput_limit="perMessageGroupId" if queue_param.is_fifo else None,
            message_retention_period=queue_param.message_retention_period,
            visibility_timeout=queue_param.message_visibility_timeout,
            redrive_policy=redrive_policy,
            redrive_allow_policy=redrive_allow_policy,
        )

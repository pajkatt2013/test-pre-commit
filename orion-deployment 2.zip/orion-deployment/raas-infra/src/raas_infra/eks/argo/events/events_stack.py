#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#
"""Argo Events CDK stack."""

import json
from typing import cast

import aws_cdk.aws_events as events
import aws_cdk.aws_iam as iam
import aws_cdk.aws_sqs as sqs
import aws_cdk.aws_ssm as ssm
import cdk_nag
from aws_cdk import CfnJson, Stack, Tags
from constructs import Construct, IConstruct

from raas_infra import ArgoEvents
from raas_infra.constructs.eventbridge_route_to_sqs_rule import (
    EventBridgeRouteToSqsRule,
)
from raas_infra.utils.helper import Helper


class ArgoEventsStack(Stack):
    """Creates the resources needed by ArgoEvents running in EKS."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: ArgoEvents,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys artifacts related to argo events.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs)
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        # List of SQS queues to be provisioned. Queues like job request trigger,
        # etl metadata triggers are provisioned.
        self.raas_argo_events_cfn_queues = [
            sqs.CfnQueue(self, queue_name, queue_name=queue_name)
            for queue_name in stack_param.raas_argo_events_queues.values()
        ]

        # SQS Queue policy to allow the event rules send the messages from
        # RaaS eventbus to SQS
        self.raas_argo_events_sqs_policies = [
            sqs.CfnQueuePolicy(
                self,
                f"{raas_sqs.queue_name}-sqs-policy",
                queues=[raas_sqs.queue_name],
                policy_document=iam.PolicyDocument(
                    statements=[
                        iam.PolicyStatement(
                            actions=[
                                "sqs:SendMessage",
                                "sqs:GetQueueAttributes",
                                "sqs:GetQueueUrl",
                            ],
                            resources=[raas_sqs.attr_arn],
                            effect=iam.Effect.ALLOW,
                            principals=[iam.ServicePrincipal("events.amazonaws.com")],
                        )
                    ]
                ),
            )
            for raas_sqs in self.raas_argo_events_cfn_queues
        ]

        # provisioning role for non-sandbox environments
        if stack_param.deployment.sandbox_name is None:
            # IAM role to read and delete messages from the job events sqs.
            self.create_sqs_trigger_subscriber_role(
                stack_param.raas_argo_events_queues_policy_arns,
                eks_oidc_provider_arn=stack_param.eks_cluster.oidc_arn,
                role_name=stack_param.sqs_eventsource_trigger_subscriber_role_name,
                argo_eventsource_service_account_name=stack_param.raas_argo_eventsource_service_account_name,
            )

        # Add event bridge rules
        self.add_eventbridge_rules()

        # Write output to SSM
        self.write_output(stack_param=stack_param)

    def create_sqs_trigger_subscriber_role(
        self,
        raas_argo_events_queues_policy_arns: list[str],
        eks_oidc_provider_arn: str,
        role_name: str,
        argo_eventsource_service_account_name: str,
    ) -> iam.Role:
        """Create role for Argo SQS Event Source for messages in job trigger queue."""
        oidc_provider_id = eks_oidc_provider_arn.split("/")[-1]
        oidc_provider = Helper.get_oidc_provider(
            region=self.stack_param.deployment.account.region,
            oidc_provider_id=oidc_provider_id,
        )

        # IAM Role construct with trust relationship and required permissions.
        role = iam.Role(
            self,
            "RaaSArgoJobTriggerSQSSubscriber",
            role_name=role_name,
            description=(
                "Role used by RaaS Argo Workflows SQS Event Source to"
                " subscribe to messages from  Trigger Queue."
            ),
            # Setting the argo event source service account to allow read and delete
            # the job events from sqs.
            assumed_by=iam.PrincipalWithConditions(
                iam.WebIdentityPrincipal(eks_oidc_provider_arn),
                conditions={
                    "StringLike": CfnJson(
                        self,
                        "ServiceAccountRoleTrustPolicy-eventsource-serviceaccount",
                        value={
                            f"{oidc_provider}:sub": f"system:serviceaccount:*:{argo_eventsource_service_account_name}",
                            f"{oidc_provider}:aud": "sts.amazonaws.com",
                        },
                    ),
                },
            ),
        )

        role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    "sqs:GetQueueUrl",
                    "sqs:ListDeadLetterSourceQueues",
                    "sqs:ListMessageMoveTasks",
                    "sqs:ReceiveMessage",
                    "sqs:GetQueueAttributes",
                    "sqs:ListQueueTags",
                    "sqs:DeleteMessage",
                ],
                resources=raas_argo_events_queues_policy_arns,
                effect=iam.Effect.ALLOW,
            )
        )

        cdk_nag.NagSuppressions.add_resource_suppressions(
            role,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-IAM5-EventSourceSA",
                    reason=(
                        "Wildcard permissions used to match any"
                        " namespace for Argo EventSource service"
                        " account role."
                    ),
                )
            ],
            apply_to_children=True,
        )

        return role

    def add_eventbridge_rules(self) -> None:
        """Add event bridge rules for etl metadata event sources to respective sqs."""
        if self.stack_param.deployment.sandbox_name is None:
            # routing oao ingest session events to session metadata sqs
            self.session_metadata_eventbridge_rule = EventBridgeRouteToSqsRule(
                scope=self,
                id_=f"{self.id}-session-metadata",
                rule_name=f"{self.id}-session-metadata",
                rule_description=(
                    "This rule is responsible to route oao ingest"
                    " session events to the raas session etl metadata"
                    " sqs queue."
                ),
                event_bus_name=self.stack_param.event_bus.oao_local,
                event_pattern=events.EventPattern(
                    detail_type=["ingest-session-completed"]
                ),
                target_input_object={
                    "session_md_params": {
                        "session_id": events.EventField.from_path(
                            "$.detail.additional-details.session-id"
                        ),
                        # TODO(unknown): should below be event.id or
                        #                correlation-id -> events.EventField.from_path('$.detail.correlation-id')
                        "event_id": events.EventField.from_path("$.id"),
                    }
                },
                target_sqs=self.get_sqs_queue(f"{self.id}-session-metadata-trigger"),
                attach_log_group_as_target=self.stack_param.deployment.sandbox_name
                is None,
            )

            # routing oao ingest session events to file metadata sqs
            self._metadata_eventbridge_rule = EventBridgeRouteToSqsRule(
                scope=self,
                id_=f"{self.id}-file-metadata",
                rule_name=f"{self.id}-file-metadata",
                rule_description=(
                    "This rule is responsible to route oao ingest"
                    " session events to the raas file etl metadata"
                    " sqs queue."
                ),
                event_bus_name=self.stack_param.event_bus.oao_local,
                event_pattern=events.EventPattern(
                    detail_type=["ingest-session-completed"]
                ),
                target_input_object={
                    "file_md_params": {
                        "session_id": events.EventField.from_path(
                            "$.detail.additional-details.session-id"
                        ),
                        # TODO(unknown): should below be event.id or
                        #                correlation-id -> events.EventField.from_path('$.detail.correlation-id')
                        "event_id": events.EventField.from_path("$.id"),
                    }
                },
                target_sqs=self.get_sqs_queue(f"{self.id}-file-metadata-trigger"),
                attach_log_group_as_target=self.stack_param.deployment.sandbox_name
                is None,
            )

    def get_sqs_queue(self, sqs_name: str) -> sqs.IQueue:
        """Get SQS queue by name."""
        cfn_sqs_queue = next(
            filter(
                lambda y: y.queue_name == sqs_name,
                self.raas_argo_events_cfn_queues,
            )
        )
        return sqs.Queue.from_queue_arn(
            self, f"{sqs_name}-queue", cfn_sqs_queue.attr_arn
        )

    def write_output(self, stack_param: ArgoEvents) -> None:
        """Responsible for capturing the metadata in the SSM"""
        # Saving the output of the argo events deployment to SSM
        output_dict = dict(
            map(
                lambda x: (
                    f"sqs_{x}_queue_url".replace("-", "_"),
                    next(
                        filter(
                            lambda y: y.queue_name
                            == stack_param.raas_argo_events_queues[x],
                            self.raas_argo_events_cfn_queues,
                        )
                    ).attr_queue_url,
                ),
                stack_param.raas_argo_events_queues.keys(),
            )
        )

        queue_arns = dict(
            map(
                lambda x: (
                    f"sqs_{x}_queue_arn".replace("-", "_"),
                    next(
                        filter(
                            lambda y: y.queue_name
                            == stack_param.raas_argo_events_queues[x],
                            self.raas_argo_events_cfn_queues,
                        )
                    ).attr_arn,
                ),
                stack_param.raas_argo_events_queues.keys(),
            )
        )

        output_dict.update(queue_arns)

        sqs_queues = {
            f"sqs_{x}_queue_name".replace(
                "-", "_"
            ): stack_param.raas_argo_events_queues[x]
            for x in stack_param.raas_argo_events_queues
        }
        output_dict["raas_argo_eventsource_service_account_name"] = (
            stack_param.raas_argo_eventsource_service_account_name
        )

        output_dict["raas_argo_eventsource_subscriber_role_arn"] = (
            stack_param.sqs_eventsource_trigger_subscriber_role_arn
        )

        output_dict.update(sqs_queues)
        output_value = json.dumps(output_dict)
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

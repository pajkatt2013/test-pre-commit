# RaaS Argo Events


This module is responsible for deploying Argo Events Helm Chart in EKS along with necessary EKS resources for eventing.


Please follow [argo-events-helm-chart](https://github.com/argoproj/argo-helm/tree/main/charts/argo-events) for more details about the default setup Argo provides.

RaaS-Argo-Events comes package with below resources on top of the default Argo-Events public helm chart.

- Event Bus for Argo Eventing
- Event Source Service Account with necessary permissions
- Sensor Role Definition & Bindings to allow trigger Workflows
- Sensor Service Account used by RaaS Sensors
- RaaS Job Request SQS Event Source
- IAM role for subscribing to RaaS Job Request SQS
- Helm Chart to deploy RaaS-Argo-Events

Each environment has the designated **values.[env].yaml** which can be used to configure environment specific settings if any.
Ex:- If Dev environment requires any specific settings, can be managed in [values.dev.yaml](helm/values.dev.yaml)


Note :- Event Sensors are managed in individual application repos
- [raas-pipeline-sensor](https://github.com/gcc-collab-006/raas-pipeline-deployment/blob/main/artifacts/helm/argo_events/raas_pipeline_events/templates/raas-pipeline-sensor.yaml)
- [etl-metadata-sensors](https://github.com/qcc-collab-006/reprocessing-etl-pipelines/tree/main/artifacts/helm/argo_events/metadata_events/templates)

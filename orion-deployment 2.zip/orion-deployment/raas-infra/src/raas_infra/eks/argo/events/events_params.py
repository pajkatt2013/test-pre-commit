#
# Software created within Project Orion.
# Copyright (C) 2023-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Argo events Parameters for CDK stack deployment.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from importlib.resources import files
from pathlib import Path

import yaml

from raas_infra.context import (
    VPC,
    ContextModel,
    Deployment,
    EKSArgoEventsContext,
    EKSCluster,
    EventBus,
    HelmChartContext,
)
from raas_infra.eks.helmcharts.helmchart_param import HelmChart
from raas_infra.utils.helper import Helper


class ArgoEvents(ContextModel):
    """Managing the necessary params for Argo Events CDK deployment"""

    id: str
    eks_cluster: EKSCluster
    vpc: VPC
    output_metadata_path: str
    deployment: Deployment
    raas_argo_events_queues: dict
    raas_argo_eventsource_service_account_name: str
    sqs_eventsource_trigger_subscriber_role_name: str
    helm_chart: HelmChart
    event_bus: EventBus
    raas_argo_events_queues_policy_arns: list[str]
    sqs_eventsource_trigger_subscriber_role_arn: str

    @classmethod
    def from_context(cls, ctx: EKSArgoEventsContext) -> "ArgoEvents":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])

        id_ = ctx.get_id()
        props = {
            "eks_cluster": eks_cluster,
            "vpc": vpc,
            "deployment": ctx.deployment,
            "id": id_,
            "output_metadata_path": ctx.metadata_output_ssm_path,
            "event_bus": EventBus.from_context(ctx.ref["eventBus"]),
        }

        # Fetching EKS cluster and Argo prerequisites deployment related metadata
        prerequisites = json.loads(ctx.ref["prerequisites"])

        # Service account for argo events source - this service account should have
        # permissions to listen from event sources such as sqs
        raas_argo_eventsource_service_account_name = "raas-argo-eventsource-sa"
        props["raas_argo_eventsource_service_account_name"] = (
            raas_argo_eventsource_service_account_name
        )

        # IAM role name arn associated with the event source service account to read and
        # delete messages from sqs
        sqs_eventsource_trigger_subscriber_role_name = f"{id_}-sqstrg-sub-role"
        props["sqs_eventsource_trigger_subscriber_role_name"] = (
            sqs_eventsource_trigger_subscriber_role_name
        )
        sqs_eventsource_trigger_subscriber_role_arn = Helper.get_iam_role_arn(
            account=ctx.deployment.account,
            role_name=sqs_eventsource_trigger_subscriber_role_name,
        )

        raas_argos_events_namespace_name = prerequisites[
            "raas_argos_events_namespace_name"
        ]

        # Loading Helm chart based on the input environment

        helm_values_file = str(
            files("raas_infra.eks.argo.events.helm").joinpath("values.yaml")
        )

        with Path(helm_values_file).open() as fp:
            helmchart_values_dict = yaml.safe_load(fp)

        # Merging the configured argo events values with the current loaded helm values
        Helper.dictionary_deep_merge(helmchart_values_dict, ctx.values_dict)

        helmchart_folderpath = Path(helm_values_file).parent

        # In case of sandbox based deployment, deploying the sandbox helm chart.
        # sandbox helm chart deploys only the workflow service account, role and role
        if ctx.deployment.sandbox_name is not None:
            helm_chart_file = str(
                files("raas_infra.eks.argo.events.sandbox_helm").joinpath("Chart.yaml")
            )
            helmchart_folderpath = Path(helm_chart_file).parent

        # Service account for argo events sensor
        raas_argo_sensor_service_account_name = "raas-argo-events-sensor-sa"
        helmchart_values_dict["sensor"] = {
            "serviceAccount": {"name": raas_argo_sensor_service_account_name}
        }

        # Setting the event source service account with annotation referring to the
        # IAM role
        event_source = helmchart_values_dict["eventsource"]
        event_source["serviceAccount"] = {
            "name": raas_argo_eventsource_service_account_name,
            "annotations": {
                "eks.amazonaws.com/role-arn": (
                    sqs_eventsource_trigger_subscriber_role_arn
                )
            },
        }
        props["sqs_eventsource_trigger_subscriber_role_arn"] = (
            sqs_eventsource_trigger_subscriber_role_arn
        )

        # Setting the argo helm chart registries for the controller
        helmchart_values_dict["argo-events"]["global"]["image"]["repository"] = (
            ctx.argo_docker_repository
        )

        # Setting the argo helm chart versions for the controller
        helmchart_values_dict["argo-events"]["global"]["image"]["tag"] = (
            ctx.argo_docker_tag
        )

        # Updating the sqs names based on the derived "fullname'"
        event_source["sqs"] = list(
            filter(lambda x: x["enabled"] is True, event_source["sqs"])
        )

        # In case of sandbox deployment, consider only specific event sources which
        # allow sandbox testing.
        if ctx.deployment.sandbox_name is not None:
            event_source["sqs"] = list(
                filter(
                    lambda x: x["allowSandbox"] is True,
                    event_source["sqs"],
                )
            )

        # Updating the sqs region from context
        region = ctx.deployment.account.region

        for sqs in event_source["sqs"]:
            sqs["queue_suffix"] = sqs["queue"]
            sqs["queue"] = f"{id_}-{sqs['queue']}"
            sqs["region"] = region

        raas_argo_events_queues = {x["name"]: x["queue"] for x in event_source["sqs"]}
        # Setting the sqs queues to be provisioned
        props["raas_argo_events_queues"] = raas_argo_events_queues

        # for sandbox deployments setting the eventsource name prefixed with
        # sandbox name
        if ctx.deployment.sandbox_name is not None:
            for sqs in event_source["sqs"]:
                sqs["name"] = f"{sqs['name']}-{ctx.deployment.sandbox_name}"

        # In case of sandbox based deployment, setting value to the "sandbox" property
        if ctx.deployment.sandbox_name is not None:
            helmchart_values_dict["sandbox"] = {
                "eventsource": helmchart_values_dict["eventsource"]
            }

        helm_chart = HelmChartContext.from_chart_folder_context(
            create_namespace=True,
            deploy_in_namespace=raas_argos_events_namespace_name,
            release_name=(
                raas_argos_events_namespace_name
                if ctx.deployment.sandbox_name is None
                else f"{raas_argos_events_namespace_name}-{ctx.deployment.sandbox_name}"
            ),
            values_dict=helmchart_values_dict,
            chart_folder_path=str(helmchart_folderpath),
            wait_till_healthy=ctx.wait_till_healthy,
            delegate_deployment_to_helm=ctx.delegate_deployment_to_helm,
            deployment=ctx.deployment,
        )

        helm_chart.ref = ctx.ref
        helm_chart.name = "argo-events"
        helm_chart.deployment = ctx.deployment
        helmchart = HelmChart.from_context(
            helm_chart,
            apply_sandbox_suffix_for_release_and_namespace_if_applicable=False,
        )
        props["helm_chart"] = helmchart

        # resource arns for the argo eventsource sqs to create policy that works for
        # both sandbox and normal environments
        raas_argo_events_queues_policy_arns = []

        account = ctx.deployment.account

        # add policy arn to cover all sandbox environments related sqs queues
        raas_argo_events_queues_policy_arns.extend(
            [
                f"arn:{account.partition}:sqs:{account.region}:{account.id}:"
                + ctx.get_sandbox_id("*")
                + "-"
                + eventsource["queue_suffix"]
                for eventsource in event_source["sqs"]
            ]
        )

        raas_argo_events_queues_policy_arns.extend(
            [
                f"arn:{account.partition}:sqs:{account.region}:{account.id}:{queue_name}"
                for queue_name in raas_argo_events_queues.values()
            ]
        )
        props["raas_argo_events_queues_policy_arns"] = (
            raas_argo_events_queues_policy_arns
        )

        return cls.model_validate(props)

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""Prometheus parameters for CDK stack deployment."""

from importlib.resources import files
from pathlib import Path

import yaml

from raas_infra.context import (
    VPC,
    CentralPrometheus,
    ContextModel,
    Deployment,
    EKSCluster,
    HelmChartContext,
    KubernetesServiceAccount,
    PrometheusContext,
)


class Prometheus(ContextModel):
    """Managing the necessary params for Prometheus Infra CDK deployment"""

    eks_cluster: EKSCluster
    deployment: Deployment
    output_metadata_path: str
    helm_chart: HelmChartContext
    kubernetes_service_account: KubernetesServiceAccount
    vpc: VPC

    @classmethod
    def from_context(cls, ctx: PrometheusContext) -> "Prometheus":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])
        central_prometheus = CentralPrometheus.from_context(
            ctx.ref.get("central_prometheus")
        )

        id = ctx.get_id()
        props: dict = {}
        props["id"] = id
        props["deployment"] = ctx.deployment
        props["eks_cluster"] = eks_cluster
        props["vpc"] = vpc
        props["output_metadata_path"] = ctx.metadata_output_ssm_path
        props["kubernetes_service_account"] = ctx.kubernetes_service_account
        props["central_prometheus"] = central_prometheus
        props["image_registry"] = ctx.image_registry

        # Loading Helm chart based on the input environment
        helm_values_file = str(
            files("raas_infra.eks.prometheus.helm").joinpath("values.yaml")
        )
        helmchart_folderpath = Path(helm_values_file).parent
        with Path(helm_values_file).open() as fp:
            helmchart_values_dict = yaml.safe_load(fp)

        helm_chart = HelmChartContext.from_chart_folder_context(
            create_namespace=True,
            deploy_in_namespace=ctx.kubernetes_service_account.namespace,
            release_name=ctx.kubernetes_service_account.namespace,
            values_dict=helmchart_values_dict,
            chart_folder_path=str(helmchart_folderpath),
            wait_till_healthy=ctx.wait_till_healthy,
            delegate_deployment_to_helm=ctx.delegate_deployment_to_helm,
            deployment=ctx.deployment,
        )

        props["helm_chart"] = helm_chart

        return cls.model_validate(props)

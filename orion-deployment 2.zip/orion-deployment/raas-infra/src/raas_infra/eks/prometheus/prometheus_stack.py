#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Prometheus CDK stack.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from typing import cast

import aws_cdk.aws_iam as iam
import aws_cdk.aws_logs as logs
import aws_cdk.aws_ssm as ssm
from aws_cdk import Stack, Tags
from aws_cdk import aws_aps as aps
from constructs import Construct, IConstruct

from raas_infra.constructs.helmchart import RaaSHelmChart
from raas_infra.constructs.iamrole_kubernetes_serviceaccount import (
    IamRoleForKubernetesServiceAccount,
)
from raas_infra.eks.prometheus.prometheus_params import Prometheus


class PrometheusStack(Stack):
    """Creates the resources needed by Prometheus running in EKS."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: Prometheus,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys artifacts related to prometheus.",
            **kwargs,
        )

        self.id = id

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs).
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        self.service_account_role = IamRoleForKubernetesServiceAccount(
            scope=self,
            id_="ServiceAccountRole",
            role_name=stack_param.kubernetes_service_account.iam_role_name,
            role_description=stack_param.kubernetes_service_account.iam_role_description,
            kubernetes_service_account_name=stack_param.kubernetes_service_account.name,
            kubernetes_service_account_namespace=stack_param.kubernetes_service_account.namespace,
            eks_cluster_metadata=stack_param.eks_cluster,
        )

        if stack_param.central_prometheus is None:
            # Create prometheus workspace in AWS managed Prometheus
            self.log_group = logs.LogGroup(
                self, "log-group", log_group_name=f"{id}-logs"
            )

            # provision aws managed prometheus workspace
            self.aps_workspace = aps.CfnWorkspace(
                self,
                "PrometheusWorkspace",
                alias=id,
                logging_configuration=aps.CfnWorkspace.LoggingConfigurationProperty(
                    log_group_arn=self.log_group.log_group_arn
                ),
            )

            aws_managed_prometheus_access_policy = iam.PolicyDocument(
                statements=[
                    iam.PolicyStatement(
                        actions=[
                            "aps:RemoteWrite",
                            "aps:GetSeries",
                            "aps:GetLabels",
                            "aps:GetMetricMetadata",
                        ],
                        resources=[self.aps_workspace.attr_arn],
                        effect=iam.Effect.ALLOW,
                    )
                ]
            )

            # add policy to access the raas prometheus service
            self.service_account_role.role.attach_inline_policy(
                iam.Policy(
                    scope=self,
                    id="aws_managed_prometheus_access_policy",
                    document=aws_managed_prometheus_access_policy,
                    policy_name="aws_managed_prometheus_access_policy",
                )
            )

            # setting the aws prometheus remote write url
            stack_param.helm_chart.values_dict["kube-prometheus-stack"]["prometheus"][
                "prometheusSpec"
            ]["remoteWrite"][0][
                "url"
            ] = f"{self.aps_workspace.attr_prometheus_endpoint}api/v1/remote_write"

            # setting the provisioned role arn to the prometheus service account
            stack_param.helm_chart.values_dict["kube-prometheus-stack"]["prometheus"][
                "serviceAccount"
            ] = {
                "name": stack_param.kubernetes_service_account.name,
                "annotations": {
                    "eks.amazonaws.com/role-arn": (
                        self.service_account_role.role.role_arn
                    )
                },
            }

            # Outputs
            output_dict = {
                "prometheus_workspace_arn": self.aps_workspace.attr_arn,
                "prometheus_workspace_url": self.aps_workspace.attr_prometheus_endpoint,
            }
        else:
            # setting central prometheus as the remote write endpoint
            stack_param.helm_chart.values_dict["kube-prometheus-stack"]["prometheus"][
                "prometheusSpec"
            ]["remoteWrite"][0] = {
                "url": f"http://{stack_param.central_prometheus.vpc_endpoint_region_dns_name}:9090/api/v1/write"
            }

            output_dict = {
                "prometheus_workspace_url": f"http://{stack_param.central_prometheus.vpc_endpoint_region_dns_name}:9090/api/v1/write",
                "use_central_prometheus": "true",
            }

        if stack_param.image_registry is not None:
            stack_param.helm_chart.values_dict["kube-prometheus-stack"]["global"][
                "imageRegistry"
            ] = stack_param.image_registry

        # Create helm chart for deploying the argo workflow artifacts.
        self.helm_chart = RaaSHelmChart(
            scope=self,
            id=f"RaaSHelm-{stack_param.helm_chart.release_name}",
            eks_cluster=stack_param.eks_cluster,
            vpc=stack_param.vpc,
            helm_chart=stack_param.helm_chart,
            deployment=stack_param.deployment,
        )

        output_value = json.dumps(output_dict)
        ssm.StringParameter(
            scope=self,
            parameter_name=stack_param.output_metadata_path,
            id=stack_param.output_metadata_path,
            string_value=output_value,
        )

# Prometheus Deployment


## Introduction

This module is responsible for deploying Prometheus stack into RaaS EKS cluster
Prometheus Stack is used to collect raas metrics and display dashboard using grafana


##  What is does?
* deploy the prometheus stack helm chart

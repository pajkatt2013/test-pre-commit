#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Service Helm Chart CDK stack.

(C) 2024 Qualcomm Technologies, Inc.  All rights reserved.
"""

import json
from typing import cast

from aws_cdk import CfnOutput, Stack, Tags
from constructs import Construct, IConstruct

from raas_infra.constructs.helmchart import RaaSHelmChart
from raas_infra.eks.helmcharts.helmchart_param import HelmChart


class HelmChartStack(Stack):
    """Creates the resources needed by Helm Chart running in EKS."""

    def __init__(
        self,
        scope: Construct,
        id: str,
        stack_param: HelmChart,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys helm chart.",
            **kwargs,
        )

        self.stack_param = stack_param

        # Create tags (automatically applied to child constructs)
        Tags.of(scope=cast(IConstruct, self)).add(
            key="customer_function", value="common"
        )
        Tags.of(scope=cast(IConstruct, self)).add(key="Deployment", value=id)

        # Create helm chart for deploying the argo workflow artifacts.
        self.helm_chart = RaaSHelmChart(
            scope=self,
            id="HelmCharts",
            eks_cluster=stack_param.eks_cluster,
            vpc=stack_param.vpc,
            helm_chart=stack_param.helm_chart,
            deployment=stack_param.deployment,
        )

        # Outputs
        self.write_output(self.helm_chart.values_dict, f"{id}-values")
        print(json.dumps(self.helm_chart.values_dict))

    def write_output(self, values: dict | str, path: str) -> None:
        """Write CloudFormation stack output."""
        value_json = json.dumps(values)
        path = path.replace("_", "-")

        max_values_cnt = 1000
        if len(value_json) > max_values_cnt:
            if isinstance(values, dict):
                for key in values:
                    self.write_output(values[key], f"{path}:{key}")
            else:
                # There is size limitation when writing to cfnoutput. Max length : 1024
                # If the value string length is more than 1000 characters then writing
                # first 1000 characters substring of the original string
                CfnOutput(
                    self,
                    id=f"{path}-output-values",
                    value=value_json[1:1000],
                    export_name=path,
                    description=(
                        "Trimming the value since the original"
                        f" length : {len(value_json)} is exceeding"
                        " the maximum length allowed to write. Max"
                        " length 1024."
                    ),
                )
        else:
            CfnOutput(
                self,
                id=f"{path}-output-values",
                value=value_json,
                export_name=path,
            )

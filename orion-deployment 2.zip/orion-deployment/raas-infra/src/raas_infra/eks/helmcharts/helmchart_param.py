#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Helm Chart Parameters for CDK stack deployment.

(C) 2023 Qualcomm Technologies, Inc.  All rights reserved.
"""

from raas_infra.context import (
    VPC,
    ContextModel,
    EKSCluster,
    HelmChartContext,
)


class HelmChart(ContextModel):
    """Managing the necessary params for Helmchart CDK deployment"""

    name: str
    eks_cluster: EKSCluster
    vpc: VPC
    helm_chart: HelmChartContext
    deploy_after: list[str] | None = None

    @classmethod
    def from_context(
        cls,
        ctx: HelmChartContext,
        *,
        apply_sandbox_suffix_for_release_and_namespace_if_applicable: bool = True,
    ) -> "HelmChart":
        """Read values from the AWS CDK context."""
        eks_cluster = EKSCluster.from_context(ctx.ref["eksCluster"])
        vpc = VPC.from_context(ctx.ref["vpc"])

        id_ = ctx.get_submodule_id(
            module_name=ctx.deployment.module_name,
            sub_module_name=ctx.name,
        )

        # setting release and deployment namespace in case of sandbox deployments
        if apply_sandbox_suffix_for_release_and_namespace_if_applicable is True:
            ctx.release_name = (
                ctx.release_name
                if ctx.deployment.sandbox_name is None
                else f"{ctx.release_name}-{ctx.deployment.sandbox_name}"
            )
            if ctx.donot_alter_namespace is False:
                ctx.deploy_in_namespace = (
                    ctx.deploy_in_namespace
                    if ctx.deployment.sandbox_name is None
                    else f"{ctx.deploy_in_namespace}-{ctx.deployment.sandbox_name}"
                )

        props = {
            "id": id_,
            "name": ctx.name,
            "deployment": ctx.deployment,
            "eks_cluster": eks_cluster,
            "vpc": vpc,
            "helm_chart": ctx,
            "deploy_after": ctx.deploy_after,
        }
        return cls.model_validate(props)

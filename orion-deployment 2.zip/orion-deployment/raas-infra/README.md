# RaaS Infrastrucure


This project is responsible for managing the artifacts required for deploying the RaaS Core Infrastructre Artifacts on top of the RaaS Seedfarmer based Realm Module.

Below are the Artifacts deployed in the Sequence.

### Modules

| Name                                                    | Description                                                                                                                                                                           |
|---------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| [Prerequisites](src/raas_infra/eks/argo/Prerequisites/) | This module deploys the pre-requisites for the Argo Workflow and Events assets                                                                                                        |
| [Workflows](src/raas_infra/eks/argo/workflows/)         | This module deploys the necessary assets for RaaS to run the RPU and ETLMetadata Workflows                                                                                            |
| [Events](src/raas_infra/eks/argo/events/)               | This module deploys the necessary assets for RaaS to listen to the input events and trigger the RPU and ETLMetadata Workflows                                                         |
| [EFS Mount](src/raas_infra/eks/argo/efsmount/)          | This module deploys the necessary assets for RaaS to mount the EFS (Elastic File System) to the PODs in the workflows to allow exchange the intermittent files for further processing |
| [ETLMetadata](src/raas_infra/etl_metadata/)             | This module deploys the ETLMetadata related assets such as RDS Postgres Serverless cluster with necessary permissions for the ETLMetadata Service Accounts to access the Tables       |
| [Argo workflow archive](src/raas_infra/argo_archive_db_setup/)             | This module deploys the argo workflow archive related assets such as RDS Postgres Serverless cluster
| [Services](src/raas_infra/services/)                    | This module deploys the necessary IAM roles with required permissions for the microservices                                                                                           |
| [Fluent Bit](src/raas_infra/eks/fluentbit/)             | This module deploys the necessary assets for RaaS to stream logs from EKS containers to CloudWatch                                                                                    |
| [ADOT Collector](src/raas_infra/eks/adot_collector/)    | This module deploys the necessary assets the ADOT collector for RaaS to collect the metrics (include raas service level metrics) into CloudWatch                                      |
| [Karpenter](src/raas_infra/eks/karpenter/)              | This module deploys Karpenter into RaaS EKS cluster, it is used to autoscale cluster nodes.   |


### Deployment Configuration

RaaS Infrastrucutre modules are deployed through CICD. The configuration to deploy are managed in [Orion-Deployment](https://github.com/qcc-collab-006/orion-deployment) Repo. Each Environment manages a separate cdk context json file.

Ex:- To access RaaS Infra Dev Configuration, Click [Here](https://github.com/qcc-collab-006/orion-deployment/blob/main/orion/raas-infra/cdk.context.dev.json)

# Release Process

## Component Release
![Overview](images/application_release.png)

Each component can be written in any language. Each component needs to adhere to the following guidelines:
1. Each component needs to have a CI based on github actions in place.
2. Each component needs to have a `Dockerfile` that can be used to build a docker image.
3. Each component needs to have a `helm` chart that can be used to deploy the component to a Kubernetes cluster.

Examples of each of these can be found in the following repos:
* https://github.com/qcc-collab-006/raas-pipeline-deployment
* https://github.com/qcc-collab-006/reprocessing-etl-pipelines

## Sandbox Setup
Below components are supported for sandbox setup in dev environment only.

1. Argo Prerequisites
2. Argo Workflows
3. Argo Events
4. Postgres
5. Services
6. Helm Charts

Trigger [workflow](https://github.com/qcc-collab-006/orion-deployment/actions/workflows/sandbox-raas-infrastructure.yaml), select environment and provide sandbox name.

Note : Sandbox name is used as suffix for aws resource names, stack names, EKS resource names etc. Ensure the sandbox name length is less than 5 characters to avoid failures due to length constraints during deployment.

### Argo Prerequisites

Creates sandbox namespaces (raas-pipeline) suffixed with the sandbox name.

### Argo Workflows

Creates workflow status sqs to receive argo workflow and task status messages and process the messages in job management service.
The sqs name is suffixed with the sandbox name.

### Argo Events

Creates sqs to queue job request, etl metadata events. Creates argo event source listening to the sqs and invoke the workflows in the sandbox namespaces.
Sqs and event source names are suffixed with the sandbox names.

### Postgres

Creates sandbox suffixed schemas with the necessary permissions for the postgres db users.

### Services

Creates aws iam roles with name suffixed by sandbox name and necessary permissions.

### Helm Charts

Installs helm charts such as services, metadata pipeline, raas pipelines with name suffixed by the sandbox name.

Also updates the helm chart values for ingress, database schema names, event source names, sensor names, trigger names etc.. suffixed by sandbox name.
[Here](https://github.com/qcc-collab-006/raas-infra/blob/ba012f02affcec5cec0622eaa758d83e135506cc/src/raas_infra/constructs/helmchart.py#L42C1-L58C92) are the list of helm value properties which are suffixed with the sandbox name.

Ex:- If sandbox name is **sb2** deployed in dev, the job management service url would be https://raas-job-management-sb2.100100019.dev.aws.orionadp.com/v1.
Note: Post deployment it takes few minutes for the service url to be accessible, since the dns takes time to resolve.

The Argo server url is same as dev, however the namespaces for raas pipeline is raas-pipeline-sb2 respectively.

The postgres schemas for JMS and RMS are raas_sb2 and raas_rpu_metadata_sb2 respectively.

## Platform Release Strategy
Each component has its own release strategy. The platform release strategy is as follows:
1. Each component has its github action release
2. Each component has its own folder under the orion folder:

```bash
├── orion
│   ├── raas-infra
│   │   ├── cdk.context.dev.json
│   │   ├── cdk.context.vpctest-int.json
│   │   ├── eu-central-1.env
│   │   └── version.txt
│   ├── raas-pipline-events
│   │   ├── Chart.yaml
│   │   ├── values.dev.yaml
│   │   └── values.yaml
│   └── raas-pipline-workflows
│       ├── Chart.yaml
│       ├── values.dev.yaml
│       └── values.yaml
```

An .env file can be in any level, and any values in the file will override the values in .env file on the higher level.


## How to add a new component to the platform
Each component should have its own github action deployment file.
The current deployments are:
1. raas-infrastructure
1. raas-pipline

Each component needs to support [activating](https://docs.github.com/en/actions/using-workflows/events-that-trigger-workflows) from another github action (full-deploy)
Each component needs to have the following input parameters:
1. env (dev, int, prod)
1. aws_region (eu-central-1)


## Branching strategy

The following links describe the problems with branch strategy per environment and suggest a different approach:

https://codefresh.io/blog/stop-using-branches-deploying-different-gitops-environments/
https://codefresh.io/blog/how-to-model-your-gitops-environments-and-promote-releases-between-them/

So our branching strategy is as follows:
1. Main branch will have all releases in it.
2. Each environment will have its own env files (e.g., cdk.context.dev.json, values.yaml, values.dev.yaml...)
2. Each region will have its own env files (e.g., eu-central-1.env, eu-west-1.env, ...)


### Release Example
#### Update a bn Converter rpu
1. Create a new branch from main
1. Open orion/raas-pipline-workflows/values.dev.yaml
1. Update bnConverterContainer
   ```
   bnConverterContainer:
     version: 2023.11.6
   ```
1. Commit and push the changes to the new branch
1. Deploy version by running github action workflow:
![Deploy](images/run_github_action.png)
1. Test environment -> deploy to user namespace (on deploy there is an option to run integration tests)
1. Merge the changes to main

1. Deploy to int:
   1. Update prod values to mirror changes to dev
   1. Deploy full flow to int (integration tests will be run)
      ![Deploy](images/full_run_github_action.png)


1. Deploy to prod:
   1. Update prod values to mirror changes to dev
   1. Open PR
   1. Once approved, merge to main && Deploy full flow to prod
   1. Create Tag on main branch

      Tag format:
      ```yyyy.mm.[incremental number]```

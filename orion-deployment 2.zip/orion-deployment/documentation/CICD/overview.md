# CI/CD Overview

![Overview](images/application_layers.png)

# Networking

![Networking](diagrams/networking.drawio.png)

- Transit Gateway in Network Hub connects all private VPCs for OnPrem routing
- OnPrem Routed VPC subnets can be reached from OnPrem networks (BMW, QC)
- no VPC to VPC connectivity
- Network Hub controls connection to OnPrem infrastructure via Transit Gateway and Direct Connect
- A Network Hub Lambda is triggered on OnPrem routed VPC creation to auto-configure the
  Transit Gateway Routing table
- CICD VPC commonly does not host a lot of resources, therefore no NAT Gateway is required
- DEV/INT/PROD commonly need more IP addresses, therefore a NAT Gateway is created

# AWS Core

## Overview

The is layer installs all AWS account components and is responsible for the following:

- ECR
- Roles
- Policies
- ...

Installation code can be found at: https://eu-central-1.console.aws.amazon.com/codesuite/codecommit/repositories/raas/browse?region=eu-central-1

## Responsibility

Capgeimi are responsible for the upkeep of this layer.

## Technologies

Aws created this layer, so the technologies are all AWS. The base is on [CDK](https://aws.amazon.com/cdk/) and uses [Seedfarmer](https://github.com/awslabs/seed-farmer) as the orchestration

# Application Blueprint

## Overview

This layer is more oriented towards The application-specific components. These components include:

- S3
- EKS
- Namespace

## Responsibility

Capgeimi are responsible for the upkeep of this layer.

## Technologies

Since this layer is still part of the AWS infrastructure it will be using the seedfarmer orchestration, like in the AWS Core above.

# RAAS Infrastructure

## Overview

This project manages the artifacts required for deploying the RaaS Core Infrastructure Artifacts on top of the RaaS Seedfarmer-based Realm Module.

Below are the Artifacts deployed in the Sequence.

### Modules

| Name | Description |
| --- | --- |
| [Prerequisites](modules/eks/argo/prerequisites/) | This module deploys the pre-requisites for the Argo Workflow and Events assets |
| [Workflows](modules/eks/argo/workflows/) | This module deploys the necessary assets for RaaS to run the RPU and ETL Metadata Workflows |
| [Events](modules/eks/argo/events/) | This module deploys the necessary assets for RaaS to listen to the input events and trigger the RPU and ETL Metadata Workflows |
| [EFS Mount](modules/eks/efsmount/) | This module deploys the necessary assets for RaaS to mount the EFS (Elastic File System) to the PODs in the workflows to allow exchange the intermittent files for further processing |
| [Postgres](modules/rds/postgres/) | This module deploys the RDS Postgres Serverless cluster with necessary permissions for the ETL Metadata Service Accounts to access the Tables |

[raas-infra Documentation](https://github.com/qcc-collab-006/raas-infra/tree/featre-raas-infra#readme)

## Responsibility

The current owner of this layer is Orion Infrastructure Team.

## Technologies

Since this layer is still part of the AWS infrastructure it will be using the seedfarmer orchestration, like in the AWS Core above.

# Application Artifacts

## Overview

![Application Flow](images/cd_cd_flow.png)

Each Application has is own repo.

List of applications:

| Name | Description | Git |
| --- | --- | --- |
| ELT Pipeline | Moves all metadata information from processes to the database | https://github.com/qcc-collab-006/reprocessing-etl-pipelines |
| RPU Pipeline | Argo Workflow configuration | https://github.com/qcc-collab-006/raas-pipeline-deployment |
| Job Management | This service is in charge of triggering all flows |  |

## Responsibility

Each application team is responsible for the upkeep of their application. Each team needs to create the release for their application.

## Technologies

All releases will include the following:

- Docker Image (published to ECR)
- Helm Chart

## Deployment structure

![Deployment structure](diagrams/deployment_structure.drawio.png)

### Infrastructure as code (IaC) using AWS CDK

The following diagram illustrates the key components and their relationships.

![Infrastructure as code (IaC) using AWS CDK](images/Key_Components_for_raas_infra_implementation.drawio.png)

*Configuration of AWS CDK Context*

The configuration of AWS CDK Context provide the necessary inputs to generate the stack for the resources, which are required for the new feature.

There are two kind of the CDK configuration files, which are maintained under (orion|orion-cn|qrp)\raas-infra\:

* "cdk.context.common.json": for the commons settings and/or variables, which can be used in all the stages.
* "cdk.context.`<stage>`.json": for the stage specific settings and/or variables. (`<stage>`:= {'dev', 'int', 'prod'}

How context values are associated from the file please find documentation here https://docs.aws.amazon.com/cdk/v2/guide/context.html

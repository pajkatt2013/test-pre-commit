---
runme:
  id: 01HXBQDYE1DPZC5G99S6CB1K0S
  version: v3
---

# CI/CD Target Architecture

![Target Architecture](images/ci_cd_pipeline.drawio.svg)

# Short Description

- Sandbox deployment on DEV to allow developers to quickly check their changes in the real environment.
- Generation of artifacts (services / helm charts / infrastructure tags) after merge to main branches.
- Nightly (manual, in case of bugfix releases) deployment of artifacts to INT for integration testing.
- Blue / green deployment to PROD with artifacts that ran successfully through integration testing.

# Todos

- Sync int / prod json deployment files (cdk.context)
- Define how to fill int and dev databases
- Mark versions that have successfully passed the integration tests (git tag?)
- Store infrastructure versions that were successfully tested in integration
- Link infrastructure version to helm / docker image versions, automate versioning (how do we make sure that we deploy version combinations (infra, helm, images) to prod)
- Define which data should be used for sandbox-testing
- Enable nightly integration tests
- Strive towards blue / green deployment

# Blue / green deployment proposal

- Rationale for blue / green deployment:

   - E2E tests in INT do not cover edge cases / problems with data, RPUs, interfaces to other realms, ...
   - Proper Smoke tests / performance tests are possible in prod only (since production data is not allowed in int / dev).
   - Rollback to older version is directly available without additional effort.
   - "Blind" prod deployment will lead to production outages in case of errors.
   - CCB (change control board) will monitor our changes closely (which leads to huge productivity losses) in case of erroneous deployments.

- Only available for production deployment.
- Use of kubernetes namespaces, instead of creating a new kubernetes cluster.
- Configure load balancer to route smoke test / special / ... requests to green deployment for extensive testing with production data and configurations.
- Create new target for load balancer.
- If Argo is not deployed, we need to make sure that the events send by argo do not confuse the blue / green job manager.
- Database-migration strategy:

   - Add new columns
   - fill new columns with script output
   - Remove code that uses old entries, when new code is properly deployed / tested.
   - remove old rows in later deployment (even after months)

- Infrastructure changes are handled like database changes:

   - Add new infrastructure components in addition to existing infrastructure + new code that accesses new infra.
   - Monitor new infrastructure
   - Delete code that accesses old infrastructure
   - Delete old infrastructure

- Open questions:
   - How to cope with SQS events?
   - Do we want to deploy Argo Workflows as well with each new service deployment?
   - What do we do when buckets are renamed? Shall we create a new bucket and copy the data over?

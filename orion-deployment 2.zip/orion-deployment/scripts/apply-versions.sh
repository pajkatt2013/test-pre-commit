#! /usr/bin/env bash
#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

project="$1"
latest_reprocessing="$2"
latest_pipeline="$3"
latest_cutter="$4"

versions="RAAS_SERVICES_DOCKER_TAG=$latest_reprocessing
RAAS_SERVICES_HELMCHART_VERSION=$latest_reprocessing

RAAS_PIPELINE_VERSION=$latest_pipeline
CUTTER_VERSION=$latest_cutter

DQ_SERVICES_DOCKER_TAG=$latest_reprocessing
DQ_SERVICES_HELMCHART_VERSION=$latest_reprocessing"

cat <<EOF >"$project/dev.env"
$versions
EOF

cat <<EOF >"$project/int.env"
$versions
EOF

cat <<EOF >"$project/prod.env"
$versions
EOF

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Output all sandbox CF stacks older than a max day count.

For the age the CF stack LastUpdatedTime or CreationTime is considered.
Script can be called with one parameter, the max age in days.
Defaults to 7 if not given.
"""

import datetime
import json
import sys

import boto3

sandbox_max_age_days = 7 if len(sys.argv) <= 1 else int(sys.argv[1])

client = boto3.client("cloudformation")
paginator = client.get_paginator("describe_stacks")
starting_token = None
page_count = 1
old_sandboxes = set()
now = datetime.datetime.now(datetime.timezone.utc)
stack_status_filter = [
    "CREATE_IN_PROGRESS",
    "CREATE_FAILED",
    "CREATE_COMPLETE",
    "ROLLBACK_IN_PROGRESS",
    "ROLLBACK_FAILED",
    "ROLLBACK_COMPLETE",
    "DELETE_IN_PROGRESS",
    "DELETE_FAILED",
    "UPDATE_IN_PROGRESS",
    "UPDATE_COMPLETE_CLEANUP_IN_PROGRESS",
    "UPDATE_COMPLETE",
    "UPDATE_FAILED",
    "UPDATE_ROLLBACK_IN_PROGRESS",
    "UPDATE_ROLLBACK_FAILED",
    "UPDATE_ROLLBACK_COMPLETE_CLEANUP_IN_PROGRESS",
    "UPDATE_ROLLBACK_COMPLETE",
    "REVIEW_IN_PROGRESS",
    "IMPORT_IN_PROGRESS",
    "IMPORT_COMPLETE",
    "IMPORT_ROLLBACK_IN_PROGRESS",
    "IMPORT_ROLLBACK_FAILED",
    "IMPORT_ROLLBACK_COMPLETE",
]

while page_count > 0:
    response = paginator.paginate(PaginationConfig={"MaxItems": 100, "StartingToken": starting_token})
    for page in response:
        page_count = page_count + 1
        starting_token = page.get("NextToken")
        if starting_token is None:
            page_count = -1
            break
        cfn_stacks = page.get("Stacks")
        if cfn_stacks:
            for cfn_stack in cfn_stacks:
                if (
                    cfn_stack["StackStatus"] in stack_status_filter
                    and "Tags" in cfn_stack
                    and any(stack_tag["Key"] == "sandbox" for stack_tag in cfn_stack["Tags"])
                ):
                    stack_timestamp = (
                        cfn_stack["LastUpdatedTime"] if "LastUpdatedTime" in cfn_stack else cfn_stack["CreationTime"]
                    )
                    if now - stack_timestamp > datetime.timedelta(days=sandbox_max_age_days):
                        # TODO(Marco Heinemann): simplify this
                        old_sandboxes.add(
                            next((tag["Value"] for tag in cfn_stack["Tags"] if tag["Key"] == "sandbox"), None)
                        )

print(json.dumps(list(filter(None.__ne__, old_sandboxes))))

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Pull a list of helm charts from ECR into a given output directory.

The script consumes 3 arguments:
- cdk context json file containing the list of helm charts
- target directory for unpacking the helm charts
- github workspace directory; this is used to replace the variable
  ${{ github.workspace }} in the cdk context json file
"""

import json
import subprocess
import sys
from pathlib import Path

cdk_context_json_file = sys.argv[1]
untar_dir = sys.argv[2]
github_workspace = sys.argv[3]

with Path(cdk_context_json_file).open(encoding="utf-8") as fp:
    context = json.load(fp)

context_json = json.dumps(context)
context_json = context_json.replace("${{ github.workspace }}", github_workspace)

with Path(cdk_context_json_file).open("w") as fp:
    fp.write(context_json)

context = json.loads(context_json)

helm_charts = context["helmcharts"]

for helm_chart_name in helm_charts:
    helm_chart = helm_charts[helm_chart_name]
    helm_chart_repo = helm_chart["chartRepository"]
    skip_deployment = helm_chart.get("skipDeployment", False)
    if skip_deployment is False:
        helm_chart_version = helm_chart["chartVersion"]
        cmd = [
            "helm",
            "pull",
            helm_chart_repo,
            "--version",
            helm_chart_version,
            "--untar",
            "--untardir",
            untar_dir,
        ]
        try:
            subprocess.run(cmd, check=True)  # noqa: S603 # subprocess-without-shell-equals-true: running in safe environment
        except subprocess.CalledProcessError as exc:
            print(exc)
            sys.exit(1)

#! /usr/bin/env python
#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Merge JSON files containing dictionaries.

Main use case is to merge cdk.context.json files from various environments.
Common parts can be put into dedicated files to deduplicate the content.

The script also features splitting files in a 'splitting mode'.
Finding common parts of JSON files is a tedious task, but perfect for a
small Python script.
"""

import argparse
import copy
import json
import logging
import os
import re
import sys
from pathlib import Path

ERROR_EXIT_CODE = 1
# file postfix for writing source file changes after removing common parts for split mode
SPLIT_POSTFIX = ".unique"


def log_and_exit(exc: Exception | None, additional_msg: str) -> None:
    """
    Log an exception and an additional message and exit the script.

    Both exception and additional message may be None.
    """
    if exc:
        logging.error(exc)
    if additional_msg:
        logging.error(additional_msg)
    sys.exit(ERROR_EXIT_CODE)


def merge(sources: list[tuple[Path, dict]]) -> dict:
    """
    Merge list of input source dicts.

    They are merged in order as they appear in the list.
    The merge algorithm is defensive, any duplicate keys at the outer dictionary
    leaves will lead to an error.
    """
    merged = sources[0][1]  # fully take over the first
    handled = str(sources[0][0])
    for idx in range(1, len(sources)):
        logging.info(f"Merging {sources[idx][0]} into [{handled}]")
        try:
            merge_deep(sources[idx][1], merged, "")
        except ValueError as exc:
            log_and_exit(
                exc,
                f"Error merging {sources[idx][0]} into [{handled}]. Stopping script.",
            )
        handled += f", {sources[idx][0]}"
    return merged


def merge_deep(source: dict, destination: dict, parent_key: str) -> None:
    """
    Deep merge a source dictionary into a destination dictionary.

    Destination is modified in-place.
    """
    for key, value in source.items():
        full_key = f"{parent_key}.{key}" if parent_key else key
        logging.debug(f"Handling key {full_key}")
        if isinstance(value, dict):
            # get node or create one
            node = destination.setdefault(key, {})
            merge_deep(value, node, full_key)
        else:
            if key in destination and value != destination[key]:
                msg = f"Duplicate key '{full_key}' of type '{type(value).__name__}' found with differing value."
                raise ValueError(msg)
            destination[key] = value


def split(
    sources_tuple: list[tuple[Path, dict]],
) -> tuple[dict, list[tuple[Path, dict]]]:
    """
    Split common parts of input source dicts.

    Common keys are put into a new shared dictionary.
    Return tuple is (common dict, modified sources).
    The modified sources keep the original tuple structure of (Path, dict) for later writing.

    The logic takes the first source dictionary as primary source, then compares against all
    other dictionaries. If keys match, it compares the value in case it's not a dict.
    """
    sources_in = [src[1] for src in sources_tuple]
    common_out: dict = {}
    sources_out: list[dict] = [copy.deepcopy(source_in) for source_in in sources_in]
    split_deep(sources_in, sources_out, common_out)
    sources_tuple_out = [(sources_tuple[idx][0], source) for idx, source in enumerate(sources_out)]
    return common_out, sources_tuple_out


def split_deep(sources_in: list[dict], sources_out: list[dict], common_out: dict) -> bool:
    """
    Recursively find common parts across souces_in.

    sources_out is expected to be a deepcopy of sources_in.
    Each common parts gets deleted from all sources_out dicts and added to common_out.

    :returns: True if the whole dictionary is equal (keys+values) else False
    """
    common_keys_set = set.intersection(*map(set, sources_in))
    # reproduce original order
    common_keys = [key for key in sources_in[0] if key in common_keys_set]
    all_keys_common_outer = True
    if len(common_keys) < max([len(source_in) for source_in in sources_in]):
        # there are less common keys than in the longest source;
        # this means there must be a unique part that cannot be deleted on the caller level of
        # the function
        all_keys_common_outer = False
    for key in common_keys:
        if all(isinstance(source[key], dict) for source in sources_in):
            # all values are dictionaries, dive deeper
            new_sources_in = [source[key] for source in sources_in]
            new_sources_out = [source[key] for source in sources_out]
            potential_common_out: dict = {}
            all_keys_common_inner = split_deep(new_sources_in, new_sources_out, potential_common_out)
            all_keys_common_outer = all_keys_common_outer & all_keys_common_inner
            if potential_common_out:
                # common inner part was stored, write it to the common dict
                common_out[key] = potential_common_out
                if all_keys_common_inner:
                    # remove key from output source dictionaries, the full body is common
                    for source_out in sources_out:
                        del source_out[key]
        else:
            all_values = [source[key] for source in sources_in]
            # use == operator to compare values is ok as only primitive json types
            # are compared (list, dict, str, int, bool); this will also deep compare lists
            all_same = all(all_values[0] == value for value in all_values)
            if all_same:
                # they are all same, so take the first value
                common_out[key] = all_values[0]
                for source_out in sources_out:
                    # remove from output source dictionaries
                    del source_out[key]
            else:
                # keep the key in sources_out and don't add to common_out
                all_keys_common_outer = False
    return all_keys_common_outer


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        prog="mix_context",
        description="Deep merge and split a list of JSON files while detecting conflicts",
    )
    parser.add_argument(
        "sources",
        type=Path,
        nargs="+",
        help=(
            "Paths to input JSON files. In merge mode, the output sources files will be"
            " placed next to the input source under a different name."
        ),
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        help="Target path for merge/split JSON file. If not given, output is printed to stdout.",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="More verbose output (change log level from INFO to DEBUG)",
    )
    parser.add_argument(
        "-s",
        "--silent",
        action="store_true",
        help="Do not print anything but JSON content to stdout. Will override --verbose.",
    )
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing output files.")
    parser.add_argument(
        "-m",
        "--mode",
        choices=["merge", "split"],
        default="merge",
        help="Working mode: merge input files into output or split common parts from inputs into output.",
    )
    return parser.parse_args(sys.argv[1:] or ["--help"])


def read_sources(sources: list[Path]) -> list[tuple[Path, dict]]:
    """
    Read input JSON files into a list of tuple data structure (source path, dictionary).

    The function is used for both merge and split mode.
    """
    if len(sources) <= 1:
        log_and_exit(None, "Need at least 2 source paths to run. Stopping script")

    source_contents: list[tuple[Path, dict]] = []
    source_path: Path
    placeholder_key_val = get_content_placeholder_key_values()
    for source_path in sources:
        if not source_path.is_file():
            log_and_exit(None, f"The source-path '{source_path}' is not a valid file")
        with source_path.open("r", encoding="utf-8") as source_file:
            content = source_file.read()
            try:
                content = apply_content_substitution(content=content, placeholder_key_val=placeholder_key_val)
                json_structure = json.loads(content)
            except (ValueError, json.JSONDecodeError) as exc:
                log_and_exit(exc, f"Error reading JSON file {source_path}. Stopping script.")
            source_contents.append((source_path, json_structure))
    return source_contents


def get_content_placeholder_key_values() -> dict:
    """
    Return dictionary of placeholder values to be replaced in a content.

    Currently covering only environment variables.
    """
    placeholder_key_val = {}

    # adding environment variables as placeholder key-val pair to replace in the content
    for name, value in os.environ.items():
        placeholder_key_val[f"[env:{name}]"] = value

    return placeholder_key_val


def apply_content_substitution(content: str, placeholder_key_val: dict) -> str:
    """Replace/Substitute the given input keys with respective values in the given content"""
    for key, val in placeholder_key_val.items():
        if key in content:
            logging.info(f"Replacing '{key}' with '{val}' in the cdk context configuration")
            content = content.replace(key, val)

    # validating if the content has any placeholders which are not substituted due to missing declarations
    # in the env files
    validate_if_content_substitution_is_missing(content=content)
    return content


def validate_if_content_substitution_is_missing(content: str) -> None:
    """Validate if content has any substitutions missed"""
    reg_search = re.findall("(\\[env:.*?\\])", content)

    if reg_search:
        placeholders = ", ".join(set(reg_search))
        msg = (
            f"Found {len(reg_search)} placeholder(s) with no proper substitution in cdk context files content.\n"
            f" Unique placeholders : {placeholders}.\n"
            "  Please check if the env files have the values to substitute the above identified placeholders."
        )
        raise ValueError(msg)


def write_output(output_path: Path, data: dict, *, overwrite: bool) -> None:
    """
    Write to the given output file path considering the --overwrite flag.

    The function is used for both merge and split mode.
    """
    if output_path:
        if output_path.is_file():
            if not overwrite:
                log_and_exit(
                    None,
                    f"Refuse to overwrite existing output-path {output_path} (use --overwrite).",
                )
            else:
                logging.info(f"Output path {output_path} exists. Overwriting.")
        with output_path.open("w", encoding="utf-8") as output_file:
            json.dump(data, output_file, indent=2, sort_keys=True)
            # make sure the file ends with an empty line (as most IDEs handle it)
            output_file.write("\n")
        logging.info(f"Successfully wrote output file {output_path}")
    else:
        output_string = json.dumps(data, indent=2, sort_keys=True)
        print(output_string)
        logging.info("Successfully wrote output to stdout")


if __name__ == "__main__":
    args = parse_args()

    log_level = logging.INFO
    if args.verbose:
        log_level = logging.DEBUG
    if args.silent:
        log_level = logging.FATAL
    logging.basicConfig(level=log_level, format="[%(levelname)s] %(message)s")
    logging.info(f"Starting CDK mixer in '{args.mode}' mode")

    sources = read_sources(args.sources)
    if args.mode == "merge":
        merge_output = merge(sources)
        write_output(args.output, merge_output, overwrite=args.overwrite)
    else:
        # split mode
        split_output, sources_out = split(sources)
        write_output(args.output, split_output, overwrite=args.overwrite)
        for source_out in sources_out:
            path: Path
            data: dict
            path, data = source_out
            # rename input file with a postfix
            path_postfixed = path.parent / Path(path.stem + SPLIT_POSTFIX + path.suffix)
            write_output(path_postfixed, data, overwrite=args.overwrite)

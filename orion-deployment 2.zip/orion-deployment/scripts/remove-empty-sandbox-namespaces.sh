#!/usr/bin/env bash
#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

# This script will identify any sandbox namespace named raas-services-<sandbox-name> that has no pods running.
# Namespaces created for each sandbox will be deleted using the sandbox name, i.e.:
# * raas-services-<sandbox-name>
# * raas-pipeline-<sandbox-name>
# * raas-eks-s3mount-<sandbox-name>

set -o pipefail
set -x

# Need to return true from the pipeline to avoid returning an error on no namespaces to delete
# shellcheck disable=SC2016
kubectl get ns |
  awk '$1 ~ /raas-services-/ {print $1}' |
  xargs -I {} bash -cex '[[ "$(kubectl get pods -n {} --output json| jq -j ".items | length")" == "0" ]] && { echo {} | sed "s/raas-services-//g"; }' |
  xargs -I {} bash -c 'kubectl delete ns raas-pipeline-{}; kubectl delete ns raas-services-{}; kubectl delete ns raas-eks-s3mount-{}' ||
  true

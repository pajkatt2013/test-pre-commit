#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Generate OpenAPI spec URLs of services referenced in context file from Artifactory.

The script consumes 3 arguments:
- cdk context json file containing the list of API gateway services
- RaaS group version
- RaaS DQ group version
"""

import json
import sys
from pathlib import Path

final_context = sys.argv[1]
raas_version = sys.argv[2]
dq_version = sys.argv[3]
with Path(final_context).open() as context_file:
    for service_name, definition in json.load(context_file).get("apigateways", {}).items():
        download_version = definition["version"]
        print(
            f"https://qartifactory-eu.qualcomm.com/artifactory/qcc-collab-006-adpapp-raas-generic-internal/openapi-specs/{download_version}/openapi-reprocessing-{service_name}.json"
        )

#! /usr/bin/env bash
#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

# Set up a local cdk deployment environment, just like the CI does.

# user specific input
aws_profile_cicd=raasv1-cicd
aws_profile_stage=raasv1-dev
stage=dev     # options: dev / int / prod
project=orion # options: orion / orion_cn / qrp
group=all     # options: dq / raas / all

# aws specific input
aws_region=eu-central-1
ecr_host=503803885491.dkr.ecr.eu-central-1.amazonaws.com

# exit early on any error
set -e

# set paths
script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)
orion_deployment_repo_path=$(realpath "${script_dir}/..")

env_path=$(realpath "${script_dir}/../${project}/${stage}.env")
raas_infra_dir=$(realpath "${script_dir}/../../raas-infra")
cdk_context_out_path=$(realpath "${raas_infra_dir}/cdk.context.json")
charts_dir=$(realpath "${raas_infra_dir}/charts")
helm_py_path=$(realpath "${script_dir}/helm.py")

# preparation to merge cdk context jsons
# create a new dictionary
declare -A group_2_paths

# key is the cdk context group, value is the directory of cdk context JSON files
group_2_paths["raas"]="${script_dir}/../${project}/raas-infra"
group_2_paths["dq"]="${script_dir}/../${project}/dq-infra"

input_files=()

if [ "$group" == "all" ]; then
  for key in "${!group_2_paths[@]}"; do
    if [ -d "${group_2_paths[$key]}" ]; then
      input_files+=("${group_2_paths[$key]}/cdk.context.common.json")
      input_files+=("${group_2_paths[$key]}/cdk.context.${stage}.json")
    else
      echo "Ignoring non-existent directory ${group_2_paths[$key]}"
    fi
  done
elif [[ ! -v group_2_paths["$group"] ]]; then
  echo "Unknown cdk_context_group '$group'"
  exit 1
else
  if [ ! -d "${group_2_paths[$group]}" ]; then
    echo "Directory ${group_2_paths[$group]} does not exist."
    exit 1
  fi
  input_files+=("${group_2_paths[$group]}/cdk.context.common.json")
  input_files+=("${group_2_paths[$group]}/cdk.context.${stage}.json")
fi

if [ ${#input_files[@]} -eq 0 ]; then
  echo "Error: List of input files is empty."
  exit 1
fi

# merge cdk context json files
set -a # automatically export all variables
# shellcheck disable=SC1090 # the env_path depends on input parameters and is dynamic in nature
source "${env_path}"
python "${script_dir}"/mix_context.py \
  --overwrite -o "${cdk_context_out_path}" \
  "${input_files[@]}"

# replace the string "${{ github\.workspace }}/deployment" with the local path setup
# this is a bad modeling in the CI that makes the bold assumption that orion-deployment is checked out to "deployment"
sed -i "s#\${{ github\.workspace }}/deployment#${orion_deployment_repo_path}#g" "${cdk_context_out_path}"

# delete old Helm charts dir
rm -rf "${charts_dir}"

# login to cicd ECR
aws ecr get-login-password --region eu-central-1 --profile ${aws_profile_cicd} | docker login --username AWS --password-stdin ${ecr_host}

# get helm charts
python "${helm_py_path}" "${cdk_context_out_path}" "${charts_dir}" "${script_dir}/.."

# give the user some ideas what to do now in the calling shell
echo
echo "Now run the following commands in your shell:"
echo "  cd \"${raas_infra_dir}\""
echo "  poetry install"
echo "  eval \"\$(aws configure export-credentials --profile ${aws_profile_stage} --format env)\" && export AWS_REGION=${aws_region}"

echo
echo "Execute cdk, e.g. with this dry-run command:"
echo '  cdk synth --app "poetry run python app.py" --c ADDF_MODULE_NAME=services --require-approval never --all'
echo "Or deploy helm charts to a sandbox with:"
echo '  cdk deploy --app "poetry run python app.py" --c ADDF_MODULE_NAME=helmcharts --c HELM_CHARTS_FOLDER=charts --c SANDBOX_NAME=<name> --require-approval never --all'

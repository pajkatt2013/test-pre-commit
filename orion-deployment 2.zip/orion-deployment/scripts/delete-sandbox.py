#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

"""
Delete sandbox

Delete one sandbox stack using boto.
Delete the most common sandbox namespaces from the EKS Cluster
The sandbox name is read in as the first argument to the script.
The cluster name is read in as the second argument to the script.
If cluster name is provided the runner has to have kubeconfig up to date.
All CloudFormation stacks are listed and filtered for the wanted sandbox.
This is done by comparing the given sandbox name with the CF stack tags.
The relevant CF tag is called 'sandbox'.
The deletion happens synchronous with a timeout of 30mins.
"""

import re
import signal
import sys
import time
from datetime import datetime, timezone
from types import FrameType
from typing import NoReturn

import boto3
from botocore.exceptions import ClientError
from kubernetes import client as kubeclient
from kubernetes import config as kubeconfig

client = boto3.client("cloudformation")
tagging_client = boto3.client("resourcegroupstaggingapi")


def get_stack_name_from_arn(arn: str) -> str:
    """Get Stack Name from stack ARN."""
    match = re.search(r"stack/([^/]+)/", arn)
    if match:
        return match.group(1)
    return ""


def get_stacks_by_tags(tag_key: str, tag_value: str) -> list[str]:
    """Fetch CloudFormation stack ARNs based on tags."""
    start_time = datetime.now(timezone.utc)
    print(f"Start time: {start_time}")

    response = tagging_client.get_resources(
        TagFilters=[{"Key": tag_key, "Values": [tag_value]}], ResourceTypeFilters=["cloudformation:stack"]
    )
    stack_arns = [res["ResourceARN"] for res in response.get("ResourceTagMappingList", [])]
    end_time = datetime.now(timezone.utc)
    print(
        f"After tag API call, total stacks: {len(stack_arns)}, End time: {end_time}, Duration: {end_time - start_time}"
    )

    return [get_stack_name_from_arn(arn) for arn in stack_arns]  # Extract stack names


def delete_stacks_sync(stacks: list[str]) -> None:
    """Trigger removal of all found CF stacks and wait until finished."""
    for stack in stacks:
        print(f"Deleting stack: {stack}")
        try:
            client.delete_stack(StackName=stack)
        except ClientError as exc:
            print(exc)

    while len(stacks) > 0:
        for stack in stacks:
            try:
                client.describe_stacks(StackName=stack)
            except ClientError:  # noqa: PERF203 # try-except-in-loop: negligible performance impact
                # stack does not exist anymore
                stacks.remove(stack)
                print(f"Fully deleted stack: {stack}")
        time.sleep(10)


def timeout_handler(signum: int, frame: FrameType | None) -> NoReturn:
    """
    Raise TimeoutError if called.

    Used together with the signal library.
    """
    del signum, frame  # indicate they are not used
    msg = "Timed out waiting for stacks to be deleted"
    raise TimeoutError(msg)


if __name__ == "__main__":
    sandbox_name = sys.argv[1]
    cluster_name = sys.argv[2]

    print(f"Fetching stacks for sandbox: {sandbox_name}")
    stacks_to_delete = get_stacks_by_tags("sandbox", sandbox_name)
    print(f"Stacks to be Deleted: {stacks_to_delete}")

    if len(stacks_to_delete) > 0:
        print(f"Deleting {len(stacks_to_delete)} cloudformation stack(s) for sandbox: {sandbox_name}")
        # wait for max 30min until all stacks are deleted
        signal.signal(signal.SIGALRM, timeout_handler)
        signal.alarm(1800)
        delete_stacks_sync(stacks=stacks_to_delete)
        # reset timeout to clean up in case timeout did not occur
        signal.alarm(0)
        print(f"Deleted the cloudformation stacks for sandbox: {sandbox_name}")

    if sandbox_name and cluster_name:
        print(f"Deleting namespaces for sandbox: {sandbox_name} in cluster: {cluster_name}")

        # List of namespaces to delete
        namespaces = [
            f"raas-pipeline-{sandbox_name}",
            f"raas-services-{sandbox_name}",
            f"raas-eks-s3mount-{sandbox_name}",
        ]

        # Load kubeconfig from system
        kubeconfig.load_kube_config()
        # Init client
        kuberenetes_client = kubeclient.CoreV1Api()
        NAMESPACE_NOT_FOUND = 404

        for namespace in namespaces:
            print(f" Deleting Namespace: {namespace}")
            try:
                kuberenetes_client.delete_namespace(name=namespace)
                print(f"\t{namespace} was deleted.")
            except kubeclient.ApiException as e:
                if e.status == NAMESPACE_NOT_FOUND:
                    print(f"\t{namespace} was not found. Skipping.")
                else:
                    print(f"\tFailed to delete namespace: {namespace}: Status: {e.status}\n")

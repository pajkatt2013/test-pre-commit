#!/bin/bash
#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

# This script will perform required update actions in order to deploy Helm charts
# with new resource names. These resources are referenced and can't be simply removed
# and updated by CloudFormation. Hence, this script severs connections from API gateway
# VPC links to LoadBalancers by replacing the integration with mocks returning 503
# responses. It also removes the VPC links and deletes the outdated LoadBalancer
# entries in Kubernetes.
#
# One update operation (i.e. on one resource) requires 2-3 seconds. For an API with
# about 50 methods, that's roughly three minutes in total runtime.
#
# Required preparations:
# * Log into AWS console and export credentials for respective target stage (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN)
# * Prepare the kubectl context of the affected environment to successfully run `kubectl`
# * Identify the affected API gateway IDs in the target stage and list them below

set -e -o pipefail

export KUBE_CONTEXT=
declare -a api_ids=(
  "qs1f1rahh8"
  "n109xaa88g"
  "f88fj6ob37"
  "9zpi0fvtig"
)

for api_id in "${api_ids[@]}"; do
  echo "Updating API $api_id integrations"
  aws apigateway get-resources --rest-api-id "$api_id" |
    jq -r '.items[] | select(.resourceMethods != null) | .id as $id | (.resourceMethods | keys[]) | [$id, .] | @tsv' |
    xargs -L1 bash -c "aws apigateway put-integration --rest-api-id $api_id --resource-id \$0 --http-method \$1 --type MOCK --request-templates '{\"application/json\":\"{\\\"statusCode\\\":503}\"}'; aws apigateway put-method-response --rest-api-id $api_id --resource-id \$0 --http-method \$1 --status-code 503 --response-parameters 'method.response.header.retry-after=false'; aws apigateway put-integration-response --rest-api-id $api_id --resource-id \$0 --http-method \$1 --status-code 503 --selection-pattern 503 --response-parameters '{\"method.response.header.retry-after\":\"'\"'\"'120'\"'\"'\"}'"
  echo "Deploying API $api_id"
  aws apigateway create-deployment --rest-api-id "$api_id" --stage-name prod
done

echo "Removing VPC links"
aws apigateway get-vpc-links |
  jq -r '.items[] | .id' |
  xargs -L1 aws apigateway delete-vpc-link --vpc-link-id

# Delete outdated load balancers
echo "Deleting load balancer objects from k8s"
kubectl get svc -n raas-services --context "$KUBE_CONTEXT" |
  awk '$1 ~ /-loadbalancer/ {print $1}' |
  xargs -L1 kubectl delete svc -n raas-services --context "$KUBE_CONTEXT"

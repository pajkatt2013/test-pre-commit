#!/bin/bash
#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

# Input variables
service=$1
tag=$2
source_repository=$3
target_repository=$4

echo "Copying $service:$tag"
docker pull "$source_repository"/"$service":"$tag"
docker tag \
  "$source_repository"/"$service":"$tag" \
  "$target_repository"/"$service":"$tag"
docker push "$target_repository"/"$service":"$tag"

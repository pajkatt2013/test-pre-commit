#!/bin/bash

#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

modified_files=$(git diff --cached --name-only -- . ':(exclude)scripts/prevent-absolute-runner-paths.sh')

for file in $modified_files; do
  if grep -E -i "__w" "$file"; then
    echo "Error: You are not allowed to introduce a dependency on the runners filesystem layout. Use 'working-directory' with a relative path or \$GITHUB_WORKSPACE."
    exit 1
  fi
done

exit 0

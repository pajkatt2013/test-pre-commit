## Table of Contents
1. CI/CD
    1. [Overview](documentation/CICD/overview.md)
    2. [Release Process](documentation/CICD/release_process.md)
    3. [Developer Guidelines](documentation/CICD/developer_guidelines.md)

## Environments

### Orion

| | Argo | RaaS API | DQ API |
|-|------|-------------|--------------|
|DEV| [https://argo-workflows.100100019.dev...](https://argo-workflows.100100019.dev.aws.orionadp.com/) | [https://raas-dev...](https://raas-dev.api.aws.orionadp.com) | [https://raas-dq-dev...](https://raas-dq-dev.api.aws.orionadp.com) |
|INT| [https://argo-workflows.100100020.int...](https://argo-workflows.100100020.int.aws.orionadp.com/) | [https://raas-int...](https://raas-int.api.aws.orionadp.com) | [https://raas-dq-int...](https://raas-dq-int.api.aws.orionadp.com) |
|PROD| [https://argo-workflows.100100021.prod...](https://argo-workflows.100100021.prod.aws.orionadp.com/) | [https://raas...](https://raas.api.aws.orionadp.com) | [https://raas-dq...](https://raas-dq.api.aws.orionadp.com) |

## Orion Deployment Instructions

:tv: [There is a video on where we walked through the instructions](https://bmwgroup.sharepoint.com/:v:/r/teams/RAPID-25/Shared%20Documents/Knowledge/RaaS+DQ-Deployment.mov?csf=1&web=1&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZy1MaW5rIiwicmVmZXJyYWxBcHBQbGF0Zm9ybSI6IldlYiIsInJlZmVycmFsTW9kZSI6InZpZXcifX0%3D&e=CSftMf) :tv:
:bulb: [List of Lessons-Learned which contains many previous errors](https://confluence.cc.bmwgroup.net/pages/viewpage.action?spaceKey=orioncn&title=Lessons+Learned%3A+Releases+to+Orion) :bulb:
:books: [The even lower level deployment is described here](https://confluence.cc.bmwgroup.net/display/orioncn/About+RaaS+Realm+Infrastructure+Deployment) :books:
:books: [There's more deployment docs here](https://confluence.cc.bmwgroup.net/display/orioncn/Release+Management+Concept+for+RaaS) :books:

> [!NOTE]
> The deployment responsibilities are split half-way: BMW has the duty of declaring a release-candidate suitable for production rollout, Capgemini performs the INT and PROD rollouts of this release candidate.

### BMW Release manager

1. Every morning, the [raas-autobump.yaml](https://github.com/qcc-collab-006/orion-deployment/actions/workflows/raas-autobump.yaml) workflow from `main` branch is run automatically. As the workflow runs, a bot will open a PR in `orion-deployment` which updates all the application versions in the respective project's `dev.env`, `int.env` and `prod.env` to the latest ones at the time. You can review and merge the PR on your own.
2. Start a new thread in the [deployment MS Teams channel](https://teams.microsoft.com/l/channel/19%3Aac46f3e1e815483a8a5f97c9b0feaba3%40thread.tacv2/05%20Deployments?groupId=c9cf8ba2-ed2f-42b2-aeb6-2d0bf2914b27&tenantId=ce849bab-cc1c-465b-b62e-18f07c9ac198) titled e.g. "Deployment July 18th". It's also worth asking if somebody still wants a couple of minutes to get a PR merged in `reprocessing` or `raas-pipeline-deployment`. As a release manager of the day you can either accept or deny that, according to the timeline you have. If you wait for some PR, make sure to get the newest version after the merge of it. In case you wait for some PR, you can re-trigger the `raas-autobump` workflow again manually. Continue to step 3 once the autobump PR is merged.
3. Start a DEV deployment by going [to the actions tab](https://github.com/qcc-collab-006/orion-deployment/actions) and selecting `raas-infra` in the left drawer, selecting **the latest tag** as the version to run the workflow from. ![Bildschirmfoto 2024-10-08 um 11 36 11](https://github.com/user-attachments/assets/5f9e21f9-69d7-48c8-a07b-4fb22be36478)
4. Post in the channel the link to the deployment workflow run with a message like "Triggered DEV https://github.com/qcc-collab-006/orion-deployment/actions/runs/9986905115". Wait for the deployment to run, now it gets exciting! If the entire thing is green (all steps have a green checkmark, from the first one to the end, including E2E tests), you can hand over the release candidate to Capgemini (explicitly making a note of the tag you selected). A handover message can look like `@Capgemini Lamport, RC creation finished successfully, handing over to you the tag 2024.10.24-1.`. If the deployment was not green, troubleshoot. :people_holding_hands: You'll get help from colleagues in the MS Teams deployment thread for the day.
5. **Recap time**! Note down any issues that arose during RC creation in the [LeLe table on confluence](https://confluence.cc.bmwgroup.net/x/fHXWD) and make sure we follow up on issues with systematic solutions.

### Capgemini

6. Start an INT deployment, same as in DEV, only difference is selecting "int" in the workflow dropdown. Post the started workflow in the MS Teams thread. E2E tests are also enabled on INT. Make sure entire thing is green including E2E tests. If there are red/failed steps, troubleshoot.
7. While the INT deployment is running (or at the very least, before you start the PROD deployment), [run the E2E tests on PROD](https://github.com/qcc-collab-006/reprocessing/actions/workflows/e2e-tests.yml). This aims to make sure the environment is in working order _before_ the deployment. Without that, if the E2E tests are failing after PROD deployment, it is very hard to judge whether the deployment is at fault or there was an incident already beforehand.
8. Now that DEV and INT were successful, you can be sure that the versions you deployed there will also be the versions you'll deploy to PROD. [Create the release notes in confluence](https://confluence.cc.bmwgroup.net/pages/viewpage.action?pageId=215380919) and record the versions there.
    - For `reprocessing` and `raas-pipeline-deployment`, create github releases first by ["Draft a new release"](https://github.com/qcc-collab-006/raas-pipeline-deployment/releases/new) in the github UI. Choose the previously deployed release (see in last release notes entry) as a comparison base. "Generate release notes" will automatically fill the Github Releases Notes. Note that the release notes for users (on confluence) are **not** the same as the ones we create in github releases. The former are hand-crafted, for users specifically! :people_holding_hands: Ask colleagues in order to get a list of user-facing release notes.
9. If you deemed the INT deployment to be successful, we start with PROD.
    - Announce the deployment in [MS Teams for "Reprocessing as a Service support"](https://teams.microsoft.com/l/channel/19%3A8380f887a8e8498886e2ef2c157325ae%40thread.tacv2/%5BRPR%5D%20Reprocessing%20as%20a%20Service%20support?groupId=46228af2-dab4-4743-8368-bb0711311569&tenantId=ce849bab-cc1c-465b-b62e-18f07c9ac198). [See here for instructions](https://teams.microsoft.com/l/message/19:ac46f3e1e815483a8a5f97c9b0feaba3@thread.tacv2/1721289825681?tenantId=ce849bab-cc1c-465b-b62e-18f07c9ac198&groupId=c9cf8ba2-ed2f-42b2-aeb6-2d0bf2914b27&parentMessageId=1721289825681&teamName=RAPID-25&channelName=05%20Deployments&createdTime=1721289825681).
    - Start the PROD deployment through github actions, same as before, just with selecting "prod" in the workflow dropdown. Pray.
    - If the deployment fails for some reason, troubleshoot. If it succeeded, do some manual testing to verify success.
    - Announce the success of the deployment in both the RaaS deployment channel as well as in the ADP.next support channel.
    - Record the version of [`orion-deployment`](https://github.com/qcc-collab-006/orion-deployment) that you did the successful deployment from by [creating a github release as well](https://github.com/qcc-collab-006/orion-deployment/releases/new). The job that creates the tag is called `Release Git Tag / tag (push)`.
10. **Recap time**! Note down any issues that arose during RC creation in the [LeLe table on confluence](https://confluence.cc.bmwgroup.net/x/fHXWD) and make sure we follow up on issues with systematic solutions.

### Rollout playbooks

If rollout procedures require special attention, manual interaction or downtimes to be communicated, they need a playbook
to describe the process. These playbooks are stored in the [playbooks](./playbooks) folder for each rollout and are to
be kept up to date by development.

### Setting up local poetry

[Poetry](https://python-poetry.org/) is a python dependency management tool used in the repo. Setting this up in your local environment will significantly ease local development.

To install poetry verify if you have the correct python version set: 3.10.X

Then execute the following in the root of the repository:

> `pip install poetry==1.8.3`
> `poetry install`

### Executing local pre-commit script

To be able to execute the pre-commit scripts - you will need to install a tool called pre-commit.

> `pip install pre-commit`
> `pre-commit --version`

Now change the directory to the root of the repo if not done previously

Here you should be able to find the .pre-commit-config.yaml  file.

Now you can execute as follow:

> `pre-commit run --all-files`

At the output of the script you will get a report with all the adjustments that the linter made to your code as well as some issues that it could not solve on its own.

On running pre-commit the issues fixed by tools itself except for ruff. For ruff it is your job now to fix these issues, most likely there is an easy fix that the tool might suggest itself!

In rare, very rare cases it may happen that you know that your code is OK but the linter tries to force you to change something - you can use a magic comment to override the linter - add `# noqa <ERROR_NUMBER> ` to the line of code where the linter sees the issue.

For noqa rules please refer CODING_GUIDELINES.md

> *USE THIS WITH CAUTION! Those tests are executed for a reason and just because there is a workaround - you should now overuse it*

> *Remember! Executing pre-commit makes changes to your files! It should not impact the logic of your code but ultimately it is up to you to guarantee that the code is OK*

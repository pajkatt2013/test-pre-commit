# Coding Guidelines

This document aims to give certain guidelines, which, as long as they are
mentioned here, are not enforced automatically. As soon as there are automated
checks in place for a specific topic, then the guideline will not mention that
topic any more. Examples for this are code-formatting and static analysis.

All of these guidelines are a rule of thumb. As no automated enforcing is in
place or (reasonably) possible, meaning there can be deviations to them.
Deviations must be explained and reasoned when they are introduced.

## Python

### Warning suppressions

All warning suppressions must be explained with a comment close to the suppression.

```python
# DO: Explain suppression with a comment
subprocess.run(cmd, check=True)  # noqa: S603 # running in safe environment and not accepting arbitrary user input

# DON'T: Leave suppression uncommented
postgres_serverless_cluster_stack = SandboxPostgresServerlessClusterStack(  # noqa: E501
```

**Rational for guideline**: Warnings emitted by the linters must be carefully considered.
Without an explanation, suppressions are a dangerous code smell. When the code is eventually
changed, a suppression might become unneeded. With an explanation it is easier to judge
whether it is still needed.

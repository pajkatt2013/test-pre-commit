INSERT INTO rpu_type(rpu_type_id)
VALUES ('QRP_AEB'),
       ('QRP_CV')
ON CONFLICT (rpu_type_id) DO NOTHING;

INSERT INTO logger_stream(logger_stream_id)
VALUES ('AVP_STACK_INPUT'),
       ('CV_DRIVING_DEBUG'),
       ('FCW_MIPI')
ON CONFLICT (logger_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata (id, version, rpu_type, software_version)
VALUES('01_aeb', 0, 'QRP_AEB', '1.0.0'),
      ('01_cv', 0, 'QRP_CV', '1.0.0')
ON CONFLICT (id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_input_logger_stream(rpu_metadata_id, input_stream_id)
VALUES('01_cv', 'AVP_STACK_INPUT'), ('01_cv', 'CV_DRIVING_DEBUG'), ('01_cv', 'FCW_MIPI'),
      ('01_aeb', 'AVP_STACK_INPUT'), ('01_aeb', 'CV_DRIVING_DEBUG'), ('01_aeb', 'FCW_MIPI')
ON CONFLICT (rpu_metadata_id, input_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_output_logger_stream(rpu_metadata_id, output_stream_id)
VALUES('01_cv', 'AVP_STACK_INPUT'), ('01_cv', 'CV_DRIVING_DEBUG'), ('01_cv', 'FCW_MIPI'),
      ('01_aeb', 'AVP_STACK_INPUT'), ('01_aeb', 'CV_DRIVING_DEBUG'), ('01_aeb', 'FCW_MIPI')
ON CONFLICT (rpu_metadata_id, output_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata (id, version, rpu_type, software_version)
VALUES('02_cv', 0, 'QRP_CV', '1.1.0')
ON CONFLICT (id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_input_logger_stream(rpu_metadata_id, input_stream_id)
VALUES('02_cv', 'AVP_STACK_INPUT'), ('02_cv', 'CV_DRIVING_DEBUG'), ('02_cv', 'FCW_MIPI')
ON CONFLICT (rpu_metadata_id, input_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_output_logger_stream(rpu_metadata_id, output_stream_id)
VALUES('02_cv', 'AVP_STACK_INPUT'), ('02_cv', 'CV_DRIVING_DEBUG'), ('02_cv', 'FCW_MIPI')
ON CONFLICT (rpu_metadata_id, output_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata (id, version, rpu_type, software_version)
VALUES('03_cv', 0, 'QRP_CV', '1.2.0')
    ON CONFLICT (id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_input_logger_stream(rpu_metadata_id, input_stream_id)
VALUES('03_cv', 'AVP_STACK_INPUT'), ('03_cv', 'CV_DRIVING_DEBUG'), ('03_cv', 'FCW_MIPI')
    ON CONFLICT (rpu_metadata_id, input_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_output_logger_stream(rpu_metadata_id, output_stream_id)
VALUES('03_cv', 'AVP_STACK_INPUT'), ('03_cv', 'CV_DRIVING_DEBUG'), ('03_cv', 'FCW_MIPI')
    ON CONFLICT (rpu_metadata_id, output_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata (id, version, rpu_type, software_version)
VALUES('04_cv', 0, 'QRP_CV', '1.3.0')
    ON CONFLICT (id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_input_logger_stream(rpu_metadata_id, input_stream_id)
VALUES('04_cv', 'AVP_STACK_INPUT'), ('04_cv', 'CV_DRIVING_DEBUG'), ('04_cv', 'FCW_MIPI')
    ON CONFLICT (rpu_metadata_id, input_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_output_logger_stream(rpu_metadata_id, output_stream_id)
VALUES('04_cv', 'AVP_STACK_INPUT'), ('04_cv', 'CV_DRIVING_DEBUG'), ('04_cv', 'FCW_MIPI')
    ON CONFLICT (rpu_metadata_id, output_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata (id, version, rpu_type, software_version)
VALUES('05_cv', 0, 'QRP_CV', '1.4.0')
    ON CONFLICT (id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_input_logger_stream(rpu_metadata_id, input_stream_id)
VALUES('05_cv', 'AVP_STACK_INPUT'), ('05_cv', 'CV_DRIVING_DEBUG'), ('05_cv', 'FCW_MIPI')
    ON CONFLICT (rpu_metadata_id, input_stream_id) DO NOTHING;

INSERT INTO raas_rpu_metadata.rpu_metadata_output_logger_stream(rpu_metadata_id, output_stream_id)
VALUES('05_cv', 'AVP_STACK_INPUT'), ('05_cv', 'CV_DRIVING_DEBUG'), ('05_cv', 'FCW_MIPI')
    ON CONFLICT (rpu_metadata_id, output_stream_id) DO NOTHING;

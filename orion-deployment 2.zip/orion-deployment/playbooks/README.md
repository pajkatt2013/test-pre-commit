## Rollout playbooks

If an upcoming rollout requires anything other than running the deployment pipelines with the agreed upon RC, a playbook
should be created to describe the process. While preparing for a new RC, all steps and notes are to be added to
[NEXT](NEXT.md). Once the RC is deployed, the playbook is to be renamed to reflect the date of the rollout and include
the tag name.

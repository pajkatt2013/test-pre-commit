## Rollout procedure for RC <XXX>

### Overall procedure steps

1. Announce a downtime requirement via the respective communication channels (see steps below for estimated duration)
    1. The downtime will affect the API gateways, any client will receive a `503` response with a header `Retry-After: 120`
       which should be respected.
    2. The downtime is expected to take up to 30 minutes, depending on how quickly the deployment job can re-create the
       load balancers and VPC links.
2. Run the migration script from PR #851
    1. Prepare AWS credentials in a shell
    2. Set `kubectl` context to the correct target stage
    3. Run the migration script
    4. Ensure the VPC links are dropped in the AWS console
    5. Ensure the Kubernetes `LoadBalancer` resources are deleted
3. Trigger the usual deployment job with the new RC tag

### [#851](https://github.com/qcc-collab-006/orion-deployment/pull/851)

#### Description

This will deploy service Helm charts that are now including `bitnami/common` for various helper utilities.
It required a change in naming of some Kubernetes resources, especially `ServiceAccount`s and `Service`s. These will now
be named like the component/Helm chart.

Since the `LoadBalancer` objects will also be renamed, the existing LBs cannot simply be deleted by Helm, as they are
all referenced by the API Gateway's VPC links. In order to delete the old LBs, the API gateway integrations pointing to
VPC links have to be replaced by mock integrations first.

#### Step details

A [migration script](../scripts/migrate_loadbalancers.sh) was added to automate the creation of mock integrations,
deletion of VPC links and removal of outdated Kubernetes `LoadBalancer` resources.

Follow the hints listed in the script, especially to prepare AWS credentials in a shell and set `kubectl` context to the
correct target stage. If you can run the following commands with meaningful results and no errors, you're good to go:

```shell
aws apigateway get-rest-apis
kubectl get svc -n raas-services
```

#### Estimated impact

While the VPC links are removed, the API gateways will respond with a status code `503`. On development stage, it took
about 8 minutes to update all integrations, remove the VPC links and delete the load balancers.

#### Risk

#!/usr/bin/env bash
#
# Software created within Project Orion.
# Copyright (C) 2024-2025 Bayerische Motoren Werke Aktiengesellschaft (BMW AG) and/or
# Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
# Authorship details are documented in the Git history.
#

set -euo pipefail

export INSTALL_LAMBDA_DEPS_PIP_CACHE_DIR="$2"

# The singlequotes for the shell -c invocation are intentional, we only want the
# shellcheck disable=SC2016
find "$1" \
  -type f \
  -name requirements.txt \
  -not -path '*/venv/*' \
  -print0 |
  xargs -0 -I{} sh -c 'cd $(dirname {}) && python -m pip --cache-dir="$INSTALL_LAMBDA_DEPS_PIP_CACHE_DIR" install --platform manylinux2014_x86_64 --target . --implementation cp --python-version 3.10 --only-binary=:all: -r $(basename {})'

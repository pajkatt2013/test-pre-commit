#### Why?

_Why am I proposing this change/addition?_

#### What?

_What is this PR changing. No reason to repeat what can be seen in the "Files" tab of the PR,
but rather describe it from a higher level of abstraction..._

#### PR Author Checklist

* [ ] I have documented any steps needed to perform manual testing: _{ e.g.: link to PR description
  or Confluence-WIKI }_
* [ ] I have added details to the [latest rollout playbook](../blob/main/playbooks/NEXT.md) (if applicable)

#### Reminder for the reviewer(s)

We aim to follow [these review guidelines](https://google.github.io/eng-practices/review/reviewer/).

Issue: ORIONINIT-XXX

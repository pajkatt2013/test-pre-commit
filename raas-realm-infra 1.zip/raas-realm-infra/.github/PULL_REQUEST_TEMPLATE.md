#### Why?

_Why am I proposing this change/addition?_

#### What?

_What is this PR changing. No reason to repeat what can be seen in the "Files" tab of the PR,
but rather describe it from a higher level of abstraction ..._

Issue: ORIONINIT-XXX

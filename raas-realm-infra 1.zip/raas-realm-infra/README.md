# RaaS Realm Infra

[![Continuous Deployment to CICD](https://github.com/qcc-collab-006/raas-realm-infra/actions/workflows/continuous_deployment_to_cicd.yaml/badge.svg)](https://github.com/qcc-collab-006/raas-realm-infra/actions/workflows/continuous_deployment_to_cicd.yaml)

[![Continuous Deployment to Dev Europe](https://github.com/qcc-collab-006/raas-realm-infra/actions/workflows/continuous_deployment_to_dev_europe.yaml/badge.svg)](https://github.com/qcc-collab-006/raas-realm-infra/actions/workflows/continuous_deployment_to_dev_europe.yaml)

[![Continuous Deployment to Dev China](https://github.com/qcc-collab-006/raas-realm-infra/actions/workflows/continuous_deployment_to_dev_china.yaml/badge.svg)](https://github.com/qcc-collab-006/raas-realm-infra/actions/workflows/continuous_deployment_to_dev_china.yaml)

## Overview

This repository uses [Seedfarmer](https://seed-farmer.readthedocs.io/en/latest/usage.html) to deploy the following manifests:

- `manifests/realm-apps` -- Elastic Container Repositories (ECR) that are deployed to the RaaS CI/CD account.
- `manifests/realm-infra` -- Baseline infrastructure deployed to RaaS dev/int/prod accounts.

Go to [RaaS Confluence](https://confluence.cc.bmwgroup.net/display/orioncn/Reprocessing+as+a+Service+(RaaS)) for more information.

## Developer Namespace

> Important: You are responsible for managing your workspace and destroying it when its no longer necessary.

### Developer Namespace with Github Action

In order to deploy a new namespace, just use the [Deployment to sandbox](https://github.com/qcc-collab-006/raas-realm-infra/actions/workflows/deployment_to_sandbox.yaml) pipeline. You can use the same pipeline to destroy your environment.

### Developer Namespace deployed from local

First make sure to setup a python virtual environment and install dependencies:

```bash
pyenv install 3.9
pyenv virtualenv 3.9 raas-realm
pyenv local raas-realm
pip install -r requirements.txt
```

Go to [AWS accounts](https://orionadp.awsapps.com/start/#/?tab=accounts) and set credentials of RaaS CICD account.

```bash
export AWS_ACCESS_KEY_ID="..."
export AWS_SECRET_ACCESS_KEY="..."
export AWS_SESSION_TOKEN="..."
```

Then set the following static environment variables and source configuration:

```bash
export BRANCH=dev
export AWS_REGION=eu-central-1
source config/common.env
source config/aws/common.env
source config/aws/dev.env
```

Make sure to set a unique namespace:

```bash
export NAMESPACE=-<your initials> # make up a unique name with at most 3 letters
export AURORA_APP_DOMAIN_NAME=$NAMESPACE-aurora.t1-r3-dev.realm.orionadp.com
```

Dry run:

```bash
seedfarmer apply manifests/realm-infra/deployment.yaml --debug --qualifier Dev000 --dry-run
```

And deploy:

```bash
seedfarmer apply manifests/realm-infra/deployment.yaml --debug --qualifier Dev000
```

And destroy:

```bash
seedfarmer destroy manifests/realm-infra/deployment.yaml --debug --qualifier Dev000
```

Check for active deployments with:

```bash
seedfarmer list deployments
```

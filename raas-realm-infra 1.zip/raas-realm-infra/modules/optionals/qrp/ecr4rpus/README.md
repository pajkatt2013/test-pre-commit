# ECR for RPU (ecr4rpus) Module

## Description

This module creates elastic container registry and add permissions to the existing IAM role for the specific user, who should be able to assume the IAM role.

## Inputs/Outputs

### Input Paramenters

#### Required

- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.

#### Optional

- `repository_names`: JSON list of partial names of the ecr repositories, it is combined with a label generator to generate a unique name among deployments
- `image_tag_mutability`: Image tag mutability. Defaults to `"MUTABLE"`. Possible values: `"IMMUTABLE"` or `"MUTABLE"`
- `lifecycle_max_days`: Max days to store the images in ECR. Defaults to `None`, (no removal of images)
- `lifecycle_max_image_count`: Max images to store the images in ECR. Defaults to `None`, (no removal of images)
- `bu_name`- business unit name (e.g, aptiv)
- `namespace`: Target namespace of deployment
- `stage`: Target stage of deployment
- `include_namespace`: Flag parameter to enable or disable the inclusion of the naming component namespace for ecr repo
- `image_transfer_cross_account_access_role_arn`: cross account access role arn, used to add policy to the role for specific actions on created ecr repository for specific user
- `access-role-arn`: ARN of the role created by explicit iam role creation module
#### Input Example

```yaml
parameters:
  - name: stage
    valueFrom:
      envVariable: STAGE

  - name: namespace
    valueFrom:
      envVariable: NAMESPACE

  - name: bu_name
    valueFrom:
      envVariable: BU_NAME

  - name: repository_names
    value: >
      [
        "pytorch_10",
        "pytorch_20"
      ]

  - name: access-role-arn
    valueFrom:
      moduleMetadata:
        group: supplier-iam
        name: s3-ecr-role
        key: RoleArn

  - name: cost-allocation-tag
    value:
      - key: customer_function
        value: common
      - key: maintainer
        value: raas_devops

  - name: include_namespace
    value: False

```

### Module Metadata Outputs

- `RepositoryName`: full names of ecr repositories created in the stack
- `RepositoryARN`: ARNs of ecr repositories created in the stack

#### Output Example

```json
{
    "RepositoryName":'["pytorch_10","pytorch_20"]',
    "RepositoryARN": '["arn:aws:ecr:<REGION>:<ACCOUNT_ID>:repository/pytorch_10","arn:aws:ecr:<REGION>:<ACCOUNT_ID>:repository/pytorch_20"]'
}


### Using of ecr4rpus module

#### Import from the same repository
```yaml
path: modules/ecr/ecr4rpus

```

#### Import using git URL

```yaml
# Import head version of specific branch
# raas-seedfarmer-modules
path: git::codecommit::eu-central-1://raas-seedfarmer-modules.git//modules/ecr/ecr4rpus/?ref=heads/<your-branch-name>
# orion-modules
path: git::codecommit::eu-central-1://CrossAccountAccessProfile@orion-modules.git//modules/ecr/ecr4rpus/?ref=heads/<your-branch-name>

# Import tagged version
# raas-seedfarmer-modules
path: git::codecommit::eu-central-1://raas-seedfarmer-modules.git//modules/ecr/ecr4rpus/?ref=<your-tag-name>
# orion-modules
path: git::codecommit::eu-central-1://CrossAccountAccessProfile@orion-modules.git//modules/ecr/ecr4rpus/?ref=<your-tag-name>

```

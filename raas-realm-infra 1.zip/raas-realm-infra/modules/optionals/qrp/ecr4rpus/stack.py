import json
from typing import Any, Dict, Optional

import cdk_nag
from aws_cdk import Aspects, Duration, RemovalPolicy, Stack, Tags
from aws_cdk import aws_ecr as ecr
from aws_cdk import aws_iam as iam
from constructs import Construct
from utils import LabelGenerator

IMAGE_MUTABILITY = {
    "IMMUTABLE": ecr.TagMutability.IMMUTABLE,
    "MUTABLE": ecr.TagMutability.MUTABLE,
}


class EcrStack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        namespace: str,
        bu_name: str,
        construct_id: str,
        config: Dict[str, Any],
        include_namespace: bool,
        repository_names: list[str],
        access_role_arn: str,
        image_transfer_cross_account_access_role_arn: str,
        image_tag_mutability: str,
        lifecycle_max_image_count: Optional[str],
        lifecycle_max_days: Optional[str],
        tags: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        for k, v in config.items():
            setattr(self, k, v)

        lg = LabelGenerator(
            prefix=config["deployment_name"],
            namespace=namespace,
            stage=stage,
            bu_name=bu_name,
            aws_env=kwargs["env"],
        )

        full_repo_names_list = []
        repo_arns_list = []

        for repository_name in repository_names:
            self.repository_name_id = lg.get_label(
                resource_type="ecr",
                resource_name=repository_name,
                include_bu=True,
                include_namespace=include_namespace,
                replace_underline=False,
                replace_slash=False,
                lowercase_only=True,
            )

            self.repository = ecr.Repository(
                self,
                self.repository_name_id,
                repository_name=self.repository_name_id,
                image_tag_mutability=IMAGE_MUTABILITY[image_tag_mutability],
                removal_policy=RemovalPolicy.DESTROY,
                auto_delete_images=True,
            )

            if lifecycle_max_days is not None:
                self.repository.add_lifecycle_rule(
                    max_image_age=Duration.days(int(lifecycle_max_days))
                )

            if lifecycle_max_image_count is not None:
                self.repository.add_lifecycle_rule(
                    max_image_count=int(lifecycle_max_image_count)
                )

            full_repo_names_list.append(self.repository.repository_name)
            repo_arns_list.append(self.repository.repository_arn)

            if access_role_arn:
                access_role = iam.Role.from_role_arn(
                    scope=self,
                    id=f"{self.repository_name_id}_ecr_access",
                    role_arn=access_role_arn,
                )

                new_ecr_policy_stmt = {
                    "Effect": "Allow",
                    "Action": [
                        "ecr:BatchGetImage",
                        "ecr:BatchCheckLayerAvailability",
                        "ecr:CompleteLayerUpload",
                        "ecr:GetDownloadUrlForLayer",
                        "ecr:InitiateLayerUpload",
                        "ecr:PutImage",
                        "ecr:UploadLayerPart",
                    ],
                    "Resource": [self.repository.repository_arn],
                }

                access_role.add_to_principal_policy(
                    iam.PolicyStatement.from_json(new_ecr_policy_stmt)
                )

            if image_transfer_cross_account_access_role_arn:
                image_transfer_cross_account_access_role = iam.Role.from_role_arn(
                    scope=self,
                    id=f"{self.repository_name_id}_image_transfer_cross_account_ecr_access",
                    role_arn=image_transfer_cross_account_access_role_arn,
                )

                new_ecr_image_transfer_policy_stmt = {
                    "Effect": "Allow",
                    "Action": [
                        "ecr:GetDownloadUrlForLayer",
                        "ecr:BatchGetImage",
                        "ecr:DescribeImages",
                        "ecr:GetAuthorizationToken",
                        "ecr:BatchCheckLayerAvailability",
                    ],
                    "Resource": [self.repository.repository_arn],
                }

                image_transfer_cross_account_access_role.add_to_principal_policy(
                    iam.PolicyStatement.from_json(new_ecr_image_transfer_policy_stmt)
                )
            else:
                print(
                    f"[INFO] The variable <{image_transfer_cross_account_access_role_arn}> is None object"
                )

        self.full_repository_names = json.dumps(full_repo_names_list)
        self.repository_arns = json.dumps(repo_arns_list)

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

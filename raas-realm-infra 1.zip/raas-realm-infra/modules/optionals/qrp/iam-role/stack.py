from typing import Any, Dict, cast

from aws_cdk import Stack, Tags
from aws_cdk import aws_iam as iam
from constructs import Construct, IConstruct
from utils import LabelGenerator


class IAMStack(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        namespace: str,
        stage: str,
        bu_name: str,
        config: Dict[str, Any],
        hash: str,
        iam_role_name: str,
        iam_role_trusted_account: str,
        aws_managed_policies: list,
        assume_role_service_principals: list,
        tags: list,
        **kwargs: Any,
    ) -> None:
        # ADDF Env vars

        for k, v in config.items():
            setattr(self, k, v)

        super().__init__(
            scope,
            id,
            description="This stack deploys empty IAM role for ADDF",
            **kwargs,
        )

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", self.deployment_name)
        add_tag("Module", self.module_name)
        for kv in tags:
            add_tag(kv["key"], kv["value"])

        lg = LabelGenerator(
            prefix=config["deployment_name"],
            namespace=namespace,
            stage=stage,
            bu_name=bu_name,
            aws_env=kwargs["env"],
        )

        # Creates IAM role
        iam_role_name = lg.get_label(
            resource_type="role",
            resource_name=iam_role_name,
            include_bu=True,
            include_namespace=True,
            include_stage=True,
            include_resource_type=True,
        )

        if iam_role_trusted_account:
            trusted_entity = iam.AccountPrincipal(iam_role_trusted_account)
        else:
            trusted_entity = iam.AccountRootPrincipal()

        self.iam_role = iam.Role(
            self, iam_role_name, role_name=iam_role_name, assumed_by=trusted_entity
        )

        if aws_managed_policies:
            for policy in aws_managed_policies:
                self.iam_role.add_managed_policy(
                    iam.ManagedPolicy.from_aws_managed_policy_name(policy)
                )

        if assume_role_service_principals:
            for service_principal in assume_role_service_principals:
                self.iam_role.assume_role_policy.add_statements(
                    iam.PolicyStatement(
                        actions=["sts:AssumeRole"],
                        principals=[iam.ServicePrincipal(service_principal)],
                    )
                )

# IAM Role Creator

## Description

This module creates an empty IAM role

## Inputs/Outputs

### Input Paramenters

#### Required

None

#### Optional

- `iam_role_name`: IAM role name, which will be created by this module
- `bu_name`- business unit name (e.g, aptiv)
- `namespace`: Namespace used in config
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.
- `aws_managed_policies`: A list of names of AWS-managed IAM policies to attach to the role
- `assume_role_iam_principals` - A list of IPrincipals to be granted assume on this role role

### Module Metadata Outputs

- `RoleName`: name of the IAM role created
- `RoleArn`: ARN of the IAM role created

# SQS Module

## Description

This module creates SQS queue (and Dead Letter Queue for itself)

## Inputs/Outputs

### Input Paramenters

#### Required

- `queue_suffix`: Suffix added to the SQS queue name. Created name will follow the pattern - `{DEPLOYMENT-NAME}-{STAGE}-{QUEUE_SUFFIX}`.

#### Optional

- `receive_message_wait_time`: Default wait time for ReceiveMessage calls. Does not wait if set to 0, otherwise waits this amount of seconds by default for messages to arrive. For more information, see Amazon SQS Long Poll. Default: 20

### Module Metadata Outputs
- `queueName`: SQS queue name


#### Output Example


```json
{
    "queueName": "realm-infra-mz-dev-jobs",
}

```

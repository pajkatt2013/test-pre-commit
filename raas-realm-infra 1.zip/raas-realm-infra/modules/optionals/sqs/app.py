#!/usr/bin/env python3
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import SqsStack

DEFAULT_RECEIVE_MESSAGE_WAIT_TIME = 20
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


queue_suffix = os.environ[_param("QUEUE_SUFFIX")]
receive_message_wait_time = (
    int(os.environ[_param("RECEIVE_MESSAGE_WAIT_TIME")])
    if _param("RECEIVE_MESSAGE_WAIT_TIME") in os.environ
    else DEFAULT_RECEIVE_MESSAGE_WAIT_TIME
)

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

app = cdk.App()
stack = SqsStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    stage=os.getenv("ADDF_PARAMETER_STAGE", "default"),
    deployment_name=deployment_name,
    env=environment,
    queue_suffix=queue_suffix,
    receive_message_wait_time=receive_message_wait_time,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "queueName": stack.sqs_queue.queue_name,
        }
    ),
)

app.synth()

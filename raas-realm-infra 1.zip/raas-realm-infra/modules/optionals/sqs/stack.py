import cdk_nag
from aws_cdk import Aspects, Duration, Stack
from aws_cdk import aws_sqs as sqs
from constructs import Construct
from utils import LabelGenerator


class SqsStack(Stack):
    DLQ_RECEIVE_MESSAGE_WAIT_TIME = 20

    def __init__(
        self,
        scope: Construct,
        id: str,
        stage: str,
        deployment_name: str,
        queue_suffix: str,
        receive_message_wait_time: int,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description=f"SQS Queue {deployment_name=} {queue_suffix=}",
            **kwargs,
        )

        lg = LabelGenerator(
            deployment_name=deployment_name, stage=stage, aws_env=kwargs["env"]
        )
        sqs_queue_dlq = sqs.Queue(
            self,
            "queue-dlq",
            queue_name=f"{lg.get_label(queue_suffix)}-dlq",
            encryption=sqs.QueueEncryption.SQS_MANAGED,
            enforce_ssl=True,
            receive_message_wait_time=Duration.seconds(
                self.__class__.DLQ_RECEIVE_MESSAGE_WAIT_TIME
            ),
        )
        cdk_nag.NagSuppressions.add_resource_suppressions(
            sqs_queue_dlq,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-SQS3", reason="This is DLQ"
                ),
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-SQS2",
                    reason="Queue has SQS managed encryption enabled",
                ),
            ],
        )
        self.dead_letter_queue = sqs.DeadLetterQueue(
            max_receive_count=5, queue=sqs_queue_dlq
        )
        self.sqs_queue = sqs.Queue(
            self,
            "queue",
            queue_name=lg.get_label(queue_suffix),
            encryption=sqs.QueueEncryption.SQS_MANAGED,
            enforce_ssl=True,
            dead_letter_queue=self.dead_letter_queue,
            receive_message_wait_time=Duration.seconds(receive_message_wait_time),
        )

        cdk_nag.NagSuppressions.add_resource_suppressions(
            self.sqs_queue,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-SQS2",
                    reason="Queue has SQS managed encryption enabled",
                ),
            ],
        )
        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

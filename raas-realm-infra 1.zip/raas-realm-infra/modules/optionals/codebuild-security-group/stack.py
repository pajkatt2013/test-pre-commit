import cdk_nag
from aws_cdk import Aspects, Stack
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_ssm as ssm
from constructs import Construct
from utils import LabelGenerator


class SecurityGroupStack(Stack):
    def __init__(
        self,
        scope: Construct,
        id: str,
        stage: str,
        deployment_name: str,
        vpc_id: str,
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="CodeBuild Security Group",
            **kwargs,
        )

        lg = LabelGenerator(
            deployment_name=deployment_name, stage=stage, aws_env=kwargs["env"]
        )

        vpc = ec2.Vpc.from_lookup(
            self,
            "VPC",
            vpc_id=vpc_id,
        )

        security_group_name = lg.get_label("codebuild-sg", include_region=True)
        security_group = ec2.SecurityGroup(
            self, "CodeBuildSG", vpc=vpc, security_group_name=security_group_name
        )
        # security_group.add_egress_rule(ec2.Peer.any_ipv4(), ec2.Port.all_traffic())

        self.ssm_parameter = ssm.StringParameter(
            self,
            "CodeBuildSGParameter",
            parameter_name="/addf/codebuild/security_group",
            string_value=f'["{security_group.security_group_id}"]',
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

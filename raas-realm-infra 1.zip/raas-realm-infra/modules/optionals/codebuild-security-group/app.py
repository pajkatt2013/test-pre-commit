#!/usr/bin/env python3
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import SecurityGroupStack

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


vpc_id = os.environ[_param("VPC")]

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

app = cdk.App()
stack = SecurityGroupStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    stage=os.getenv("STAGE", "dev"),
    deployment_name=deployment_name,
    env=environment,
    vpc_id=vpc_id,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "ssmParameterName": stack.ssm_parameter.parameter_name,
        }
    ),
)

app.synth()

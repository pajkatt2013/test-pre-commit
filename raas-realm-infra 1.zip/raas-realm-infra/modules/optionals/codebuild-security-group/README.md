# CodeBuild Security Group Module

## Description

This module creates Security Group from CodeBuild.
By default CodeBuild runs in the AWS backbone. However, when we run EKS in the private API endpoint mode it cannot be accessed from AWS backbone. This means CodeBuild needs to be put into the VPC and assigned Security Group.
In the `deployment.yaml` this security group will be used in the `network` block, for example:

```yaml
        network:
          vpcId:
            valueFrom:
              parameterStore: /orionadp/blueprint/vpc/network-onprem-vpc/vpc-id
          privateSubnetIds:
            valueFrom:
              parameterStore: /orionadp/blueprint/vpc/network-onprem-vpc/routable-private-subnets
          securityGroupIds:
            valueFrom:
              parameterStore: /addf/codebuild/security_group
```

## Inputs/Outputs

### Input Parameters

#### Required

- `vpc`: VPC id.

#### Optional

### Module Metadata Outputs

#### Output Example


```json
{
    "ssmParameterName": "/realm-app-cicd/codebuild/security_group",
}

```

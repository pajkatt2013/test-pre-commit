from aws_cdk import Duration, Stack
from aws_cdk import aws_events as events
from aws_cdk import aws_sqs as sqs
from aws_solutions_constructs.aws_eventbridge_sqs import EventbridgeToSqs
from constructs import Construct
from utils import LabelGenerator


class EventbridgeToSqsRuleStack(Stack):
    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        stage: str,
        deployment_name: str,
        event_bus_name: str,
        event_name: str,
        queue_suffix: str,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        event_bus = events.EventBus.from_event_bus_name(
            self, "event-bus", event_bus_name
        )

        lg = LabelGenerator(
            deployment_name=deployment_name, stage=stage, aws_env=kwargs["env"]
        )

        self.eventbridge2sqs = EventbridgeToSqs(
            self,
            "eventbridge-sqs",
            event_rule_props=events.RuleProps(
                event_pattern=events.EventPattern(detail_type=[event_name])
            ),
            existing_event_bus_interface=event_bus,
            queue_props=sqs.QueueProps(
                queue_name=lg.get_label(queue_suffix),
                visibility_timeout=Duration.seconds(60),
            ),
            dead_letter_queue_props=sqs.QueueProps(
                queue_name=f"{lg.get_label(queue_suffix)}-dlq",
            ),
        )

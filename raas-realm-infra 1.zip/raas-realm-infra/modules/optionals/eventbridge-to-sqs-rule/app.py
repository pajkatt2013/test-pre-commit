#!/usr/bin/env python3
import os

import aws_cdk as cdk
from aws_cdk import Tags
from stack import EventbridgeToSqsRuleStack

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
app_prefix = f"addf-{deployment_name}-{module_name}"


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

event_name = os.getenv(_param("EVENT_NAME"))
queue_suffix = os.getenv(_param("QUEUE_SUFFIX"))
event_bus_name = os.getenv(_param("EVENT_BUS_NAME"))

app = cdk.App()
stack = EventbridgeToSqsRuleStack(
    scope=app,
    construct_id=app_prefix,
    stage=os.getenv("STAGE", "dev"),
    deployment_name=deployment_name,
    event_name=event_name,
    queue_suffix=queue_suffix,
    event_bus_name=event_bus_name,
    env=environment,
)

Tags.of(stack).add("customer_function", "common")

app.synth()

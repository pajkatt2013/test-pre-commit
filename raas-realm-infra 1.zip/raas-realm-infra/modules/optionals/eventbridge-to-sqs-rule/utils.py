class LabelGenerator:
    def __init__(
        self,
        *,
        deployment_name,
        aws_env,
        stage,
        delim="-",
        module_name=None,
        character_limit=12
    ):
        self.region = aws_env.region
        self.account = aws_env.account
        self.stage = stage  # e.g. dev/int/prod
        self.delim = delim
        self.deployment_name = deployment_name
        self.module_name = module_name

    def get_label(
        self,
        component_name,
        include_stage=True,
        include_module_name=True,
        include_region=False,
    ):
        parts = [self.deployment_name]
        if self.module_name is not None and include_module_name is True:
            parts.append(self.module_name)
        if include_stage is True:
            parts.append(self.stage)
        if include_region is True:
            parts.append(self.region)
        parts.append(component_name)

        # Format [deploymentname]-[stage]-[region]-component
        return self.delim.join(parts).replace("_", self.delim).lower()

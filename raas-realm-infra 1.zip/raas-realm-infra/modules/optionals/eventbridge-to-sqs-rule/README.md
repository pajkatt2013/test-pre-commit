# Eventbridge to SQS Module

## Description

This module creates an Eventbridge Rule targeting an SQS queue.

## Inputs/Outputs

### Input Parameters

#### Required

- `event_name` - detailType of the EventBridge event that will be forwarded to the queue
- `queue_suffix` - SQS queue suffix used for label generation
- `event_bus_name`- realm-local name of EventBus where EventBridge Rule will be created for

#### Optional

### Module Metadata Outputs

from typing import Optional

import cdk_nag
from aws_cdk import Aspects, Duration, RemovalPolicy, Stack
from aws_cdk import aws_ecr as ecr
from constructs import Construct
from utils import LabelGenerator

IMAGE_MUTABILITY = {
    "IMMUTABLE": ecr.TagMutability.IMMUTABLE,
    "MUTABLE": ecr.TagMutability.MUTABLE,
}


class EcrStack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        deployment_name: str,
        construct_id: str,
        repository_names: list[str],
        image_tag_mutability: str,
        lifecycle_max_image_count: Optional[str],
        lifecycle_max_days: Optional[str],
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        lg = LabelGenerator(prefix="app", stage=stage, aws_env=kwargs["env"])

        self.repositories = []
        self.repository_ids = []

        for repository_name in repository_names:
            repository_name_id = lg.get_label(repository_name, include_region=True)
            repository = ecr.Repository(
                self,
                repository_name_id,
                repository_name=repository_name_id,
                image_tag_mutability=IMAGE_MUTABILITY[image_tag_mutability],
                removal_policy=RemovalPolicy.DESTROY,
                auto_delete_images=True,
            )

            if lifecycle_max_days is not None:
                repository.add_lifecycle_rule(
                    max_image_age=Duration.days(int(lifecycle_max_days))
                )

            if lifecycle_max_image_count is not None:
                repository.add_lifecycle_rule(
                    max_image_count=int(lifecycle_max_image_count)
                )

            self.repositories.append(repository)
            self.repository_ids.append(repository_name_id)

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

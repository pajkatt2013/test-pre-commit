# ECR Module multi-repo

## Description

This module creates multiple elastic container registry repositories.

## Inputs/Outputs

### Input Parameters

#### Required

None

#### Optional

- `repository_names`: JSON list of partial names of the ecr repositories, it is combined with a label generator to generate a unique name among deployments
- `image_tag_mutability`: Image tag mutability. Defaults to `"IMMUTABLE"`. Possible values: `"IMMUTABLE"` or `"MUTABLE"`
- `lifecycle_max_days`: Max days to store the images in ECR. Defaults to `None`, (no removal of images)
- `lifecycle_max_image_count`: Max images to store the images in ECR. Defaults to `None`, (no removal of images)

#### Input Example

```json
["avx/tsa-frontend", "avx/lsm_scenario_generation_job"]
```

### Module Metadata Outputs

- `RepositoryName<X>`: ECR repository name <X>, X is a position in the input list
- `RepositoryARN<X>`: ECR repository ARN <X>, X is a position in the input list
- `RepositoryUri<X>`: ECR repository URI <X>, X is a position in the input list


#### Output Example

```json
{
    "RepositoryName1": "realm-infra-<ENV>-<REGION>/avx/tsa-frontend",
    "RepositoryARN1": "arn:aws:ecr:<REGION>:<ACCOUNT_ID>:repository/realm-infra-dev-eu-central-1/avx/tsa-frontend",
    "RepositoryUri1": "<ACCOUNT_ID>.dkr.ecr.<REGION>.amazonaws.com/realm-infra-dev-eu-central-1/avx/tsa-frontend",
    "RepositoryName2": "realm-infra-<ENV>-<REGION>/avx/lsm_scenario_generation_job",
    "RepositoryARN2": "arn:aws:ecr:<REGION>:<ACCOUNT_ID>:repository/realm-infra-dev-eu-central-1/avx/lsm_scenario_generation_job",
    "RepositoryUri2": "<ACCOUNT_ID>.dkr.ecr.<REGION>.amazonaws.com/realm-infra-dev-eu-central-1/avx/lsm_scenario_generation_job"

}

```

import json
import os

from aws_cdk import App, CfnOutput, Environment
from stack import Route53HealthCheckStack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")
stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")
namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "target_realm_account_id": target_realm_account_id,
}
healthcheck_url_list = list(os.getenv(_param("HEALTHCHECK_URL_LIST")).split("\n"))
healthcheck_url_list_no_split = os.getenv(_param("HEALTHCHECK_URL_LIST"))
email_addr = os.getenv(_param("SNS_EMAIL_ADDR"))
protocol = str(os.getenv(_param("PROTOCOL")))
cw_metric_namespace = str(os.getenv(_param("CW_METRIC_NAMESPACE")))
port = str(os.getenv(_param("PORT")))
vpc_id = str(os.getenv(_param("VPC_ID")))

app = App()

stack = Route53HealthCheckStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    namespace=namespace,
    stage=stage,
    config=config,
    cw_metric_namespace=cw_metric_namespace,
    healthcheck_url_list=healthcheck_url_list,
    email_addr=email_addr,
    vpc_id=vpc_id,
    port=port,
    protocol=protocol,
    env=Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
    tags=tag_list,
)


CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "SecurityGroupName": stack.security_group.security_group_id,
            "ListOfEvenbridgeRulesArns": stack.list_of_evenbridge_rules_arns,
        }
    ),
)


app.synth(force=True)

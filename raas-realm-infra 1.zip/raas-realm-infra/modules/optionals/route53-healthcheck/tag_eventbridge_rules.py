import json
import os

import boto3

# Add tags to EventBridge rule via boto3, tagging via CF for EventBridge is not supported yet.


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
module_metadata = json.loads(os.getenv("ADDF_MODULE_METADATA", ""))
tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

tags_list_of_dicts = [
    {"Key": "Deployment", "Value": f"{deployment_name}"},
    {"Key": "Module", "Value": f"{module_name}"},
]
for kv in tag_list:
    tags_list_of_dicts.append({"Key": kv["key"], "Value": kv["value"]})

list_of_evenbridge_rules_arns = module_metadata["ListOfEvenbridgeRulesArns"]

print(f"printing tag list: {tags_list_of_dicts}")
print(f"printing module metadata: {module_metadata}")

for evenbridge_rule_arn in list_of_evenbridge_rules_arns:
    boto3.client("events").tag_resource(
        ResourceARN=evenbridge_rule_arn, Tags=tags_list_of_dicts
    )

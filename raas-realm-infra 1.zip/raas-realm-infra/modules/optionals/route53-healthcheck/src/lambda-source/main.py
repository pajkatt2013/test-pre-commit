import logging
import os

import boto3
import urllib3
import urllib3.util

logger = logging.getLogger()
logger.setLevel(logging.ERROR)


def lambda_handler(event, context):
    cloudwatch = boto3.client("cloudwatch")
    domain = os.environ["domain"]
    port = os.environ["port"]
    path = os.environ["path"]
    protocol = os.environ["protocol"]
    url = f"{protocol}://{domain}:{port}/{path}"
    metric_namespace = os.environ["metric_namespace"]

    try:
        timeout = urllib3.util.Timeout(connect=2.0, read=2.0)
        http = urllib3.PoolManager(timeout=timeout)
        r = http.request("GET", url)
        if r.status <= 499:
            metric = 1
            print("The HTTPS GET Request to " + url + " was successful.")
            print("The HTTPS response code is " + str(r.status))
            cloudwatch.put_metric_data(
                Namespace=metric_namespace,
                MetricData=[
                    {
                        "MetricName": f"Health Check for resource: {domain}",
                        "Dimensions": [
                            {
                                "Name": f"{protocol} Health Check",
                                "Value": f"{protocol} Health Check",
                            }
                        ],
                        "Unit": "None",
                        "Value": metric,
                    },
                ],
            )

        else:
            metric = 0
            print(
                "The HTTPS GET Request to "
                + url
                + " was not successful because it received a HTTPS Client Side or Server Side Error Code."
            )
            print("The HTTPS response code is " + str(r.status))
            cloudwatch.put_metric_data(
                Namespace=metric_namespace,
                MetricData=[
                    {
                        "MetricName": f"Health Check for resource: {domain}",
                        "Dimensions": [
                            {
                                "Name": f"{protocol} Health Check",
                                "Value": f"{protocol} Health Check",
                            }
                        ],
                        "Unit": "None",
                        "Value": metric,
                    },
                ],
            )

    except urllib3.exceptions.ConnectionError as e:
        metric = 0
        cloudwatch.put_metric_data(
            Namespace=metric_namespace,
            MetricData=[
                {
                    "MetricName": f"Health Check for resource: {domain}",
                    "Dimensions": [
                        {
                            "Name": f"{protocol} Health Check",
                            "Value": f"{protocol} Health Check",
                        }
                    ],
                    "Unit": "None",
                    "Value": metric,
                },
            ],
        )

        if "Name or service not known" in str(e):
            print(
                "The domain name "
                + url
                + " does not resolve to an IP address. Kindly ensure the domain name resolves in the VPC."
            )
        elif "refused" in str(e):
            print(
                "The HTTPS connection was refused by the endpoint. Please check if the endpoint is listening for HTTPS connections on the correct port."
            )
        elif "timed out" in str(e):
            print(
                "The HTTPS connection timed out because a HTTPS response was not received within the 2 seconds timeout period."
            )
        elif "SSLError" in str(e):
            print("The HTTPS connection timed out due to SSL error.")
        else:
            logger.error("Error: " + str(e))

    except Exception:
        metric = 0
        cloudwatch.put_metric_data(
            Namespace=metric_namespace,
            MetricData=[
                {
                    "MetricName": f"Health Check for resource: {domain}",
                    "Dimensions": [
                        {
                            "Name": f"{protocol} Health Check",
                            "Value": f"{protocol} Health Check",
                        }
                    ],
                    "Unit": "None",
                    "Value": metric,
                },
            ],
        )
        logger.error("An error occurred while performing the health check")

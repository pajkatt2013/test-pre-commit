# IAM Role Creator

## Description

This module creates a healthcheck for a list of non-public endpoints.
It leverages a http/https request done via a Lambda function with results stored in Cloudwatch metrics. This metrics are used as a source for Cloudwatch Alarm, that in turn is used as a source for a Route 53 healthcheck.

## Inputs/Outputs

### Input Paramenters

#### Required

- `vpc_id`: VPC in which the resources will be deployed
- `stage`- Stage that the modules is deployed in
- `namespace`: Namespace used the resources will be deployed in
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.
- `healthcheck_url_list`: List of full url that will be monitored, usually provide via config
- `protocol`: Protocol that will be used to health check
- `port`: Port that will be used to health check
- `cw_metric_namespace`: Name of the Cloudwatch metric that will used as a storing the HC responses

#### Optional



### Module Metadata Outputs

- `SecurityGroupName`: name of the security group used by the Lambda functions
- `ListOfEvenbridgeRulesArns`: ARN of the IAM EventBridge rule created

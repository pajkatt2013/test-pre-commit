import os
from typing import Any, Dict, cast

from aws_cdk import Aws, Duration, Stack, Tags
from aws_cdk import aws_cloudwatch as cloudwatch
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_events as events
from aws_cdk import aws_events_targets
from aws_cdk import aws_iam as iam
from aws_cdk import aws_lambda
from aws_cdk import aws_route53 as route53
from aws_cdk import aws_sns as sns
from aws_cdk import aws_sns_subscriptions as subs
from constructs import Construct, IConstruct
from utils import LabelGenerator


class Route53HealthCheckStack(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        namespace: str,
        stage: str,
        config: Dict[str, Any],
        tags: list,
        port: str,
        cw_metric_namespace: str,
        healthcheck_url_list: list,
        email_addr: str,
        vpc_id: str,
        protocol: str,
        **kwargs: Any,
    ) -> None:
        # ADDF Env vars

        for k, v in config.items():
            setattr(self, k, v)

        # CDK Env Vars
        region: str = Aws.REGION

        super().__init__(
            scope,
            id,
            description="This stack deploys a Route53 Healthcheck a on list of domain names provided",
            **kwargs,
        )

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", self.deployment_name)
        add_tag("Module", self.module_name)

        for kv in tags:
            add_tag(kv["key"], kv["value"])

        lg = LabelGenerator(
            prefix=config["deployment_name"],
            namespace=namespace,
            stage=stage,
            aws_env=kwargs["env"],
        )
        # Prepare a list of rule ARNs for export for tagging separately, tagging rules via CDK is not supported
        self.list_of_evenbridge_rules_arns = []

        # Importing the VPC
        self.vpc = ec2.Vpc.from_lookup(self, id="VPC", vpc_id=vpc_id)

        # Security Group for Lambda execution
        security_group_name = lg.get_label(
            resource_type="security_group",
            resource_name="route53-healtcheck",
            include_prefix=True,
        )

        self.security_group = ec2.SecurityGroup(
            self,
            id=f"{id}-security_group",
            security_group_name=security_group_name,
            vpc=self.vpc,
            allow_all_outbound=True,
        )

        # Creates IAM role for Lambda to assume
        iam_role_name = lg.get_label(
            resource_type="role",
            resource_name="route53-healtcheck",
            include_prefix=True,
        )

        self.iam_role = iam.Role(
            self,
            id=f"{id}-iam_role",
            role_name=iam_role_name,
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
        )

        self.iam_role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    "logs:PutLogEvents",
                    "logs:CreateLogStream",
                    "logs:CreateLogGroup",
                    "logs:DescribeLogStreams",
                    "cloudwatch:PutMetricData",
                    "ec2:CreateNetworkInterface",
                    "ec2:DescribeNetworkInterfaces",
                    "ec2:DeleteNetworkInterface",
                    "lambda:*",
                ],
                resources=["*"],
            )
        )

        # For every URL provided in the config create:
        # A Lambda healhcheck function that posts to Cloudwatch metrics
        # An EventBridge schedule trigger for that lambda
        # A Cloudwatch alarm to use as source for Route53 Healthcheck
        # A Route53 HealthCheck
        lambda_src_code_path = os.path.join(
            os.path.dirname(__file__), "src/lambda-source"
        )
        for url in healthcheck_url_list:
            if "/" in url:
                domain, path = str(url).split("/", maxsplit=1)
            else:
                domain = url
                path = ""

            # Lambda creation
            lambda_function_name = lg.get_label(
                resource_type="lambda",
                resource_name=f"healthcheck-{domain.split('.')[0]}",
                include_prefix=True,
            )

            lambda_function = aws_lambda.Function(
                self,
                id=f"{id}-{domain}",
                function_name=lambda_function_name,
                runtime=aws_lambda.Runtime.PYTHON_3_9,
                handler="main.lambda_handler",
                code=aws_lambda.Code.from_asset(lambda_src_code_path),
                vpc=self.vpc,
                role=self.iam_role,
                security_groups=[self.security_group],
                timeout=Duration.seconds(5),
                environment={
                    "protocol": protocol,
                    "domain": domain,
                    "port": port,
                    "path": path,
                    "metric_namespace": cw_metric_namespace,
                },
            )

            # Eventbus rule creation
            event_rule_name = lg.get_label(
                resource_type="eventbridge-rule",
                resource_name=f"healthcheck-trigger-{domain.split('.')[0]}",
                include_prefix=True,
            )

            rule = events.Rule(
                self,
                id=f"{id}-eventbridge-rule-{domain}",
                rule_name=event_rule_name,
                schedule=events.Schedule.rate(Duration.seconds(60)),
                description=f"Time trigger for Lambda healthcheck-{domain}",
                targets=[aws_events_targets.LambdaFunction(lambda_function)],
            )

            self.list_of_evenbridge_rules_arns.append(rule.rule_arn)

            # Couldwatch creation
            cloudwatch_alarm_name = lg.get_label(
                resource_type="cloudwatch_alarm",
                resource_name=f"cloudwatch-alarm-{domain.split('.')[0]}",
                include_prefix=True,
            )

            sns_topic = sns.Topic(
                self,
                f"AlarmTopic-{domain}",
                topic_name=f"Route53-Alarm-Notificaiton-For-{domain.split('.')[0]}",
                display_name=f"CloudWatch Alarm Topic-{domain}",
            )

            # Subscribe an email to the SNS topic
            sns_topic.add_subscription(subs.EmailSubscription(email_addr))

            cloudwatch_alarm = cloudwatch.CfnAlarm(
                self,
                id=f"{id}-cloudwatch-alarm-{domain}",
                alarm_name=cloudwatch_alarm_name,
                alarm_description=f"CW alarm that is used as source for Route53 Healthcheck for {url}",
                threshold=1,
                evaluation_periods=3,
                datapoints_to_alarm=3,
                comparison_operator="LessThanThreshold",
                treat_missing_data="breaching",
                metric_name=f"Health Check for resource: {domain}",
                namespace=cw_metric_namespace,
                statistic="Minimum",
                period=60,
                dimensions=[
                    cloudwatch.CfnAlarm.DimensionProperty(
                        name=f"{protocol} Health Check",
                        value=f"{protocol} Health Check",
                    )
                ],
                alarm_actions=[sns_topic.topic_arn],
            )

            # Route53 Healthchecks Creations
            route53_healthcheck_name = lg.get_label(
                resource_type="route53_healthcheck",
                resource_name=f"route53_healthcheck-{domain.split('.')[0]}",
                include_prefix=True,
            )

            route53_healthcheck = route53.CfnHealthCheck(
                self,
                id=f"{id}-r53-{domain}",
                health_check_config=route53.CfnHealthCheck.HealthCheckConfigProperty(
                    type="CLOUDWATCH_METRIC",
                    alarm_identifier=route53.CfnHealthCheck.AlarmIdentifierProperty(
                        name=cloudwatch_alarm_name, region=region
                    ),
                ),
                health_check_tags=[
                    route53.CfnHealthCheck.HealthCheckTagProperty(
                        key="Name", value=route53_healthcheck_name
                    )
                ],
            )

            route53_healthcheck.add_dependency(cloudwatch_alarm)

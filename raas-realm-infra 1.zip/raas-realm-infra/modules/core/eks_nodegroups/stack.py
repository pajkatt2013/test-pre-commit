# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
from typing import Any, Dict, cast

import boto3
from aws_cdk import Stack, Tags
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_eks as eks
from aws_cdk import aws_iam as iam
from constructs import Construct, IConstruct
from helpers import get_ami_version
from utils import LabelGenerator


# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
class EKS_Nodegroup(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        config: Dict[str, Any],
        tags: list,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys the node groups into EKS Cluster",
            **kwargs,
        )

        for k, v in config.items():
            setattr(self, k, v)

        # Tagging all resources
        for kv in tags:
            Tags.of(scope=cast(IConstruct, self)).add(key=kv["key"], value=kv["value"])

        # set label generator
        lg = LabelGenerator(
            prefix=self.deployment_name,
            namespace=self.namespace,
            stage=self.stage,
            bu_name=self.bu_name,
            aws_env=kwargs["env"],
        )

        # Importing the VPC
        self.vpc = ec2.Vpc.from_lookup(self, "VPC", vpc_id=self.vpc_id)

        print("[DEBUG] VPC_ARN:", self.vpc.vpc_arn)

        # # Get the target EKS Cluster
        self.eks_cluster = eks.Cluster.from_cluster_attributes(
            self, "RaaSEksCluster", cluster_name=self.target_cluster_name, vpc=self.vpc
        )

        print("[DEBUG] EKS_Cluster_Info:", self.eks_cluster.cluster_arn)

        # nodegroup_labels = json.loads(self.customer_nodegroup_labels)
        nodegroup_labels = self.customer_nodegroup_labels.split(",")
        self.customer_eks_nodegroups = []

        ami_type = getattr(eks.NodegroupAmiType, self.ami_type_param)

        # get support AZ for target instance type
        client = boto3.client("ec2")
        instance_availability_zone = []
        for instance_type in self.instance_types:
            response = client.describe_instance_type_offerings(
                LocationType="availability-zone",
                Filters=[{"Name": "instance-type", "Values": [instance_type]}],
            )

            for offering in response["InstanceTypeOfferings"]:
                instance_availability_zone.append(offering["Location"]) if offering[
                    "Location"
                ] not in instance_availability_zone else None

        print("[INFO] Instance availability zone:", instance_availability_zone)

        # Set node role if provided
        node_role = self.set_node_role(lg)

        for i, np in enumerate(nodegroup_labels):
            print("i: ", i, "label: ", np)

            # Create the initial node_labels and node_tags
            node_labels = {"customer_function": np}
            node_tags = {"customer_function": np}

            # Add the plugin_type
            if self.ng_name_suffix and self.ng_plugin:
                node_labels["plugin_type"] = self.ng_plugin
                node_tags["plugin_type"] = self.ng_plugin

            # Add custom labels defined in template
            if self.ng_labels:
                for label in self.ng_labels:
                    node_labels[label["key"]] = label["value"]

            # add customer function taints
            node_taints = []
            cf_taint = eks.TaintSpec(
                effect=eks.TaintEffect.NO_SCHEDULE, key="customer_function", value=np
            )
            node_taints.append(cf_taint)

            # add custom taints defined in template
            if self.ng_taints:
                for taint in self.ng_taints:
                    node_taints.append(
                        eks.TaintSpec(
                            effect=eks.TaintEffect.NO_SCHEDULE,
                            key=taint["key"],
                            value=taint["value"],
                        )
                    )

            np_full_name = f"{np}-{self.ng_name_suffix}" if self.ng_name_suffix else np

            tmp_nodegroup = eks.Nodegroup(
                scope=self,
                id=f"addf-{self.module_name}-{i}",
                cluster=self.eks_cluster,
                labels=node_labels,
                nodegroup_name=np_full_name,
                node_role=node_role,
                desired_size=int(self.node_scaling_config["desiredSize"]),
                min_size=int(self.node_scaling_config["minSize"]),
                max_size=int(self.node_scaling_config["maxSize"]),
                # Set disk size only if launch template not defined
                disk_size=int(self.disk_size),
                instance_types=[
                    ec2.InstanceType(instance_type)
                    for instance_type in self.instance_types
                ],
                ami_type=ami_type,
                release_version=get_ami_version(str(self.eks_version)),
                tags=node_tags,
                subnets=ec2.SubnetSelection(
                    availability_zones=instance_availability_zone
                ),
                # Added to apply taint specification
                taints=node_taints,
            )
            self.customer_eks_nodegroups.append(tmp_nodegroup)

    def set_node_role(self, lg):
        node_role = None
        if self.nodegroup_role_name:
            print("[INFO] Create nodegroup with nodegroup_role_name provided")
            node_role_id_name = lg.get_label(
                resource_type="node-role",
                resource_name="eks-ng",
                include_prefix=True,
                include_stage=True,
                include_resource_type=True,
            )

            node_role = iam.Role.from_role_name(
                scope=self, id=node_role_id_name, role_name=self.nodegroup_role_name
            )
        else:
            print("[INFO] Create nodegroups with individual node role")
        return node_role

        # Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())


# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

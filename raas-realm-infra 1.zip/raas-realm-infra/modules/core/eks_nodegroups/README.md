# EKS


## Description

This module creates the nodegroups into existing EKS Cluster with the following configuration options:

- intance type of the nodegroups
- desired node size of the nodegroups
- minimum node size of the nodegroups
- maximum node size of the nodegroups
- default node IAM role of the nodegroups



## Inputs/Outputs

### Input Paramenters

#### Required

- `vpc-id`: The VPC-ID that the cluster will be created in
- `dataplane-subnet-ids`: The dataplane subnets can be either private subnets (NATG enabled) or in isolated subnets(link local route only) depending on the compliance required to achieve
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.
- `stage`: Target stage of deployment.
- `namespace`: Target namespace of deployment.
- `bu_name`: Business unit name (e.g, aptiv or raas), which is used to generate the resource name.
- `target-cluster-name`: Name of target cluster, in which the nodegroups will be created.
- `vpc-id`: The ID of the VPC, in which the EKS cluster located.
- `customer-functions`: The parameter customer-functions consist a list of customer functions with comma separated values. This parameter is used to get list of all the customer-functions to propagated cost allocation tags and customer node group labels.
- `instance-type`: Instance type of the to be created EKS nodegroups.
- `node_scaling_config` : Node size config for the nodegroups. Ex. node_scaling_config={"desiredSize": 0, "minSize": 0, "maxSize": 10}

#### Optional
- `disk-size`: Not used.
- `default-node-iam-role-arn`: If `default-node-iam-role-arn` is set, the default IAM role will be assigned for all the new created nodegroups.

### Example declaration of EKS Compute Configuration

```yaml
name: eks-customer-nodegroups-1
path: modules/core/eks_nodegroups
parameters:
  - name: cost-allocation-tag
    value:
      - key: maintainer
        value: raas_devops

  - name: stage
    valueFrom:
      envVariable: STAGE

  - name: namespace
    valueFrom:
      envVariable: NAMESPACE

  - name: bu_name
    value: raas-eks

  - name: target-cluster-name
    valueFrom:
      moduleMetadata:
        group: core
        name: eks
        key: EksClusterName

  - name: vpc-id
    valueFrom:
      parameterStore: /orionadp/blueprint/vpc/network-onprem-vpc/vpc-id

  # - name: dataplane-subnet-ids
  #   valueFrom:
  #     parameterStore: /orionadp/blueprint/vpc/network-onprem-vpc/non-routable-private-subnets

  # - name: controlplane-subnet-ids
  #   valueFrom:
  #     parameterStore: /orionadp/blueprint/vpc/network-onprem-vpc/routable-private-subnets

  - name: customer-functions
    valueFrom:
      parameterStore: /addf/customer_functions

  - name: default-node-iam-role-arn
    value: arn:aws:iam::178345759618:role/addf-realm-infra-dev-core-clusterNodegroupclusterde-c8Lo8vzhIKvF

  - name: instance-type
    value: m5.xlarge

  - name: disk-size
    value: 20

  - name: node_scaling_config # Node size config for the nodegroups i.e. desiredSize, minSize and maxSize
    valueFrom:
      envVariable: NODE_SCALING_CONFIG # Ex. {"desiredSize": 0, "minSize": 0, "maxSize": 10}

```



#### Output Example

No output

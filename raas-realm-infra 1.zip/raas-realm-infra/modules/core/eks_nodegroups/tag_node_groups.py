# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
#  Software created within Project Orion.
#  All rights reserved. Authorship details are documented in the Git history.
#  This script is to propagated cost allocation tags to EC2 instance & ASG so that EC2 instances are billed correctly.
# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
import json
import os

import boto3

# ------------------------------------------------------------------------------
# ADDF vars
# ------------------------------------------------------------------------------
# SSM_CLIENT = boto3.client("ssm")

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "").lower()
module_name = os.getenv("ADDF_MODULE_NAME", "")
hash = os.getenv("ADDF_HASH", "")
customer_functions = os.getenv("ADDF_PARAMETER_CUSTOMER_FUNCTIONS", "")
assert customer_functions
customer_functions_list = customer_functions.split(",")

ng_name_suffix = os.getenv("ADDF_PARAMETER_NG_NAME_SUFFIX")
tgt_cluster_name = os.getenv("ADDF_PARAMETER_TARGET_CLUSTER_NAME", None)
ng_plugin = os.getenv("ADDF_PARAMETER_NG_PLUGIN")
ng_labels_param = os.getenv("ADDF_PARAMETER_NG_LABELS")
if ng_labels_param is not None:
    ng_labels = json.loads(ng_labels_param)

# ------------------------------------------------------------------------------
# Constant
# ------------------------------------------------------------------------------
c_label_customer_function = "customer_function"
c_label_plugin_type_key = "plugin_type"

c_key_asgs = "AutoScalingGroups"
c_key_asg_name = "AutoScalingGroupName"
c_key_eks_cluster_name = "eks:cluster-name"
c_key_eks_ng_name = "eks:nodegroup-name"
c_key_tags = "Tags"
c_key_key = "Key"
c_key_value = "Value"
c_key_next_token = "NextToken"
c_eks_ng_asg_suspendproc = "AZRebalance"
c_prefix_eks_asg_label_tag_key = "k8s.io/cluster-autoscaler/node-template/label/"


# ------------------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------------------
def get_customer_function_str(ng_name, ng_suffix):
    if ng_suffix is None:
        return ng_name
    else:
        cf_pos = ng_name.find(ng_suffix)
        if cf_pos > 1:
            return ng_name[: cf_pos - 1]
        else:
            return None


def get_tag_if_exists(lst_tag: list, search_key: str):
    ret = None
    for t in lst_tag:
        t_key = t.get("Key")
        if t_key == search_key:
            ret = t.get("Value")
    return ret


def update_eks_ng_asg_suspend_process(lst_asg: list, client, suspendproc):
    for asg in lst_asg:
        t_asg_name = asg.get(c_key_asg_name)
        t_asg_tags = asg.get(c_key_tags)
        t_cluster_name = get_tag_if_exists(
            lst_tag=t_asg_tags, search_key=c_key_eks_cluster_name
        )
        t_ng_name = get_tag_if_exists(lst_tag=t_asg_tags, search_key=c_key_eks_ng_name)
        if (
            t_cluster_name == tgt_cluster_name
            and get_customer_function_str(t_ng_name, ng_name_suffix)
            in customer_functions_list
            and not any(
                d.get("ProcessName", "") == suspendproc
                for d in asg.get("SuspendedProcesses")
            )
        ):
            print(f"suspending process {suspendproc} for ng {t_ng_name}")
            client.suspend_processes(
                AutoScalingGroupName=t_asg_name,
                ScalingProcesses=[
                    suspendproc,
                ],
            )


def update_eks_ng_asg_tags(lst_asg: list, client):
    for asg in lst_asg:
        t_asg_name = asg.get(c_key_asg_name)
        t_asg_tags = asg.get(c_key_tags)
        t_cluster_name = get_tag_if_exists(
            lst_tag=t_asg_tags, search_key=c_key_eks_cluster_name
        )
        t_ng_name = get_tag_if_exists(lst_tag=t_asg_tags, search_key=c_key_eks_ng_name)
        if t_ng_name is not None:
            t_ng_cf_name = get_customer_function_str(
                ng_name=t_ng_name, ng_suffix=ng_name_suffix
            )

            if (
                t_cluster_name == tgt_cluster_name
                and t_ng_cf_name in customer_functions_list
            ):
                # print(f"[DEBUG] cluster_name: {t_cluster_name}")
                asg_tags = [
                    {
                        "ResourceId": t_asg_name,
                        "Key": c_label_customer_function,
                        "Value": t_ng_cf_name,
                        "PropagateAtLaunch": True,
                        "ResourceType": "auto-scaling-group",
                    },
                    {
                        "ResourceId": t_asg_name,
                        "Key": f"{c_prefix_eks_asg_label_tag_key}{c_label_customer_function}",
                        "Value": t_ng_cf_name,
                        "PropagateAtLaunch": True,
                        "ResourceType": "auto-scaling-group",
                    },
                ]
                if ng_plugin is not None:
                    asg_tags.extend(
                        [
                            {
                                "ResourceId": t_asg_name,
                                "Key": f"{c_prefix_eks_asg_label_tag_key}{c_label_plugin_type_key}",
                                "Value": ng_plugin,
                                "PropagateAtLaunch": True,
                                "ResourceType": "auto-scaling-group",
                            }
                        ]
                    )
                elif ng_labels_param is not None:
                    node_labels = {label["key"]: label["value"] for label in ng_labels}
                    for key, value in node_labels.items():
                        asg_tags.extend(
                            [
                                {
                                    "ResourceId": t_asg_name,
                                    "Key": f"{c_prefix_eks_asg_label_tag_key}{key}",
                                    "Value": value,
                                    "PropagateAtLaunch": True,
                                    "ResourceType": "auto-scaling-group",
                                }
                            ]
                        )
                client.create_or_update_tags(Tags=asg_tags)


# ------------------------------------------------------------------------------
# Main
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    print(f"[INFO] target cluster name: {tgt_cluster_name}")
    print(f"[INFO] nodegroup name suffix: {ng_name_suffix}")
    print(f"[DEBUG] nodegroup plugin name: {ng_plugin}")
    as_client = boto3.client("autoscaling", region_name=os.getenv("AWS_REGION"))
    res1 = as_client.describe_auto_scaling_groups(
        Filters=[
            {"Name": f"tag:{c_key_eks_cluster_name}", "Values": [tgt_cluster_name]}
        ]
    )
    res1_lst_asg = res1.get(c_key_asgs)
    update_eks_ng_asg_suspend_process(res1_lst_asg, as_client, c_eks_ng_asg_suspendproc)
    res0 = as_client.describe_auto_scaling_groups()
    res0_lst_asg = res0.get(c_key_asgs)
    # print("[INFO] Size of list ASGs:", len(res0_lst_asg))
    update_eks_ng_asg_tags(lst_asg=res0_lst_asg, client=as_client)
    next_token = res0.get(c_key_next_token)
    # print(f"[DEBUG] NextToken: {next_token}")
    while next_token:
        res_as_client = as_client.describe_auto_scaling_groups(NextToken=next_token)
        res_lst_asg = res_as_client.get(c_key_asgs)
        # print("[INFO] Size of list ASGs:", len(res_lst_asg))
        update_eks_ng_asg_tags(lst_asg=res_lst_asg, client=as_client)
        next_token = res_as_client.get(c_key_next_token)
        # print(f"[DEBUG] NextToken: {next_token}")
# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

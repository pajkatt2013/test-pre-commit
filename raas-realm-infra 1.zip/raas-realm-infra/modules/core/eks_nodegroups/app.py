# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
import json
import os

import aws_cdk
from aws_cdk import App, CfnOutput
from stack import EKS_Nodegroup


# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME")
module_name = os.getenv("ADDF_MODULE_NAME")
customer_functions = os.getenv("ADDF_PARAMETER_CUSTOMER_FUNCTIONS", "")

stage = os.getenv(_param("STAGE"), "defaultSTAGE")
namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

vpc_id = os.getenv(_param("VPC_ID"))
if not vpc_id:
    raise ValueError("[ERROR]: Missing input parameter vpc-id")

# dataplane_subnet_ids_str = os.getenv(_param("DATAPLANE_SUBNET_IDS"))
# if not dataplane_subnet_ids_str:
#     raise ValueError("[ERROR]: Missing input parameter dataplane-subnet-ids")
# dataplane_subnet_ids = json.loads(dataplane_subnet_ids_str)

# controlplane_subnet_ids_str = os.getenv(_param("CONTROLPLANE_SUBNET_IDS"))
# if not controlplane_subnet_ids_str:
#     print(f"[INFO] Missing input parameter controlplane-subnet-ids")
# else:
#     controlplane_subnet_ids = json.loads(controlplane_subnet_ids_str)

target_cluster_name = os.getenv(_param("TARGET_CLUSTER_NAME"))
customer_nodegroup_labels = os.getenv(_param("CUSTOMER_FUNCTIONS"))

nodegroup_role_name = os.getenv(_param("NODEGROUP_ROLE_NAME"))

if nodegroup_role_name:
    (
        f"[INFO] nodegroup_role_name was provided. The nodegroup will use role: {nodegroup_role_name}"
    )

else:
    print(
        "[INFO] Default node iam role has not been configured. New node iam role will be created for each single nodegroup automatically"
    )

node_scaling_config = json.loads(
    os.getenv(_param("NODE_SCALING_CONFIG"))
)  # Node size config for the nodegroups i.e. desiredSize, minSize and maxSize
instance_types = list(os.getenv(_param("INSTANCE_TYPES_LIST")).split(","))
disk_size = os.getenv(_param("DISK_SIZE"))
ami_type_param = os.getenv(_param("AMI_TYPE"), "AL2_X86_64")
eks_version = os.getenv(_param("EKS_VERSION"))
ng_name_suffix = os.getenv(_param("NG_NAME_SUFFIX"), None)
ng_plugin = os.getenv(_param("NG_PLUGIN"), None)
ng_taints = json.loads(os.getenv(_param("NG_TAINTS"), "[]"))
ng_labels = json.loads(os.getenv(_param("NG_LABELS"), "[]"))

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "stage": stage,
    "namespace": namespace,
    "bu_name": bu_name,
    "target_cluster_name": target_cluster_name,
    "vpc_id": vpc_id,
    # "dataplane_subnet_ids": dataplane_subnet_ids,
    # "controlplane_subnet_ids": controlplane_subnet_ids,
    "customer_nodegroup_labels": customer_nodegroup_labels,
    "customer_functions": customer_functions,
    "instance_types": instance_types,
    "disk_size": disk_size,
    "nodegroup_role_name": nodegroup_role_name,
    "node_scaling_config": node_scaling_config,
    "ami_type_param": ami_type_param,
    "eks_version": eks_version,
    "ng_name_suffix": ng_name_suffix,
    "ng_plugin": ng_plugin,
    "ng_taints": ng_taints,
    "ng_labels": ng_labels,
}

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
app = App()

stack = EKS_Nodegroup(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    config=config,
    tags=tag_list,
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string({"VpcArn": stack.vpc.vpc_arn}),
)

app.synth(force=True)

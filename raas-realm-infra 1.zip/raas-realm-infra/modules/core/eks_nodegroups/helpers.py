"""Helper utilities"""
import logging
import os

import yaml

_logger: logging.Logger = logging.getLogger(__name__)

project_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = "data/eks_dockerimage-replication/versions/"

workload_versions = {}


def _get_ami_version_from_file(eks_version: str) -> str:
    """Get AMI version

    Args:
        eks_version (str): EKS version

    Returns:
        str: AMI version
    """
    _parse_versions_file(eks_version)
    return workload_versions[eks_version]["ami"]["version"]


def _parse_versions_file(eks_version: str) -> dict:
    """Parse versions file

    Args:
        eks_version (str): EKS version

    Returns:
        dict: Parsed file
    """

    # we do not want to load and parse yaml file for every workload
    if eks_version not in workload_versions:
        yaml_path = os.path.join(data_dir, f"{eks_version}.yaml")

        with open(yaml_path, encoding="utf-8") as yaml_file:
            workload_versions[eks_version] = yaml.safe_load(yaml_file)


def get_ami_version(eks_version: str) -> str:
    """Get AMI version

    Args:
        eks_version (str): EKS version

    Returns:
        str: AMI version
    """

    return _get_ami_version_from_file(eks_version)

import json
import os

import boto3


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


nodegroup_name = os.getenv(_param("NODEGROUP_NAME"))
target_cluster_name = os.getenv(_param("TARGET_CLUSTER_NAME"))
ng_labels = json.loads(os.getenv(_param("NG_LABELS"), ""))
c_prefix_eks_asg_label_tag_key = "k8s.io/cluster-autoscaler/node-template/label/"
c_label_customer_function = "customer_function"

print(
    f"nodegroup_name: {nodegroup_name}, target_cluster_name: {target_cluster_name}, ng_labels: {ng_labels}"
)

# Initialize the Boto3 AutoScaling client
eks_client = boto3.client("eks")
autoscaling_client = boto3.client("autoscaling")


def get_auto_scaling_groups(cluster_name: str, node_group_name: str):
    # Describe the EKS node group
    response = eks_client.describe_nodegroup(
        clusterName=cluster_name, nodegroupName=node_group_name
    )
    print(
        f"autoScalingGroups: {response['nodegroup']['resources']['autoScalingGroups']}"
    )
    asg_names = []
    for asg in response["nodegroup"]["resources"]["autoScalingGroups"]:
        asg_names.append(asg["name"])

    return asg_names


def add_tags_to_auto_scaling_groups(asg_names: list, tags: dict):
    for asg_name in asg_names:
        autoscaling_client.create_or_update_tags(
            Tags=[
                {
                    "ResourceId": asg_name,
                    "ResourceType": "auto-scaling-group",
                    "Key": key,
                    "Value": value,
                    "PropagateAtLaunch": True,
                }
                for key, value in tags.items()
            ]
        )


# Fetch ASG names based on cluster and node group
asg_names = get_auto_scaling_groups(target_cluster_name, nodegroup_name)

node_labels = {label["key"]: label["value"] for label in ng_labels}
customer_function = node_labels.get(c_label_customer_function, "common")

# Tags to be added
tags_to_add = {c_label_customer_function: customer_function}
for ng_label_key, ng_label_value in node_labels.items():
    asg_tag_key = f"{c_prefix_eks_asg_label_tag_key}{ng_label_key}"
    tags_to_add[asg_tag_key] = ng_label_value

# Add tags to the fetched ASGs
add_tags_to_auto_scaling_groups(asg_names, tags_to_add)

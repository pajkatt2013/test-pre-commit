# EKS Single Node Group Module

## Description
This AWS CDK module facilitates the creation of an EKS node group into existing EKS Cluster, which requires parameters such as the target deployment stage, namespace, and cluster details to ensure seamless integration within your AWS environment.
The module provide customization configurations, such as instance type, disk size, and scaling settings. It supports advanced options like applying labels, tags, and taints to the node group.

## Inputs/Outputs
### Input Paramenters
#### Required
- `stage`: The deployment stage or environment (e.g., dev, prod).
- `namespace`: The Kubernetes namespace where the resources will be deployed.
- `bu_name`: Business unit identifier (e.g., aptiv, raas) used in resource name generation.
- `target-cluster-name`: The name of the target Kubernetes cluster for node group creation.
- `vpc-id`: The ID of the VPC where the EKS cluster resides.
- `nodegroup-name`: The desired name for the node group.
- `nodegroup-role-name`: The IAM role to be associated with the node group.
- `instance-type`: The instance type for the EKS node group.
- `disk-size`: The disk size (in GB) for each node in the node group.
- `node_scaling_config`: Configuration for scaling the node group (e.g., {"desiredSize": 0, "minSize": 0, "maxSize": 4}).
- `ng-labels`: Key-value pairs to label the node group.
- `ng-tags`: Key-value pairs to tag the node group resources.
- `ng-taints`: Taints to apply to the node group for workload scheduling.

#### Optional
- `AMI_TYPE`: The AMI type for the node group. Defaults to "AL2_X86_64".

## Example declaration of EKS single nodegroup creation module

```yaml
name: eks-customer-nodegroup-argo
path: modules/core/eks_nodegroups
parameters:
  - name: stage
    valueFrom:
      envVariable: STAGE

  - name: namespace
    valueFrom:
      envVariable: NAMESPACE

  - name: bu_name
    value: raas-eks

  - name: target-cluster-name
    valueFrom:
      moduleMetadata:
        group: core
        name: eks
        key: EksClusterName

  - name: vpc-id
    valueFrom:
      parameterStore: /orionadp/blueprint/vpc/network-onprem-vpc/vpc-id

  - name: nodegroup-name  # The desired name for the node group
    value: argo_nodes

  - name: nodegroup-role-name
    valueFrom:
      moduleMetadata:
        group: core-nodegroup-role
        name: nodegroup-role
        key: RoleName

  - name: instance-type
    value: r5.2xlarge

  - name: disk-size
    value: 20

  - name: node_scaling_config # Config for scaling the node group i.e. desiredSize, minSize and maxSize.
    value: {"desiredSize": 0, "minSize": 0, "maxSize": 4}

  - name: ng-tags
    value:
      - key: customer_function
        value: common
      - key: orionadp.com/node-target
        value: argo

  - name: ng-labels
    value:
      - key: customer_function
        value: common
      - key: orionadp.com/node-target
        value: argo

  - name: ng-taints
    value:
      - key: orionadp.com/node-target
        value: argo

```

#### Outputs
- `nodegroup_name`
- `nodegroup_arn`
- `VpcArn`

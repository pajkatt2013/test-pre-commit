from typing import Any, Dict, cast

from aws_cdk import Stack, Tags
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_eks as eks
from aws_cdk import aws_iam as iam
from constructs import Construct, IConstruct
from helpers import get_ami_version
from utils import LabelGenerator


class EKS_Nodegroup_Single(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        config: Dict[str, Any],
        labels: list,
        tags: list,
        taints: list,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys the single node group into EKS Cluster",
            **kwargs,
        )

        for k, v in config.items():
            setattr(self, k, v)

        # Tagging all resources
        for kv in tags:
            Tags.of(scope=cast(IConstruct, self)).add(key=kv["key"], value=kv["value"])

        # set label generator
        lg = LabelGenerator(
            prefix=self.deployment_name,
            namespace=self.namespace,
            stage=self.stage,
            bu_name=self.bu_name,
            aws_env=kwargs["env"],
        )

        # Importing the VPC
        self.vpc = ec2.Vpc.from_lookup(self, "VPC", vpc_id=self.vpc_id)

        # Get the target EKS Cluster
        self.eks_cluster = eks.Cluster.from_cluster_attributes(
            self, "RaaSEksCluster", cluster_name=self.target_cluster_name, vpc=self.vpc
        )
        print("[DEBUG] EKS_Cluster_Info:", self.eks_cluster.cluster_arn)

        node_role_id_name = lg.get_label(
            resource_type="node-role",
            resource_name="eks-ng",
            include_prefix=True,
            include_stage=True,
            include_resource_type=True,
        )
        node_role = iam.Role.from_role_name(
            scope=self, id=node_role_id_name, role_name=self.nodegroup_role_name
        )

        # prepare nodegroup param values
        ami_type = getattr(eks.NodegroupAmiType, self.ami_type_param)
        node_labels = {label["key"]: label["value"] for label in labels}
        node_tags = {tag["key"]: tag["value"] for tag in tags}
        node_taints = []
        for taint in taints:
            node_taints.append(
                eks.TaintSpec(
                    effect=eks.TaintEffect.NO_SCHEDULE,
                    key=taint["key"],
                    value=taint["value"],
                )
            )

        print(
            f"param values - node_tags: {node_tags}, node_labels: {node_labels}, node_taints: {node_taints}"
        )

        self.eks_nodegroup = eks.Nodegroup(
            scope=self,
            id=f"addf-{self.module_name}-{self.nodegroup_name}",
            cluster=self.eks_cluster,
            nodegroup_name=self.nodegroup_name,
            node_role=node_role,
            desired_size=int(self.node_scaling_config["desiredSize"]),
            min_size=int(self.node_scaling_config["minSize"]),
            max_size=int(self.node_scaling_config["maxSize"]),
            disk_size=int(self.disk_size),
            instance_types=[
                ec2.InstanceType(instance_type) for instance_type in self.instance_types
            ],
            ami_type=ami_type,
            release_version=get_ami_version(str(self.eks_version)),
            labels=node_labels,
            tags=node_tags,
            taints=node_taints,
        )

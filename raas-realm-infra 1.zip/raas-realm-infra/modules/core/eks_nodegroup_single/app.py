import json
import os

import aws_cdk
from aws_cdk import App, CfnOutput
from stack import EKS_Nodegroup_Single


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME")
module_name = os.getenv("ADDF_MODULE_NAME")
stage = os.getenv(_param("STAGE"), "defaultSTAGE")
namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")
target_cluster_name = os.getenv(_param("TARGET_CLUSTER_NAME"))
vpc_id = os.getenv(_param("VPC_ID"))
if not vpc_id:
    raise ValueError("[ERROR]: Missing input parameter vpc-id")

nodegroup_name = os.getenv(_param("NODEGROUP_NAME"))
nodegroup_role_name = os.getenv(_param("NODEGROUP_ROLE_NAME"))
# Node size config for the nodegroups i.e. desiredSize, minSize and maxSize
node_scaling_config = json.loads(os.getenv(_param("NODE_SCALING_CONFIG")))
instance_types = list(os.getenv(_param("INSTANCE_TYPES_LIST")).split(","))
disk_size = os.getenv(_param("DISK_SIZE"))
ami_type_param = os.getenv(_param("AMI_TYPE"), "AL2_X86_64")
eks_version = os.getenv(_param("EKS_VERSION"))

ng_labels = json.loads(os.getenv(_param("NG_LABELS"), ""))
ng_tags = json.loads(os.getenv(_param("NG_TAGS"), ""))
ng_taints = json.loads(os.getenv(_param("NG_TAINTS"), ""))

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "stage": stage,
    "namespace": namespace,
    "bu_name": bu_name,
    "target_cluster_name": target_cluster_name,
    "vpc_id": vpc_id,
    "instance_types": instance_types,
    "disk_size": disk_size,
    "nodegroup_name": nodegroup_name,
    "nodegroup_role_name": nodegroup_role_name,
    "node_scaling_config": node_scaling_config,
    "ami_type_param": ami_type_param,
    "eks_version": eks_version,
}

app = App()

stack = EKS_Nodegroup_Single(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    config=config,
    labels=ng_labels,
    tags=ng_tags,
    taints=ng_taints,
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "nodegroup_name": stack.eks_nodegroup.nodegroup_name,
            "nodegroup_arn": stack.eks_nodegroup.nodegroup_arn,
            "VpcArn": stack.vpc.vpc_arn,
        }
    ),
)

app.synth(force=True)

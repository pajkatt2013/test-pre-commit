#  Software created within Project Orion.
#  Copyright (C) 2023 Qualcomm Technologies Inc.
#  All rights reserved. Authorship details are documented in the Git history.

import os

from aws_cdk import App, CfnOutput
from stack import CustomerFunctionsStack

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "").lower()
module_name = os.getenv("ADDF_MODULE_NAME", "")
# Parameter
customer_functions = os.getenv("ADDF_PARAMETER_CUSTOMER_FUNCTIONS", "")
app = App()
# Insert to parameter store
stack = CustomerFunctionsStack(
    scope=app,
    id="customer-functions-ssm-stack",
    deployment_name=deployment_name,
    module_name=module_name,
    customer_functions_str=customer_functions,
)


CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string({"CustomerFunctions": stack.customer_functions_list}),
)


app.synth(force=True)

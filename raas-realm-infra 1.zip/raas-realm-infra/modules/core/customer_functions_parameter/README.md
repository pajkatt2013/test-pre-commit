# Customer Functions Parameters

## Getting started
This module is used to store a list of customer functions to SSM Parameter store so it can be used by other modules or services

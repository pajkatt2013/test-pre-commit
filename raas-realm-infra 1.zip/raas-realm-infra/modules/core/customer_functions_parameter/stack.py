#  Software created within Project Orion.
#  Copyright (C) 2023 Qualcomm Technologies Inc.
#  All rights reserved. Authorship details are documented in the Git history.

from typing import Any, cast

from aws_cdk import Stack, Tags
from aws_cdk import aws_ssm as ssm
from constructs import Construct, IConstruct


class CustomerFunctionsStack(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        deployment_name: str,
        module_name: str,
        customer_functions_str: str,
        **kwargs: Any,
    ) -> None:
        # ADDF Env vars

        super().__init__(
            scope,
            id,
            description="This stack deploys ssm parameter with customer function values",
            **kwargs,
        )

        def add_tag(key: str, value: str) -> None:
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", deployment_name)
        add_tag("Module", module_name)

        parameter_name = "/addf/customer-functions"
        # Customer function input is a list as string. Therefore transform it to a list of strings
        self.customer_functions_list = (
            customer_functions_str.strip("][")
            .replace("'", "")
            .replace('"', "")
            .split(", ")
        )
        ssm.StringListParameter(
            self,
            id="customer-functions-parameter",
            string_list_value=self.customer_functions_list,
            parameter_name=parameter_name,
            description="Parameter containing all allowed customer functions",
        )

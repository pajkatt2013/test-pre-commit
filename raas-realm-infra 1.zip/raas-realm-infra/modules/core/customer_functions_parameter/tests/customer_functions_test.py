#  Software created within Project Orion.
#  Copyright (C) 2023 Qualcomm Technologies Inc.
#  All rights reserved. Authorship details are documented in the Git history.

import aws_cdk
from aws_cdk.assertions import Match, Template

from ..stack import CustomerFunctionsStack

DEPLOYMENT = "prod"
MODULE_NAME = "customer_functions_parameter"
CUSTOMER_FUNCTIONS = '["asf_mid", "asf_high", "l2_mid", "l2_high", "l2p_basic_mid", "l2p_ucc_mid", "l2p_hoo_mid", \
"l2p_basic_high", "l2p_hoo_high", "cp60", "llp", "cv_buy", "fasinfo", "rcw", "common", "platform"]'


def _create_stack() -> Template:
    app = aws_cdk.App()

    # Create the Stack.
    stack = CustomerFunctionsStack(
        scope=app,
        id="customer-functions-ssm-stack",
        deployment_name=DEPLOYMENT,
        module_name=MODULE_NAME,
        customer_functions_str=CUSTOMER_FUNCTIONS,
        env=aws_cdk.Environment(
            account="12345",
            region="eu-central-1",
        ),
    )

    # Prepare the stack for assertions.
    template = Template.from_stack(stack)
    return template


STACK_TEMPLATE = _create_stack()


def test_customer_functions() -> None:
    customer_functions_ssm_value = (
        CUSTOMER_FUNCTIONS.strip("][").replace('"', "").replace(" ", "")
    )
    STACK_TEMPLATE.has_resource_properties(
        "AWS::SSM::Parameter",
        Match.object_like(
            {
                "Type": "StringList",
                "Value": customer_functions_ssm_value,
                "Name": "/addf/customer-functions",
                "Tags": {"Deployment": DEPLOYMENT, "Module": MODULE_NAME},
            }
        ),
    )

#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

import json
import os
from string import Template
from typing import Any, Dict, cast

import aws_cdk
import cdk_nag
import yaml
from aws_cdk import Aspects, CfnJson, RemovalPolicy, Stack, Tags
from aws_cdk import aws_aps as aps
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_eks as eks
from aws_cdk import aws_iam as iam
from aws_cdk import aws_kms as kms
from aws_cdk.lambda_layer_kubectl_v23 import KubectlV23Layer
from cdk_nag import NagSuppressions
from constructs import Construct, IConstruct
from helpers import (
    deep_merge,
    get_addon_version,
    get_ami_version,
    get_az_from_subnet,
    get_chart_name_from_file,
    get_chart_release,
    get_chart_repo,
    get_chart_values,
    get_chart_version,
    get_image,
)

project_dir = os.path.dirname(os.path.abspath(__file__))

# We are loading the data from docker replication module and use the following constants
# to get correct values from SSM
ALB_CONTROLLER = "alb_controller"
AWS_VPC_CNI = "aws_vpc_cni"
CALICO = "calico"
CERT_MANAGER = "cert_manager"
CLOUDWATCH_AGENT = "cloudwatch_agent"
CLUSTER_AUTOSCALER = "cluster_autoscaler"
EBS_CSI_DRIVER = "ebs_csi_driver"
EFS_CSI_DRIVER = "efs_csi_driver"
EXTERNAL_DNS = "external_dns"
EXTERNAL_SECRETS = "external_secrets"
FLUENTBIT = "fluentbit"
FSX_DRIVER = "fsx_driver"
GRAFANA = "grafana"
KURED = "kured"
KYVERNO = "kyverno"
KYVERNO_POLICY_REPORTER = "kyverno_policy_reporter"
METRICS_SERVER = "metrics_server"
NGINX_CONTROLLER = "nginx_controller"
PROMETHEUS_STACK = "prometheus_stack"
SECRETS_MANAGER_CSI_DRIVER = "secrets_manager_csi_driver"
SECRETS_STORE_CSI_DRIVER_PROVIDER_AWS = "secrets_store_csi_driver_provider_aws"
NVIDIA_DEVICE_PLUGIN = "nvidia_device_plugin"
CORE_DNS = "core_dns"
KUBE_PROXY = "kube_proxy"
CORE_DUMP_HANDLER = "core_dump_handler"


class Eks(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        *,
        config: Dict[str, Any],
        tags: list,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys EKS Cluster, Managed Nodegroup(s) with standard plugins for ADDF",
            **kwargs,
        )
        # CDK Env Vars
        partition: str = aws_cdk.Aws.PARTITION

        # Set folder path
        deploy_helm_chart_local = False
        if self.region == "cn-north-1":
            deploy_helm_chart_local = True

        # Disable pylint class has no member because we load class attributes dynamically
        # pylint: disable=no-member
        for k, v in config.items():
            setattr(self, k, v)

        # Tagging all resources
        Tags.of(scope=cast(IConstruct, self)).add(
            key="Deployment", value=f"addf-{self.deployment_name}"
        )

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        for kv in tags:
            add_tag(kv["key"], kv["value"])

        # Importing the VPC
        self.vpc = ec2.Vpc.from_lookup(
            self,
            "VPC",
            vpc_id=self.vpc_id,
        )

        # DataPlane Subnets
        self.dataplane_subnets = []
        for idx, subnet_id in enumerate(self.dataplane_subnet_ids):
            self.dataplane_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"dp-subnet{idx}", subnet_id=subnet_id
                )
            )
        # ControlPlane Subnets
        self.controlplane_subnets = []
        for idx, subnet_id in enumerate(self.controlplane_subnet_ids):
            self.controlplane_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"cp-subnet{idx}", subnet_id=subnet_id
                )
            )

        cluster_admin_role = iam.Role(
            self,
            "ClusterAdminRole",
            role_name=f"addf-{self.deployment_name}-{self.module_name}-{self.region}-masterrole",
            assumed_by=iam.CompositePrincipal(
                iam.AccountRootPrincipal(),
                iam.ServicePrincipal("ec2.amazonaws.com"),
            ),
        )

        # Add all necessary aws managed policies to master role
        cluster_admin_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name(
                "AmazonEC2ContainerRegistryFullAccess"
            )
        )
        cluster_admin_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonEKSClusterPolicy")
        )
        cluster_admin_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonEKSServicePolicy")
        )
        cluster_admin_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonEKSWorkerNodePolicy")
        )
        cluster_admin_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonS3FullAccess")
        )
        cluster_admin_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonSQSFullAccess")
        )
        cluster_admin_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonSSMFullAccess")
        )
        cluster_admin_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonVPCReadOnlyAccess")
        )
        cluster_admin_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name(
                "AWSCloudFormationFullAccess"
            )
        )

        cni_metrics_role_name = (
            f"addf-{self.deployment_name}-{self.module_name}-CNIMetricsHelperRole"
        )
        self.cni_metrics_role_name = cni_metrics_role_name[:60]

        # Cluster Admin Role Default Policy document required for master role
        cluster_AdminRoleDefault_PolicyDocument = {
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "eks:ListClusters",
                        "eks:DescribeCluster",
                        "iam:Get*",
                        "cloudformation:List*",
                        "cloudformation:Describe*",
                        "cloudformation:Get*",
                        "secretsmanager:GetSecretValue",
                        "sts:AssumeRole",
                        "sts:TagSession",
                    ],
                    "Resource": "*",
                },
                {
                    "Effect": "Allow",
                    "Action": "cloudformation:*",
                    "Resource": [
                        f"arn:{partition}:cloudformation:{self.region}:{self.account}:stack/eksctl-addf-{self.deployment_name}*",
                    ],
                },
                {
                    "Effect": "Allow",
                    "Action": [
                        "iam:Create*",
                        "iam:Put*",
                        "iam:List*",
                        "iam:Detach*",
                        "iam:Attach*",
                        "iam:DeleteRole",
                    ],
                    "Resource": [
                        f"arn:{partition}:iam::{self.account}:role/AmazonEKSVPCCNIMetricsHelperRole",
                        f"arn:{partition}:iam::{self.account}:policy/AmazonEKSVPCCNIMetricsHelperPolicy",
                        f"arn:{partition}:iam::{self.account}:role/{self.cni_metrics_role_name}",
                    ],
                },
            ]
        }
        # Create the Custom cluster AdminRole Default Policy
        cluster_AdminRoleDefault_Policy = iam.Policy(
            self,
            id="ClusterAdminRoleDefaultPolicy",
            policy_name="ClusterAdminRoleDefaultPolicy",
            document=iam.PolicyDocument.from_json(
                cluster_AdminRoleDefault_PolicyDocument
            ),
        )
        # Attach the ClusterAdminRoleDefaultPolicy to the role
        cluster_admin_role.attach_inline_policy(cluster_AdminRoleDefault_Policy)

        node_role = iam.Role.from_role_name(
            scope=self, id=self.nodegroup_role_name, role_name=self.nodegroup_role_name
        )

        if self.eks_compute_config.get("eks_secrets_envelope_encryption"):
            # KMS key for Kubernetes secrets envelope encryption
            secrets_key = kms.Key(self, "SecretsKey")

        # Creates an EKS Cluster
        eks_cluster = eks.Cluster(
            self,
            "cluster",
            vpc=self.vpc,
            vpc_subnets=[ec2.SubnetSelection(subnets=self.controlplane_subnets)],
            cluster_name=f"addf-{self.deployment_name}-{self.module_name}-cluster",
            masters_role=cluster_admin_role,
            endpoint_access=eks.EndpointAccess.PRIVATE
            if self.eks_compute_config.get("eks_api_endpoint_private")
            else eks.EndpointAccess.PUBLIC,
            version=eks.KubernetesVersion.of(str(self.eks_version)),
            # Work around until CDK team makes kubectl upto date https://github.com/aws/aws-cdk/issues/23376
            kubectl_layer=KubectlV23Layer(self, "Kubectlv23Layer"),
            default_capacity=0,
            secrets_encryption_key=secrets_key
            if self.eks_compute_config.get("eks_secrets_envelope_encryption")
            else None,
            cluster_logging=[
                eks.ClusterLoggingTypes.API,
                eks.ClusterLoggingTypes.AUDIT,
                eks.ClusterLoggingTypes.AUTHENTICATOR,
                eks.ClusterLoggingTypes.CONTROLLER_MANAGER,
                eks.ClusterLoggingTypes.SCHEDULER,
            ],
        )

        # Whitelist traffic between Codebuild SG and EKS SG conditionally
        if (
            self.eks_compute_config.get("eks_api_endpoint_private")
            and self.codebuild_sg_id
        ):
            codebuild_sg = ec2.SecurityGroup.from_security_group_id(
                self, "eks-codebuild-sg", self.codebuild_sg_id
            )
            eks_cluster.kubectl_security_group.add_ingress_rule(
                codebuild_sg,
                ec2.Port.all_traffic(),
                description="Allowing traffic between private codebuild (codeseeder) and private API server",
            )
            # Ingress rule to allow access to cluster with kubectl.
            eks_cluster.kubectl_security_group.add_ingress_rule(
                peer=ec2.Peer.ipv4("0.0.0.0/0"),
                connection=ec2.Port.all_traffic(),
                description="Ingress rule to allow access to cluster with kubectl",
            )

        # Managing core-dns, kube-proxy andvpc-cni as Server Side softwares using Addons.
        # https://docs.aws.amazon.com/eks/latest/userguide/eks-add-ons.html
        coredns_addon = eks.CfnAddon(
            self,
            "coredns",
            addon_name="coredns",
            addon_version=get_addon_version(str(self.eks_version), CORE_DNS),
            configuration_values="""{
              "autoScaling": {
                "enabled": true,
                "minReplicas": 2,
                "maxReplicas": 10
              }
            }""",
            resolve_conflicts="OVERWRITE",
            cluster_name=eks_cluster.cluster_name,
        )

        kube_proxy_addon = eks.CfnAddon(
            self,
            "kube-proxy",
            addon_name="kube-proxy",
            addon_version=get_addon_version(str(self.eks_version), KUBE_PROXY),
            resolve_conflicts="OVERWRITE",
            cluster_name=eks_cluster.cluster_name,
        )

        coredns_addon.node.add_dependency(eks_cluster)
        kube_proxy_addon.node.add_dependency(eks_cluster)

        # Set folder path
        addons_iam_policies_folder = "addons-iam-policies"
        if self.region == "cn-north-1":
            addons_iam_policies_folder = "addons-iam-policies-cn"

        # Adopting the existing aws-node resources to Helm to fix error `helm ownership errors`
        patch_types = ["DaemonSet", "ClusterRole", "ClusterRoleBinding"]
        patches = []
        for kind in patch_types:
            patch = eks.KubernetesPatch(
                self,
                "CNI-Patch-" + kind,
                cluster=eks_cluster,
                resource_name=kind + "/aws-node",
                resource_namespace="kube-system",
                apply_patch={
                    "metadata": {
                        "annotations": {
                            "meta.helm.sh/release-name": "aws-vpc-cni",
                            "meta.helm.sh/release-namespace": "kube-system",
                        },
                        "labels": {"app.kubernetes.io/managed-by": "Helm"},
                    }
                },
                restore_patch={},
                patch_type=eks.PatchType.STRATEGIC,
            )
            # We don't want to clean this up on Delete - it is a one-time patch to let the Helm Chart own the resources
            patch_resource = patch.node.find_child("Resource")
            patch_resource.apply_removal_policy(RemovalPolicy.RETAIN)
            # Keep track of all the patches to set dependencies down below
            patches.append(patch)

        # fix ownership issue for amazon-vpc-cni
        patch = eks.KubernetesPatch(
            self,
            "CNI-Patch-Config",
            cluster=eks_cluster,
            resource_name="configmap/amazon-vpc-cni",
            resource_namespace="kube-system",
            apply_patch={
                "metadata": {
                    "annotations": {
                        "meta.helm.sh/release-name": "aws-vpc-cni",
                        "meta.helm.sh/release-namespace": "kube-system",
                    },
                    "labels": {"app.kubernetes.io/managed-by": "Helm"},
                }
            },
            restore_patch={},
            patch_type=eks.PatchType.STRATEGIC,
        )
        patches.append(patch)

        # Create the Service Account
        sg_pods_service_account = eks_cluster.add_service_account(
            "aws-node", name="aws-node-helm", namespace="kube-system"
        )
        # Give it the required policies
        sg_pods_service_account.role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("AmazonEKS_CNI_Policy")
        )
        eks_cluster.role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name(
                "AmazonEKSVPCResourceController"
            )
        )

        custom_subnet_values = {}
        if self.custom_subnet_ids:
            custom_subnet_ids = get_az_from_subnet(self.custom_subnet_ids)
            custom_subnets_values = {}
            for subnet_id, subnet_availability_zone in custom_subnet_ids.items():
                custom_subnets_values[subnet_availability_zone] = {"id": subnet_id}

            custom_subnet_values = {
                "init": {
                    "env": {
                        "AWS_VPC_K8S_CNI_CUSTOM_NETWORK_CFG": True,
                        "ENI_CONFIG_LABEL_DEF": "failure-domain.beta.kubernetes.io/zone",
                    },
                },
                "env": {
                    "AWS_VPC_K8S_CNI_CUSTOM_NETWORK_CFG": True,
                    "ENI_CONFIG_LABEL_DEF": "failure-domain.beta.kubernetes.io/zone",
                },
                "eniConfig": {
                    "create": True,
                    "subnets": custom_subnets_values,
                },
            }

        # Unfortunately vpc addon is always installed last, after the nodes are created and
        # we are unable to influence pod cidrs without recreating the nodes after the cluster creation.
        # To mitigate this and support out-of-the-box custom cidr for pods, we install
        # VPC CNI as a helm chart instead of vpc addon.
        # https://github.com/aws/eks-charts/tree/master/stable/aws-vpc-cni
        # https://docs.aws.amazon.com/eks/latest/userguide/add-ons-images.html
        import aws_cdk.aws_s3_assets as s3_assets

        vpc_cni_chart = eks_cluster.add_helm_chart(
            "aws-vpc-cni",
            chart_asset=s3_assets.Asset(
                self,
                get_chart_name_from_file(
                    self.replicated_ecr_images_metadata, AWS_VPC_CNI
                ),
                path="./helmchart/"
                + get_chart_name_from_file(
                    self.replicated_ecr_images_metadata, AWS_VPC_CNI
                ),
            )
            if deploy_helm_chart_local
            else None,
            chart=None
            if deploy_helm_chart_local
            else get_chart_release(str(self.eks_version), AWS_VPC_CNI),
            version=None
            if deploy_helm_chart_local
            else get_chart_version(str(self.eks_version), AWS_VPC_CNI),
            repository=None
            if deploy_helm_chart_local
            else get_chart_repo(str(self.eks_version), AWS_VPC_CNI),
            release="aws-vpc-cni",
            namespace="kube-system",
            values=deep_merge(
                {
                    "init": {
                        "image": {
                            "region": self.region,
                            "account": self.aws_vpc_cni_repo_account,
                            "domain": self.aws_vpc_cni_repo_domain,
                        },
                        "env": {"DISABLE_TCP_EARLY_DEMUX": True},
                    },
                    "nodeAgent": {
                        "image": {
                            "region": self.region,
                            "account": self.aws_vpc_cni_repo_account,
                            "domain": self.aws_vpc_cni_repo_domain,
                        }
                    },
                    "image": {
                        "region": self.region,
                        "account": self.aws_vpc_cni_repo_account,
                        "domain": self.aws_vpc_cni_repo_domain,
                    },
                    "env": {
                        "ENABLE_POD_ENI": True,
                        "ENABLE_PREFIX_DELEGATION": self.vpc_cni_enable_prefix_delegation,
                        "WARM_IP_TARGET": self.vpc_cni_warm_ip_target,
                        "MINIMUM_IP_TARGET": self.vpc_cni_minimum_ip_target,
                        "WARM_PREFIX_TARGET": self.vpc_cni_warm_prefix_target,
                    },
                    "serviceAccount": {"create": False, "name": "aws-node-helm"},
                    "originalMatchLabels": True,
                },
                custom_subnet_values,
                get_chart_values(self.replicated_ecr_images_metadata, AWS_VPC_CNI),
            ),
        )

        # # This depends both on the service account and the patches to the existing CNI resources having been done first
        vpc_cni_chart.node.add_dependency(sg_pods_service_account)

        # Add a Managed Node Group
        if self.eks_compute_config.get("eks_nodegroup_config"):
            # Spot InstanceType
            if self.eks_compute_config.get("eks_node_spot"):
                node_capacity_type = eks.CapacityType.SPOT
            # OnDemand InstanceType
            else:
                node_capacity_type = eks.CapacityType.ON_DEMAND
            # List of Managed Node Group IDs for export into Output
            self.nodegroup_ids = []
            for ng in self.eks_compute_config.get("eks_nodegroup_config", [{}]):
                lt = ec2.CfnLaunchTemplate(
                    self,
                    f"ng-lt-{str(ng.get('eks_ng_name'))}",
                    launch_template_data=ec2.CfnLaunchTemplate.LaunchTemplateDataProperty(
                        instance_type=str(ng.get("eks_node_instance_type")),
                        block_device_mappings=[
                            ec2.CfnLaunchTemplate.BlockDeviceMappingProperty(
                                device_name="/dev/xvda",
                                ebs=ec2.CfnLaunchTemplate.EbsProperty(
                                    volume_type="gp3",
                                    volume_size=ng.get("eks_node_disk_size"),
                                    encrypted=True,
                                ),
                            )
                        ],
                    ),
                )

                nodegroup = eks_cluster.add_nodegroup_capacity(
                    f"cluster-default-{ng}",
                    capacity_type=node_capacity_type,
                    desired_size=ng.get("eks_node_quantity"),
                    min_size=ng.get("eks_node_min_quantity"),
                    max_size=ng.get("eks_node_max_quantity"),
                    # The default in CDK is to force upgrades through even if they violate - it is safer to not do that
                    force_update=False,
                    launch_template_spec=eks.LaunchTemplateSpec(
                        id=lt.ref, version=lt.attr_latest_version_number
                    ),
                    labels=ng.get("eks_node_labels")
                    if ng.get("eks_node_labels")
                    else None,
                    release_version=get_ami_version(str(self.eks_version)),
                    subnets=ec2.SubnetSelection(subnets=self.dataplane_subnets),
                    node_role=node_role,
                )

                nodegroup.role.add_managed_policy(
                    iam.ManagedPolicy.from_aws_managed_policy_name(
                        "AmazonSSMManagedInstanceCore"
                    )
                )

                nodegroup.node.add_dependency(vpc_cni_chart)
                self.nodegroup_ids.append(nodegroup.nodegroup_name)

        # AWS Load Balancer Controller
        if self.eks_addons_config.get("deploy_aws_lb_controller"):
            awslbcontroller_service_account = eks_cluster.add_service_account(
                "aws-load-balancer-controller",
                name="aws-load-balancer-controller",
                namespace="kube-system",
            )

            # Create the PolicyStatements to attach to the role
            # https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/main/docs/install/iam_policy.json
            awslbcontroller_policy_document_path = os.path.join(
                project_dir, addons_iam_policies_folder, "ingress-controller.json"
            )
            with open(awslbcontroller_policy_document_path) as json_file:
                awslbcontroller_policy_document_json = json.load(json_file)
            # Attach the necessary permissions
            awslbcontroller_policy = iam.Policy(
                self,
                "awslbcontrollerpolicy",
                document=iam.PolicyDocument.from_json(
                    awslbcontroller_policy_document_json
                ),
            )
            awslbcontroller_service_account.role.attach_inline_policy(
                awslbcontroller_policy
            )

            # Deploy the AWS Load Balancer Controller from the AWS Helm Chart
            # For more info check out https://github.com/aws/eks-charts/tree/master/stable/aws-load-balancer-controller
            import aws_cdk.aws_s3_assets as s3_assets

            awslbcontroller_chart = eks_cluster.add_helm_chart(
                "aws-load-balancer-controller",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, ALB_CONTROLLER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, ALB_CONTROLLER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), ALB_CONTROLLER),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), ALB_CONTROLLER),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), ALB_CONTROLLER),
                release="awslbcontroller",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "clusterName": eks_cluster.cluster_name,
                        "region": self.region,
                        "vpcId": self.vpc_id,
                        "serviceAccount": {
                            "create": False,
                            "name": "aws-load-balancer-controller",
                        },
                        "replicaCount": 2,
                        "podDisruptionBudget": {"maxUnavailable": 1},
                        "resources": {"requests": {"cpu": "0.25", "memory": "0.5Gi"}},
                    },
                    get_chart_values(
                        self.replicated_ecr_images_metadata, ALB_CONTROLLER
                    ),
                ),
            )
            awslbcontroller_chart.node.add_dependency(awslbcontroller_service_account)

        # NGINX Ingress Controller
        if (
            "value" in self.eks_addons_config.get("deploy_nginx_controller")
            and self.eks_addons_config.get("deploy_nginx_controller")["value"]
        ):
            nginx_controller_service_account = eks_cluster.add_service_account(
                "nginx-controller",
                name="nginx-controller",
                namespace="kube-system",
            )

            # Create the PolicyStatements to attach to the role
            nginx_controller_policy_statement = iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=[
                    "acm:DescribeCertificate",
                    "acm:ListCertificates",
                    "acm:GetCertificate",
                    "ec2:AuthorizeSecurityGroupIngress",
                    "ec2:CreateSecurityGroup",
                    "ec2:CreateTags",
                    "ec2:DeleteTags",
                    "ec2:DeleteSecurityGroup",
                    "ec2:DescribeAccountAttributes",
                    "ec2:DescribeAddresses",
                    "ec2:DescribeInstances",
                    "ec2:DescribeInstanceStatus",
                    "ec2:DescribeInternetGateways",
                    "ec2:DescribeNetworkInterfaces",
                    "ec2:DescribeSecurityGroups",
                    "ec2:DescribeSubnets",
                    "ec2:DescribeTags",
                    "ec2:DescribeVpcs",
                    "ec2:ModifyInstanceAttribute",
                    "ec2:ModifyNetworkInterfaceAttribute",
                    "ec2:RevokeSecurityGroupIngress",
                ],
                resources=["*"],
            )

            # Attach the necessary permissions
            nginx_controller_policy = iam.Policy(
                self,
                "nginx-controller-policy",
                policy_name="nginx-controller-policy",
                statements=[nginx_controller_policy_statement],
            )
            nginx_controller_service_account.role.attach_inline_policy(
                nginx_controller_policy
            )

            custom_values = {}
            if "nginx_additional_annotations" in self.eks_addons_config.get(
                "deploy_nginx_controller"
            ):
                custom_values = {
                    "controller": {
                        "configAnnotations": self.eks_addons_config.get(
                            "deploy_nginx_controller"
                        )["nginx_additional_annotations"]
                    }
                }

            # Deploy the Nginx Ingress Controller
            # For more info check out https://github.com/kubernetes/ingress-nginx/tree/main/charts/ingress-nginx
            import aws_cdk.aws_s3_assets as s3_assets

            nginx_controller_chart = eks_cluster.add_helm_chart(
                "nginx-ingress",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, NGINX_CONTROLLER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, NGINX_CONTROLLER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), NGINX_CONTROLLER),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), NGINX_CONTROLLER),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), NGINX_CONTROLLER),
                release="nginxcontroller",
                namespace="kube-system",
                values=deep_merge(
                    custom_values,
                    get_chart_values(
                        self.replicated_ecr_images_metadata, NGINX_CONTROLLER
                    ),
                ),
            )
            nginx_controller_chart.node.add_dependency(nginx_controller_service_account)

        # AWS EBS CSI Driver
        if self.eks_addons_config.get("deploy_aws_ebs_csi"):
            awsebscsidriver_service_account = eks_cluster.add_service_account(
                "awsebscsidriver", name="awsebscsidriver", namespace="kube-system"
            )

            # Reference: https://github.com/kubernetes-sigs/aws-ebs-csi-driver/blob/master/docs/example-iam-policy.json
            awsebscsidriver_policy_document_json_path = os.path.join(
                project_dir, addons_iam_policies_folder, "ebs-csi-iam.json"
            )
            with open(awsebscsidriver_policy_document_json_path) as json_file:
                awsebscsidriver_policy_document_json = json.load(json_file)

            # Attach the necessary permissions
            awsebscsidriver_policy = iam.Policy(
                self,
                "awsebscsidriverpolicy",
                document=iam.PolicyDocument.from_json(
                    awsebscsidriver_policy_document_json
                ),
            )
            awsebscsidriver_service_account.role.attach_inline_policy(
                awsebscsidriver_policy
            )

            # Install the AWS EBS CSI Driver
            # https://github.com/kubernetes-sigs/aws-ebs-csi-driver/tree/master/charts/aws-ebs-csi-driver
            import aws_cdk.aws_s3_assets as s3_assets

            awsebscsi_chart = eks_cluster.add_helm_chart(
                "aws-ebs-csi-driver",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, EBS_CSI_DRIVER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, EBS_CSI_DRIVER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), EBS_CSI_DRIVER),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), EBS_CSI_DRIVER),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), EBS_CSI_DRIVER),
                release="awsebscsidriver",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "controller": {
                            "region": self.region,
                            "serviceAccount": {
                                "create": False,
                                "name": "awsebscsidriver",
                            },
                        },
                        "node": {
                            "serviceAccount": {
                                "create": False,
                                "name": "awsebscsidriver",
                            }
                        },
                    },
                    get_chart_values(
                        self.replicated_ecr_images_metadata, EBS_CSI_DRIVER
                    ),
                ),
            )
            awsebscsi_chart.node.add_dependency(awsebscsidriver_service_account)

            # Set up the StorageClass pointing at the new CSI Driver
            # https://github.com/kubernetes-sigs/aws-ebs-csi-driver/blob/master/examples/kubernetes/dynamic-provisioning/specs/storageclass.yaml
            ebs_csi_storageclass = eks_cluster.add_manifest(
                "EBSCSIStorageClassGP2",
                {
                    "kind": "StorageClass",
                    "apiVersion": "storage.k8s.io/v1",
                    "metadata": {"name": "ebs-gp2"},
                    "parameters": {"type": "gp2", "encrypted": "true"},
                    "provisioner": "ebs.csi.aws.com",
                    "volumeBindingMode": "WaitForFirstConsumer",
                },
            )
            ebs_csi_storageclass.node.add_dependency(awsebscsi_chart)

            # Set up the StorageClass pointing at the new CSI Driver
            # https://github.com/kubernetes-sigs/aws-ebs-csi-driver/blob/master/examples/kubernetes/dynamic-provisioning/specs/storageclass.yaml
            ebs_csi_storageclass_gp3 = eks_cluster.add_manifest(
                "EBSCSIStorageClassGP3",
                {
                    "kind": "StorageClass",
                    "apiVersion": "storage.k8s.io/v1",
                    "metadata": {"name": "ebs-gp3"},
                    "parameters": {"type": "gp3", "encrypted": "true"},
                    "provisioner": "ebs.csi.aws.com",
                    "volumeBindingMode": "WaitForFirstConsumer",
                },
            )
            ebs_csi_storageclass_gp3.node.add_dependency(awsebscsi_chart)

        # AWS EFS CSI Driver
        if self.eks_addons_config.get("deploy_aws_efs_csi"):
            awsefscsidriver_service_account = eks_cluster.add_service_account(
                "awsefscsidriver", name="awsefscsidriver", namespace="kube-system"
            )

            awsefscsidriver_policy_statement_json_path = os.path.join(
                project_dir, addons_iam_policies_folder, "efs-csi-iam.json"
            )
            with open(awsefscsidriver_policy_statement_json_path) as json_file:
                awsefscsidriver_policy_statement_json = json.load(json_file)

            # Attach the necessary permissions
            awsefscsidriver_policy = iam.Policy(
                self,
                "awsefscsidriverpolicy",
                document=iam.PolicyDocument.from_json(
                    awsefscsidriver_policy_statement_json
                ),
            )
            awsefscsidriver_service_account.role.attach_inline_policy(
                awsefscsidriver_policy
            )

            import aws_cdk.aws_s3_assets as s3_assets

            awsefscsi_chart = eks_cluster.add_helm_chart(
                "aws-efs-csi-driver",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, EFS_CSI_DRIVER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, EFS_CSI_DRIVER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), EFS_CSI_DRIVER),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), EFS_CSI_DRIVER),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), EFS_CSI_DRIVER),
                release="awsefscsidriver",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "controller": {
                            "serviceAccount": {
                                "create": False,
                                "name": "awsefscsidriver",
                            },
                            "deleteAccessPointRootDir": True,
                        },
                        "node": {
                            "serviceAccount": {
                                "create": False,
                                "name": "awsefscsidriver",
                            }
                        },
                    },
                    get_chart_values(
                        self.replicated_ecr_images_metadata, EFS_CSI_DRIVER
                    ),
                ),
            )

            awsefscsi_chart.node.add_dependency(awsefscsidriver_service_account)

        # AWS FSx CSI Driver does not work in isolated subnets at the time of developing the module
        if self.eks_addons_config.get("deploy_aws_fsx_csi"):
            awsfsxcsidriver_service_account = eks_cluster.add_service_account(
                "awsfsxcsidriver", name="awsfsxcsidriver", namespace="kube-system"
            )

            awsfsxcsidriver_policy_statement_json_path = os.path.join(
                project_dir, addons_iam_policies_folder, "fsx-csi-iam.json"
            )
            with open(awsfsxcsidriver_policy_statement_json_path) as json_file:
                awsfsxcsidriver_policy_statement_json = json.load(json_file)

            # Attach the necessary permissions
            awsfsxcsidriver_policy = iam.Policy(
                self,
                "awsfsxcsidriverpolicy",
                document=iam.PolicyDocument.from_json(
                    awsfsxcsidriver_policy_statement_json
                ),
            )
            awsfsxcsidriver_service_account.role.attach_inline_policy(
                awsfsxcsidriver_policy
            )

            # Install the AWS FSx CSI Driver
            # https://github.com/kubernetes-sigs/aws-fsx-csi-driver/tree/release-0.9/charts/aws-fsx-csi-driver
            import aws_cdk.aws_s3_assets as s3_assets

            awsfsxcsi_chart = eks_cluster.add_helm_chart(
                "aws-fsx-csi-driver",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, FSX_DRIVER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, FSX_DRIVER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), FSX_DRIVER),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), FSX_DRIVER),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), FSX_DRIVER),
                release="awsfsxcsidriver",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "controller": {
                            "serviceAccount": {
                                "create": False,
                                "name": "awsfsxcsidriver",
                            }
                        },
                        "node": {
                            "serviceAccount": {
                                "create": False,
                                "name": "awsfsxcsidriver",
                            }
                        },
                    },
                    get_chart_values(self.replicated_ecr_images_metadata, FSX_DRIVER),
                ),
            )
            awsfsxcsi_chart.node.add_dependency(awsfsxcsidriver_service_account)

        # Cluster Autoscaler
        if self.eks_addons_config.get("deploy_cluster_autoscaler"):
            clusterautoscaler_service_account = eks_cluster.add_service_account(
                "clusterautoscaler", name="clusterautoscaler", namespace="kube-system"
            )

            clusterautoscaler_policy_statement_json_path = os.path.join(
                project_dir, addons_iam_policies_folder, "cluster-autoscaler-iam.json"
            )
            with open(clusterautoscaler_policy_statement_json_path) as json_file:
                clusterautoscaler_policy_statement_json = json.load(json_file)

            # Attach the necessary permissions
            clusterautoscaler_policy = iam.Policy(
                self,
                "clusterautoscalerpolicy",
                document=iam.PolicyDocument.from_json(
                    clusterautoscaler_policy_statement_json
                ),
            )
            clusterautoscaler_service_account.role.attach_inline_policy(
                clusterautoscaler_policy
            )

            # Install the Cluster Autoscaler
            # For more info see https://github.com/kubernetes/autoscaler/tree/master/charts/cluster-autoscaler
            import aws_cdk.aws_s3_assets as s3_assets

            clusterautoscaler_chart = eks_cluster.add_helm_chart(
                "cluster-autoscaler",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, CLUSTER_AUTOSCALER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, CLUSTER_AUTOSCALER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), CLUSTER_AUTOSCALER),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), CLUSTER_AUTOSCALER),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), CLUSTER_AUTOSCALER),
                release="clusterautoscaler",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "autoDiscovery": {"clusterName": eks_cluster.cluster_name},
                        "awsRegion": self.region,
                        "rbac": {
                            "serviceAccount": {
                                "create": False,
                                "name": "clusterautoscaler",
                            }
                        },
                        "replicaCount": 2,
                        "extraArgs": {
                            "skip-nodes-with-system-pods": False,
                            "balance-similar-node-groups": True,
                        },
                    },
                    get_chart_values(
                        self.replicated_ecr_images_metadata, CLUSTER_AUTOSCALER
                    ),
                ),
            )
            clusterautoscaler_chart.node.add_dependency(
                clusterautoscaler_service_account
            )

        # Metrics Server (required for the Horizontal Pod Autoscaler (HPA))
        if self.eks_addons_config.get("deploy_metrics_server"):
            # For more info see https://github.com/kubernetes-sigs/metrics-server/tree/master/charts/metrics-server
            # Changed from the Bitnami chart for Graviton/ARM64 support
            import aws_cdk.aws_s3_assets as s3_assets

            eks_cluster.add_helm_chart(
                "metrics-server",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, METRICS_SERVER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, METRICS_SERVER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), METRICS_SERVER),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), METRICS_SERVER),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), METRICS_SERVER),
                release="metricsserver",
                namespace="kube-system",
                values=deep_merge(
                    {"resources": {"requests": {"cpu": "0.25", "memory": "0.5Gi"}}},
                    get_chart_values(
                        self.replicated_ecr_images_metadata, METRICS_SERVER
                    ),
                ),
            )

        # AWS Distro for Opentelemetry
        if self.eks_addons_config.get("deploy_adot"):
            adot_addon = eks.CfnAddon(
                self,
                "adot",
                addon_name="adot",
                resolve_conflicts="OVERWRITE",
                cluster_name=eks_cluster.cluster_name,
            )

            adot_addon.node.add_dependency(eks_cluster)

            # Create the namespace manifest
            namespace_manifest = {
                "apiVersion": "v1",
                "kind": "Namespace",
                "metadata": {"name": "cert-manager"},
            }

            # Add the namespace manifest to the EKS cluster
            cert_manager_namespace = eks_cluster.add_manifest(
                "cert-manager", namespace_manifest
            )

            # Create service account for cert-manager
            cert_manager_service_account = eks_cluster.add_service_account(
                "cert-manager",
                name="cert-manager",
                namespace="cert-manager",
            )

            cert_manager_service_account.node.add_dependency(cert_manager_namespace)

            # Adding policy statement
            cert_manager_policy_statement = iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=[
                    "acm:DescribeCertificate",
                    "acm:ListCertificates",
                    "acm:GetCertificate",
                    "route53:ChangeResourceRecordSets",
                    "route53:GetChange",
                    "route53:GetHostedZone",
                    "route53:ListHostedZones",
                    "route53:ListResourceRecordSets",
                ],
                resources=["*"],
            )

            # Create IAM policy for cert-manager
            cert_manager_policy = iam.Policy(
                self,
                "cert-manager-policy",
                policy_name="cert-manager-policy",
                statements=[cert_manager_policy_statement],
            )

            cert_manager_service_account.role.attach_inline_policy(cert_manager_policy)

            # Deploy cert-manager
            import aws_cdk.aws_s3_assets as s3_assets

            cert_manager_chart = eks_cluster.add_helm_chart(
                "cert-manager",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, CERT_MANAGER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, CERT_MANAGER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), CERT_MANAGER),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), CERT_MANAGER),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), CERT_MANAGER),
                release="cert-manager",
                namespace="cert-manager",
                create_namespace=False,
                values=deep_merge(
                    {
                        "installCRDs": True,
                        "extraArgs": [
                            "--dns01-recursive-nameservers-only=false",
                        ],
                        "podSecurityPolicy": {
                            "enabled": False,
                        },
                        "serviceAccount": {
                            "create": False,
                            "name": cert_manager_service_account.service_account_name,
                            "annotations": {
                                "eks.amazonaws.com/role-arn": cert_manager_service_account.role.role_arn,
                            },
                        },
                    },
                    get_chart_values(str(self.eks_version), CERT_MANAGER),
                ),
            )

            cert_manager_chart.node.add_dependency(cert_manager_service_account)
            cert_manager_chart.node.add_dependency(awslbcontroller_chart)

        if self.eks_addons_config.get("deploy_external_dns"):
            externaldns_service_account = eks_cluster.add_service_account(
                "external-dns", name="external-dns", namespace="kube-system"
            )

            # Create the PolicyStatements to attach to the role
            # See https://github.com/kubernetes-sigs/external-dns/blob/master/docs/tutorials/aws.md#iam-policy
            # NOTE that this will give External DNS access to all Route53 zones
            # For production you'll likely want to replace 'Resource *' with specific resources
            externaldns_policy_statement_json_1 = {
                "Effect": "Allow",
                "Action": ["route53:ChangeResourceRecordSets"],
                "Resource": [f"arn:{partition}:route53:::hostedzone/*"],
            }
            externaldns_policy_statement_json_2 = {
                "Effect": "Allow",
                "Action": ["route53:ListHostedZones", "route53:ListResourceRecordSets"],
                "Resource": ["*"],
            }

            # Attach the necessary permissions
            externaldns_service_account.add_to_principal_policy(
                iam.PolicyStatement.from_json(externaldns_policy_statement_json_1)
            )
            externaldns_service_account.add_to_principal_policy(
                iam.PolicyStatement.from_json(externaldns_policy_statement_json_2)
            )

            # Deploy External DNS from the bitnami Helm chart
            # For more info see https://github.com/kubernetes-sigs/external-dns/tree/master/charts/external-dns
            # Changed from the Bitnami chart for Graviton/ARM64 support
            import aws_cdk.aws_s3_assets as s3_assets

            externaldns_chart = eks_cluster.add_helm_chart(
                "external-dns",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, EXTERNAL_DNS
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, EXTERNAL_DNS
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), EXTERNAL_DNS),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), EXTERNAL_DNS),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), EXTERNAL_DNS),
                release="externaldns",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "serviceAccount": {"create": False, "name": "external-dns"},
                        "resources": {"requests": {"cpu": "0.25", "memory": "0.5Gi"}},
                    },
                    get_chart_values(self.replicated_ecr_images_metadata, EXTERNAL_DNS),
                ),
            )
            externaldns_chart.node.add_dependency(externaldns_service_account)

        # Secrets Manager CSI Driver
        if self.eks_addons_config.get("deploy_secretsmanager_csi"):
            # https://docs.aws.amazon.com/secretsmanager/latest/userguide/integrating_csi_driver.html

            # First we install the Secrets Store CSI Driver Helm Chart
            # https://github.com/kubernetes-sigs/secrets-store-csi-driver/tree/main/charts/secrets-store-csi-driver
            import aws_cdk.aws_s3_assets as s3_assets

            eks_cluster.add_helm_chart(
                "csi-secrets-store",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, SECRETS_MANAGER_CSI_DRIVER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, SECRETS_MANAGER_CSI_DRIVER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(
                    str(self.eks_version), SECRETS_MANAGER_CSI_DRIVER
                ),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(
                    str(self.eks_version), SECRETS_MANAGER_CSI_DRIVER
                ),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(
                    str(self.eks_version),
                    SECRETS_MANAGER_CSI_DRIVER,
                ),
                release="csi-secrets-store",
                namespace="kube-system",
                # Since sometimes you want these secrets as environment variables enabling syncSecret
                # For more info see https://secrets-store-csi-driver.sigs.k8s.io/topics/sync-as-kubernetes-secret.html
                values=deep_merge(
                    {"syncSecret": {"enabled": True}},
                    get_chart_values(
                        self.replicated_ecr_images_metadata,
                        SECRETS_MANAGER_CSI_DRIVER,
                    ),
                ),
            )
            # Install the AWS Provider
            # See https://github.com/aws/secrets-store-csi-driver-provider-aws for more info

            # Create the IRSA Mapping
            secrets_csi_sa = eks_cluster.add_service_account(
                "secrets-csi-sa",
                name="csi-secrets-store-provider-aws",
                namespace="kube-system",
            )

            # Associate the IAM Policy
            # NOTE: you really want to specify the secret ARN rather than * in the Resource
            # Consider namespacing these by cluster/environment name or some such as in this example:
            # "Resource": ["arn:aws:secretsmanager:Region:AccountId:secret:TestEnv/*"]
            secrets_csi_policy_statement_json_1 = {
                "Effect": "Allow",
                "Action": [
                    "secretsmanager:GetSecretValue",
                    "secretsmanager:DescribeSecret",
                ],
                "Resource": ["*"],
            }
            secrets_csi_sa.add_to_principal_policy(
                iam.PolicyStatement.from_json(secrets_csi_policy_statement_json_1)
            )

            # Deploy the manifests from secrets-store-csi-driver-provider-aws.yaml
            secrets_store_csi_driver_image = get_image(
                str(self.eks_version),
                self.replicated_ecr_images_metadata,
                SECRETS_STORE_CSI_DRIVER_PROVIDER_AWS,
            )
            t = Template(
                open(
                    os.path.join(
                        project_dir,
                        "secrets-config/secrets-store-csi-driver-provider-aws.yaml",
                    ),
                    "r",
                ).read()
            )

            # Substitute the image name in the secrets-store-csi-driver-provider-aws.yaml file
            secrets_csi_provider_yaml_file = t.substitute(
                image=str(secrets_store_csi_driver_image)
            )
            secrets_csi_provider_yaml = list(
                yaml.load_all(secrets_csi_provider_yaml_file, Loader=yaml.FullLoader)
            )
            loop_iteration = 0
            for value in secrets_csi_provider_yaml:
                loop_iteration = loop_iteration + 1
                manifest_id = "SecretsCSIProviderManifest" + str(loop_iteration)
                manifest = eks_cluster.add_manifest(manifest_id, value)
                manifest.node.add_dependency(secrets_csi_sa)

        # Kubernetes External Secrets
        if self.eks_addons_config.get("deploy_external_secrets"):
            # Deploy the External Secrets Controller
            # Create the Service Account
            externalsecrets_service_account = eks_cluster.add_service_account(
                "kubernetes-external-secrets",
                name="kubernetes-external-secrets",
                namespace="kube-system",
            )

            # Define the policy in JSON
            externalsecrets_policy_statement_json_1 = {
                "Effect": "Allow",
                "Action": [
                    "secretsmanager:GetResourcePolicy",
                    "secretsmanager:GetSecretValue",
                    "secretsmanager:DescribeSecret",
                    "secretsmanager:ListSecretVersionIds",
                ],
                "Resource": ["*"],
            }

            # Add the policies to the service account
            externalsecrets_service_account.add_to_principal_policy(
                iam.PolicyStatement.from_json(externalsecrets_policy_statement_json_1)
            )

            # Deploy the Helm Chart
            # https://github.com/external-secrets/external-secrets/tree/main/deploy/charts/external-secrets
            import aws_cdk.aws_s3_assets as s3_assets

            eks_cluster.add_helm_chart(
                "external-secrets",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, EXTERNAL_SECRETS
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, EXTERNAL_SECRETS
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), EXTERNAL_SECRETS),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), EXTERNAL_SECRETS),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), EXTERNAL_SECRETS),
                release="external-secrets",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "env": {"AWS_REGION": self.region},
                        "serviceAccount": {
                            "name": "kubernetes-external-secrets",
                            "create": False,
                        },
                        "securityContext": {"fsGroup": 65534},
                        "resources": {"requests": {"cpu": "0.25", "memory": "0.5Gi"}},
                    },
                    get_chart_values(
                        self.replicated_ecr_images_metadata, EXTERNAL_SECRETS
                    ),
                ),
            )
        # CloudWatch Container Insights - Metrics
        if self.eks_addons_config.get("deploy_cloudwatch_container_insights_metrics"):
            # https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Container-Insights-setup-metrics.html

            # Create the Service Account
            cw_container_insights_sa = eks_cluster.add_service_account(
                "cloudwatch-agent", name="cloudwatch-agent", namespace="kube-system"
            )
            cw_container_insights_sa.role.add_managed_policy(
                iam.ManagedPolicy.from_aws_managed_policy_name(
                    "CloudWatchAgentServerPolicy"
                )
            )

            # It opens cwagentconfig.json file in read mode ("r") and reads its content using the read() method. The content is stored in the cwagentconfig_content variable.
            with open(
                os.path.join(project_dir, "monitoring-config/cwagentconfig.json"),
                "r",
                encoding="utf-8",
            ) as f:
                cwagentconfig_content = f.read()

            # Set up the settings ConfigMap
            eks_cluster.add_manifest(
                "CWAgentConfigMap",
                {
                    "apiVersion": "v1",
                    "kind": "ConfigMap",
                    "data": {
                        "cwagentconfig.json": cwagentconfig_content,
                    },
                    "metadata": {"name": "cwagentconfig", "namespace": "kube-system"},
                },
            )

            # Import cloudwatch-agent.yaml to a list of dictionaries and submit them as a manifest to EKS
            # Read the YAML file
            cloudwatch_agent_image = get_image(
                str(self.eks_version),
                self.replicated_ecr_images_metadata,
                CLOUDWATCH_AGENT,
            )
            t = Template(
                open(
                    os.path.join(
                        project_dir, "monitoring-config/cloudwatch-agent.yaml"
                    ),
                    "r",
                ).read()
            )

            # Substitute the image name in the cwagentconfig.json file
            cw_agent_yaml_file = t.substitute(image=str(cloudwatch_agent_image))
            cw_agent_yaml = list(
                yaml.load_all(cw_agent_yaml_file, Loader=yaml.FullLoader)
            )
            loop_iteration = 0
            for value in cw_agent_yaml:
                loop_iteration = loop_iteration + 1
                manifest_id = "CWAgent" + str(loop_iteration)
                eks_cluster.add_manifest(manifest_id, value)

        # CloudWatch Container Insights - Logs
        if self.eks_addons_config.get("deploy_cloudwatch_container_insights_logs"):
            # Create the Service Account
            fluentbit_cw_service_account = eks_cluster.add_service_account(
                "fluentbit-cw", name="fluentbit-cw", namespace="kube-system"
            )

            fluentbit_cw_policy_statement_json_1 = {
                "Effect": "Allow",
                "Action": [
                    "logs:PutLogEvents",
                    "logs:DescribeLogStreams",
                    "logs:DescribeLogGroups",
                    "logs:CreateLogStream",
                    "logs:CreateLogGroup",
                    "logs:PutRetentionPolicy",
                ],
                "Resource": ["*"],
            }

            # Add the policies to the service account
            fluentbit_cw_service_account.add_to_principal_policy(
                iam.PolicyStatement.from_json(fluentbit_cw_policy_statement_json_1)
            )

            # https://github.com/fluent/helm-charts/tree/main/charts/fluent-bit
            import aws_cdk.aws_s3_assets as s3_assets

            fluentbit_chart_cw = eks_cluster.add_helm_chart(
                "fluentbit-cw",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, FLUENTBIT
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, FLUENTBIT
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), FLUENTBIT),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), FLUENTBIT),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), FLUENTBIT),
                release="fluent-bit-cw",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "serviceAccount": {"create": False, "name": "fluentbit-cw"},
                        "config": {
                            "outputs": "[OUTPUT]\n    Name cloudwatch_logs\n    Match   *\n    region "
                            + self.region
                            + "\n    log_group_name "
                            + eks_cluster.cluster_name
                            + "fluent-bit-cloudwatch\n    log_stream_prefix from-fluent-bit-\n "
                            + "   auto_create_group true\n    log_retention_days "
                            + str(
                                self.node.try_get_context(
                                    "cloudwatch_container_insights_logs_retention_days"
                                )
                            )
                            + "\n",
                            "filters.conf": "[FILTER]\n  Name  kubernetes\n  Match  kube.*\n  Merge_Log  On\n  Buffer_Size  0\n  Kube_Meta_Cache_TTL  300s\n"
                            + "[FILTER]\n    Name modify\n    Match *\n    Rename log log_data\n    Rename stream stream_name\n"
                            + "[FILTER]\n    Name record_modifier\n    Match *\n    Record log_type startup\n"
                            + "[FILTER]\n    Name record_modifier\n    Match *\n    Record log_type shutdown\n"
                            + "[FILTER]\n    Name record_modifier\n    Match *\n    Record log_type error\n"
                            + "[FILTER]\n    Name record_modifier\n    Match *\n    Record log_type exception\n"
                            + "[FILTER]\n    Name record_modifier\n    Match *\n    Record log_type ingestion\n"
                            + "[FILTER]\n    Name record_modifier\n    Match *\n    Record log_type processing\n"
                            + "[FILTER]\n    Name record_modifier\n    Match *\n    Record log_type output\n"
                            + "[FILTER]\n    Name record_modifier\n    Match *\n    Record log_type performance\n"
                            + "\n",
                        },
                    },
                    get_chart_values(self.replicated_ecr_images_metadata, FLUENTBIT),
                ),
            )
            fluentbit_chart_cw.node.add_dependency(fluentbit_cw_service_account)

        # Amazon Managed Prometheus (AMP)
        if self.eks_addons_config.get("deploy_amp"):
            # https://aws.amazon.com/blogs/mt/getting-started-amazon-managed-service-for-prometheus/
            # Create AMP workspace
            amp_workspace = aps.CfnWorkspace(self, "AMPWorkspace")

            # Create IRSA mapping
            amp_sa = eks_cluster.add_service_account(
                "amp-sa", name="amp-iamproxy-service-account", namespace="kube-system"
            )

            # Associate the IAM Policy
            amp_policy_statement_json_1 = {
                "Effect": "Allow",
                "Action": [
                    "aps:RemoteWrite",
                    "aps:QueryMetrics",
                    "aps:GetSeries",
                    "aps:GetLabels",
                    "aps:GetMetricMetadata",
                ],
                "Resource": ["*"],
            }
            amp_sa.add_to_principal_policy(
                iam.PolicyStatement.from_json(amp_policy_statement_json_1)
            )

            # Install Prometheus with a low 1 hour local retention to ship the metrics to the AMP
            # https://github.com/prometheus-community/helm-charts/tree/main/charts/kube-prometheus-stack
            # Changed this from just Prometheus to the Prometheus Operator for the additional functionality
            # Changed this to not use EBS PersistentVolumes so it'll work with Fargate Only Clusters
            # This should be acceptable as the metrics are immediatly streamed to the AMP
            import aws_cdk.aws_s3_assets as s3_assets

            amp_prometheus_chart = eks_cluster.add_helm_chart(
                "prometheus-chart",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, PROMETHEUS_STACK
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, PROMETHEUS_STACK
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), PROMETHEUS_STACK),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), PROMETHEUS_STACK),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), PROMETHEUS_STACK),
                release="prometheus-for-amp",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "prometheus": {
                            "serviceAccount": {
                                "create": False,
                                "name": "amp-iamproxy-service-account",
                                "annotations": {
                                    "eks.amazonaws.com/role-arn": amp_sa.role.role_arn,
                                },
                            },
                            "prometheusSpec": {
                                "storageSpec": {"emptyDir": {"medium": "Memory"}},
                                "remoteWrite": [
                                    {
                                        "queueConfig": {
                                            "maxSamplesPerSend": 1000,
                                            "maxShards": 200,
                                            "capacity": 2500,
                                        },
                                        "url": amp_workspace.attr_prometheus_endpoint
                                        + "api/v1/remote_write",
                                        "sigv4": {"region": self.region},
                                    }
                                ],
                                "retention": "1h",
                                "resources": {"limits": {"cpu": 1, "memory": "1Gi"}},
                            },
                        },
                        "alertmanager": {"enabled": False},
                        "grafana": {"enabled": False},
                        "prometheusOperator": {
                            "admissionWebhooks": {"enabled": False},
                            "tls": {"enabled": False},
                            "resources": {
                                "requests": {"cpu": "0.25", "memory": "0.5Gi"}
                            },
                        },
                        "kubeControllerManager": {"enabled": False},
                        "kubeScheduler": {"enabled": False},
                        "kubeProxy": {"enabled": False},
                        "nodeExporter": {"enabled": False},
                    },
                    get_chart_values(
                        self.replicated_ecr_images_metadata, PROMETHEUS_STACK
                    ),
                ),
            )
            amp_prometheus_chart.node.add_dependency(amp_sa)

        # Self-Managed Grafana for AMP
        if self.eks_addons_config.get("deploy_grafana_for_amp"):
            # Install a self-managed Grafana to visualise the AMP metrics
            # NOTE You likely want to use the AWS Managed Grafana (AMG) in production
            # We are using this as AMG requires SSO/SAML and is harder to include in the template
            # NOTE We are not enabling PersistentVolumes to allow this to run in Fargate making this immutable
            # Any changes to which dashboards to use should be deployed via the ConfigMaps in order to persist
            # https://github.com/grafana/helm-charts/tree/main/charts/grafana#sidecar-for-dashboards
            # For more information see https://github.com/grafana/helm-charts/tree/main/charts/grafana
            import aws_cdk.aws_s3_assets as s3_assets

            amp_grafana_chart = eks_cluster.add_helm_chart(
                "amp-grafana-chart",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, GRAFANA
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, GRAFANA
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), GRAFANA),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), GRAFANA),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), GRAFANA),
                release="grafana-for-amp",
                namespace="kube-system",
                values=deep_merge(
                    {
                        "serviceAccount": {
                            "name": "amp-iamproxy-service-account",
                            "annotations": {
                                "eks.amazonaws.com/role-arn": amp_sa.role.role_arn
                            },
                            "create": False,
                        },
                        "grafana.ini": {"auth": {"sigv4_auth_enabled": True}},
                        "service": {
                            "type": "LoadBalancer",
                            "annotations": {
                                "service.beta.kubernetes.io/aws-load-balancer-type": "nlb-ip",
                                "service.beta.kubernetes.io/aws-load-balancer-internal": "true",
                            },
                        },
                        "datasources": {
                            "datasources.yaml": {
                                "apiVersion": 1,
                                "datasources": [
                                    {
                                        "name": "Prometheus",
                                        "type": "prometheus",
                                        "access": "proxy",
                                        "url": amp_workspace.attr_prometheus_endpoint,
                                        "isDefault": True,
                                        "editable": True,
                                        "jsonData": {
                                            "httpMethod": "POST",
                                            "sigV4Auth": True,
                                            "sigV4AuthType": "default",
                                            "sigV4Region": self.region,
                                        },
                                    }
                                ],
                            }
                        },
                        "sidecar": {
                            "dashboards": {
                                "enabled": True,
                                "label": "grafana_dashboard",
                            }
                        },
                        "resources": {"requests": {"cpu": "0.25", "memory": "0.5Gi"}},
                    },
                    get_chart_values(self.replicated_ecr_images_metadata, GRAFANA),
                ),
            )
            amp_grafana_chart.node.add_dependency(amp_prometheus_chart)
            amp_grafana_chart.node.add_dependency(awslbcontroller_chart)

            # Dashboards for Grafana from the grafana-dashboards.yaml file
            grafana_dashboards_yaml_file = open(
                "monitoring-config/grafana-dashboards.yaml", "r"
            )
            grafana_dashboards_yaml = list(
                yaml.load_all(grafana_dashboards_yaml_file, Loader=yaml.FullLoader)
            )
            grafana_dashboards_yaml_file.close()
            loop_iteration = 0
            for value in grafana_dashboards_yaml:
                loop_iteration = loop_iteration + 1
                manifest_id = "GrafanaDashboard" + str(loop_iteration)
                eks_cluster.add_manifest(manifest_id, value)

        eks_cluster.add_manifest(
            "cluster-role",
            {
                "apiVersion": "rbac.authorization.k8s.io/v1",
                "kind": "ClusterRole",
                "metadata": {"name": "system-access"},
                "rules": [
                    {
                        "apiGroups": ["", "storage.k8s.io"],
                        "resources": ["persistentVolumes", "nodes", "storageClasses"],
                        "verbs": ["get", "watch", "list"],
                    }
                ],
            },
        )

        # Defining the read only access role
        readonly_role_access_manifest = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "Role",
            "metadata": {"name": "readonly-role"},
            "rules": [
                {
                    "apiGroups": [""],
                    "resources": ["*"],
                    "verbs": ["get", "list", "watch"],
                }
            ],
        }

        # Deploying the read only access role to the EKS cluster
        eks_cluster.add_manifest(
            "readonly_role_access_manifest", readonly_role_access_manifest
        )

        # Defining the cluster read only access role
        cluster_readonly_role_access_manifest = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "ClusterRole",
            "metadata": {"name": "cluster-readonly-role"},
            "rules": [
                {
                    "apiGroups": [""],
                    "resources": ["*"],
                    "verbs": ["get", "list", "watch"],
                }
            ],
        }

        # Deploying the read only access role to the EKS cluster
        eks_cluster.add_manifest(
            "cluster_readonly_role_access_manifest",
            cluster_readonly_role_access_manifest,
        )

        # Defining the admin role access role
        admin_role_access_manifest = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "ClusterRole",
            "metadata": {"name": "admin-role"},
            "rules": [
                {
                    "apiGroups": ["*"],
                    "resources": ["*"],
                    "verbs": [
                        "get",
                        "list",
                        "watch",
                        "create",
                        "delete",
                        "update",
                        "patch",
                    ],
                }
            ],
        }

        # Deploying the admin role access role to the EKS cluster
        eks_cluster.add_manifest(
            "admin_role_access_manifest", admin_role_access_manifest
        )

        # Defining the poweruser role access role
        poweruser_role_access_manifest = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "Role",
            "metadata": {"name": "poweruser-role"},
            "rules": [
                {
                    "apiGroups": ["", "apps", "extensions"],
                    "resources": ["*"],
                    "verbs": [
                        "get",
                        "list",
                        "watch",
                        "create",
                        "delete",
                        "update",
                        "patch",
                    ],
                }
            ],
        }

        # Deploying the poweruser role access role to the EKS cluster
        eks_cluster.add_manifest(
            "poweruser_role_access_manifest", poweruser_role_access_manifest
        )

        # Define the RoleBinding manifest as a dictionary for readonly role
        readonly_role_binding_manifest = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "RoleBinding",
            "metadata": {"name": "readonly-role-binding"},
            "subjects": [
                {
                    "kind": "Group",
                    "name": "readonly-group",
                    "apiGroup": "rbac.authorization.k8s.io",
                }
            ],
            "roleRef": {
                "kind": "Role",
                "name": "readonly-role",
                "apiGroup": "rbac.authorization.k8s.io",
            },
        }

        # Deploy the RoleBinding manifest to the EKS cluster for readonly role
        eks_cluster.add_manifest(
            "readonly_role_binding_manifest", readonly_role_binding_manifest
        )

        # Define the RoleBinding manifest as a dictionary for readonly role
        cluster_readonly_role_binding_manifest = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "ClusterRoleBinding",
            "metadata": {"name": "cluster-readonly-role-binding"},
            "subjects": [
                {
                    "kind": "Group",
                    "name": "cluster-readonly-group",
                    "apiGroup": "rbac.authorization.k8s.io",
                }
            ],
            "roleRef": {
                "kind": "ClusterRole",
                "name": "cluster-readonly-role",
                "apiGroup": "rbac.authorization.k8s.io",
            },
        }

        # Deploy the RoleBinding manifest to the EKS cluster for readonly role
        eks_cluster.add_manifest(
            "cluster_readonly_role_binding_manifest",
            cluster_readonly_role_binding_manifest,
        )

        # Define the RoleBinding manifest as a dictionary for admin role
        admin_role_binding_manifest = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "ClusterRoleBinding",
            "metadata": {"name": "admin-role-binding"},
            "subjects": [
                {
                    "kind": "Group",
                    "name": "admin",
                    "apiGroup": "rbac.authorization.k8s.io",
                }
            ],
            "roleRef": {
                "kind": "ClusterRole",
                "name": "admin-role",
                "apiGroup": "rbac.authorization.k8s.io",
            },
        }

        # Deploy the RoleBinding manifest to the EKS cluster for admin role
        eks_cluster.add_manifest(
            "admin_role_binding_manifest", admin_role_binding_manifest
        )

        # Define the RoleBinding manifest as a dictionary for poweruser role
        poweruser_role_binding_manifest = {
            "apiVersion": "rbac.authorization.k8s.io/v1",
            "kind": "RoleBinding",
            "metadata": {"name": "poweruser-role-binding"},
            "subjects": [
                {
                    "kind": "Group",
                    "name": "poweruser-group",
                    "apiGroup": "rbac.authorization.k8s.io",
                }
            ],
            "roleRef": {
                "kind": "Role",
                "name": "poweruser-role",
                "apiGroup": "rbac.authorization.k8s.io",
            },
        }

        # Deploy the RoleBinding manifest to the EKS cluster for admin role
        eks_cluster.add_manifest(
            "poweruser_role_binding_manifest", poweruser_role_binding_manifest
        )

        # Create a PodDisruptionBudget for ADDF Jobs
        eks_cluster.add_manifest(
            "addf-job-pdb",
            {
                "apiVersion": "policy/v1",
                "kind": "PodDisruptionBudget",
                "metadata": {
                    "name": "addf-job-pdb",
                },
                "spec": {
                    "minAvailable": 1,
                    "selector": {
                        "matchLabels": {"app": "addf-job"},
                    },
                },
            },
        )

        if self.eks_addons_config.get("deploy_kured"):
            # https://kubereboot.github.io/charts/
            import aws_cdk.aws_s3_assets as s3_assets

            _ = eks_cluster.add_helm_chart(
                "kured",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, KURED
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, KURED
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), KURED),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), KURED),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), KURED),
                release="kured",
                namespace="kured",
                values=deep_merge(
                    {
                        "nodeSelector": {"kubernetes.io/os": "linux"},
                    },
                    get_chart_values(self.replicated_ecr_images_metadata, KURED),
                ),
            )

        if self.eks_addons_config.get("deploy_calico"):
            calico_values = get_chart_values(
                self.replicated_ecr_images_metadata, CALICO
            )
            if (
                calico_values
                and "tigeraOperator" in calico_values
                and "registry" in calico_values["tigeraOperator"]
            ):
                # https://docs.tigera.io/calico/3.25/reference/installation/api#operator.tigera.io/v1.InstallationSpec
                calico_values["installation"] = {}
                calico_values["installation"]["registry"] = calico_values[
                    "tigeraOperator"
                ]["registry"]

            # https://docs.projectcalico.org/charts
            import aws_cdk.aws_s3_assets as s3_assets

            calico_chart = eks_cluster.add_helm_chart(
                "tigera-operator",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, CALICO
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, CALICO
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), CALICO),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), CALICO),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), CALICO),
                values=deep_merge(
                    calico_values,
                ),
                release="calico",
                namespace="tigera-operator",
            )

            with open(
                os.path.join(
                    project_dir, "network-policies/default-allow-kube-system.json"
                ),
                "r",
            ) as f:
                default_allow_kube_system_policy_file = f.read()

            allow_kube_system_policy = eks_cluster.add_manifest(
                "default-allow-kube-system",
                json.loads(default_allow_kube_system_policy_file),
            )

            allow_kube_system_policy.node.add_dependency(calico_chart)

            with open(
                os.path.join(
                    project_dir, "network-policies/default-allow-tigera-operator.json"
                ),
                "r",
            ) as f:
                default_allow_tigera_operator_policy_file = f.read()

            allow_tigera_operator_policy = eks_cluster.add_manifest(
                "default-allow-tigera-operator",
                json.loads(default_allow_tigera_operator_policy_file),
            )

            allow_tigera_operator_policy.node.add_dependency(allow_kube_system_policy)

            with open(
                os.path.join(project_dir, "network-policies/default-deny.json"), "r"
            ) as f:
                default_deny_policy_file = f.read()

            default_deny_policy = eks_cluster.add_manifest(
                "default-deny-policy", json.loads(default_deny_policy_file)
            )

            default_deny_policy.node.add_dependency(allow_tigera_operator_policy)

        if (
            "value" in self.eks_addons_config.get("deploy_kyverno")
            and self.eks_addons_config.get("deploy_kyverno")["value"]
        ):
            # https://kyverno.github.io/kyverno/
            import aws_cdk.aws_s3_assets as s3_assets

            kyverno_chart = eks_cluster.add_helm_chart(
                "kyverno",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, KYVERNO
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, KYVERNO
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), KYVERNO),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), KYVERNO),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), KYVERNO),
                values=deep_merge(
                    {
                        "resources": {
                            "limits": {"memory": "4Gi"},
                            "requests": {"cpu": "1", "memory": "1Gi"},
                        }
                    },
                    get_chart_values(self.replicated_ecr_images_metadata, KYVERNO),
                ),
                release="kyverno",
                namespace="kyverno",
            )

            if self.eks_addons_config.get("deploy_calico"):
                with open(
                    os.path.join(
                        project_dir, "network-policies/default-allow-kyverno.json"
                    ),
                    "r",
                ) as f:
                    default_allow_kyverno_policy_file = f.read()

                allow_kyverno_policy = eks_cluster.add_manifest(
                    "default-allow-kyverno",
                    json.loads(default_allow_kyverno_policy_file),
                )

                allow_kyverno_policy.node.add_dependency(kyverno_chart)

            if "kyverno_policies" in self.eks_addons_config.get("deploy_kyverno"):
                all_policies = self.eks_addons_config.get("deploy_kyverno")[
                    "kyverno_policies"
                ]
                for policy_type, policies in all_policies.items():
                    for policy in policies:
                        f = open(
                            os.path.join(
                                project_dir,
                                "kyverno-policies",
                                policy_type,
                                f"{policy}.yaml",
                            ),
                            "r",
                        ).read()
                        manifest_yaml = list(yaml.load_all(f, Loader=yaml.FullLoader))
                        previous_manifest = None
                        for value in manifest_yaml:
                            manifest_name = value["metadata"]["name"]
                            manifest = eks_cluster.add_manifest(manifest_name, value)
                            if previous_manifest is None:
                                manifest.node.add_dependency(kyverno_chart)
                            else:
                                manifest.node.add_dependency(previous_manifest)
                            previous_manifest = manifest
            import aws_cdk.aws_s3_assets as s3_assets

            kyverno_policy_reporter_chart = eks_cluster.add_helm_chart(
                "kyverno-policy-reporter",
                chart_asset=s3_assets.Asset(
                    self,
                    get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, KYVERNO_POLICY_REPORTER
                    ),
                    path="./helmchart/"
                    + get_chart_name_from_file(
                        self.replicated_ecr_images_metadata, KYVERNO_POLICY_REPORTER
                    ),
                )
                if deploy_helm_chart_local
                else None,
                chart=None
                if deploy_helm_chart_local
                else get_chart_release(str(self.eks_version), KYVERNO_POLICY_REPORTER),
                version=None
                if deploy_helm_chart_local
                else get_chart_version(str(self.eks_version), KYVERNO_POLICY_REPORTER),
                repository=None
                if deploy_helm_chart_local
                else get_chart_repo(str(self.eks_version), KYVERNO_POLICY_REPORTER),
                release="policy-reporter",
                namespace="policy-reporter",
                values=deep_merge(
                    {
                        "kyvernoPlugin": {"enabled": True},
                        "ui": {
                            "enabled": True,
                            "plugins": {"kyverno": True},
                        },
                    },
                    get_chart_values(
                        str(self.eks_version),
                        KYVERNO_POLICY_REPORTER,
                    ),
                ),
            )

            kyverno_policy_reporter_chart.node.add_dependency(kyverno_chart)

        # Add NVIDIA Device Pugin via helm chart
        nvidia_plugin_sa = eks_cluster.add_service_account(
            "nvidia_plugin_sa",
            name="nvidia-device-plugin-ds",
            namespace="kube-system",
        )

        nvidia_plugin_policy_statement_json_1 = {
            "Effect": "Allow",
            "Action": [
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret",
            ],
            "Resource": ["*"],
        }
        nvidia_plugin_sa.add_to_principal_policy(
            iam.PolicyStatement.from_json(nvidia_plugin_policy_statement_json_1)
        )

        nvidia_chart_values = get_chart_values(
            self.replicated_ecr_images_metadata,
            NVIDIA_DEVICE_PLUGIN,
        )

        nvidia_image = (
            nvidia_chart_values["image"]["repository"]
            + ":"
            + nvidia_chart_values["appVersion"]
        )
        print("nvidia_image: ", nvidia_image)

        t = Template(
            open(
                os.path.join(
                    project_dir, "daemonset-plugins/nvidia-device-plugin.yaml"
                ),
                "r",
            ).read()
        )

        # Substitute the image name in the cwagentconfig.json file
        nvdp_manifest_yaml_file = t.substitute(image=str(nvidia_image))
        nvdp_manifest_yaml = list(
            yaml.load_all(nvdp_manifest_yaml_file, Loader=yaml.FullLoader)
        )

        loop_iteration = 0
        for value in nvdp_manifest_yaml:
            loop_iteration = loop_iteration + 1
            nvdp_manifest_id = "NvidiaPluginManifest" + str(loop_iteration)
            nvdp_manifest = eks_cluster.add_manifest(nvdp_manifest_id, value)
            nvdp_manifest.node.add_dependency(nvidia_plugin_sa)

        # Add Core Dump Handler via helm chart
        core_dump_handler_chart_values = get_chart_values(
            self.replicated_ecr_images_metadata,
            CORE_DUMP_HANDLER,
        )
        core_dump_handler_image = (
            core_dump_handler_chart_values["image"]["registry"]
            + "/"
            + core_dump_handler_chart_values["image"]["repository"]
            + ":"
            + core_dump_handler_chart_values["appVersion"]
        )
        print("core_dump_handler_image: ", core_dump_handler_image)

        t = Template(
            open(
                os.path.join(project_dir, "core-dump-handler/core-dump-handler.yaml"),
                "r",
            ).read()
        )

        cdh_manifest_yaml_file = t.substitute(
            {
                "image": str(core_dump_handler_image),
                "region": f"{self.region}",
                "bucket": f"{self.core_dumps_bucket_name}",
            }
        )
        core_dump_handler_manifest_yaml = list(
            yaml.load_all(cdh_manifest_yaml_file, Loader=yaml.FullLoader)
        )

        cdh_namespace_manifest = eks_cluster.add_manifest(
            f"{self.deployment_name}-CDHManifest0",
            {
                "apiVersion": "v1",
                "kind": "Namespace",
                "metadata": {"name": "observe", "labels": {"name": "observe"}},
            },
        )

        cdhsarole = iam.Role(
            self,
            f"{self.deployment_name}-EKSCDHServiceAccountRole",
            role_name=f"{self.deployment_name}-core-dump-handler-role-s3-access",
            assumed_by=iam.PrincipalWithConditions(
                iam.WebIdentityPrincipal(
                    eks_cluster.open_id_connect_provider.open_id_connect_provider_arn
                ),
                conditions={
                    "StringEquals": CfnJson(
                        self,
                        f"{self.deployment_name}-ServiceAccountRoleTrustPolicy",
                        value={
                            f"{eks_cluster.cluster_open_id_connect_issuer}:aud": "sts.amazonaws.com",
                            f"{eks_cluster.cluster_open_id_connect_issuer}:sub": "system:serviceaccount:observe:core-dump-admin",
                        },
                    ),
                },
            ),
        )
        cdh_source_s3_access_policy_stmt = iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            actions=["s3:*", "s3-object-lambda:*"],
            resources=[f"arn:{partition}:s3:::{self.core_dumps_bucket_name}/*"],
        )
        print(
            f"core dump bucket name: arn:{partition}:s3:::{self.core_dumps_bucket_name}/*"
        )
        cdh_source_s3_access_policy = iam.Policy(
            scope=self,
            id=f"{self.deployment_name}-core-dump-handler-s3-access-policy",
            policy_name=f"{self.deployment_name}-core-dump-handler-s3-access-policy",
            statements=[cdh_source_s3_access_policy_stmt],
        )
        cdhsarole.attach_inline_policy(cdh_source_s3_access_policy)

        cdh_sa = eks_cluster.add_service_account(
            "core-dump-admin",
            name="core-dump-admin",
            namespace="observe",
            annotations={"eks.amazonaws.com/role-arn": cdhsarole.role_arn},
            labels={"name": "core-dump-admin"},
        )
        cdh_sa.node.add_dependency(cdh_namespace_manifest)
        cdh_sa.node.add_dependency(cdhsarole)

        loop_iteration = 0
        for value in core_dump_handler_manifest_yaml:
            loop_iteration = loop_iteration + 1
            cdh_manifest_id = f"{self.deployment_name}-CDHManifest" + str(
                loop_iteration
            )
            cdh_manifest = eks_cluster.add_manifest(cdh_manifest_id, value)
            cdh_manifest.node.add_dependency(cdh_namespace_manifest)

        # Outputs
        self.eks_cluster = eks_cluster
        self.eks_cluster_masterrole = cluster_admin_role

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

        NagSuppressions.add_stack_suppressions(
            self,
            apply_to_nested_stacks=True,
            suppressions=[
                {
                    "id": "AwsSolutions-IAM5",
                    "reason": "Resource access restriced to ADDF resources",
                },
                {
                    "id": "AwsSolutions-EC23",
                    "reason": "Open access for EKS API from whole corporate network needs to be enabled",
                },
                {
                    "id": "AwsSolutions-IAM4",
                    "reason": "Managed Policies are for service account roles only",
                },
                {
                    "id": "AwsSolutions-EKS1",
                    "reason": "No Customer data resides on the compute resources",
                },
                {
                    "id": "AwsSolutions-KMS5",
                    "reason": "The KMS Symmetric key does not have automatic key rotation enabled",
                },
            ],
        )

# EKS


## Description

This module creates an EKS Cluster with the following features and addons available for use:

- Can create EKS Control plane and data plane in Private Subnets (having NATG in the route tables)
- Can create EKS Control plane in Private Subnets and data plane in Isolated Subnets (having Link local route in the route tables)
- Can launch application pods in secondary CIDR to save IP exhaustion in the primary CIDR
- Encrypts the root EBS volumes of managed node groups
- Can encrypt the EKS Control plane using Envelope encryption

### Plugins supported by category

Load balancing:

- ALB Ingress Controller
- Nginx Ingress Controller

Storage:

- EBS CSI Driver
- EFS CSI Driver
- FSX Lustre Driver

Secrets:

- Secrets Manager CSI Driver

Scaling:

- Horizontal Pod Autoscaler (HPA)
- CLuster Autoscaler (CA)

Monitoring/Logging/Alerting:

- Cloudwatch Container Insights (Metrics & logs)

Networking:

- Custom CIDR implementation
- Calico for network isolation/security

Security:

- Kyverno policies (policy as enforcement in k8s)


## Inputs/Outputs

### Input Paramenters

#### Required

- `dataFiles`: Data files is a [seedfarmer feature](https://seed-farmer.readthedocs.io/en/latest/manifests.html#a-word-about-datafiles) which helps you to link a commonly available directory at the root of the repo. For EKS module, we declare the list of helm chart versions inside the supported `k8s-version.yaml` with the detailed metadata available inside the `default.yaml` for every supported plugin.
- `vpc-id`: The VPC-ID that the cluster will be created in
- `controlplane-subnet-ids`: The controlplane subnets that the EKS Cluster should be deployed in. These subnets should have internet connectivity enabled via NATG
- `dataplane-subnet-ids`: The dataplane subnets can be either private subnets (NATG enabled) or in isolated subnets(link local route only) depending on the compliance required to achieve
- `eks-compute` and `eks_nodegroup_config`: List of EKS Managed NodeGroup Configurations to use with the preferred EC2 instance types. The framework would automatically encrypt the root volume
- `eks-version`: The EKS Cluster version to lock the version to
- `eks-addons`: List of EKS addons to deploy on the EKS Cluster
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.

#### Optional

- `custom-subnet-ids`: The custom subnets for assigning IP addresses to the pods. Usually used when there is a limited number of IP addresses available in the primary CIDR subnets. Refer to [custom networking](https://docs.aws.amazon.com/eks/latest/userguide/cni-custom-network.html) for feature details
- `eks_admin_role_name`: The Admin Role to be mapped to the `systems:masters` group of RBAC
- `eks_poweruser_role_name`: The PowerUser Role to be mapped to the `poweruser-group` group of RBAC
- `eks_readonly_role_name`: The ReadOnly Role to be mapped to the `readonly-group` group of RBAC
- `eks-deployment-role-name`: Role that will be used by the runner that executes `seedfarmer apply` on the module. This role will be added to `system:masters` group
- `eks_node_spot`: If `eks_node_spot` is set to True, we deploy SPOT instances of the above `nodegroup_config` for you else we deploy `ON_DEMAND` instances.
- `eks_secrets_envelope_encryption`: If set to True, we enable KMS secret for [envelope encryption](https://aws.amazon.com/about-aws/whats-new/2020/03/amazon-eks-adds-envelope-encryption-for-secrets-with-aws-kms/) for Kubernetes secrets.
- `eks_api_endpoint_private`: If set to True, we deploy EKS cluster with API endpoint set to [private mode](https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html).
- `deploy_aws_lb_controller`: Deploys the [ALB Ingress controller](https://docs.aws.amazon.com/eks/latest/userguide/alb-ingress.html). Default behavior is set to False
- `deploy_external_dns`: Deploys the External DNS to interact with [AWS Route53](https://github.com/kubernetes-sigs/external-dns/blob/master/docs/tutorials/aws.md). Default behavior is set to False
- `deploy_aws_ebs_csi`: Deploys the [AWS EBS](https://docs.aws.amazon.com/eks/latest/userguide/ebs-csi.html) Driver. Default behavior is set to False
- `deploy_aws_efs_csi`: Deploys the [AWS EFS](https://docs.aws.amazon.com/eks/latest/userguide/efs-csi.html). Default behavior is set to False
- `deploy_aws_fsx_csi`: Deploys the [AWS FSX](https://docs.aws.amazon.com/eks/latest/userguide/fsx-csi.html). Default behavior is set to False
- `deploy_cluster_autoscaler`: Deploys the [Cluster Autoscaler](https://docs.aws.amazon.com/eks/latest/userguide/autoscaling.html) to scale EKS Workers
- `deploy_metrics_server`: Deploys the [Metrics server](https://docs.aws.amazon.com/eks/latest/userguide/metrics-server.html) and HPA for scaling out/in pods. Default behavior is set to False
- `deploy_secretsmanager_csi`: Deploys [Secrets Manager CSI driver](https://docs.aws.amazon.com/secretsmanager/latest/userguide/integrating_csi_driver.html) to interact with Secrets mounted as files. Default behavior is set to False
- `deploy_cloudwatch_container_insights_metrics`: Deploys the [CloudWatch Agent](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Container-Insights-EKS-agent.html) to ingest containers metrics into AWS Cloudwatch. Default behavior is set to False
- `deploy_cloudwatch_container_insights_logs`: Deploys the [Fluent bit](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Container-Insights-setup-logs-FluentBit.html) plugin to ingest containers logs into AWS Cloudwatch. Default behavior is set to False
- `deploy_adot`: Deploys AWS Distro for OpenTelemetry (ADOT) which is a secure, production-ready, AWS supported distribution of the OpenTelemetry project.
- `deploy_amp`: Deploys AWS Managed Prometheus for centralized log monitoring - ELK Stack. Default behavior is set to False
- `deploy_grafana_for_amp`: Deploys Grafana boards for visualization of logs/metrics from Elasticsearch/Opensearch cluster. Default behavior is set to False
- `deploy_kured`: Deploys [kured reboot daemon](https://github.com/kubereboot/kured) that performs safe automatic node reboots when the need to do so is indicated by the package management system of the underlying OS. Default behavior is set to False
- `deploy_calico`: Deploys [Calico network engine](https://docs.aws.amazon.com/eks/latest/userguide/calico.html) and default-deny network policies. Default behavior is set to False.
- `deploy_nginx_controller`: Deploys [nginx ingress controller](https://aws.amazon.com/blogs/opensource/network-load-balancer-nginx-ingress-controller-eks/). You can provide `nginx_additional_annotations` which populates Optional list of nginx annotations. Default behavior is set to False
- `deploy_kyverno`: Deploys [Kyverno policy engine](https://aws.amazon.com/blogs/containers/managing-pod-security-on-amazon-eks-with-kyverno/) which is is a Policy-as-Code (PaC) solution that includes a policy engine designed for Kubernetes. You can provide the list of policies to be enabled using `kyverno_policies` attribute. Default behavior is set to False
- `aws_vpc_cni_repo_account`: The value of the repo account used for installing the aws-vpc-cni plugin, the default value is 602401143452
- `aws_vpc_cni_repo_domain`: The value of the repo domain used for installing the aws-vpc-cni plugin, the default value is amazonaws.com
- `vpc_enable_prefix_delegation`: Enables support for prefix-based IP allocation to improve scalability and reduce IP management overhead, False in case if we are using warm ip address pool.
- `vpc_cni_warm_ip_target`: Specifies the number of unused IP addresses to keep pre-allocated for new pods on each node. Based on PROD testing, we decided the value 4 to handle moderate pod scaling scenarios, ensuring enough pre-allocated IPs are available for rapid pod creation without over-provisioning resources in Prod.
- `vpc_cni_minimum_ip_target`: Ensures a minimum number of total IPs (allocated + warm) are always available per node, we decided the value 16 after observing that the average pod density per node required at least 12 IPs, with an additional buffer of 4 to accommodate fluctuations and avoid allocation delays and this is working fine as per our current workload on PROD.
You can also verify the allocated ips on nodes with the cli command - aws ec2 describe-network-interfaces --filters Name=attachment.instance-id,Values={node-instance-id}
- `vpc_warm_prefix_target`: Sets the number of unused IP prefixes to keep pre-allocated for new pods when prefix delegation is enabled, 0 in case if we are using vpc_cni_warm_ip_target.

### Sample declaration of EKS Compute Configuration

```yaml
name: eks
path: modules/core/eks/
parameters:
  - name: vpc-id
    valueFrom:
      parameterValue: vpcId
  - name: private-subnet-ids
    valueFrom:
      parameterValue: privateSubnetIds
  - name: eks-admin-role-name
    value: Admin
  - name: eks-compute
    value:
      eks_admin_role_name: "Admin"
      eks_nodegroup_config:
        - eks_ng_name: ng1
          eks_node_quantity: 2
          eks_node_max_quantity: 5
          eks_node_min_quantity: 1
          eks_node_disk_size: 20
          eks_node_instance_type: "m5.large"
        - eks_ng_name: ng2
          eks_node_quantity: 2
          eks_node_max_quantity: 5
          eks_node_min_quantity: 1
          eks_node_disk_size: 20
          eks_node_instance_type: "m5.xlarge"
          eks_node_labels:
            usage: visualization
      eks_version: 1.24
      eks_node_spot: False
  - name: eks-addons
    value:
      deploy_aws_lb_controller: True
      deploy_external_dns: True
      deploy_aws_ebs_csi: False
      deploy_aws_efs_csi: True
      deploy_cluster_autoscaler: True
      deploy_metrics_server: True
      deploy_secretsmanager_csi: True
      deploy_external_secrets: False
      deploy_cloudwatch_container_insights_metrics: True
      deploy_cloudwatch_container_insights_logs: True
      cloudwatch_container_insights_logs_retention_days: 7
      deploy_amp: False
      deploy_grafana_for_amp: False
```

### Sample declaration of EKS Compute Configuration in Isolated/Non-routable subnets

For deploying EKS module in Isolated/Non-routable subnets (which has access through VPC interface endpoints), following is a sample format of declaring manifest file.

```yaml
name: eks
path: modules/core/eks/
parameters:
  - name: vpc-id
    valueFrom:
      parameterValue: vpcId
  - name: private-subnet-ids
    valueFrom:
      parameterValue: privateSubnetIds
  - name: isolated-subnet-ids
    valueFrom:
      parameterValue: isolatedSubnetIds
  - name: codebuild-sg-id
    valueFrom:
      parameterValue: securityGroupIds
  - name: eks-admin-role-name
    value: Admin
  - name: eks-compute
    value:
      eks_nodegroup_config:
        - eks_ng_name: ng1
          eks_node_quantity: 2
          eks_node_max_quantity: 5
          eks_node_min_quantity: 1
          eks_node_disk_size: 20
          eks_node_instance_type: "m5.large"
        # - eks_ng_name: ng2
        #   eks_node_quantity: 2
        #   eks_node_max_quantity: 5
        #   eks_node_min_quantity: 1
        #   eks_node_disk_size: 20
        #   eks_node_instance_type: "m5.xlarge"
      eks_version: 1.24
      eks_node_spot: False
  - name: eks-addons
    value:
      deploy_aws_lb_controller: True
      deploy_external_dns: True
      deploy_aws_ebs_csi: False
      deploy_aws_efs_csi: True
      deploy_cluster_autoscaler: True
      deploy_metrics_server: True
      deploy_secretsmanager_csi: True
      deploy_external_secrets: False
      deploy_cloudwatch_container_insights_metrics: True
      deploy_cloudwatch_container_insights_logs: True
      cloudwatch_container_insights_logs_retention_days: 7
      deploy_amp: False
      deploy_grafana_for_amp: False
  ### Below is how you source docker images from docker replication module for deploying eks plugins in isolated subnets
  ### EFS Plugin ###
  - name: efs-csi-provisioner
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: eks-distro/kubernetes-csi/external-provisioner
  - name: efs-plugin
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: aws-efs-csi-driver
  - name: efs-liveness-probe
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: eks-distro/kubernetes-csi/livenessprobe
  - name: efs-node-registrar
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: eks-distro/kubernetes-csi/node-driver-registrar
  ### Cluster Autoscaler Plugin ###
  - name: cluster-autoscaler
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: autoscaling/cluster-autoscaler
  ### Metrics Server Plugin ###
  - name: metrics-server
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: metrics-server/metrics-server
  ### CloudWatch Container Insights Metrics/Logs ###
  - name: fluent-bit
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: fluent-bit
  - name: cloudwatch-agent
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: cloudwatch-agent
  ### Secrets Manager ###
  - name: csi-secrets-driver-crds
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: csi-secrets-store/driver-crds
  - name: csi-secrets-driver
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: csi-secrets-store/driver
  - name: csi-secrets-driver-registrar
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: sig-storage/csi-node-driver-registrar
  - name: csi-secrets-driver-livenessprobe
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: sig-storage/livenessprobe
  - name: secrets-store-csi-driver-provider-aws
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: aws-secrets-manager/secrets-store-csi-driver-provider-aws
  ### ALB Ingress ###
  - name: aws-load-balancer-controller
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: aws-alb-ingress-controller
  ### External DNS ###
  - name: external-dns
    valueFrom:
      moduleMetadata:
        group: replication
        name: replication
        key: external-dns/external-dns
  - name: aws-vpc-cni-repo-account
      valueFrom:
        envVariable: AWS_VPC_CNI_REPO_ACCOUNT
  - name: aws-vpc-cni-repo-domain
      valueFrom:
        envVariable: AWS_VPC_CNI_REPO_DOMAIN
```

> We have enabled [Security groups for pods](https://docs.aws.amazon.com/eks/latest/userguide/security-groups-for-pods.html) by default as the best security practise and the feature is supported by most Nitro-based Amazon EC2 instance families. For finding the right instance type which supports the feature, refer to [limits.go](https://github.com/aws/amazon-vpc-resource-controller-k8s/blob/master/pkg/aws/vpc/limits.go)

### Sample declaration of EKS Addons Configuration

```yaml
- name: eks-addons
  value:
    deploy_aws_lb_controller: True # We deploy it unless set to False
    deploy_external_dns: True # We deploy it unless set to False
    deploy_aws_ebs_csi: True # We deploy it unless set to False
    deploy_aws_efs_csi: True # We deploy it unless set to False
    deploy_cluster_autoscaler: True # We deploy it unless set to False
    deploy_metrics_server: True # We deploy it unless set to False
    deploy_secretsmanager_csi: True # We deploy it unless set to False
    deploy_external_secrets: False
    deploy_cloudwatch_container_insights_metrics: True # We deploy it unless set to False
    deploy_cloudwatch_container_insights_logs: False
    cloudwatch_container_insights_logs_retention_days: 7
    deploy_amp: False
    deploy_grafana_for_amp: False
    deploy_kured: False
    deploy_calico: False
    deploy_nginx_controller:
        value: False
        nginx_additional_annotations:
          nginx.ingress.kubernetes.io/whitelist-source-range: "100.64.0.0/10,10.0.0.0/8"
    deploy_kyverno:
        value: False
        kyverno_policies:
          validate:
            - block-ephemeral-containers
            - block-stale-images
            - block-updates-deletes
            - check-deprecated-apis
            - disallow-cri-sock-mount
            - disallow-custom-snippets
            - disallow-empty-ingress-host
            - disallow-helm-tiller
            - disallow-latest-tag
            - disallow-localhost-services
            - disallow-secrets-from-env-vars
            - ensure-probes-different
            - ingress-host-match-tls
            - limit-hostpath-vols
            - prevent-naked-pods
            - require-drop-cap-net-raw
            - require-emptydir-requests-limits
            - require-labels
            - require-pod-requests-limits
            - require-probes
            - restrict-annotations
            - restrict-automount-sa-token
            - restrict-binding-clusteradmin
            - restrict-clusterrole-nodesproxy
            - restrict-escalation-verbs-roles
            - restrict-ingress-classes
            - restrict-ingress-defaultbackend
            - restrict-node-selection
            - restrict-path
            - restrict-service-external-ips
            - restrict-wildcard-resources
            - restrict-wildcard-verbs
            - unique-ingress-host-and-path
```

#### IAM integration

EKS integrates with AWS Identity and Access Management (IAM) to control access to Kubernetes resources. IAM policies can be used to control access to Kubernetes API server and resources. EKS also supports role-based access control (RBAC), which allows you to define fine-grained access controls for users and groups. As of now we defined three roles, more roles can be added and refined as the requirements:

1. Admin role - allows full access to the namespaced and cluster-wide resources of EKS
2. Poweruser role - allows CRUD operations for namespaced resources of the EKS cluster
3. Read-only role - allows read operations for namespaced resources of the EKS cluster

#### Logging & Monitoring

- We have enabled [CloudWatch Container Insights](https://docs.aws.amazon.com/prescriptive-guidance/latest/implementing-logging-monitoring-cloudwatch/kubernetes-eks-metrics.html) by default as the standard practise for ingesting Cluster metrics to AWS CloudWatch

- For ingesting application logs, you could either enable `deploy_cloudwatch_container_insights_logs` flag in the above sample to write to AWS CloudWatch or deploy the module `eks-to-opensearch` under `modules/integration/` to write to AWS OpenSearch using fluent-bit logging driver.

### Module Metadata Outputs

- `EksClusterName`: The EKS Cluster Name
- `EksClusterAdminRoleArn`: The EKS Cluster's Admin Role Arn
- `EksClusterSecurityGroupId`: The EKS Cluster's SecurityGroup ID
- `EksOidcArn`: The EKS Cluster's OIDC Arn
- `EksClusterOpenIdConnectIssuer`: EKS Cluster's OPEN ID Issuer
- `CNIMetricsHelperRoleName`: Name of role created for CNIMetricHelper SA
- `EksClusterMasterRoleArn` - the masterrole used for cluster creation

#### Output Example

```json
{
  "EksClusterName": "addf-local-core-eks-cluster",
  "EksClusterAdminRoleArn": "arn:aws:iam::XXXXXXXX:role/addf-local-core-eks-stack-clusterCreationRoleXXXX",
  "EksClusterSecurityGroupId": "sg-XXXXXXXXXXXXXX",
  "EksOidcArn": "arn:aws:iam::XXXXXXXX:oidc-provider/oidc.eks.us-west-2.amazonaws.com/id/XXXXXXXX",
  "EksClusterOpenIdConnectIssuer": "oidc.eks.us-west-2.amazonaws.com/id/098FBE7B04A9C399E4A3534FF1C288C6",
  "CNIMetricsHelperRoleName": "addf-dataservice-core-eks-CNIMetricsHelperRole",
  "EksClusterMasterRoleArn" : "arn:aws:iam::XXXXXXXX:role/addf-local-core-eks-us-east-1-masterrole"
}

```

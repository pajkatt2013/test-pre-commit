def test_placeholder() -> None:
    return None

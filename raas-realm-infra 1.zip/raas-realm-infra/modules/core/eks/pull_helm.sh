#!/bin/bash

set -euo pipefail
set +x

create() {
    while IFS="" read -r helmchart || [ -n "$helmchart" ]
    do
    repo_address=$(echo $helmchart | awk -F ' ' '{ print $1 }')
    chart_version=$(echo $helmchart | awk -F ' ' '{ print $2 }')
    echo pull $repo_address:$chart_version
    helm pull oci://$repo_address --version $chart_version --untar --untardir helmchart
    done < helmCharts.txt
}

destroy() {
    echo "Sorry... not working"
}

$1

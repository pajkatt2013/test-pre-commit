# ------------------------------------------------------------------------------
#  Software created within Project Orion.
#  All rights reserved. Authorship details are documented in the Git history.
#  This script is to propagated cost allocation tags to EC2 instance & ASG so that EC2 instances are billed correctly.
# ------------------------------------------------------------------------------
import json
import os

import boto3

# ------------------------------------------------------------------------------
# ADDF vars
# ------------------------------------------------------------------------------

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "").lower()
module_name = os.getenv("ADDF_MODULE_NAME", "")
hash = os.getenv("ADDF_HASH", "")
module_metadata_str = os.getenv("ADDF_MODULE_METADATA", "")
module_metadata = json.loads(module_metadata_str)
tgt_cluster_name = module_metadata["EksClusterName"]

# ------------------------------------------------------------------------------
# Constant
# ------------------------------------------------------------------------------
c_key_asgs = "AutoScalingGroups"
c_key_next_token = "NextToken"
c_key_asg_name = "AutoScalingGroupName"
c_key_tags = "Tags"
c_key_eks_cluster_name = "eks:cluster-name"
c_key_eks_ng_name = "eks:nodegroup-name"
c_key_node_template_customer_function = (
    "k8s.io/cluster-autoscaler/node-template/label/customer_function"
)
c_key_customer_function = "customer_function"
c_value_customer_function = "common"


# Import tags from env variable
def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

default_ng_name = module_metadata["EksNodeGroupIds"][0].split("/")[-1]

# ------------------------------------------------------------------------------
# Add tag to EKS cluster
# ------------------------------------------------------------------------------
EKS_CLIENT = boto3.client("eks")
cluster_tags = {"Deployment": f"addf-{deployment_name}"}
for kv in tag_list:
    cluster_tags[kv["key"]] = kv["value"]
cluster_arn = module_metadata["EksClusterArn"]
EKS_CLIENT.tag_resource(resourceArn=cluster_arn, tags=cluster_tags)


# ------------------------------------------------------------------------------
# Propagate tags to ASG
# ------------------------------------------------------------------------------
def get_tag_if_exists(lst_tag: list, search_key: str):
    ret = None
    for t in lst_tag:
        t_key = t.get("Key")
        if t_key == search_key:
            ret = t.get("Value")
    return ret


def update_eks_ng_asg_tags(lst_asg: list, client):
    for asg in lst_asg:
        t_asg_name = asg.get(c_key_asg_name)
        t_asg_tags = asg.get(c_key_tags)
        t_cluster_name = get_tag_if_exists(
            lst_tag=t_asg_tags, search_key=c_key_eks_cluster_name
        )
        t_ng_name = get_tag_if_exists(lst_tag=t_asg_tags, search_key=c_key_eks_ng_name)

        if t_cluster_name == tgt_cluster_name and t_ng_name == default_ng_name:
            asg_tags = [
                {
                    "ResourceId": t_asg_name,
                    "Key": c_key_customer_function,
                    "Value": c_value_customer_function,
                    "PropagateAtLaunch": True,
                    "ResourceType": "auto-scaling-group",
                },
                {
                    "ResourceId": t_asg_name,
                    "Key": c_key_node_template_customer_function,
                    "Value": c_value_customer_function,
                    "PropagateAtLaunch": True,
                    "ResourceType": "auto-scaling-group",
                },
            ]
            client.create_or_update_tags(Tags=asg_tags)


# ------------------------------------------------------------------------------
# Main
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    print(f"[INFO] target cluster name: {tgt_cluster_name}")

    as_client = boto3.client("autoscaling", region_name=os.getenv("AWS_REGION"))

    res0 = as_client.describe_auto_scaling_groups()
    res0_lst_asg = res0.get(c_key_asgs)
    update_eks_ng_asg_tags(lst_asg=res0_lst_asg, client=as_client)

    next_token = res0.get(c_key_next_token)
    while next_token:
        res_as_client = as_client.describe_auto_scaling_groups(NextToken=next_token)
        res_lst_asg = res_as_client.get(c_key_asgs)
        update_eks_ng_asg_tags(lst_asg=res_lst_asg, client=as_client)
        next_token = res_as_client.get(c_key_next_token)

# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

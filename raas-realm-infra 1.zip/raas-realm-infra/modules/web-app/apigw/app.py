import json
import logging
import os

import aws_cdk
from aws_cdk import App, CfnOutput
from stack import HttpApiStack

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
listener_arn = os.getenv("ADDF_PARAMETER_LISTENER_ARN")
alb_arn = os.getenv("ADDF_PARAMETER_ALB_ARN")
vpc_id = os.getenv("ADDF_PARAMETER_VPC_ID")
private_subnet_ids = json.loads(os.getenv("ADDF_PARAMETER_PRIVATE_SUBNET_IDS"))

logger = logging.getLogger()


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


logger.info(os.getenv(_param("VPC_ID")))


app = App()


stack = HttpApiStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
    deployment=deployment_name,
    module=module_name,
    stage=os.getenv("STAGE", "dev"),
    vpc_id=vpc_id,
    private_subnet_ids=private_subnet_ids,
    listener_arn=listener_arn,
    alb_arn=alb_arn,
)


CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "ApiId": stack.api.api_id,
            "ApiEndpoint": stack.api.api_endpoint,
        }
    ),
)

app.synth(force=True)

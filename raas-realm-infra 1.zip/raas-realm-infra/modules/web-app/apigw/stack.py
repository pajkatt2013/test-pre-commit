#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.
import json
from typing import Any, cast

import aws_cdk.aws_apigatewayv2_alpha as api_gw
import aws_cdk.aws_apigatewayv2_integrations_alpha as integrations
import aws_cdk.aws_logs as logs
import cdk_nag
from aws_cdk import Aspects, Stack, Tags
from aws_cdk import aws_apigatewayv2 as apigw
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_elasticloadbalancingv2 as elbv2
from aws_cdk import aws_iam as iam
from aws_cdk.aws_apigatewayv2_authorizers_alpha import HttpIamAuthorizer
from constructs import Construct, IConstruct
from utils import LabelGenerator


class HttpApiStack(Stack):
    def __init__(
        self,
        scope: Construct,
        id: str,
        *,
        deployment: str,
        listener_arn: str,
        alb_arn: str,
        stage: str,
        vpc_id: str,
        private_subnet_ids: list,
        module: str,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys and HTTP API",
            **kwargs,
        )
        Tags.of(scope=cast(IConstruct, self)).add(
            key="Deployment", value=f"addf-{deployment}"
        )
        self.vpc = ec2.Vpc.from_lookup(
            self,
            "VPC",
            vpc_id=vpc_id,
        )
        self.private_subnets = []
        for idx, subnet_id in enumerate(private_subnet_ids):
            self.private_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"subnet{idx}", subnet_id=subnet_id
                )
            )

        lg = LabelGenerator(
            deployment_name=deployment, stage=stage, aws_env=kwargs["env"]
        )
        log_group = logs.LogGroup(
            self,
            "log-group",
            log_group_name=lg.get_label("log-group", include_region=True),
            retention=logs.RetentionDays.THREE_MONTHS,
        )
        elbv2.ApplicationLoadBalancer.from_lookup(
            self, "alb", load_balancer_arn=alb_arn
        )

        listener = elbv2.ApplicationListener.from_lookup(
            self, "alb-listener", listener_arn=listener_arn
        )

        api_name = lg.get_label("demo-api", include_region=True)
        self.api = api_gw.HttpApi(self, api_name, api_name=api_name)
        access_log = apigw.CfnStage.AccessLogSettingsProperty(
            destination_arn=log_group.log_group_arn,
            format=json.dumps(
                {
                    "requestId": "$context.requestId",
                    "userAgent": "$context.identity.userAgent",
                    "sourceIp": "$context.identity.sourceIp",
                    "requestTime": "$context.requestTime",
                    "httpMethod": "$context.httpMethod",
                    "path": "$context.path",
                    "status": "$context.status",
                    "responseLength": "$context.responseLength",
                }
            ),
        )
        self.api.default_stage.node.default_child.access_log_settings = access_log
        log_group.grant_write(iam.ServicePrincipal("apigateway.amazonaws.com"))

        vpc_link_sg = ec2.SecurityGroup(
            self,
            "vpc_link_sg",
            security_group_name=lg.get_label("vpc-link-sg", include_region=True),
            vpc=self.vpc,
        )
        vpc_link_sg.add_egress_rule(
            peer=ec2.Peer.any_ipv4(),
            connection=ec2.Port.tcp(80),
            description="Allow all traffic from port 80",
        )

        vpc_link_name = lg.get_label(
            "vpclink-to-private-http-enpoint", include_region=True
        )
        vpc_link = api_gw.VpcLink(
            self,
            vpc_link_name,
            vpc=self.vpc,
            vpc_link_name=vpc_link_name,
            security_groups=[vpc_link_sg],
            subnets=ec2.SubnetSelection(subnets=self.private_subnets),
        )

        api_gateway_integration_name = lg.get_label("http-alb-int", include_region=True)
        api_gateway_integration = integrations.HttpAlbIntegration(
            api_gateway_integration_name, listener, vpc_link=vpc_link
        )

        api_gateway_route_name = lg.get_label("apigw-route", include_region=True)
        api_gw.HttpRoute(
            self,
            api_gateway_route_name,
            http_api=self.api,
            route_key=api_gw.HttpRouteKey.with_("/{proxy+}", api_gw.HttpMethod.ANY),
            integration=api_gateway_integration,
            authorizer=HttpIamAuthorizer(),
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

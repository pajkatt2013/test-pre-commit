# API Gateway Module


## Description

This module creates an Http API


## Inputs/Outputs

### Input Paramenters

#### Required

- `vpc-id`: VPC Id where the Aurora cluster will be deployed
- `alb`: The Application Load Balancer ARN to be integrated with the API as listener


### Input Example
```yaml
parameters:
  - name: alb
    valueFrom:
      moduleMetadata:
        group: web-app-alb-ecs
        name: alb-ecs
        key: ApplicationLoadBalancedFargateALB
  - name: vpc-id
    valueFrom:
      #parameterValue: vpcId
      moduleMetadata:
        group: optionals
        name: networking
        key: VpcId
```

### Module Metadata Outputs

- `OpenSearchDomainEndpoint`: the endpoint name of the OpenSearch Domain
  `OpenSearchDomainName`: the name of the OpenSearch Domain
- `OpenSeearchDashboardUrl`: URL of the OpenSearch cluster dashboard
- `OpenSearchSecurityGroupId`: name of the DDB table created for Rosbag Scene Data

#### Output Example

```json
{
  "OpenSearchDashboardUrl": "https://vpc-addf-test-core-opensearch-aaa.us-east-1.es.amazonaws.com/_dashboards/",
  "OpenSearchDomainName": "vpc-addf-test-core-opensearch-aaa",
  "OpenSearchDomainEndpoint": "vpc-addf-test-core-opensearch-aaa.us-east-1.es.amazonaws.com",
  "OpenSearchSecurityGroupId": "sg-0475c9e7efba05c0d"
}

```

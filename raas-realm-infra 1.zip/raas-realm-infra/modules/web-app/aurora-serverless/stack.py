from typing import Any, cast

from aws_cdk import RemovalPolicy, Stack, Tags
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_rds as rds
from aws_cdk import custom_resources as cr
from constructs import Construct, IConstruct
from utils import LabelGenerator


class AuroraServerlessStack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        id: str,
        *,
        deployment_name: str,
        module_name: str,
        vpc_id: str,
        private_subnet_ids: list,
        database_name: str,
        table_name: str,
        allow_traffic_from_sg: str,
        **kwargs: Any,
    ) -> None:
        # ADDF Env vars
        self.deployment_name = deployment_name
        self.module_name = module_name
        self.table_name = table_name

        super().__init__(
            scope,
            id,
            description="This stack deploys a Aurora servelss with Postgress",
            **kwargs,
        )
        Tags.of(scope=cast(IConstruct, self)).add(
            key="Deployment", value=f"addf-{self.deployment_name}"
        )

        lg = LabelGenerator(
            deployment_name=deployment_name, stage=stage, aws_env=kwargs["env"]
        )

        self.vpc = ec2.Vpc.from_lookup(
            self,
            "VPC",
            vpc_id=vpc_id,
        )
        self.private_subnets = []
        for idx, subnet_id in enumerate(private_subnet_ids):
            self.private_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"subnet{idx}", subnet_id=subnet_id
                )
            )

        # Create a Serverless Cluster

        db_security_group_name = lg.get_label(
            f"{deployment_name}-db-sg", include_region=True
        )

        self.db_security_group = ec2.SecurityGroup(
            self,
            db_security_group_name,
            security_group_name=db_security_group_name,
            vpc=self.vpc,
            allow_all_outbound=False,
        )
        if allow_traffic_from_sg is not None:
            self.db_security_group.add_ingress_rule(
                ec2.SecurityGroup.from_security_group_id(
                    self, "AllowTrafficFrom", allow_traffic_from_sg
                ),
                ec2.Port.tcp(5432),
                "Allow traffic from the specified security group",
            )

        cluster_id_name = lg.get_label(
            f"{deployment_name}-cluster", include_region=True
        )

        self.db_cluster = rds.ServerlessCluster(
            self,
            cluster_id_name,
            engine=rds.DatabaseClusterEngine.aurora_postgres(
                version=rds.AuroraPostgresEngineVersion.VER_13_6
            ),
            cluster_identifier=cluster_id_name,
            enable_data_api=True,
            default_database_name=database_name,
            security_groups=[self.db_security_group],
            vpc=self.vpc,
            vpc_subnets=ec2.SubnetSelection(subnets=self.private_subnets),
            removal_policy=RemovalPolicy.DESTROY,
        )

        create_table_name = lg.get_label(
            f"{deployment_name}-create-table", include_region=True
        )

        create_table = cr.AwsCustomResource(
            self,
            create_table_name,
            on_create=cr.AwsSdkCall(
                service="RDSDataService",
                action="executeStatement",
                physical_resource_id=cr.PhysicalResourceId.of(
                    self.db_cluster.cluster_identifier
                ),
                parameters={
                    "resourceArn": self.db_cluster.cluster_arn,
                    "secretArn": self.db_cluster.secret.secret_arn,
                    "sql": f"CREATE TABLE {self.table_name} (col1 VARCHAR (250), col2 VARCHAR (250));",
                    "database": database_name,
                },
            ),
            policy=cr.AwsCustomResourcePolicy.from_sdk_calls(
                resources=cr.AwsCustomResourcePolicy.ANY_RESOURCE
            ),
        )

        # Add dependency and grant permissions
        create_table.node.add_dependency(self.db_cluster)
        self.db_cluster.secret.grant_read(create_table)

        # # Allow traffic to the database from within the cluster
        # self.db_cluster.connections.allow_default_port_from(
        #     self.db_cluster,
        #     "Allow traffic on 5432 for any resource with this sec grp attached",
        # )

import json
import os

from aws_cdk import App, CfnOutput, Environment
from stack import AuroraServerlessStack

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
vpc_id = os.getenv("ADDF_PARAMETER_VPC_ID")
private_subnet_ids = json.loads(os.getenv("ADDF_PARAMETER_PRIVATE_SUBNET_IDS"))
database_name = os.getenv("ADDF_PARAMETER_DATABASE_NAME")
table_name = os.getenv("ADDF_PARAMETER_TABLE_NAME")
allow_traffic_from_sg = os.getenv("ADDF_PARAMETER_ALLOW_TRAFFIC_FROM_SG")

environment = Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)


app = App()

stack = AuroraServerlessStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    stage=os.getenv("STAGE", "dev"),
    deployment_name=deployment_name,
    module_name=module_name,
    vpc_id=vpc_id,
    private_subnet_ids=private_subnet_ids,
    database_name=database_name,
    table_name=table_name,
    allow_traffic_from_sg=allow_traffic_from_sg,
    env=environment,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "DBClusterId": stack.db_cluster.cluster_identifier,
            "TableName": stack.table_name,
            "DBClusterSecretArn": stack.db_cluster.secret.secret_arn,
            "DBSecurityGroupId": stack.db_security_group.security_group_id,
        }
    ),
)


app.synth(force=True)

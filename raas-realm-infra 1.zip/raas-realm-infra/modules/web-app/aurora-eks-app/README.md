# Aurora EKS module


## Description
This is a SeedFarmer module. More information about how to work with SeedFarmer and how is it deployed is available at https://asc.bmwgroup.net/wiki/display/ORIONPRODUCTS/Realm+Application+Development%3A+Developer+Guide section `Seedfarmer Realm Development`
### Infrastructure
This module builds and deploys a simple app that connects to aurora. It does (in that order):
1. docker build (and related commands). It builds docker image using `demo-app/Dockerfile`. It pushes it to the repository (from input parameters) and tags it by using MD5 hash of the module and `latest`
2. CDK deploy. It creates IAM roles and Certificate using CDK. This includes roles and policies according to the docs (https://docs.aws.amazon.com/eks/latest/userguide/associate-service-account-role.html#irsa-create-role), but using CDK instead of AWS CLI. _Note_: In CDK `WebIdentityPrincipal`, while in CLI it is `Federated` principal. `WebIdentityPrincipal` is a CDK construct based on `FederatedPrincipal`, with correct `Action` of trust policy defined (source in JavaScript: https://github.com/aws/aws-cdk/blob/main/packages/aws-cdk-lib/aws-iam/lib/principals.ts#L681).
3. Installs a helm chart, using parameters and outputs of steps before. As a result, application is deployed that connects to Aurora and its available (internal facing) using the given domain-name.
For more detailed steps, inspect deployspec.yaml
### Networking
This modules shows how to create a service that is accessible from within VPC. There are 3 important steps that are done to achieve it:
1. Certificate Creation - Certificate for the domain is created inside CDK in stack.py
```
acm.Certificate(
    self,
    "Certificate",
    domain_name=domain_name,
    validation=acm.CertificateValidation.from_dns(hosted_zone),
)
```
2. Records creation in route53 - done automatically when creating ingress by External-DNS module. You can read more about the module at https://asc.bmwgroup.net/wiki/display/ORIONPRODUCTS/EKS+Addons
3. Ingress. You can inspect the ingress definition in `raas/modules/web-app/aurora-eks-app/aurora-app-chart/templates/ingress.yaml`. Some values come from `raas/modules/web-app/aurora-eks-app/aurora-app-chart/values.yaml` and some are set inside deployspec. Pay attention to the annotations. This ingress will create Application Load Balancer that will forward the traffic to the service.

**Important**: Load Balancer will discover only the Subnets that have proper tags. Tags are added to the Subnets in EKS module. For more information about Subnet tagging, refer to https://docs.aws.amazon.com/eks/latest/userguide/alb-ingress.html. Subnets in RaaS have tags:  `kubernetes.io/cluster/{CLUSTER_NAME}: shared` and `kubernetes.io/role/elb: 1`.

_Note_: To reach the application you have to have access to VPC. From within VPC (i.e. from EC2 instance inside the VPC), you can use command `curl {domain_name}` thats specified in the manifest. It may take couple minutes after deployment for DNS records to be updated.

### Example Helm Chart Values
```
namespace: default
serviceAccountName: aurora-592b5579-sa
serviceAccountRole: arn:aws:iam::178345759618:role/aurora-592b5579-role

deployment:
  name: aurora
  labels:
    app: aurora

replicaCount: 1

image: 178345759618.dkr.ecr.eu-central-1.amazonaws.com/addf-app-dev-eu-central-1-demo-app:latest
secretName: "appdeveucentral1realminfrac-RvDIUdKEOPkE"
tableName: "testtable"

healthcheckPath: /health

host: aurora.t1-r3-dev.realm.orionadp.com

containers:
  name: webapp
  ports:
    http:
      name: http
      containerPort: 80

service:
  name: aurora
  port: 80
  protocol: TCP

ingress:
  name: aurora
  annotations:
    kubernetes.io/ingress.class: alb
    alb.ingress.kubernetes.io/scheme: internal
    alb.ingress.kubernetes.io/target-type: ip
    alb.ingress.kubernetes.io/backend-protocol: HTTP
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
```

## Inputs/Outputs

### Input Paramenters

#### Required
- namespace: Kubernetes namespace for the application to be deployed
- healthcheck-path: Path which ELB will use to mark target as healthy
- hosted-zone-id: Id of route53 hosted zone
- domain-name: Domain name for the application. Domain name should be any valid record that has your hosted zone name (t1-r3-dev.realm.orionadp.com ) as SLD, i.e. example.t1-r3-dev.realm.orionadp.com
- eks-cluster-name: EKS cluster name
- eks-master-role-arn: EKS master role ARN
- db-cluster-secret-arn: id of secret which stores credentials to Aurora
- oidc-provier-arn: OIDC provider ARN
- table-name: Name of the table in Aurora (used for the application)
- ecr-repo-name: Name of ECR repository to which docker images will be pushed.
- event-writer-lambda-arn: ARN of event writer lambda
### Input Example
```yaml
parameters:
  - name: namespace
    value: default
  - name: healthcheck-path
    value: /health
  - name: hosted-zone-id
    value: Z03908841DRE3PXZIZE3R
  - name: domain-name
    value: aurora.t1-r3-dev.realm.orionadp.com
  - name: eks-cluster-name
    valueFrom:
      moduleMetadata:
        group: core
        name: eks
        key: EksClusterName
  - name: eks-master-role-arn
    valueFrom:
      moduleMetadata:
        group: core
        name: eks
        key: EksClusterMasterRoleArn
  - name: db-cluster-secret-arn
    valueFrom:
      moduleMetadata:
        group: web-app-aurora
        name: auroradb
        key: DBClusterSecretArn
  - name: oidc-provider-arn
    valueFrom:
      moduleMetadata:
        group: core
        name: eks
        key: EksOidcArn
  - name: table-name
    valueFrom:
      moduleMetadata:
        group: web-app-aurora
        name: auroradb
        key: TableName
  - name: ecr-repo-name
    valueFrom:
      moduleMetadata:
        group: optionals
        name: ecr-eks-aurora
        key: RepositoryName
  - name: event-writer-lambda-arn
    valueFrom:
      moduleMetadata:
        group: oao
        name: event-writer
        key: EventWriterLambdaArn

```
### Module Metadata Outputs

- `ServiceRoleArn`: ARN of the Service Role created
- `ServiceAccountName`: Name of the Service Account


#### Output Example

```json
{
    "ServiceRoleArn": "arn:aws:iam::178345759618:role/aurora-realm-infra-role",
    "ServiceAccountName": "aurora-realm-infra-sa",
}

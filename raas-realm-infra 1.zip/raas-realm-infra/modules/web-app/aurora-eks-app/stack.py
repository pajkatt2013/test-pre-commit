#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.
from typing import Any, cast

import cdk_nag
from aws_cdk import Aspects, Aws, CfnJson, Stack, Tags
from aws_cdk import aws_certificatemanager as acm
from aws_cdk import aws_iam as iam
from aws_cdk import aws_route53 as route53
from constructs import Construct, IConstruct
from utils import LabelGenerator

MANIFESTS_DIR = "manifests"


class EksAuroraAppStack(Stack):
    def __init__(
        self,
        scope: Construct,
        id: str,
        *,
        deployment: str,
        module: str,
        hash: str,
        stage: str,
        namespace: str,
        hosted_zone_id: str,
        domain_name: str,
        oidc_provider_arn: str,
        db_cluster_secret_arn: str,
        event_writer_lambda_arn: str,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="""This stack deploys Service Account
            for EKS cluster to connect with Aurora Serverless""",
            **kwargs,
        )
        Tags.of(scope=cast(IConstruct, self)).add(
            key="Deployment", value=f"addf-{deployment}"
        )
        lg = LabelGenerator(
            prefix=f"aurora-{deployment}", aws_env=kwargs["env"], stage=stage
        )

        oidc_provider_id = oidc_provider_arn.split("/")[-1]
        oidc_provider = f"oidc.eks.{Aws.REGION}.amazonaws.com/id/{oidc_provider_id}"
        self.service_account_name = lg.get_label("sa", include_stage=False)
        self.service_account_role = iam.Role(
            self,
            "AuroraServiceAccountRole",
            role_name=lg.get_label("role", include_stage=False),
            assumed_by=iam.PrincipalWithConditions(
                iam.WebIdentityPrincipal(oidc_provider_arn),
                conditions={
                    "StringEquals": CfnJson(
                        self,
                        "ServiceAccountRoleTrustPolicy",
                        value={
                            f"{oidc_provider}:aud": "sts.amazonaws.com",
                            f"{oidc_provider}:sub": f"system:serviceaccount:{namespace}:{self.service_account_name}",
                        },
                    ),
                },
            ),
        )

        self.service_account_role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    "secretsmanager:GetSecretValue",
                ],
                resources=[db_cluster_secret_arn],
            )
        )

        self.service_account_role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    "lambda:InvokeFunction",
                ],
                resources=[event_writer_lambda_arn],
            )
        )

        hosted_zone = route53.HostedZone.from_hosted_zone_id(
            self, "HostedZone", hosted_zone_id=hosted_zone_id
        )
        acm.Certificate(
            self,
            "Certificate",
            domain_name=domain_name,
            validation=acm.CertificateValidation.from_dns(hosted_zone),
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

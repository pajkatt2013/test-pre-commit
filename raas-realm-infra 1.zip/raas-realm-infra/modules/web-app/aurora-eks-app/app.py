#  Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License").
#    You may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

import logging
import os

import aws_cdk
import cdk_nag
from aws_cdk import App, CfnOutput
from stack import EksAuroraAppStack

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
hash = os.getenv("ADDF_HASH")

namespace = os.getenv("ADDF_PARAMETER_NAMESPACE")
cluster_name = os.getenv("ADDF_PARAMETER_EKS_CLUSTER_NAME")
service_account_name = os.getenv("ADDF_PARAMETER_EKS_SERVICE_ACCOUNT_NAME")
hosted_zone_id = os.getenv("ADDF_PARAMETER_HOSTED_ZONE_ID")
domain_name = os.getenv("ADDF_PARAMETER_DOMAIN_NAME")
oidc_provider_arn = os.getenv("ADDF_PARAMETER_OIDC_PROVIDER_ARN")
db_cluster_secret_arn = os.getenv("ADDF_PARAMETER_DB_CLUSTER_SECRET_ARN")
event_writer_lambda_arn = os.getenv("ADDF_PARAMETER_EVENT_WRITER_LAMBDA_ARN")

# Logging

logging.basicConfig(level=logging.INFO)

logger = logging.getLogger()

app = App()

stack = EksAuroraAppStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
    deployment=deployment_name,
    module=module_name,
    hash=hash,
    stage=os.getenv("STAGE", "dev"),
    namespace=namespace,
    hosted_zone_id=hosted_zone_id,
    domain_name=domain_name,
    oidc_provider_arn=oidc_provider_arn,
    db_cluster_secret_arn=db_cluster_secret_arn,
    event_writer_lambda_arn=event_writer_lambda_arn,
)
aws_cdk.Aspects.of(stack).add(cdk_nag.AwsSolutionsChecks())

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "ServiceRoleArn": stack.service_account_role.role_arn,
            "ServiceAccountName": stack.service_account_name,
        }
    ),
)

app.synth(force=True)

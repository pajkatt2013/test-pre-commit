from typing import Any, cast

import cdk_nag
from aws_cdk import Aspects, Aws, Duration, RemovalPolicy, Stack, Tags
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_ecr as ecr
from aws_cdk import aws_ecs as ecs
from aws_cdk import aws_ecs_patterns as ecs_patterns
from aws_cdk import aws_s3 as s3
from aws_cdk import aws_secretsmanager as sm
from aws_cdk import aws_sqs as sqs
from aws_cdk.aws_elasticloadbalancingv2 import Protocol
from cdk_nag import NagPackSuppression, NagSuppressions
from constructs import Construct, IConstruct
from utils import LabelGenerator


class ALB_ECS_Stack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        id: str,
        *,
        deployment_name: str,
        module_name: str,
        vpc_id: str,
        private_subnet_ids: list,
        db_cluster_id: str,
        table_name: str,
        ecr_repo_name: str,
        db_cluster_secret_arn: str,
        db_sg: str,
        job_management_sqs_name: str,
        **kwargs: Any,
    ) -> None:
        # ADDF Env vars
        self.deployment_name = deployment_name
        self.module_name = module_name

        super().__init__(
            scope,
            id,
            description="This stack deploys a ALB and ECS Fargate service",
            **kwargs,
        )
        Tags.of(scope=cast(IConstruct, self)).add(
            key="Deployment", value=f"addf-{self.deployment_name}"
        )

        lg = LabelGenerator(
            deployment_name=deployment_name, stage=stage, aws_env=kwargs["env"]
        )

        self.vpc_id = vpc_id
        self.vpc = ec2.Vpc.from_lookup(
            self,
            "VPC",
            vpc_id=self.vpc_id,
        )

        logs_bucket = s3.Bucket(
            self,
            "logs-bucket",
            bucket_name=lg.get_label("logs-bucket", include_region=True),
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            encryption=s3.BucketEncryption.S3_MANAGED,
            enforce_ssl=True,
            versioned=True,
            removal_policy=RemovalPolicy.RETAIN,
            server_access_logs_prefix="bucket-logs/",
            object_ownership=s3.ObjectOwnership.OBJECT_WRITER,
        )

        db_cluster_secret = sm.Secret.from_secret_complete_arn(
            self, "DBSecret", secret_complete_arn=db_cluster_secret_arn
        )

        ecs_cluster_name = lg.get_label("ecs-fargate-cluster", include_region=True)
        ecs_cluster = ecs.Cluster(
            self,
            ecs_cluster_name,
            vpc=self.vpc,
            cluster_name=ecs_cluster_name,
            container_insights=True,
        )

        repo = ecr.Repository.from_repository_name(
            self, id=id, repository_name=f"addf-{ecr_repo_name}"
        )
        img = ecs.EcrImage.from_ecr_repository(repository=repo, tag="latest")

        load_balanced_fargate_service_name = lg.get_label(
            "alb-ecs-service", include_region=True
        )
        load_balanced_fargate_service = (
            ecs_patterns.ApplicationLoadBalancedFargateService(
                self,
                load_balanced_fargate_service_name,
                cluster=ecs_cluster,
                public_load_balancer=False,
                task_image_options=ecs_patterns.ApplicationLoadBalancedTaskImageOptions(
                    image=img,
                    environment={
                        "TABLE_NAME": table_name,
                        "AWS_SECRET_NAME": db_cluster_secret.secret_name,
                        "JOB_MANAGEMENT_SQS_NAME": job_management_sqs_name,
                    },
                ),
            )
        )

        load_balanced_fargate_service.load_balancer.node.default_child.access_logging_policy = {
            "Enabled": True,
            "S3BucketName": logs_bucket.bucket_name,
        }

        load_balanced_fargate_service.target_group.configure_health_check(
            healthy_threshold_count=2,
            interval=Duration.seconds(20),
            path="/health",
            protocol=Protocol.HTTP,
            timeout=Duration.seconds(5),
            unhealthy_threshold_count=5,
        )

        db_cluster_secret.grant_read(
            load_balanced_fargate_service.task_definition.task_role
        )
        job_management_sqs = sqs.Queue.from_queue_arn(
            self,
            "JobManagementQueue",
            queue_arn=f"arn:{Aws.PARTITION}:sqs:{Aws.REGION}:{Aws.ACCOUNT_ID}:{job_management_sqs_name}",
        )
        job_management_sqs.grant_send_messages(
            load_balanced_fargate_service.task_definition.task_role
        )

        db_security_group = ec2.SecurityGroup.from_security_group_id(self, "SG", db_sg)

        for sg in load_balanced_fargate_service.service.connections.security_groups:
            db_security_group.add_ingress_rule(
                peer=sg,
                connection=ec2.Port.tcp(5432),
                description="Allow ECS cluster tasks from port 5432",
            )

        self.cluster = load_balanced_fargate_service.cluster.cluster_arn
        self.alb = load_balanced_fargate_service.load_balancer.load_balancer_arn
        self.listener = load_balanced_fargate_service.listener.listener_arn
        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())
        suppressions = [
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-ELB2",
                    "reason": "It is enabled using escape hatches and CDK nag does not recognize this.",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-EC23",
                    "reason": "Public access is enabled as it is publicly saving Api Gateway endpoint authenticated with IAMv4 Signature",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-ECS2",
                    "reason": "The environment variables passed in container definition are not sensitive (only the name of resources are passed)",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-IAM5",
                    "reason": "ecr:GetAuthorizationToken requires * in the resource. This is the only iam entity that has * in the resource",
                }
            ),
        ]

        NagSuppressions.add_stack_suppressions(self, suppressions)

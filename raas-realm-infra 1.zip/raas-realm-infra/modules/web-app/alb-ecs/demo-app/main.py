import json
import logging
import os
import sys
from datetime import datetime

import boto3
from fastapi import Depends, FastAPI, status
from fastapi.responses import JSONResponse
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker


def secrets_helper():
    client = boto3.client("secretsmanager")
    try:
        secret_name = os.environ["AWS_SECRET_NAME"]
    except KeyError:
        logger.error("AWS_SECRET_NAME environment variable not set")
        sys.exit(1)
    secret_string = client.get_secret_value(SecretId=secret_name)["SecretString"]
    return json.loads(secret_string)


app = FastAPI(
    title="3-Tier web app demo",
    description="Demo API that demonstrates a connection from an alb-ecs service to a database residing in a vpc",
    version="1.0.0",
    debug=False,
)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
try:
    TABLE_NAME = os.environ["TABLE_NAME"]
except KeyError:
    logger.error("TABLE_NAME environment variable not set")
    sys.exit(1)

try:
    JOB_MANAGEMENT_SQS_NAME = os.environ["JOB_MANAGEMENT_SQS_NAME"]
except KeyError:
    logger.error("JOB_MANAGEMENT_SQS_NAME not set")
    sys.exit(1)

secrets = secrets_helper()
sqs = boto3.resource("sqs")
queue = sqs.get_queue_by_name(QueueName=JOB_MANAGEMENT_SQS_NAME)

SQLALCHEMY_DATABASE_URL = (
    f"postgresql+psycopg2://{secrets['username']}:"
    f"{secrets['password']}@{secrets['host']}:"
    f"{int(secrets['port'])}/{secrets['dbname']}"
)

logger.info(f"SQLALCHEMY_DATABASE_URL: {SQLALCHEMY_DATABASE_URL}")

engine = create_engine(SQLALCHEMY_DATABASE_URL)

SessionLocal = sessionmaker(bind=engine)

logger.info(f"Connection to {secrets['dbname']} established")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/health")
def health():
    return JSONResponse(status_code=status.HTTP_200_OK, content={"Status": "Healthy"})


@app.get("/test-table")
def test_table(db: Session = Depends(get_db)):
    logger.info(f"Executing: SELECT * from {TABLE_NAME}")  # nosec B608
    latest_queries = []
    try:
        records = db.execute(text(f"select * from {TABLE_NAME}"))  # nosec B608
        logger.info(f"Query: on {TABLE_NAME=} finished")  # nosec B608
        logger.info(f"Records: {records}")
        for record in records:
            latest_queries.append({"col1": str(record[0]), "col2": str(record[1])})

        logger.info(f"latest_queries: {latest_queries}")

        message_body = f"Sample message created at {datetime.now().isoformat()}"
        logger.info("Writing sample message to SQS")
        logger.info(f"Message: {message_body}")
        response = queue.send_message(MessageBody=message_body)
        logger.info("Message sent to SQS")
        logger.info(f"Response: {response}")
        return JSONResponse(
            status_code=status.HTTP_200_OK, content={"Response": latest_queries}
        )
    except Exception as e:
        logger.error(e)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"Response": "Error, unable to produce recent visits"},
        )


if __name__ == "__main__":
    logger.info(f"Starting up on {secrets['host']}:{secrets['port']}")

import json
import os

from aws_cdk import App, CfnOutput, Environment
from stack import ALB_ECS_Stack

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
vpc_id = os.getenv("ADDF_PARAMETER_VPC_ID")
private_subnet_ids = json.loads(os.getenv("ADDF_PARAMETER_PRIVATE_SUBNET_IDS"))
ecr_repo_name = os.getenv("ADDF_PARAMETER_ECR_REPO_NAME")
db_cluster_id = os.getenv("ADDF_PARAMETER_DB_CLUSTER_ID")
db_cluster_secret_arn = os.getenv("ADDF_PARAMETER_DB_CLUSTER_SECRET")
db_sg = os.getenv("ADDF_PARAMETER_DB_SG")
table_name = os.getenv("ADDF_PARAMETER_TABLE_NAME")
environment = Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)
job_management_sqs_name = os.getenv("ADDF_PARAMETER_JOB_MANAGEMENT_SQS_NAME")


app = App()

stack = ALB_ECS_Stack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    stage=os.getenv("STAGE", "dev"),
    deployment_name=deployment_name,
    module_name=module_name,
    vpc_id=vpc_id,
    private_subnet_ids=private_subnet_ids,
    db_cluster_id=db_cluster_id,
    db_cluster_secret_arn=db_cluster_secret_arn,
    db_sg=db_sg,
    table_name=table_name,
    ecr_repo_name=ecr_repo_name,
    job_management_sqs_name=job_management_sqs_name,
    env=environment,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "ApplicationLoadBalancedFargateCluster": stack.cluster,
            "ApplicationLoadBalancedFargateALB": stack.alb,
            "ApplicationLoadBalancedFargateListener": stack.listener,
        }
    ),
)


app.synth(force=True)

# ALB-ECS Module

## Description

This module deploys a Fargate service running on an ECS cluster fronted by an application load balancer.

## Inputs/Outputs

### Input Paramenters

#### Required

  - `ecr-repo-name`: Name of the repository where the container image hosted in ECS is uploaded
  - `vpc-id`: VPC Id where the Aurora cluster will be deployed
  - `private-subnet-ids`: List of Private Subnets Ids where the Aurora cluster will be deployed
  - `db-cluster-id`: Id of the RDS cluster to be connected with the ECS cluster
  - `table-name`: Name of the table created inside the Aurora DB
  - `db-cluster-secret`: ARN of the secret stored in Secrets Managet containing all the connection information of the Aurora DB
  - `job-management-sqs-name`: Name of the job management SQS queue to connect to.


#### Input Example
```yaml
parameters:
  - name: ecr-repo-name
    valueFrom:
      moduleMetadata:
        group: optionals
        name: ecr
        key: RepositoryName
  - name: vpc-id
    valueFrom:
      #parameterValue: vpcId
      moduleMetadata:
        group: optionals
        name: networking
        key: VpcId
  - name: private-subnet-ids
    valueFrom:
      # parameterValue: privateSubnetIds
      moduleMetadata:
        group: optionals
        name: networking
        key: PrivateSubnetIds
  - name: db-cluster-id
    valueFrom:
      moduleMetadata:
        group: web-app-aurora
        name: auroradb
        key: DBClusterId
  - name: table-name
    valueFrom:
      moduleMetadata:
        group: web-app-aurora
        name: auroradb
        key: TableName
  - name: db-cluster-secret
    valueFrom:
      moduleMetadata:
        group: web-app-aurora
        name: auroradb
        key: DBClusterSecretArn
  - name: job-management-sqs-name
    valueFrom:
      moduleMetadata:
        group: job-management-sqs
        name: sqs
        key: queueName


```
### Module Metadata Outputs

- `ApplicationLoadBalancedFargateCluster`: ARN of the ECS cluster deployed by the Stack
- `ApplicationLoadBalancedFargateALB`: Name of the Load Balancer deployed by the Stack


#### Output Example

```json
{
    "ApplicationLoadBalancedFargateCluster": "",
    "ApplicationLoadBalancedFargateALB": "",
}

```

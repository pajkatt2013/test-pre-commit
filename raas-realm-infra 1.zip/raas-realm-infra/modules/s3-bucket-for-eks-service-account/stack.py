from typing import Any, Dict, cast

import aws_cdk
import aws_cdk.aws_s3 as aws_s3
import cdk_nag
from aws_cdk import Aspects, Stack, Tags
from aws_cdk import aws_iam as iam
from cdk_nag import NagPackSuppression, NagSuppressions
from constructs import Construct, IConstruct
from utils import LabelGenerator


class BucketsStack(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        namespace: str,
        stage: str,
        bu_name: str,
        config: Dict[str, Any],
        hash: str,
        bucket_name_param: str,
        new_role: bool,
        iam_role_name: str,
        retention_type_param: str,
        retention_days: str,
        eks_service_account_name: str,
        eks_oidc_issuer: str,
        eks_oidc_issuer_arn: str,
        full_name_include_bu: bool,
        tags: list,
        **kwargs: Any,
    ) -> None:
        # ADDF Env vars

        for k, v in config.items():
            setattr(self, k, v)

        # CDK Env Vars
        account: str = aws_cdk.Aws.ACCOUNT_ID
        # region: str = aws_cdk.Aws.REGION
        partition: str = aws_cdk.Aws.PARTITION

        super().__init__(
            scope,
            id,
            description="This stack deploys Storage resources for ADDF",
            **kwargs,
        )

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", self.deployment_name)
        add_tag("Module", self.module_name)
        for kv in tags:
            add_tag(kv["key"], kv["value"])

        lg = LabelGenerator(
            prefix=config["deployment_name"],
            namespace=namespace,
            stage=stage,
            bu_name=bu_name,
            aws_env=kwargs["env"],
        )

        bucket_name = lg.get_label(
            resource_type="bucket",
            resource_name=bucket_name_param,
            include_prefix=True,
            include_bu=full_name_include_bu,
        )

        removal_policy = (
            aws_cdk.RemovalPolicy.RETAIN
            if retention_type_param == "RETAIN"
            else aws_cdk.RemovalPolicy.DESTROY
        )
        auto_delete_objects = None if retention_type_param == "RETAIN" else True

        lifecycle_rules = []
        if retention_days and int(retention_days) > 0:
            lifecycle_rules.append(
                aws_s3.LifecycleRule(
                    id="DeleteAfterRetentionDays",
                    expiration=aws_cdk.Duration.days(int(retention_days)),
                )
            )

        self.bucket = aws_s3.Bucket(
            self,
            removal_policy=removal_policy,
            bucket_name=bucket_name,
            auto_delete_objects=auto_delete_objects,
            id=f"addf-{self.deployment_name}-{self.module_name}-bucket",
            encryption=aws_s3.BucketEncryption.S3_MANAGED,
            block_public_access=aws_s3.BlockPublicAccess.BLOCK_ALL,
            event_bridge_enabled=True,
            enforce_ssl=True,
            lifecycle_rules=lifecycle_rules,
        )

        role_id = lg.get_label(
            resource_type="s3",
            resource_name=bucket_name_param,
            include_prefix=True,
            include_bu=full_name_include_bu,
        )

        # Creates new IAM role for s3 bucket if does not exist
        # bucket_role_name = f"{self.deployment_name}-role-{iam_role_name}"

        if new_role:
            bucket_role_name = lg.get_label(
                resource_type="role",
                resource_name=bucket_name_param,
                include_prefix=True,
                include_bu=full_name_include_bu,
            )

            self.s3_bucket_role = iam.Role(
                self,
                bucket_role_name,
                role_name=bucket_role_name,
                assumed_by=iam.AccountRootPrincipal(),
            )
        else:
            self.s3_bucket_role = iam.Role.from_role_arn(
                scope=self,
                id=f"{role_id}_access",
                role_arn=f"arn:{partition}:iam::{account}:role/{iam_role_name}",
            )

        s3_bucket_role_policy_statement_json_1 = {
            "Effect": "Allow",
            "Action": [
                "s3:Get*",
                "s3:List*",
                "s3:PutObject",
                "s3:PutObjectVersionTagging",
                "s3:PutObjectVersionAcl",
                "s3:PutObjectTagging",
                "s3:PutObjectRetention",
                "s3:PutObjectAcl",
                "s3:DeleteObject",
                "s3:DeleteObjectTagging",
                "s3:DeleteObjectVersion",
                "s3:DeleteObjectVersionTagging",
                "s3:ReplicateObject",
                "s3:ReplicateTags",
            ],
            "Resource": [f"arn:{partition}:s3:::{self.bucket.bucket_name}/*"],
        }

        s3_bucket_role_policy_statement_json_2 = {
            "Effect": "Allow",
            "Action": ["s3:Get*", "s3:List*", "s3:Describe*"],
            "Resource": [f"arn:{partition}:s3:::{self.bucket.bucket_name}"],
        }

        self.s3_bucket_role.add_to_principal_policy(
            iam.PolicyStatement.from_json(s3_bucket_role_policy_statement_json_1)
        )
        self.s3_bucket_role.add_to_principal_policy(
            iam.PolicyStatement.from_json(s3_bucket_role_policy_statement_json_2)
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

        suppressions = [
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-IAM5",
                    "reason": "The IAM entity contains wildcard permissions",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-S1",
                    "reason": "Logging has been disabled for demo purposes",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-IAM4",
                    "reason": "The IAM user, role, or group uses AWS managed policies",
                }
            ),
        ]

        NagSuppressions.add_stack_suppressions(self, suppressions)

# S3 Bucket Creator

## Description
This module creates an S3 bucket with an IAM role.

## Inputs/Outputs

### Input Paramenters

#### Required
- `bucket-name`: name for the bucket (Default "addf-{deployment_name}-{account}-{hash}")
- `bu_name`- business unit name (e.g, aptiv)
- `namespace`: Namespace used in config
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.
- `iam_role_name`: IAM role name to which access to the bucket will be added, if not provided a new role will be added
- `eks_service_account_name`: EKS service account that will be added to the trust relationship to allow it to assume the IAM role

#### Optional
- `full_name_include_bu`: Flag boolean variale to enable/disable the inclusion of the name component "bu_name". Default: False
- `retention-type`: type of data retention policy when deleteing the buckets
  - `DESTROY` or `RETAIN` (Default `DESTROY`)
- `retention-days`: a numeric value specifying the number of days after objects in the bucket expire and are permanently deleted


### Module Metadata Outputs

- `BucketName`: name of the bucket
- `BucketRoleName`: name of the bucket role
- `BucketRoleArn`: ARN of the bucket role

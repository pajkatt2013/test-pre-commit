from typing import Any, Dict, cast

import aws_cdk
import aws_cdk.aws_s3 as aws_s3
from aws_cdk import Stack, Tags
from aws_cdk import aws_iam as iam
from constructs import Construct, IConstruct
from utils import LabelGenerator


class IAMStack(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        namespace: str,
        stage: str,
        config: Dict[str, Any],
        hash: str,
        bucket_name_param: str,
        retention_type_param: str,
        iam_user_name: str,
        tags: list,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys IAM user for ADDF",
            **kwargs,
        )
        # ADDF Env vars
        for k, v in config.items():
            setattr(self, k, v)

        # CDK Env Vars

        account = kwargs["env"].account
        partition = aws_cdk.Aws.PARTITION

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", self.deployment_name)
        add_tag("Module", self.module_name)
        for kv in tags:
            add_tag(kv["key"], kv["value"])

        lg = LabelGenerator(
            prefix="realm-infra",
            namespace=namespace,
            stage=stage,
            aws_env=kwargs["env"],
        )
        #                            S3 bucket
        bucket_name = lg.get_label(
            resource_type="bucket",
            resource_name=bucket_name_param,
            include_prefix=True,
            include_namespace=True,
            include_account=True,
            include_stage=True,
            include_resource_type=False,
        )
        removal_policy = (
            aws_cdk.RemovalPolicy.RETAIN
            if retention_type_param == "RETAIN"
            else aws_cdk.RemovalPolicy.DESTROY
        )
        auto_delete_objects = None if retention_type_param == "RETAIN" else True

        self.bucket = aws_s3.Bucket(
            self,
            removal_policy=removal_policy,
            bucket_name=bucket_name,
            auto_delete_objects=auto_delete_objects,
            id=f"addf-{self.deployment_name}-{self.module_name}-bucket",
            encryption=aws_s3.BucketEncryption.S3_MANAGED,
            block_public_access=aws_s3.BlockPublicAccess.BLOCK_ALL,
            event_bridge_enabled=True,
            enforce_ssl=True,
        )

        #                              IAM USER
        path_prefix = "platform-permission-boundaries"
        boundary_name = "orionadp-iam-user-permission-boundary-baseline"
        permission_boundary_arn = (
            f"arn:{partition}:iam::{account}:policy/{path_prefix}/{boundary_name}"
        )

        iam_user_name_full = lg.get_label(
            resource_type="user",
            resource_name=iam_user_name,
            include_prefix=True,
            include_namespace=True,
            include_stage=True,
        )

        self.iam_user = iam.CfnUser(
            self,
            iam_user_name_full,
            user_name=iam_user_name_full,
            permissions_boundary=permission_boundary_arn,
        )

        self.s3_policy = iam.CfnUserPolicy(
            self,
            "S3Policy",
            policy_name=f"{self.bucket.bucket_name}",
            user_name=iam_user_name_full,
            policy_document={
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "s3:List*",
                            "s3:PutObject",
                            "s3:AbortMultipartUpload",
                            "s3:CreateMultipartUpload",
                        ],
                        "Resource": [
                            f"{self.bucket.bucket_arn}",
                            f"{self.bucket.bucket_arn}/*",
                        ],
                    }
                ],
            },
        )
        self.s3_policy.node.add_dependency(self.iam_user)

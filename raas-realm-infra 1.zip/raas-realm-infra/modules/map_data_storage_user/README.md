# IAM Role Creator

## Description

This module creates s3 bucket and IAM user with boundary policy and,
with policy which resources corespounding to the new created s3 bucket.

## Inputs/Outputs

### Input Paramenters

#### Required
- `stage`: Stage used in naming and, in config
- `bucket-name`: name for the bucket (Default "addf-{deployment_name}-{account}-{hash}")-
- `iam_user_name`: IAM user name, which will be created by this module

#### Optional
- `namespace`: Namespace used in naming and, in config


### Module Metadata Outputs
- `UserName`: name of the IAM user created
- `BucketName`: policy attached to the bucket and IAM user

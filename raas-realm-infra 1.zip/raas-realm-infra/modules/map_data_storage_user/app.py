import json
import os

import aws_cdk
from aws_cdk import App, CfnOutput
from stack import IAMStack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
hash = os.getenv("ADDF_HASH", "")

target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")
stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")

namespace = os.getenv(_param("NAMESPACE"), "defaultNS")

IamUserName = os.getenv(_param("IAM_USER_NAME"), "")

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "target_realm_account_id": target_realm_account_id,
}

app = App()

bucket_name_param = os.getenv("ADDF_PARAMETER_BUCKET_NAME", None)
retention_type_param = os.getenv("ADDF_PARAMETER_RETENTION_TYPE", "DESTROY").upper()

stack = IAMStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    namespace=namespace,
    stage=stage,
    config=config,
    hash=hash,
    bucket_name_param=bucket_name_param,
    retention_type_param=retention_type_param,
    iam_user_name=IamUserName,
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
    tags=tag_list,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {"UserName": stack.iam_user.user_name, "BucketName": stack.bucket.bucket_name}
    ),
)

app.synth(force=True)

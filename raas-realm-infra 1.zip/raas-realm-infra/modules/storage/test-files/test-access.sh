#!/bin/bash

#DOC: error codes: https://docs.aws.amazon.com/cli/latest/userguide/cli-usage-returncodes.html

assert_exit_code() {
  local command=$1
  local test_name=$2

  GREEN='\033[0;32m'
  RED='\033[0;31m'
  NC='\033[0m' # No color

  bold=$(tput bold)
  normal=$(tput sgr0)

  # Execute the command
  eval "$command"
  # Get the exit code of the command
  exit_code=$?
  if [ $exit_code -eq 0 ]; then
    COLOR=$GREEN
    connection="accepted"
  else
    COLOR=$RED
    connection="rejected"
  fi
  echo -e "${bold}test name${normal}:  $test_name | ${bold}connection status${normal}: ${COLOR} $connection ${NC}"
}


# sso into the account to be tested

# Read permissions - try to download the test file in test bucket

## 1. Directly from the bucket:

assert_exit_code "(aws s3api get-object --key test.txt --bucket orion-raasv1-tftest-rpu-debug ./test.txt &> /dev/null)" "read from bucket"

## 2. Using the access points:
assert_exit_code "(aws s3api get-object --key test.txt --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-continental ./test.txt &> /dev/null)" "read from supplier ap - no tag"
assert_exit_code "(aws s3api get-object --key test.txt --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-vigem ./test.txt &> /dev/null)" "read from supplier ap - no tag"
assert_exit_code "(aws s3api get-object --key test.txt --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-orion ./test.txt &> /dev/null)" "read from platform ap - no tag"


### 2.1 Test supplier access with tagged object

assert_exit_code "(aws s3api get-object --key test_continental.txt --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-continental ./test_continental.txt &> /dev/null)" "read from supplier ap - correct tag"
assert_exit_code "(aws s3api get-object --key test_vigem.txt --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-vigem ./test_vigem.txt &> /dev/null)" "read from supplier ap - correct tag"
assert_exit_code "(aws s3api get-object --key test_vigem.txt --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-orion ./test.txt &> /dev/null)" "read from platform ap - tagged"

# Write permissions - try to upload the test file to the test bucket

## 1. Directly from the bucket:

assert_exit_code "(aws s3api put-object --bucket orion-raasv1-tftest-rpu-debug --key test-uploaded.txt  --body test.txt &> /dev/null)" "write directly to bucket"


## 2. Using the access points:
assert_exit_code "(aws s3api put-object --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-continental --key test-uploaded.txt --body test.txt &> /dev/null)" "write using supplier ap"
assert_exit_code "(aws s3api put-object --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-vigem --key test-uploaded.txt --body test.txt &> /dev/null)" "write using supplier ap"
assert_exit_code "(aws s3api put-object --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-orion --key test-uploaded.txt --body test.txt &> /dev/null)" "write using platform ap"


# List bucket permissions

## 1. Directly from the bucket:

assert_exit_code "(aws s3api list-objects-v2 --bucket orion-raasv1-tftest-rpu-debug &> /dev/null)" "list directly from bucket"

## 2. Using the access points:
assert_exit_code "(aws s3api list-objects-v2 --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-continental &> /dev/null)" "list from supplier ap"
assert_exit_code "(aws s3api list-objects-v2 --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-vigem &> /dev/null)" "list from supplier ap"
assert_exit_code "(aws s3api list-objects-v2 --bucket arn:aws:s3:eu-central-1:178345759618:accesspoint/orion-tftest-rpu-debug-orion &> /dev/null)" "list from platform ap"

import json
import os

import aws_cdk
from aws_cdk import App
from stack import BucketsAPStack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
hash = os.getenv("ADDF_HASH", "")

target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")
stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")

namespace = os.getenv(_param("NAMESPACE"), "defaultNS")

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "target_realm_account_id": target_realm_account_id,
}

app = App()

bucket_name_param_str = os.getenv("ADDF_PARAMETER_BUCKET_NAME")
if not bucket_name_param_str:
    raise RuntimeError("Input parameter <bucket_name> is missing")
bucket_name_param = json.loads(bucket_name_param_str)

ap_config_file = os.getenv(_param("AP_CONFIG_FILE"))
if not ap_config_file:
    raise RuntimeError("Input parameter <ap_config_file> is missing")


stack = BucketsAPStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    namespace=namespace,
    stage=stage,
    config=config,
    hash=hash,
    bucket_name_param=bucket_name_param,
    ap_config_file=ap_config_file,
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
    suppress_template_indentation=True,
    tags=tag_list,
)

app.synth(force=True)

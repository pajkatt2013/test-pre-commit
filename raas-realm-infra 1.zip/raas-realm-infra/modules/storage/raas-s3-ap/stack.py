import json
import os
from typing import Any, Dict, cast

import aws_cdk
import aws_cdk.aws_s3 as aws_s3
import cdk_nag
from aws_cdk import Aspects, Stack, Tags

# from aws_cdk import aws_iam as iam
# from cdk_nag import NagPackSuppression, NagSuppressions
from constructs import Construct, IConstruct

# from utils import LabelGenerator


class BucketsAPStack(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        namespace: str,
        stage: str,
        config: Dict[str, Any],
        hash: str,
        bucket_name_param: list,
        ap_config_file: str,
        tags: list,
        **kwargs: Any,
    ) -> None:
        # ADDF Env vars

        for k, v in config.items():
            setattr(self, k, v)

        # CDK Env Vars
        partition: str = aws_cdk.Aws.PARTITION
        account: str = aws_cdk.Aws.ACCOUNT_ID
        region: str = aws_cdk.Aws.REGION

        super().__init__(
            scope,
            id,
            description="This stack deploys Access points for S3 Buckets",
            **kwargs,
        )

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", self.deployment_name)
        add_tag("Module", self.module_name)
        for kv in tags:
            add_tag(kv["key"], kv["value"])

        project_dir = os.path.dirname(os.path.abspath(__file__))
        path_conf_file = os.path.join(project_dir, ap_config_file)

        # open config file
        with open(path_conf_file) as ap_config_file:
            raas_s3_ap_conf = json.load(ap_config_file)

        r_accounts = raas_s3_ap_conf["read_accounts"]

        def get_access_point_policy(read_account, path_filter, ap_name):
            policy_statements = []

            read_permissions = {
                "Sid": "grant read access to raas buckets to selected services originating in a list of defined accounts",
                "Effect": "Allow",
                "Principal": {
                    "AWS": [
                        f"arn:{partition}:iam::{str(acc)}:root" for acc in read_account
                    ]
                },
                "Action": "s3:GetObject*",
                "Resource": path_filter,
            }

            allow_list_objects = {
                "Sid": "Allow list bucket from Access Points",
                "Effect": "Allow",
                "Principal": {
                    "AWS": [
                        f"arn:{partition}:iam::{str(acc)}:root" for acc in read_account
                    ]
                },
                "Action": "s3:ListBucket",
                "Resource": f"arn:{partition}:s3:{region}:{account}:accesspoint/{ap_name}",
            }

            ssl_only = {
                "Sid": "Allow SSL requests only",
                "Effect": "Deny",
                "Principal": {"AWS": "*"},
                "Action": "s3:*",
                "Resource": [
                    f"arn:{partition}:s3:{region}:{account}:accesspoint/{ap_name}/object/*",
                    f"arn:{partition}:s3:{region}:{account}:accesspoint/{ap_name}",
                ],
                "Condition": {"Bool": {"aws:SecureTransport": "false"}},
            }

            deny_read_noncompliant = {
                "Sid": "Explicit deny read to non-compliant",
                "Effect": "Deny",
                "Principal": {"AWS": "*"},
                "Action": "s3:GetObject*",
                "Resource": f"arn:{partition}:s3:{region}:{account}:accesspoint/{ap_name}/object/*",
                "Condition": {
                    "StringNotEquals": {
                        "aws:PrincipalAccount": [f"{acc}" for acc in read_account]
                    }
                },
            }

            deny_write = {
                "Sid": "Explicit deny write to non-compliant",
                "Effect": "Deny",
                "Principal": {"AWS": "*"},
                "Action": "s3:PutObject*",
                "Resource": f"arn:{partition}:s3:{region}:{account}:accesspoint/{ap_name}/object/*",
            }

            policy_statements.extend(
                [
                    read_permissions,
                    allow_list_objects,
                    ssl_only,
                    deny_read_noncompliant,
                    deny_write,
                ]
            )

            access_point_policy = {
                "Version": "2012-10-17",
                "Statement": policy_statements,
            }

            return access_point_policy

        for bucket_name in bucket_name_param:
            bname = bucket_name.split("-")
            new_bname = bname[:1] + bname[2:]
            ap_prefix = "-".join(new_bname)

            # suppliers access points
            for supp in r_accounts["suppliers"]:
                supplier_name = supp["name"]
                ap_name = f"{ap_prefix}-{supplier_name}"
                sensor_name = supp["sensors"]
                if type(supp[stage]) == list:
                    supplier_account = supp[stage]
                else:
                    supplier_account = [supp[stage]]

                path_filter = [
                    f"arn:{partition}:s3:{region}:{account}:accesspoint/{ap_name}/object/*{sensor}*"
                    for sensor in sensor_name
                ]

                # Define the policy
                access_point_policy = get_access_point_policy(
                    supplier_account, path_filter, ap_name
                )

                # Create an Access Point
                aws_s3.CfnAccessPoint(
                    self,
                    ap_name,
                    bucket=bucket_name,
                    name=ap_name,
                    policy=access_point_policy,
                )

            # tenant access points
            for tenant in r_accounts["tenants"]:
                tenant_name = tenant["name"]
                ap_name = f"{ap_prefix}-{tenant_name}"
                tenant_account = [realm[stage] for realm in tenant["realm"]]

                path_filter = f"arn:{partition}:s3:{region}:{account}:accesspoint/{ap_name}/object/*"

                # Define the policy
                access_point_policy = get_access_point_policy(
                    tenant_account, path_filter, ap_name
                )

                # Create an Access Point
                aws_s3.CfnAccessPoint(
                    self,
                    ap_name,
                    bucket=bucket_name,
                    name=ap_name,
                    policy=access_point_policy,
                )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

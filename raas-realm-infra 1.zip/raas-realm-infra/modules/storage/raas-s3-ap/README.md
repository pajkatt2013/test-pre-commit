# S3 Bucket Access Point Creator

## Description

This module creates supplier and tenant access points to S3 Buckets, which created by the dependent module "raas_s3", including the permissions.

Access points naming has dependency on bucket naming convention in raas_s3. e.g,

s3-naming-convention: <tenant_name>-<instance_alias>-<namespace>-<customer-function>-<suffix>
AP-naming-convention: <tenant_name>-<namespace>-<customer-function>-<suffix>-<supplier/tenant name>

Instance-alias is removed from the bucket name and supplier/tenant name is appended as suffix to generate Access Point name.
Note that access point name has limitation of 50 characters. (Reference: https://docs.aws.amazon.com/AmazonS3/latest/userguide/creating-access-points.html#access-points-names)

## Inputs/Outputs

### Input Paramenters

#### Required

- `bucket-name`: List of bucket names for which access points needs to be created.
- `stage`: Target stage of deployment.
- `ap-config-file`: Config file path for access points to define read_accounts including suppliers and tenants.
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.

#### Optional

- `namespace`: Target namespace of deployment.


#### Input Example

```yaml
name: storage-ap
path: <path_to_module>/modules/raas-s3-ap

parameters:
  - name: bucket-name
    valueFrom:
      moduleMetadata:
        group: raas-s3
        name: storage
        key: ListBucketName

  - name: stage
    valueFrom:
      envVariable: STAGE

  - name: namespace
    valueFrom:
      envVariable: NAMESPACE

  - name: ap-config-file
    valueFrom:
      envVariable: RAAS_S3_AP_CONFIG

  - name: cost-allocation-tag
    value:
      - key: customer_function
        value: common
      - key: maintainer
        value: raas_devops
```

### Module Metadata Outputs
No output.


## About update configuration file

The configuration is in JSON format. It contains two items: suppliers and tenants.

First item contains list of suppliers. Adding a supplier in the list will create access point for new supplier. Second item is tenants. Adding a tenant in the list will create access point for new tenant.

Tenants include realms list to give read permissions to multiple realms in access point

### Example

```json

{
    "read_accounts": {
      "suppliers": [
        {
          "name": "aptiv",
          "realm": "AptivRpuSandbox",
          "dev": "252558989731",
          "int": "760844882854",
          "prod": "555552677817",
          "sensors": ["mrrhead", "mrrtracker", "srrhead", "srrtracker"]
        },
        {
          "name": "continental",
          "realm": "ContiRpuSandbox",
          "dev": "681426436539",
          "int": "153935578439",
          "prod": "222835328957",
          "sensors": ["frr"]
        },
        <New suppplier can be defined here>
      ],
      "tenants": [
        {
          "name": "orion",
          "realm": [
            {
              "name": "RaaSv1",
              "dev": "178345759618",
              "int": "361298712206",
              "prod": "984792474975"
            },
            {
              "name": "KPIv1",
              "dev": "407581092542",
              "int": "813937823235",
              "prod": "009603782950"
            },
            {
              "name": "SignalExtractv1",
              "dev": "623379174628",
              "int": "969556237058",
              "prod": "542096431227"
            },
            <New realm can be defined here>
          ]
        }
      ]
      <New tenant can be defined here>
    },
    "write_accounts": []
  }

```

## Introduction
Terraform IAC for Collected Zone realm, integrated with seedfarmer.
## Description
This stack deploys the following two S3 buckets:

* **Collected:** This bucket stores the sessions' payload
* **Other:** This bucket holds data (e.g metadata) on the sessions themselves

... per each customer function (declared either in an external file or read from SSM parameters)


<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 5.4 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.4 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_access_point_supplier"></a> [access\_point\_supplier](#module\_access\_point\_supplier) | ./modules/access_points | n/a |
| <a name="module_access_point_tenant_collected"></a> [access\_point\_tenant\_collected](#module\_access\_point\_tenant\_collected) | ./modules/access_points | n/a |
| <a name="module_access_point_tenant_other"></a> [access\_point\_tenant\_other](#module\_access\_point\_tenant\_other) | ./modules/access_points | n/a |
| <a name="module_s3_collected_zone_bucket_collected"></a> [s3\_collected\_zone\_bucket\_collected](#module\_s3\_collected\_zone\_bucket\_collected) | ./modules/buckets | n/a |
| <a name="module_s3_collected_zone_bucket_other"></a> [s3\_collected\_zone\_bucket\_other](#module\_s3\_collected\_zone\_bucket\_other) | ./modules/buckets | n/a |

## Resources

| Name | Type |
|------|------|
| [aws_ssm_parameter.instance_alias](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.org_id](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.tenant_name](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |
| [aws_ssm_parameter.tenant_stage_org_unit_id](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssm_parameter) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | Deployment region for this module | `string` | `"eu-central-1"` | no |
| <a name="input_buckets"></a> [buckets](#input\_buckets) | Object declaring the name and tag of all buckets to be deployed | `map(any)` | `{}` | no |
| <a name="input_namespace"></a> [namespace](#input\_namespace) | Namespace of the current deployment | `string` | `"empty"` | no |
| <a name="input_read_accounts"></a> [read\_accounts](#input\_read\_accounts) | Account ids that are able to read from S3 access point | `map(any)` | `{}` | no |
| <a name="input_stage"></a> [stage](#input\_stage) | The environment in which you want to deploy [i.e.: int, dev, prod] | `string` | `"dev"` | no |
| <a name="input_write_accounts"></a> [write\_accounts](#input\_write\_accounts) | Object declaring accounts that should have permission to write to S3 buckets | <pre>list(object({<br>    realm = string<br>    stage = string<br>    id    = string<br>  }))</pre> | `[]` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->

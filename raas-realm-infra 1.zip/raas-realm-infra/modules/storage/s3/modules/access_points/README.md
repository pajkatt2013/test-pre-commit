<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 5.4 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.4 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_s3_access_point.bucket_access_point](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_access_point) | resource |
| [aws_s3control_access_point_policy.ac_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3control_access_point_policy) | resource |
| [aws_iam_policy_document.access_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_org_id"></a> [org\_id](#input\_org\_id) | Organizational ID of the deployment account | `string` | n/a | yes |
| <a name="input_read_account_list"></a> [read\_account\_list](#input\_read\_account\_list) | List defining accounts with read access | `list(list(string))` | n/a | yes |
| <a name="input_s3_bucket_id"></a> [s3\_bucket\_id](#input\_s3\_bucket\_id) | Bucket id | `string` | n/a | yes |
| <a name="input_s3_bucket_short_name"></a> [s3\_bucket\_short\_name](#input\_s3\_bucket\_short\_name) | Shortened name identifying the S3 bucket containing the access point | `string` | n/a | yes |
| <a name="input_supplier_names"></a> [supplier\_names](#input\_supplier\_names) | Name of suppliers with own access points | `list(string)` | n/a | yes |
| <a name="input_tenant_names"></a> [tenant\_names](#input\_tenant\_names) | Name of the tenants with own access points | `list(string)` | <pre>[<br>  "orion"<br>]</pre> | no |
| <a name="input_tenant_stage_org_unit_id"></a> [tenant\_stage\_org\_unit\_id](#input\_tenant\_stage\_org\_unit\_id) | ID in this organization for the specific deployment stage | `string` | n/a | yes |
| <a name="input_write_account_list"></a> [write\_account\_list](#input\_write\_account\_list) | List defining tenant accounts with write access | `list(string)` | `[]` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->

# RaaS S3 Bucket Module

## Description

This module creates the S3 Buckets with configurations, such as bucket policy, encryption properties.

## Inputs/Outputs
### Input Paramenters
#### Required
- `stage`: Target stage of deployment.
- `namespace`: Target namespace of deployment.
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.
- `s3-config-file`: Configuration file as input for the creation of the S3 Buckets.

- `realm-tenant-name`: The name of platform parameter, which is stored within the AWS parameter store.
- `realm-instance-alias`: The name of platform parameter, which is stored within the AWS parameter store.
- `org_id`: The name of platform parameter <organization-id>, which is stored within the AWS parameter store.
- `org_unit_id_dev`: The name of platform parameter stage org unit id <dev_ou_id>, which is stored within the AWS parameter store.
- `org_unit_id_int`: The name of platform parameter stage org unit id <int_ou_id>, which is stored within the AWS parameter store.
- `org_unit_id_prod`: The name of platform parameter stage org unit id <prod_ou_id>, which is stored within the AWS parameter store.

#### Optional
- `bu_name`- business unit name (e.g, aptiv)
- `s3-name-suffix`: The suffix of the S3 bucket name.
- `s3_acc_config`: The Value of the S3 accelerate configuration. The default value is Suspended

#### Input Example
```yaml
parameters:
  - name: bu_name
    valueFrom:
      envVariable: BU_NAME

  - name: stage
    valueFrom:
      envVariable: STAGE

  - name: namespace
    valueFrom:
      envVariable: NAMESPACE

  - name: cost-allocation-tag
    value:
      - key: maintainer
        value: raas_devops

  - name: s3-config-file
    valueFrom:
      envVariable: RAAS_S3_CONFIG

  - name: realm-tenant-name
    valueFrom:
      parameterStore: /orionadp/platform/account-info/tenant-name

  - name: realm-instance-alias
    valueFrom:
      parameterStore: /orionadp/platform/account-info/realm/instance-alias

  - name: org_id
    valueFrom:
      parameterStore: /orionadp/platform/organization-id

  - name: org_unit_id_dev
    valueFrom:
      parameterStore: /orionadp/platform/tenant/organizational-unit/dev_ou_id

  - name: org_unit_id_int
    valueFrom:
      parameterStore: /orionadp/platform/tenant/organizational-unit/int_ou_id

  - name: org_unit_id_prod
    valueFrom:
      parameterStore: /orionadp/platform/tenant/organizational-unit/prod_ou_id

  - name: s3-name-suffix
    value: reprocessed

  - name: s3_acc_config
    valueFrom:
      envVariable: S3_ACC_CONFIG

```

### Module Metadata Outputs
- `ListBucketName`: The list of S3 bucket full names.
- `ListBucketARN`: The list of S3 bucket ARNs.


## About update configuration file

### Structure

The configuration is in JSON format. It contains two items, "buckets" and "realm".

The 1st item contain a list of buckets definition. Two kind of buckets can be defined in the list, "customer function" and "debug".

The "debug" bucket definition, should have the value "debug" in the "id" attribute as shown in the example.
All buckets can be defined as list in the buckets item.

The 2nd item is "realm", which should contains all the account id with in the realm, and the name of the realm.

### Example
```json
{
    "buckets": [
        {
            "id": "cp60",
            "name": "cp60",
            "tag": "cp60"
        },

        ...,

        {
            "id": "debug",
            "name": "rpu",
            "tag": "common"
        }
    ],
    "realm": {
        "name": "RaaSv1",
        "dev": "178345759618",
        "int": "361298712206",
        "prod": "984792474975"
    }
}
```
Added retention policy of 7 days for "common" bucket by using the parameter "retention_days": "7"

```json
{
    "buckets": [
        {
            "id": "common",
            "name": "common",
            "tag": "common",
            "retention_days": "7"
        }
    ],

    ...

}
```

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
import json
import os
from typing import Any, Dict

import aws_cdk as cdk
from aws_cdk import Stack, Tags, aws_s3
from constructs import Construct

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
project_dir = os.path.dirname(os.path.abspath(__file__))

C_KEY_BUCKETS = "buckets"
C_KEY_REALM = "realm"
C_KEY_DEV = "dev"
C_KEY_INT = "int"
C_KEY_PROD = "prod"

C_KEY_ID = "id"
C_KEY_NAME = "name"
C_KEY_TAG = "tag"
C_KEY_RETENTION_DAYS = "retention_days"
C_S3_TAG_KEY_NAME = "name"
C_S3_TAG_KEY_CUSTOMER_FUNCTION = "customer_function"


# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
class RAAS_S3(Stack):
    def __init__(
        self,
        scope: Construct,
        id: str,
        config: Dict[str, Any],
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys the secret in Secret Manager",
            **kwargs,
        )

        partition = cdk.Aws.PARTITION

        for k, v in config.items():
            setattr(self, k, v)

        tags = self.tag_list
        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        def get_stage_ou_id(stage: str):
            if stage == C_KEY_DEV:
                return self.org_unit_id_dev
            if stage == C_KEY_INT:
                return self.org_unit_id_int
            if stage == C_KEY_PROD:
                return self.org_unit_id_prod
            return None

        # get info of config file
        print(f"[INFO] s3_config_file: {self.s3_config_file}")
        path_conf_file = os.path.join(project_dir, self.s3_config_file)

        with open(path_conf_file) as s3_conf_file:
            raas_s3_conf = json.load(s3_conf_file)

        list_bucket_infos = raas_s3_conf[C_KEY_BUCKETS]
        realm_info = raas_s3_conf[C_KEY_REALM]
        dev_acc_id = realm_info[C_KEY_DEV]
        int_acc_id = realm_info[C_KEY_INT]
        prod_acc_id = realm_info[C_KEY_PROD]

        self.list_bucket_name = []
        self.list_bucket_arn = []

        # loop to create all bucket with configurations
        for b in list_bucket_infos:
            bid = b[C_KEY_ID]
            bname = b[C_KEY_NAME]
            btag = b[C_KEY_TAG]
            bretention_days = None
            if C_KEY_RETENTION_DAYS in b and b[C_KEY_RETENTION_DAYS]:
                bretention_days = int(b[C_KEY_RETENTION_DAYS])

            lifecycle_rules = []
            if bretention_days and int(bretention_days) > 0:
                lifecycle_rules = aws_s3.CfnBucket.LifecycleConfigurationProperty(
                    rules=[
                        aws_s3.CfnBucket.RuleProperty(
                            id="RetainAndDelete",
                            status="Enabled",
                            expiration_in_days=bretention_days,
                        )
                    ]
                )

            if bid == "debug":
                s3_full_name = f"{self.realm_tenant_name}-{self.realm_instance_alias}{self.namespace}-{bname}-{bid}".lower()
            else:
                s3_full_name = f"{self.realm_tenant_name}-{self.realm_instance_alias}{self.namespace}-{bname}-{self.s3_name_suffix}".lower()
            s3_full_name = s3_full_name.replace("_", "-")
            print(f"[INFO] Creating S3 Bucket: {s3_full_name}")

            # Deletion Policy: Force deletion disable
            # For Amazon S3 buckets, you must delete all objects in the bucket for deletion to succeed.
            cfn_bucket = aws_s3.CfnBucket(
                scope=self,
                id=s3_full_name,
                bucket_name=s3_full_name,
                accelerate_configuration=aws_s3.CfnBucket.AccelerateConfigurationProperty(
                    acceleration_status="Suspended"
                )
                if self.s3_acc_config == "Suspended"
                else None,
                bucket_encryption=aws_s3.CfnBucket.BucketEncryptionProperty(
                    server_side_encryption_configuration=[
                        aws_s3.CfnBucket.ServerSideEncryptionRuleProperty(
                            # bucket_key_enabled=False,
                            server_side_encryption_by_default=aws_s3.CfnBucket.ServerSideEncryptionByDefaultProperty(
                                sse_algorithm="AES256"
                            )
                        )
                    ]
                ),
                object_lock_enabled=False,
                ownership_controls=aws_s3.CfnBucket.OwnershipControlsProperty(
                    rules=[
                        aws_s3.CfnBucket.OwnershipControlsRuleProperty(
                            object_ownership="BucketOwnerEnforced"
                        )
                    ]
                ),
                public_access_block_configuration=aws_s3.CfnBucket.PublicAccessBlockConfigurationProperty(
                    block_public_acls=True,
                    block_public_policy=True,
                    ignore_public_acls=True,
                    restrict_public_buckets=True,
                ),
                tags=[
                    cdk.CfnTag(key=C_S3_TAG_KEY_NAME, value=s3_full_name),
                    cdk.CfnTag(key=C_S3_TAG_KEY_CUSTOMER_FUNCTION, value=btag),
                ],
                versioning_configuration=aws_s3.CfnBucket.VersioningConfigurationProperty(
                    status="Enabled"
                ),
                lifecycle_configuration=lifecycle_rules,
            )
            self.list_bucket_name.append(cfn_bucket.bucket_name)
            self.list_bucket_arn.append(cfn_bucket.attr_arn)

            stage_ou_id = get_stage_ou_id(stage=self.stage)
            if not stage_ou_id:
                raise RuntimeError("stage_org_unit is None")

            bucket_policy_document = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Sid": "Delegate bucket permissions to access points",
                        "Effect": "Allow",
                        "Principal": {"AWS": "*"},
                        "Action": "s3:*",
                        "Resource": [f"{cfn_bucket.attr_arn}/*", cfn_bucket.attr_arn],
                        "Condition": {
                            "StringEquals": {
                                "s3:DataAccessPointAccount": realm_info[self.stage]
                            }
                        },
                    },
                    {
                        "Sid": "grant selected accounts (e.g ingest realm) WRITE/READ permissions to cz buckets. Verify stage in org",
                        "Effect": "Allow",
                        "Principal": {
                            "AWS": [
                                f"arn:{partition}:iam::{dev_acc_id}:root",
                                f"arn:{partition}:iam::{int_acc_id}:root",
                                f"arn:{partition}:iam::{prod_acc_id}:root",
                            ]
                        },
                        "Action": ["s3:PutObject", "s3:GetObject"],
                        "Resource": f"{cfn_bucket.attr_arn}/*",
                        "Condition": {
                            "ForAnyValue:StringLike": {
                                "aws:PrincipalOrgPaths": f"{self.org_id}/*/{stage_ou_id}*"
                            }
                        },
                    },
                    {
                        "Sid": "grant accounts in same stage and org LIST permission to raas buckets",
                        "Effect": "Allow",
                        "Principal": {
                            "AWS": [
                                f"arn:{partition}:iam::{dev_acc_id}:root",
                                f"arn:{partition}:iam::{int_acc_id}:root",
                                f"arn:{partition}:iam::{prod_acc_id}:root",
                            ]
                        },
                        "Action": "s3:ListBucket",
                        "Resource": cfn_bucket.attr_arn,
                        "Condition": {
                            "ForAnyValue:StringLike": {
                                "aws:PrincipalOrgPaths": f"{self.org_id}/*/{stage_ou_id}*"
                            }
                        },
                    },
                ],
            }

            aws_s3.CfnBucketPolicy(
                scope=self,
                id=f"{cfn_bucket.bucket_name}-bucket-policy",
                bucket=cfn_bucket.bucket_name,
                policy_document=bucket_policy_document,
            )

        # Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())


# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

import json
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import RAAS_S3


# ------------------------------------------------------------------------------
def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


# ------------------------------------------------------------------------------

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
stage = os.getenv(_param("STAGE"), "defaultStage")
namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")
tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

s3_config_file = os.getenv(_param("S3_CONFIG_FILE"))
if not s3_config_file:
    raise RuntimeError("Input parameter <s3_config_file> is missing")

realm_tenant_name = os.getenv(_param("REALM_TENANT_NAME"))
if not realm_tenant_name:
    raise RuntimeError("Input parameter <realm_tenant_name> is missing")

realm_instance_alias = os.getenv(_param("REALM_INSTANCE_ALIAS"))
if not realm_instance_alias:
    raise RuntimeError("Input parameter <realm_instance_alias> is missing")


org_id = os.getenv(_param("ORG_ID"))
if not org_id:
    raise RuntimeError("Input parameter <org_id> is missing")

org_unit_id_dev = os.getenv(_param("ORG_UNIT_ID_DEV"))
if not org_unit_id_dev:
    raise RuntimeError("Input parameter <org_unit_id_dev> is missing")

org_unit_id_int = os.getenv(_param("ORG_UNIT_ID_INT"))
if not org_unit_id_int:
    raise RuntimeError("Input parameter <org_unit_id_int> is missing")

org_unit_id_prod = os.getenv(_param("ORG_UNIT_ID_PROD"))
if not org_unit_id_prod:
    raise RuntimeError("Input parameter <org_unit_id_prod> is missing")

s3_name_suffix = os.getenv(_param("S3_NAME_SUFFIX"), "reprocessed")

s3_acc_config = os.getenv(_param("S3_ACC_CONFIG"), "Suspended")

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "stage": stage,
    "namespace": namespace,
    "bu_name": bu_name,
    "tag_list": tag_list,
    "s3_config_file": s3_config_file,
    "realm_tenant_name": realm_tenant_name,
    "realm_instance_alias": realm_instance_alias,
    "s3_name_suffix": s3_name_suffix,
    "s3_acc_config": s3_acc_config,
    "org_id": org_id,
    "org_unit_id_dev": org_unit_id_dev,
    "org_unit_id_int": org_unit_id_int,
    "org_unit_id_prod": org_unit_id_prod,
}

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

app_id = f"addf-{deployment_name}-{module_name}"

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
app = cdk.App()
stack = RAAS_S3(scope=app, id=app_id, config=config, env=environment)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "ListBucketName": stack.list_bucket_name,
            "ListBucketARN": stack.list_bucket_arn,
        }
    ),
)

app.synth(force=True)

# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

# Aurora serverless

## Description

This module creates a serverless Aurora cluster with a Postgres engine with an IAM role for access to the DB cluster


## Inputs/Outputs

### Input Paramenters

#### Required

- `stage`: Target stage of deployment
- `namespace`: Target namespace of deployment
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.
- `vpc-id`: VPC Id where the Aurora cluster will be deployed
- `private-subnet-ids`: List of Private Subnets Ids where the Aurora cluster will be deployed
- `cluster-name`: Main name of the RDS database cluster
- `sg-name`: Main name of the security group to be associated with the DB cluster
- `database-name`: Name of the database created inside the Aurora cluster
- `table-name`: Name of the table created in the database
- `iam-role-name`: IAM role name, which will be created by this module to provide access to the DB cluster

#### Optional
- `db_port`: RDS database port. Default: 5432
- `db_engine_version`: RDS database engine version. Default: 15
- `master-username`: RDS database master username. Default: raasmaster
- `read_only_username`: RDS database engine version. Default: readonlyuser

#### Input Example
```yaml
parameters:
  - name: bu_name
    valueFrom:
      envVariable: BU_NAME

  - name: stage
    valueFrom:
      envVariable: STAGE

  - name: namespace
    valueFrom:
      envVariable: NAMESPACE

  - name: cost-allocation-tag
    value:
      - key: customer_function
        value: common
      - key: maintainer
        value: raas_devops

  - name: vpc-id
    valueFrom:
      parameterStore: /orionadp/blueprint/vpc/network-awsrouted-vpc/vpc-id

  - name: private-subnet-ids
    valueFrom:
      parameterStore: /orionadp/blueprint/vpc/network-awsrouted-vpc/private-subnets

  - name: db_port
    value: 5432

  - name: db_engine_version
    value: 15

  - name: cluster-name
    value: mdm-pg-cluster

  - name: sg-name
    value: rdsapg

  - name: database-name
    value: demos

  - name: master-username
    value: pgmaster

  - name: read_only_username
    value: grafana

```

### Module Metadata Outputs

- `DBClusterId`: name of the S3 Bucket configured to store MWAA Environment DAG artifacts.
- `DBClusterName`: name of the created cluster.
- `DBClusterSecretArn`: ARN of the secret entry for the master user.
- `DBSecurityGroupId`: Id of the security group of the cluster.
- `DBReadOnlyUserSecretArn`: ARN of the secret entry for the read-only user.
- `DBInitName`: Initial database name.
- `DBClusterVPCID`: Id of the VPC of the cluster.
- `DBClusterSubnets`: Id of the VPC subnets of the cluster.
- `DBPort`: RDS database port.
- `DBProxyEndpoint`: Endpoint of the DB Proxy Endpoint of the cluster.

#### Output Example

```json
{
    "DBClusterId": stack.db_cluster.cluster_identifier,
    "DBClusterName": stack.clustername,
    "DBInitName": stack.init_dbname,
    "DBClusterSecretArn": stack.db_cluster.secret.secret_arn,
    "DBReadOnlyUserSecretArn": stack.read_only_user_secret.secret_arn,
    "DBClusterVPCID": stack.db_cluster.vpc.vpc_id,
    "DBClusterSubnets": stack.subnet_ids,
    "DBPort": stack.db_port,
    "DBSecurityGroupId": stack.db_security_group.security_group_id,
    "DBProxyEndpoint": stack.db_proxy.endpoint
}
```

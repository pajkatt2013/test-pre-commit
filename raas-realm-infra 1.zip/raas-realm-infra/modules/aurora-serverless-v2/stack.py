from typing import Any, cast

import cdk_nag
from aws_cdk import Aspects, Stack, Tags
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_rds as rds
from aws_cdk import aws_secretsmanager as secretsmanager
from cdk_nag import NagPackSuppression, NagSuppressions
from constructs import Construct, IConstruct
from utils import LabelGenerator


class AuroraServerlessV2Stack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        deployment_name: str,
        module_name: str,
        namespace: str,
        bu_name: str,
        id: str,
        *,
        vpc_id: str,
        private_subnet_ids: list,
        database_name: str,
        cluster_name: str,
        sg_name: str,
        tags: list,
        read_only_username: str = "readonlyuser",
        db_master_username: str = "raasmaster",
        db_port: int = 5432,
        db_engine_version: int = 15,
        dq_rds_storage_encrypted: bool,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys serverless cluster with Postgres",
            **kwargs,
        )

        # ADDF Env vars
        self.deployment_name = deployment_name
        self.module_name = module_name

        # CDK Env Vars
        # region: str = kwargs["env"].region
        # account: str = kwargs["env"].account

        def get_aurora_pg_engine_version(ver: int):
            if ver == 13:
                return rds.AuroraPostgresEngineVersion.VER_13_9
            elif ver == 14:
                return rds.AuroraPostgresEngineVersion.VER_14_6
            else:
                return rds.AuroraPostgresEngineVersion.VER_15_3

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", self.deployment_name)
        add_tag("Module", self.module_name)
        for kv in tags:
            add_tag(kv["key"], kv["value"])

        self.db_port = db_port
        self.clustername = cluster_name
        self.init_dbname = database_name
        self.subnet_ids = private_subnet_ids

        lg = LabelGenerator(
            prefix=deployment_name,
            namespace=namespace,
            stage=stage,
            bu_name=bu_name,
            aws_env=kwargs["env"],
        )

        self.vpc = ec2.Vpc.from_lookup(
            self,
            "VPC",
            vpc_id=vpc_id,
        )
        self.private_subnets = []
        for idx, subnet_id in enumerate(private_subnet_ids):
            self.private_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"subnet{idx}", subnet_id=subnet_id
                )
            )

        # Create a Serverless Cluster
        db_security_group_name = lg.get_label(
            resource_type="sg",
            resource_name=sg_name,
            include_stage=True,
            include_namespace=True,
            include_region=True,
            include_resource_type=True,
        )

        self.db_security_group = ec2.SecurityGroup(
            self,
            db_security_group_name,
            security_group_name=db_security_group_name,
            vpc=self.vpc,
            allow_all_outbound=True,
        )

        self.db_security_group.add_ingress_rule(
            ec2.Peer.any_ipv4(), ec2.Port.tcp(self.db_port), "Access within vpc"
        )

        cluster_id_name = lg.get_label(
            resource_type="rds",
            resource_name=cluster_name,
            include_namespace=True,
            include_stage=True,
            include_resource_type=True,
        )

        pg_version = get_aurora_pg_engine_version(ver=db_engine_version)

        if self.region == "cn-north-1":
            self.db_cluster = rds.DatabaseCluster(
                scope=self,
                id="Database",
                engine=rds.DatabaseClusterEngine.aurora_postgres(version=pg_version),
                cluster_identifier=cluster_id_name,
                credentials=rds.Credentials.from_generated_secret(db_master_username),
                default_database_name=database_name,
                iam_authentication=True,
                parameter_group=rds.ParameterGroup.from_parameter_group_name(
                    self, "ParameterGroup", "default.aurora-postgresql15"
                ),
                # parameters = [],
                port=db_port,
                readers=[
                    rds.ClusterInstance.serverless_v2(
                        id="serverlessv2-reader", scale_with_writer=True
                    )
                ],
                security_groups=[self.db_security_group],
                serverless_v2_max_capacity=4,
                serverless_v2_min_capacity=0.5,
                storage_encrypted=dq_rds_storage_encrypted,
                vpc=self.vpc,
                vpc_subnets=ec2.SubnetSelection(subnets=self.private_subnets),
                writer=rds.ClusterInstance.serverless_v2(id="serverlessv2-writer")
                # writer=rds.ClusterInstance.provisioned("writer",
                #     instance_type=ec2.InstanceType.of(ec2.InstanceClass.T4G, ec2.InstanceSize.MEDIUM)
                # )
            )

        else:
            self.db_cluster = rds.DatabaseCluster(
                scope=self,
                id="Database",
                engine=rds.DatabaseClusterEngine.aurora_postgres(version=pg_version),
                cluster_identifier=cluster_id_name,
                credentials=rds.Credentials.from_generated_secret(db_master_username),
                default_database_name=database_name,
                iam_authentication=True,
                parameter_group=rds.ParameterGroup.from_parameter_group_name(
                    self, "ParameterGroup", "default.aurora-postgresql15"
                ),
                # parameters = [],
                port=db_port,
                readers=[
                    rds.ClusterInstance.serverless_v2(
                        id="serverlessv2-reader", scale_with_writer=True
                    )
                ],
                security_groups=[self.db_security_group],
                serverless_v2_max_capacity=4,
                serverless_v2_min_capacity=0.5,
                # storage_encrypted = dq_rds_storage_encrypted,
                vpc=self.vpc,
                vpc_subnets=ec2.SubnetSelection(subnets=self.private_subnets),
                writer=rds.ClusterInstance.serverless_v2(id="serverlessv2-writer")
                # writer=rds.ClusterInstance.provisioned("writer",
                #     instance_type=ec2.InstanceType.of(ec2.InstanceClass.T4G, ec2.InstanceSize.MEDIUM)
                # )
            )

        # enable data api of rds cluster
        self.cfn_db_cluster = self.db_cluster.node.default_child
        self.cfn_db_cluster.enable_http_endpoint = True

        read_only_user_secret_id_name = lg.get_label(
            resource_type="secret",
            resource_name="readonlyuser",
            include_namespace=True,
            include_stage=True,
            include_resource_type=True,
        )

        self.read_only_user_secret = secretsmanager.Secret(
            scope=self,
            id=read_only_user_secret_id_name,
            secret_name=read_only_user_secret_id_name,
            description="Read-only database user for Grafana access",
            generate_secret_string=secretsmanager.SecretStringGenerator(
                secret_string_template='{"username": "' + read_only_username + '"}',
                generate_string_key="password",
                password_length=30,
                exclude_punctuation=True,
            ),
        )

        rds_proxy_id_name = lg.get_label(
            resource_type="Proxy",
            resource_name=cluster_name,
            include_namespace=True,
            include_stage=True,
            include_resource_type=True,
        )

        self.db_proxy = rds.DatabaseProxy(
            scope=self,
            id=rds_proxy_id_name,
            proxy_target=rds.ProxyTarget.from_cluster(self.db_cluster),
            secrets=[self.read_only_user_secret],
            vpc=self.db_cluster.vpc,
            security_groups=[self.db_security_group],
        )

        self.db_proxy_endpoint = rds.CfnDBProxyEndpoint(
            scope=self,
            id="Proxy_Endpoint",
            db_proxy_endpoint_name=f"readonly-{rds_proxy_id_name}",
            db_proxy_name=self.db_proxy.db_proxy_name,
            vpc_subnet_ids=self.subnet_ids,
            target_role="READ_ONLY",
            vpc_security_group_ids=[self.db_security_group.security_group_id],
        )

        print("[INFO] RDS.Proxy.arn:", self.db_proxy.db_proxy_arn)
        print("[INFO] RDS.Proxy.name:", self.db_proxy.db_proxy_name)
        print("[INFO] RDS.Proxy.ep:", self.db_proxy.endpoint)

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

        suppressions = [
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-SMG4",
                    "reason": "The secret does not have automatic rotation scheduled",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-EC23",
                    "reason": "The Security Group allows for 0.0.0.0/0 or ::/0 inbound access",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-RDS2",
                    "reason": "The RDS instance or Aurora DB cluster does not have storage encryption enabled",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-RDS6",
                    "reason": "The RDS Aurora MySQL/PostgresSQL cluster does not have IAM Database Authentication enabled",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-RDS10",
                    "reason": "The RDS instance or Aurora DB cluster does not have deletion protection enabled",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-RDS11",
                    "reason": "The RDS instance or Aurora DB cluster uses the default endpoint port",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-RDS15",
                    "reason": "The RDS DB instance or Aurora DB cluster does not have deletion protection enabled",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-IAM4",
                    "reason": "The IAM user, role, or group uses AWS managed policies",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-IAM5",
                    "reason": "The IAM entity contains wildcard permissions",
                }
            ),
        ]

        NagSuppressions.add_stack_suppressions(self, suppressions)

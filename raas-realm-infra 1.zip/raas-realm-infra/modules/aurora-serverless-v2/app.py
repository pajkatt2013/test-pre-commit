import json
import os

import aws_cdk
from aws_cdk import App, CfnOutput
from stack import AuroraServerlessV2Stack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")


namespace = os.getenv(_param("NAMESPACE"), "")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")

# target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")
stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")

vpc_id = os.getenv(_param("VPC_ID"))
private_subnet_ids = json.loads(os.getenv(_param("PRIVATE_SUBNET_IDS")))
db_port = os.getenv(_param("DB_PORT"))
db_engine_version = os.getenv(_param("DB_ENGINE_VERSION"))

cluster_name = os.getenv(_param("CLUSTER_NAME"))
sg_name = os.getenv(_param("SG_NAME"))
database_name = os.getenv(_param("DATABASE_NAME"))
master_username = os.getenv(_param("MASTER_USERNAME"))
read_only_username = os.getenv(_param("READ_ONLY_USERNAME"))
dq_rds_storage_encrypted_str = os.getenv(_param("DQ_RDS_STORAGE_ENCRYPTED"), "False")
dq_rds_storage_encrypted = (
    True if str.lower(dq_rds_storage_encrypted_str) == "true" else False
)

app = App()

stack = AuroraServerlessV2Stack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    stage=stage,
    namespace=namespace,
    bu_name=bu_name,
    deployment_name=deployment_name,
    module_name=module_name,
    vpc_id=vpc_id,
    private_subnet_ids=private_subnet_ids,
    database_name=database_name,
    db_master_username=master_username,
    read_only_username=read_only_username,
    cluster_name=cluster_name,
    sg_name=sg_name,
    db_port=int(db_port),
    db_engine_version=int(db_engine_version),
    dq_rds_storage_encrypted=dq_rds_storage_encrypted,
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
    tags=tag_list,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "DBClusterId": stack.db_cluster.cluster_identifier,
            "DBClusterARN": stack.db_cluster.cluster_arn,
            "DBClusterName": stack.clustername,
            "DBClusterEndpoint": stack.db_cluster.cluster_endpoint,
            "DBInitName": stack.init_dbname,
            "DBClusterSecretArn": stack.db_cluster.secret.secret_arn,
            "DBReadOnlyUserSecretArn": stack.read_only_user_secret.secret_arn,
            "DBClusterVPCID": stack.db_cluster.vpc.vpc_id,
            "DBClusterSubnets": stack.subnet_ids,
            "DBPort": stack.db_port,
            "DBSecurityGroupId": stack.db_security_group.security_group_id,
            "DBProxyEndpoint": stack.db_proxy_endpoint.attr_endpoint,
        }
    ),
)

app.synth(force=True)

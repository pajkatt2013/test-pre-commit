# S3 Bucket Creator

## Description

This module creates an S3 bucket with an IAM role

## Inputs/Outputs

### Input Paramenters

#### Required

- `bucket-name`: name for the bucket (Default "addf-{deployment_name}-{account}-{hash}")
- `retention-type`: type of data retention policy when deleteing the buckets
  - `DESTROY` or `RETAIN` (Default `DESTROY`)
- `iam_role_name`: IAM role name, which will be accepted if existing or created by this module
- `new_role`- boolean variable, True when IAM role does not exist, False if IAM role already exists
- `bu_name`- business unit name (e.g, aptiv)
- `namespace`: Namespace used in config
- `full_name_inclue_deployment_prefix`: Flag boolean variale to enable/disable the inclusion of the name component "deployment name" as prefix.
- `full_name_include_bu`: Flag boolean variale to enable/disable the inclusion of the name component "bu_name".
- `full_name_include_ns`: Flag boolean variale to enable/disable the inclusion of the name component "namespace".
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.

#### Optional
- `retention-days`: a numeric value specifying the number of days after objects in the bucket expire and are permanently deleted


### Module Metadata Outputs

- `BucketName`: name of the bucket
- `BucketRoleName`: name of the bucket role
- `BucketRoleArn`: ARN of the bucket role

import json
import os

import aws_cdk
from aws_cdk import App, CfnOutput
from stack import BucketsStack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
hash = os.getenv("ADDF_HASH", "")

target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")
stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")

namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")

new_role_str = os.getenv(_param("NEW_ROLE"))
new_role = True if str.lower(new_role_str) == "true" else False
bucketsIamRoleName = os.getenv(_param("IAM_ROLE_NAME"), "")

full_name_inclue_deployment_prefix_str = os.getenv(
    _param("FULL_NAME_INCLUE_DEPLOYMENT_PREFIX"), "False"
)
full_name_inclue_deployment_prefix = (
    True if str.lower(full_name_inclue_deployment_prefix_str) == "true" else False
)

full_name_include_bu_str = os.getenv(_param("FULL_NAME_INCLUDE_BU"), "False")
full_name_include_bu = True if str.lower(full_name_include_bu_str) == "true" else False

full_name_include_ns_str = os.getenv(_param("FULL_NAME_INCLUDE_NS"), "False")
full_name_include_ns = True if str.lower(full_name_include_ns_str) == "true" else False


config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "target_realm_account_id": target_realm_account_id,
}

app = App()

bucket_name_param = os.getenv("ADDF_PARAMETER_BUCKET_NAME", None)
retention_type_param = os.getenv("ADDF_PARAMETER_RETENTION_TYPE", "DESTROY").upper()
retention_days = os.getenv("ADDF_PARAMETER_RETENTION_DAYS", "").upper()

stack = BucketsStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    namespace=namespace,
    stage=stage,
    bu_name=bu_name,
    config=config,
    hash=hash,
    bucket_name_param=bucket_name_param,
    new_role=new_role,
    iam_role_name=bucketsIamRoleName,
    retention_type_param=retention_type_param,
    retention_days=retention_days,
    full_name_inclue_deployment_prefix=full_name_inclue_deployment_prefix,
    full_name_include_bu=full_name_include_bu,
    full_name_include_ns=full_name_include_ns,
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
    tags=tag_list,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "BucketName": stack.bucket.bucket_name,
            "BucketRoleName": stack.s3_bucket_role.role_name,
            "BucketRoleArn": stack.s3_bucket_role.role_arn,
        }
    ),
)


app.synth(force=True)

import unittest
from unittest import mock

import botocore.errorfactory
import botocore.session
from helmparser.aws import ssm

_SSM_MODEL = botocore.session.get_session().get_service_model("ssm")
_SSM_FACTORY = botocore.errorfactory.ClientExceptionsFactory()
_SSM_EXCEPTIONS = _SSM_FACTORY.create_client_exceptions(_SSM_MODEL)


class TestAWSCode(unittest.TestCase):
    @mock.patch("boto3.client")
    def test_put_parameter(self, mock_boto3_client):
        response = {"Version": 1, "Tier": "Standard"}
        mock_ssm_client = mock.Mock()
        mock_ssm_client.put_parameter.return_value = response
        mock_boto3_client.return_value = mock_ssm_client
        ssm.put_parameter("test", "value")
        self.assertTrue(mock_boto3_client.called)

        mock_boto3_client.return_value.put_parameter.side_effect = (
            _SSM_EXCEPTIONS.InternalServerError(
                {"Error": {"Code": "InternalServerError"}}, ""
            )
        )

        with self.assertRaises(_SSM_EXCEPTIONS.InternalServerError):
            ssm.put_parameter("test", "value")

        mock_boto3_client.return_value.put_parameter.side_effect = (
            _SSM_EXCEPTIONS.InvalidKeyId({"Error": {"Code": "InvalidKeyId"}}, "")
        )

        with self.assertRaises(_SSM_EXCEPTIONS.InvalidKeyId):
            ssm.put_parameter("test", "value")

        mock_boto3_client.return_value.put_parameter.side_effect = (
            _SSM_EXCEPTIONS.ParameterLimitExceeded(
                {"Error": {"Code": "ParameterLimitExceeded"}}, ""
            )
        )

        with self.assertRaises(_SSM_EXCEPTIONS.ParameterLimitExceeded):
            ssm.put_parameter("test", "value")

        mock_boto3_client.return_value.put_parameter.side_effect = (
            _SSM_EXCEPTIONS.TooManyUpdates({"Error": {"Code": "TooManyUpdates"}}, "")
        )

        with self.assertRaises(_SSM_EXCEPTIONS.TooManyUpdates):
            ssm.put_parameter("test", "value")


if __name__ == "__main__":
    unittest.main()

    print("Everything passed")

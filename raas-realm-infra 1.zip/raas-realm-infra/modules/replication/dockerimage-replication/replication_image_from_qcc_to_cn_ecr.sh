#!/bin/bash

set -euo pipefail
set +x

create() {
    ARTII_JSON=$(aws secretsmanager get-secret-value --secret-id orionadp-artifactory-mirror-credentials-orion-tenant-default --region "$AWS_REGION" --output text --query SecretString)
    ARTIFACTORY_USERNAME=$(echo $ARTII_JSON | jq -r '.artifactory.username')
    ARTIFACTORY_TOKEN=$(echo $ARTII_JSON | jq -r '.artifactory.password')
    ARTIFACTORY_SSL_TOKEN=$(echo $ARTII_JSON | jq -r '.artifactory.ssl_token')
    QCC_ARTIFACTORY_URL_DOCKER=$(aws ssm get-parameter --name /orionadp/platform/artifactory/default/artifactory-url-docker --region "$AWS_REGION" --output text --query Parameter.Value)

    echo "ARTIFACTORY_USERNAME:${ARTIFACTORY_USERNAME}"
    echo "QCC_ARTIFACTORY_URL_DOCKER:${QCC_ARTIFACTORY_URL_DOCKER}"

    while IFS="" read -r image || [ -n "$image" ]
    do
    qcc_image_name=$(echo $image | awk -F ':' '{ print $1 }')
    qcc_image_tag=$(echo $image | awk -F ':' '{ print $2 }')
    image_name=$(echo $image | awk -F ':' '{ print $3 }')
    image_tag=$(echo $image | awk -F ':' '{ print $4 }')

    echo Checking ${image_name}:${image_tag}
    aws ecr describe-repositories --repository-names ${AWS_CODESEEDER_NAME}-${image_name} || aws ecr create-repository --repository-name ${AWS_CODESEEDER_NAME}-${image_name} --image-scanning-configuration scanOnPush=true
    aws ecr describe-images --repository-name=${AWS_CODESEEDER_NAME}-${image_name} --image-ids=imageTag=${image_tag} && echo Skip pulling. image exist && continue

    echo Pulling the ${image_name}:${image_tag} from QCC ${qcc_image_name}:${qcc_image_tag}
    docker login -u ${ARTIFACTORY_USERNAME} -p ${ARTIFACTORY_TOKEN} ${QCC_ARTIFACTORY_URL_DOCKER}
    docker pull ${qcc_image_name}:${qcc_image_tag}

    # Setting connection with AWS ECR
    echo Pushing local image ${qcc_image_name}:${qcc_image_tag} to $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com.cn/${AWS_CODESEEDER_NAME}-${image_name}:${image_tag}
    aws ecr get-login-password --region $AWS_DEFAULT_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com.cn
    # Tagging and pushing Docker images according to https://docs.aws.amazon.com/AmazonECR/latest/userguide/docker-pull-ecr-image.html
    docker tag ${qcc_image_name}:${qcc_image_tag} $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com.cn/${AWS_CODESEEDER_NAME}-${image_name}:${image_tag}
    docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com.cn/${AWS_CODESEEDER_NAME}-${image_name}:${image_tag}
    # Deleting so it wouldn't cause issues with codebuild storage space for huge images

    echo Deleting local image ${qcc_image_name}:${qcc_image_tag}
    docker rmi ${qcc_image_name}:${qcc_image_tag}
    done < images.txt
}

destroy() {
    echo "Sorry... not working"
}

$1

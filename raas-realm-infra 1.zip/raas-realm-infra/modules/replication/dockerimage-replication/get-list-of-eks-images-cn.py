"""Main application"""
import json
import os
from copy import deepcopy

import helmparser.helm.commands as helm
from deepmerge import always_merger
from helmparser.arguments import args
from helmparser.logging import logger
from helmparser.parser import parser

project_path = os.path.realpath(os.path.dirname(__file__))

docker_repo_qcc_dict = {
    "registry.k8s.io": "qartifactory-eu.qualcomm.com/qcc-platform-docker-remote-registry-k8s-io",
    "docker.io": "qartifactory-eu.qualcomm.com/qcc-platform-docker-remote-hub-docker-com",
    "cr.fluentbit.io": "qartifactory-eu.qualcomm.com/qcc-platform-docker-remote-cr-fluentbit-io",
    "ghcr.io": "qartifactory-eu.qualcomm.com/qcc-platform-docker-remote-ghcr-io",
    "public.ecr.aws": "qartifactory-eu.qualcomm.com/qcc-platform-docker-remote-public-ecr-aws",
    "quay.io": "qartifactory-eu.qualcomm.com/qcc-platform-docker-remote-quay-io",
    "nvcr.io": "qartifactory-eu.qualcomm.com/qcc-platform-docker-remote-nvcr.io",
}

helm_repo_qcc_dict = {
    "https://ibm.github.io/core-dump-handler": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-ibm-gh-io-core-dump-handler",
    "https://aws.github.io/eks-charts": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-aws-github-io-eks-charts/",
    "https://docs.projectcalico.org/charts": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-docs-prjcalico-org-charts",
    "https://charts.external-secrets.io/": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-charts-external-secrets-io",
    "https://grafana.github.io/helm-charts": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-grafana-gh-io-helm-charts",
    "https://charts.jetstack.io": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-charts-jetstack-io",
    "https://kubernetes.github.io/autoscaler": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-k8s-github-io-autoscaler",
    "https://kubernetes-sigs.github.io/aws-ebs-csi-driver": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-k8s-sigs-gh-io-ebs-csi-drv",
    "https://kubernetes-sigs.github.io/aws-efs-csi-driver": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-k8s-sigs-gh-io-efs-csi-drv",
    "https://kubernetes-sigs.github.io/external-dns": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-k8s-sigs-github-io-ext-dns",
    "https://fluent.github.io/helm-charts": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-fluent-github-io-helm-charts",
    "https://kubereboot.github.io/charts": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-kubereboot-github-io-charts",
    "https://kyverno.github.io/kyverno": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-kyverno-gh-io-kyverno",
    "https://kyverno.github.io/policy-reporter": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-kyverno-gh-io-policy-rep",
    "https://kubernetes-sigs.github.io/metrics-server": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-k8s-sigs-gh-io-metrics-srv",
    "https://kubernetes.github.io/ingress-nginx": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-k8s-github-io-ingress-nginx",
    "https://kubernetes-sigs.github.io/secrets-store-csi-driver/charts": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-k8s-sigs-gh-io-ss-csi-drv",
    "https://argoproj.github.io/argo-helm": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-argoproj-gh-io-argo-helm",
    "https://awslabs.github.io/mountpoint-s3-csi-driver": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-awslabs-gh-io-mp-s3-csi-drv",
    "https://prometheus-community.github.io/helm-charts": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-pheus-comm-gh-io-helm-charts",
    "https://nvidia.github.io/k8s-device-plugin": "https://qartifactory-eu.qualcomm.com/artifactory/qcc-platform-helm-remote-nvidia-k8s-device-plugin",
}


def get_qcc_image_link(image_link: str) -> str:
    """Get Qcc image link

    Args:
        image_link (str): image link

    Returns:
        str: qcc image link
    """
    if "/" not in image_link:
        return docker_repo_qcc_dict["docker.io"] + "/" + image_link

    image_repo_host = image_link.split("/")[0]

    if "." not in image_repo_host:
        return docker_repo_qcc_dict["docker.io"] + "/" + image_link

    replace_repo_host = docker_repo_qcc_dict[image_repo_host]
    replace_image_link = image_link.replace(image_repo_host, replace_repo_host)
    return replace_image_link


def get_qcc_helm_repo(repo_name: str) -> str:
    """Get Qcc helm repo

    Args:
        repo_name (str): helm chart repo name

    Returns:
        str: qcc helm chart repo name
    """
    format_repo_name = repo_name
    if format_repo_name[-1] == "/":
        format_repo_name = format_repo_name[:-1]
    return helm_repo_qcc_dict[format_repo_name]


def deep_merge(*dicts: dict) -> dict:
    """Merges two dictionaries

    Returns:
        dict: Merged dictionary
    """
    merged = {}
    for d in dicts:
        tmp = deepcopy(d)
        merged = always_merger.merge(merged, tmp)
    return merged


def main() -> None:
    """Main handler"""
    logger.info("EKS version: %s", args.eks_version)

    logger.info(
        "EKS node AMI image version: %s",
        parser.get_ami_version(args.versions_dir, args.eks_version),
    )

    images = []
    helmCharts = []

    additional_images = parser.get_additional_images(
        args.versions_dir, args.eks_version
    )

    for _, image in additional_images.items():
        images.append(image)

    updated_additional_images = {}
    for name, image in additional_images.items():
        updated_additional_images[name] = f"{args.registry_prefix}{image}"

    additional_images_json = {"additional_images": updated_additional_images}

    workloads_data = parser.get_workloads(args.versions_dir, args.eks_version)

    if args.update_helm:
        for workload, values in workloads_data.items():
            logger.info("Syncing %s", workload)
            helm.add_repo_with_user_and_password(
                workload,
                get_qcc_helm_repo(values["repository"]),
                args.qcc_helm_username,
                args.qcc_helm_password,
            )
        helm.update_repos()

    custom_chart_values = {}

    parsed_charts = {}
    for workload, values in workloads_data.items():
        parsed_charts[workload] = {}
        if "images" not in values:
            continue

        logger.debug("Getting %s data", workload)
        parsed_charts[workload]["chart"] = helm.show(
            "chart", f"{workload}/{values['name']}", values["version"]
        )

        parsed_charts[workload]["values"] = helm.show(
            "values", f"{workload}/{values['name']}", values["version"]
        )

        if "subcharts" in values:
            parsed_charts[workload]["subcharts"] = {}
            for subchart in values["subcharts"]:
                parsed_charts[workload]["subcharts"][subchart] = {}
                parsed_charts[workload]["subcharts"][subchart] = helm.show_subchart(
                    project_path, workload, values["name"], subchart, values["version"]
                )

    for workload, values in workloads_data.items():
        chart_name = values["name"]
        chart_version = values["version"]
        qcc_chart_repo = get_qcc_helm_repo(values["repository"])
        helmCharts.append(
            f"{args.registry_prefix}chart/{chart_name} {chart_version} {qcc_chart_repo} {chart_name}"
        )
        custom_chart_values[workload] = {
            "helm": {
                "name": values["name"],
                "repository": f"{args.registry_prefix}chart/{chart_name}",
                "version": values["version"],
                "local": "true",
            },
            "values": {},
        }

        logger.debug("Chart %s:", workload)

        if "images" in values:
            logger.debug("\tImages:")

            for image_name, image_data in values["images"].items():
                registry = None
                repository = None
                tag = None

                # parse registries first
                for k, v in image_data.items():
                    if k == "registry":
                        registry = parser.parse_value(
                            parsed_charts[workload], values, image_name, v, k
                        )

                        if registry:
                            custom_chart_values[workload][
                                "values"
                            ] = parser.add_branch_to_dict(
                                custom_chart_values[workload]["values"],
                                v,
                                f"{args.registry_prefix}{registry}",
                            )

                        continue

                # parse repositories and tags
                for k, v in image_data.items():
                    if k == "repository":
                        if "name" in v:
                            repository = v["name"]
                            continue

                        repository = parser.parse_value(
                            parsed_charts[workload], values, image_name, v, k
                        )

                        repository_in_chart_values = repository
                        if not registry:
                            repository_in_chart_values = (
                                f"{args.registry_prefix}{repository}"
                            )

                        custom_chart_values[workload][
                            "values"
                        ] = parser.add_branch_to_dict(
                            custom_chart_values[workload]["values"],
                            v,
                            repository_in_chart_values,
                        )

                        continue

                    if k == "tag":
                        tag = parser.parse_value(
                            parsed_charts[workload], values, image_name, v, k
                        )

                        custom_chart_values[workload][
                            "values"
                        ] = parser.add_branch_to_dict(
                            custom_chart_values[workload]["values"], v, tag
                        )

                        continue

                # remove some values
                for k, v in image_data.items():
                    # set value to empty, e.g. digest as it will be different after push to ECR
                    if k == "remove":
                        custom_chart_values[workload][
                            "values"
                        ] = parser.add_branch_to_dict(
                            custom_chart_values[workload]["values"], v, ""
                        )
                        continue

                image = repository
                if registry:
                    image = f"{registry}/{repository}"
                if tag:
                    image += f":{tag}"

                logger.debug("\t\t%s", image)
                images.append(image)

        logger.debug("\tCustom chart values:")
        logger.debug("\t\t%s", json.dumps(custom_chart_values[workload]))

    sorted_images = sorted(set(images))
    for i in range(0, len(sorted_images)):
        sorted_images[i] = get_qcc_image_link(sorted_images[i]) + ":" + sorted_images[i]

    ami_json = {
        "ami": {"version": parser.get_ami_version(args.versions_dir, args.eks_version)}
    }
    charts_json = {"charts": custom_chart_values}

    with open(
        os.path.join(project_path, "replication-result.json"),
        "w",
        encoding="utf-8",
    ) as file:
        file.write(
            json.dumps(deep_merge(ami_json, charts_json, additional_images_json))
        )

    with open(
        os.path.join(project_path, "images.txt"),
        "w",
        encoding="utf-8",
    ) as file:
        file.write("\n".join(sorted_images))

    with open(
        os.path.join(project_path, "helmCharts.txt"),
        "w",
        encoding="utf-8",
    ) as file:
        file.write("\n".join(helmCharts))


if __name__ == "__main__":
    main()

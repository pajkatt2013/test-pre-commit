#!/bin/bash

set -euo pipefail
set +x

create() {
    ARTII_JSON=$(aws secretsmanager get-secret-value --secret-id orionadp-artifactory-mirror-credentials-orion-tenant-default --region "$AWS_REGION" --output text --query SecretString)
    ARTIFACTORY_USERNAME=$(echo $ARTII_JSON | jq -r '.artifactory.username')
    ARTIFACTORY_TOKEN=$(echo $ARTII_JSON | jq -r '.artifactory.password')
    ARTIFACTORY_SSL_TOKEN=$(echo $ARTII_JSON | jq -r '.artifactory.ssl_token')

    echo "ARTIFACTORY_USERNAME:${ARTIFACTORY_USERNAME}"

    while IFS="" read -r helmchart || [ -n "$helmchart" ]
    do
    addf_chart_repo=$(echo $helmchart | awk -F ' ' '{ print $1 }')
    chart_version=$(echo $helmchart | awk -F ' ' '{ print $2 }')
    qcc_chart_repo=$(echo $helmchart | awk -F ' ' '{ print $3 }')
    chart_name=$(echo $helmchart | awk -F ' ' '{ print $4 }')

    echo Checking helm in ECR
    aws ecr describe-repositories --repository-names ${AWS_CODESEEDER_NAME}-chart/${chart_name} || aws ecr create-repository --repository-name ${AWS_CODESEEDER_NAME}-chart/${chart_name} --image-scanning-configuration scanOnPush=true
    aws ecr describe-images --repository-name=${AWS_CODESEEDER_NAME}-chart/${chart_name} --image-ids=imageTag=${chart_version} && echo Skip pulling. helm chart exist && continue

    echo Adding helm repo ${chart_name} ${qcc_chart_repo}
    helm repo add ${chart_name} ${qcc_chart_repo} --username ${ARTIFACTORY_USERNAME} --password ${ARTIFACTORY_TOKEN}

    echo Pulling ${chart_name} ${chart_version} from ${qcc_chart_repo}
    helm pull $chart_name/$chart_name --version $chart_version
    if [ -f ${chart_name}-v${chart_version}.tgz ]
    then
    	mv ${chart_name}-v${chart_version}.tgz ${chart_name}-${chart_version}.tgz
    fi
    chart_version_without_v=$(echo $chart_version | tr -d 'v')
    if [ -f ${chart_name}-${chart_version_without_v}.tgz  ] && [ ${chart_version_without_v} != ${chart_version} ]
    then
    	mv ${chart_name}-${chart_version_without_v}.tgz ${chart_name}-${chart_version}.tgz
    fi

    echo Pushing local ${chart_name}-${chart_version}.tgz to ECR $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com.cn/${AWS_CODESEEDER_NAME}-chart/${chart_name}:${chart_version}
    aws ecr get-login-password --region $AWS_DEFAULT_REGION | helm registry login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com.cn
    helm push ${chart_name}-${chart_version}.tgz oci://$AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com.cn/${AWS_CODESEEDER_NAME}-chart/

    echo Deleting local ${chart_name}-${chart_version}.tgz
    rm ${chart_name}-${chart_version}.tgz

    done < helmCharts.txt
}

destroy() {
    echo "Sorry... not working"
}

$1

# ECR for RPU (ecr4rpus) Module

## Description

This module creates elastic container registry with particular IAM role for the specific user, who should be able to assume the IAM role.

## Inputs/Outputs

### Input Paramenters

#### Required
- `stage`: Target stage of deployment
- `namespace`: Target namespace of deployment
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.
- `vpc-id`: VPC Id where the Aurora cluster will be deployed
- `private-subnet-ids`: List of Private Subnets Ids where the Aurora cluster will be deployed
- `cluster-name`: Main name of the RDS database cluster
- `database-name`: Name of the initial database of the Aurora cluster.
- `rds-cluster-id`: RDS cluster id.
- `rds-proxy-ep`: RDS database proxy endpoint.
- `db-secret-arn`: ARN of the secret entry for master db user.
- `read_only_db_user_secret_arn`: ARN of the secret entry for the read-only user.
- `vpc_epsvc_trust_accountid`: Trust account id for the endpoint service accesses.
- `service_db_user_username`: Username for the service user with IAM authentication (has ALL PRIVILIGES ON DATABASE $database-name)

#### Optional

- `db_port`: RDS database port. Default: 5432
- `bu_name`: business unit name of the resources.

#### Input example
```yaml
  - name: bu_name
    valueFrom:
      envVariable: BU_NAME

  - name: stage
    valueFrom:
      envVariable: STAGE

  - name: namespace
    valueFrom:
      envVariable: NAMESPACE

  - name: cost-allocation-tag
    value:
      - key: customer_function
        value: common
      - key: maintainer
        value: raas_devops

  - name: vpc-id
    valueFrom:
      moduleMetadata:
        group: rds-cluster
        name: aurorapg
        key: DBClusterVPCID

  - name: private-subnet-ids
    valueFrom:
      moduleMetadata:
        group: rds-cluster
        name: aurorapg
        key: DBClusterSubnets

  - name: cluster-name
    valueFrom:
      moduleMetadata:
        group: rds-cluster
        name: aurorapg
        key: DBClusterName

  - name: database-name
    valueFrom:
      moduleMetadata:
        group: rds-cluster
        name: aurorapg
        key: DBInitName

  - name: rds-cluster-id
    valueFrom:
      moduleMetadata:
        group: rds-cluster
        name: aurorapg
        key: DBClusterId

  - name: rds-proxy-ep
    valueFrom:
      moduleMetadata:
        group: rds-cluster
        name: aurorapg
        key: DBProxyEndpoint

  - name: db-secret-arn
    valueFrom:
      moduleMetadata:
        group: rds-cluster
        name: aurorapg
        key: DBClusterSecretArn

  - name: read_only_db_user_secret_arn
    valueFrom:
      moduleMetadata:
        group: rds-cluster
        name: aurorapg
        key: DBReadOnlyUserSecretArn

  - name: db_port
    valueFrom:
      moduleMetadata:
        group: rds-cluster
        name: aurorapg
        key: DBPort

  - name: vpc_epsvc_trust_accountid
    value: 747552271162

  - name: service_db_user_username
    value: data_quality_service_db_user
```


### Module Metadata Outputs
- `VpcEndpointServiceName`: VPC endpoint service name for the RDS database cluster connection.
- `ReadOnlyUserSecret`: ARN of the secret entry for the read-only user.
- `EPSvcRoleARN`: ARN of the IAM role for the access to the endpoint service.
- `ServiceDbUserUsername`: Username of the database service user.
#### Output Example

```json
{
    "VpcEndpointServiceName": stack.vpcEPService.vpc_endpoint_service_name,
    "ReadOnlyUserSecret": read_only_db_user_secret_arn,
    "EPSvcRoleARN": stack.endpoint_service_role.role_arn,
    "ServiceDbUserUsername": service_db_user_username
}

```

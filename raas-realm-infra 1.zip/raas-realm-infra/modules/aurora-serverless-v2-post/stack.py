import json
import socket
from typing import cast

import boto3
import cdk_nag
import psycopg2 as pg
from aws_cdk import Aspects, Aws, Stack, Tags
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_elasticloadbalancingv2 as elbv2
from aws_cdk import aws_elasticloadbalancingv2_targets as elbv2_tgt
from aws_cdk import aws_iam as iam
from botocore.exceptions import ClientError
from cdk_nag import NagPackSuppression, NagSuppressions
from constructs import Construct, IConstruct
from utils import LabelGenerator


class AuroraServerlessV2PostStack(Stack):
    def __init__(
        self,
        scope: Construct,
        region_name: str,
        stage: str,
        deployment_name: str,
        module_name: str,
        namespace: str,
        bu_name: str,
        id: str,
        *,
        # Secret & Users Params
        DB_Cluster_Endpoint: str,
        DB_Engine: str,
        db_secret_arn: str,
        read_only_db_user_secret_arn: str,
        service_db_user_username: str,
        rds_dq_maintainer_schema_list: str,
        secret_name_viewer: str,
        secret_username_viewer: str,
        secret_name_maintainer: str,
        secret_username_maintainer: str,
        rds_cluster_id: str,
        cluster_name: str,
        init_dbname: str,
        vpc_id: str,
        private_subnet_ids: list,
        rds_proxy_ep: str,
        vpc_epsvc_trust_accountids: list,
        tags: list,
        db_port: int = 5432,
        **kwargs,
    ) -> None:
        super().__init__(scope, id, **kwargs)

        # ADDF Env vars
        self.deployment_name = deployment_name
        self.module_name = module_name

        # CDK Env Vars
        region: str = kwargs["env"].region
        account: str = kwargs["env"].account
        partition: str = Aws.PARTITION

        def get_rds_proxy_info(proxy_ep: str):
            try:
                hostinfos = socket.gethostbyname_ex(proxy_ep)
                return hostinfos
            except socket.error as e:
                print(f"Error: {e}")
                return None

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", self.deployment_name)
        add_tag("Module", self.module_name)
        for kv in tags:
            add_tag(kv["key"], kv["value"])

        self.db_port = db_port
        self.clustername = cluster_name
        self.init_dbname = init_dbname
        self.subnet_ids = private_subnet_ids

        lg = LabelGenerator(
            prefix=deployment_name,
            namespace=namespace,
            stage=stage,
            bu_name=bu_name,
            aws_env=kwargs["env"],
        )

        # ------------------------------------------------------------------------------
        # DB User & Secret - Start
        # ------------------------------------------------------------------------------

        def user_exists(cursor, username):
            query = f"SELECT 1 FROM pg_roles WHERE rolname = '{username}'"
            cursor.execute(query)
            return cursor.fetchone() is not None

        # ------------------------------------------------------------------------------
        def create_user(cursor, username, dbname, password=None):
            if password is None:
                query = f"CREATE USER {username};"
                print(f'[DEBUG]EXECUTING QUERY:   "CREATE USER {username}')
                cursor.execute(query)
                print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")
            else:
                query = f"CREATE USER {username} WITH ENCRYPTED PASSWORD '{password}';"
                print(
                    f'[DEBUG]EXECUTING QUERY:   "CREATE USER {username} WITH ENCRYPTED PASSWORD *********;"'
                )
                cursor.execute(query)
                print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")

            query = f'GRANT CONNECT ON DATABASE "{dbname}" TO {username};'
            print(f"[DEBUG]EXECUTING QUERY:   {query}")
            cursor.execute(query)
            print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")

        # ------------------------------------------------------------------------------

        def create_role(cursor, role_name):
            query = f"CREATE ROLE {role_name};"
            print(f"[DEBUG]EXECUTING QUERY:   {query}")
            cursor.execute(query)
            print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")

        # ------------------------------------------------------------------------------

        def grant_role_to_user(cursor, username, role_name):
            query = f"GRANT {role_name} TO {username};"
            print(f"[DEBUG]EXECUTING QUERY:   {query}")
            cursor.execute(query)
            print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")

        # ------------------------------------------------------------------------------
        def create_read_only_db_user(
            host: str,
            port: str,
            dbname: str,
            dbuser: str,
            password: str,
            read_only_username: str,
            read_only_userpwd: str,
        ):
            try:
                # Connect to the PostgreSQL database
                pg_conn = pg.connect(
                    database=dbname,
                    user=dbuser,
                    password=password,
                    host=host,
                    port=port,
                    sslmode="require",
                )

                with pg_conn.cursor() as cursor:
                    # Create read-only user
                    if not user_exists(cursor, read_only_username):
                        print(f"[INFO] Creating user {read_only_username} ...")
                        create_user(
                            cursor=cursor,
                            username=read_only_username,
                            dbname=dbname,
                            password=read_only_userpwd,
                        )
                        print(f"[INFO] User {read_only_username} has been created.")
                    else:
                        print(
                            f"[INFO] User: {read_only_username} already exists. Updating password.."
                        )
                        query = f"ALTER USER {read_only_username} WITH ENCRYPTED PASSWORD '{read_only_userpwd}';"
                        cursor.execute(query)

                    # Create real-only role
                    if not user_exists(cursor, "read_only_role"):
                        print("[INFO] Creating read-only role ...")
                        create_role(cursor, "read_only_role")
                        print("[INFO] Role: read_only_role has been created.")
                    else:
                        print("[INFO] Role: read_only_role already exists.")

                    # Grant read-all permissions to the read-only role
                    print("[INFO] Granting read-all permissions to the read-only role.")
                    query = "GRANT pg_read_all_data TO read_only_role;"
                    print(f"[DEBUG]EXECUTING QUERY:   {query}")
                    cursor.execute(query)
                    print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")

                    # Grant read-only role to user
                    print(
                        f"[INFO] Granting read_only_role to the user: {read_only_username}."
                    )
                    grant_role_to_user(cursor, read_only_username, "read_only_role")
                pg_conn.commit()

            except Exception as e:
                print(f"Error: {e}")

            finally:
                # Close the connection
                if pg_conn:
                    pg_conn.close()

        # ------------------------------------------------------------------------------

        def create_service_db_user(
            host: str,
            port: str,
            dbname: str,
            dbuser: str,
            password: str,
            service_db_user_username: str,
        ):
            try:
                # Connect to the PostgreSQL database
                pg_conn = pg.connect(
                    database=dbname,
                    user=dbuser,
                    password=password,
                    host=host,
                    port=port,
                    sslmode="require",
                )

                with pg_conn.cursor() as cursor:
                    # Create read-only user
                    if not user_exists(cursor, service_db_user_username):
                        print(f"[INFO] Creating user {service_db_user_username} ...")
                        create_user(cursor, service_db_user_username, dbname)
                        print(
                            f"[INFO] User {service_db_user_username} has been created."
                        )
                    else:
                        print(f"[INFO] User {service_db_user_username} already exists.")

                    # Grant rds-iam role to enable authentication via IAM
                    print(
                        f"[INFO] Granting rds_iam role to the user: {service_db_user_username}."
                    )
                    grant_role_to_user(cursor, service_db_user_username, "rds_iam")

                    # GRANT ALL PRIVILEGES ON DATABASE directly to the service user
                    print(
                        "[INFO] Granting all privileges directly to the service user."
                    )
                    query = f"GRANT ALL PRIVILEGES ON DATABASE {dbname} to {service_db_user_username};"
                    print(f"[DEBUG]EXECUTING QUERY:   {query}")
                    cursor.execute(query)
                    print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")

                pg_conn.commit()

            except Exception as e:
                print(f"Error: {e}")

            finally:
                # Close the connection
                if pg_conn:
                    pg_conn.close()

        # ------------------------------------------------------------------------------
        def create_dq_viewer_db_user(
            host: str,
            port: str,
            dbname: str,
            dbuser: str,
            password: str,
            dq_viewer_username: str,
            dq_viewer_userpwd: str,
        ):
            try:
                # Connect to the PostgreSQL database
                pg_conn = pg.connect(
                    database=dbname,
                    user=dbuser,
                    password=password,
                    host=host,
                    port=port,
                    sslmode="require",
                )

                with pg_conn.cursor() as cursor:
                    # Create or replace dq viewer user
                    if not user_exists(cursor, dq_viewer_username):
                        print(f"[INFO] Creating user {dq_viewer_username} ...")
                        create_user(
                            cursor=cursor,
                            username=dq_viewer_username,
                            dbname=dbname,
                            password=dq_viewer_userpwd,
                        )
                        print(f"[INFO] User {dq_viewer_username} has been created.")
                    else:
                        print(
                            f"[INFO] User: {dq_viewer_username} already exists. Updating password.."
                        )
                        query = f"ALTER USER {dq_viewer_username} WITH ENCRYPTED PASSWORD '{dq_viewer_userpwd}';"
                        cursor.execute(query)

                    # Create read-only role
                    if not user_exists(cursor, "read_only_role"):
                        print("[INFO] Creating read-only role ...")
                        create_role(cursor, "read_only_role")
                        print("[INFO] Role: read_only_role has been created.")
                    else:
                        print("[INFO] Role: read_only_role already exists.")

                    # Grant read-all permissions to the read-only role
                    print("[INFO] Granting read-all permissions to the read-only role.")
                    query = "GRANT pg_read_all_data TO read_only_role;"
                    print(f"[DEBUG]EXECUTING QUERY:   {query}")
                    cursor.execute(query)
                    print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")

                    # Grant read-only role to user
                    print(
                        f"[INFO] Granting read_only_role to the user: {dq_viewer_username}."
                    )
                    grant_role_to_user(cursor, dq_viewer_username, "read_only_role")
                pg_conn.commit()

            except Exception as e:
                print(f"Error: {e}")

            finally:
                # Close the connection
                if pg_conn:
                    pg_conn.close()

        # ------------------------------------------------------------------------------
        def create_dq_maintainer_db_user(
            host: str,
            port: str,
            dbname: str,
            dbuser: str,
            password: str,
            write_db_user_username: str,
            write_db_user_userpwd: str,
            writable_schemas: list,
        ):
            try:
                # Connect to the PostgreSQL database
                pg_conn = pg.connect(
                    database=dbname,
                    user=dbuser,
                    password=password,
                    host=host,
                    port=port,
                    sslmode="require",
                )
                role_name = write_db_user_username + "_role"
                with pg_conn.cursor() as cursor:
                    # create dq maintainer user
                    if not user_exists(cursor, write_db_user_username):
                        print(f"[INFO] Creating user {write_db_user_username} ...")
                        create_user(
                            cursor=cursor,
                            username=write_db_user_username,
                            dbname=dbname,
                            password=write_db_user_userpwd,
                        )
                        print(f"[INFO] User {write_db_user_username} has been created.")
                    else:
                        print(
                            f"[INFO] User: {write_db_user_username} already exists. Updating password.."
                        )
                        query = f"ALTER USER {write_db_user_username} WITH ENCRYPTED PASSWORD '{write_db_user_userpwd}';"
                        cursor.execute(query)

                    # Create write role for provided schemas
                    if not user_exists(cursor, role_name):
                        print(
                            f"[INFO] Creating write role for {write_db_user_username} ..."
                        )
                        create_role(cursor, role_name)
                        print(f"[INFO] Role: {role_name} has been created.")
                    else:
                        print(f"[INFO] Role: {role_name} already exists.")

                    # Grant read-write permissions for schemas the role
                    print("[INFO] Granting read-write permissions to the role.")

                    # Grant read_all permission
                    query = f"GRANT pg_read_all_data TO {role_name};"
                    print(f"[DEBUG]EXECUTING QUERY:   {query}")
                    cursor.execute(query)
                    print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")

                    # Grant write_all permission
                    query = f"GRANT pg_write_all_data TO {role_name};"
                    print(f"[DEBUG]EXECUTING QUERY:   {query}")
                    cursor.execute(query)
                    print(f"[DEBUG]DATABASE RESPONSE:   {cursor.statusmessage}")

                    # Grant read-only role to user
                    print(
                        f"[INFO] Granting read_only_role to the user: {write_db_user_username}."
                    )
                    grant_role_to_user(cursor, write_db_user_username, role_name)
                pg_conn.commit()

            except Exception as e:
                print(f"Error: {e}")

            finally:
                # Close the connection
                if pg_conn:
                    pg_conn.close()

        # ------------------------------------------------------------------------------
        def get_secret(secret_id: str, region_name: str):
            # Create a Secrets Manager client
            session = boto3.session.Session()
            client = session.client(
                service_name="secretsmanager", region_name=region_name
            )
            try:
                get_secret_value_response = client.get_secret_value(SecretId=secret_id)
            except ClientError as e:
                raise e
            secret = get_secret_value_response["SecretString"]
            return secret

        def generate_secret(secret_name, secret_username, description):
            # Initialize a session using Amazon Secrets Manager
            client = boto3.client("secretsmanager")
            description = (
                description
                + f" This secret is deployed as part of {self.deployment_name} deployment and {self.module_name} module"
            )
            secret_id_name = lg.get_label(
                resource_type="secret",
                resource_name=secret_name,
                include_namespace=True,
                # include_stage=True,
                include_resource_type=True,
            )
            print("[INFO] Generating rds postgres secret: ", secret_id_name)

            # Get the tag list
            secret_tags = [{"Key": tag["key"], "Value": tag["value"]} for tag in tags]
            secret_tags.append({"Key": "Deployment", "Value": self.deployment_name})
            secret_tags.append({"Key": "Module", "Value": self.module_name})

            # Prepare secret values and password
            responsePWD = client.get_random_password(
                PasswordLength=30, ExcludePunctuation=True
            )
            db_endpoint = json.loads(DB_Cluster_Endpoint)
            db_secret_json = {
                "username": secret_username,
                "dbClusterIdentifier": rds_cluster_id,
                "dbname": self.init_dbname,
                "engine": DB_Engine,
                "host": db_endpoint["hostname"],
                "port": db_endpoint["port"],
                "password": responsePWD["RandomPassword"],
            }
            db_secret_values = json.dumps(db_secret_json)

            try:
                # Create the secret
                response = client.create_secret(
                    Name=secret_id_name,
                    Description=description,
                    SecretString=db_secret_values,
                    Tags=secret_tags,
                )
                print("[INFO] Created rds postgres secret: ", secret_id_name)
                # Return the ARN of the secret
                return response["ARN"]
            except client.exceptions.ResourceExistsException:
                # If the secret already exists, you might want to update it
                response = client.update_secret(
                    SecretId=secret_id_name,
                    Description=description,
                    SecretString=db_secret_values,
                )
                # tag resource, because tag cannot be update with update_secret method
                client.tag_resource(SecretId=secret_id_name, Tags=secret_tags)
                print("[INFO] Updated rds postgres secret: ", secret_id_name)
                return response["ARN"]
            except Exception as e:
                print(f"An error occurred: {e}")
                return None

        # ------------------------------------------------------------------------------
        #
        # ------------------------------------------------------------------------------

        master_secret_value = get_secret(
            secret_id=db_secret_arn, region_name=region_name
        )
        master_secret_dict = json.loads(master_secret_value)
        dbusername = master_secret_dict["username"]
        dbpassword = master_secret_dict["password"]
        dbhost = master_secret_dict["host"]
        read_only_user_secret_value = get_secret(
            secret_id=read_only_db_user_secret_arn, region_name=region_name
        )
        read_only_user_secret_dict = json.loads(read_only_user_secret_value)
        ro_username = read_only_user_secret_dict["username"]
        ro_password = read_only_user_secret_dict["password"]

        create_read_only_db_user(
            host=dbhost,
            port=db_port,
            dbname=self.init_dbname,
            dbuser=dbusername,
            password=dbpassword,
            read_only_username=ro_username,
            read_only_userpwd=ro_password,
        )

        create_service_db_user(
            host=dbhost,
            port=db_port,
            dbname=self.init_dbname,
            dbuser=dbusername,
            password=dbpassword,
            service_db_user_username=service_db_user_username,
        )

        # generate viewer secret
        user_viewer_secret_arn = generate_secret(
            secret_name=secret_name_viewer,
            secret_username=secret_username_viewer,
            description="DQ viewer database user with read permissions",
        )
        self.user_viewer_secret_arn = user_viewer_secret_arn
        print("[Info] user_viewer_secret:", user_viewer_secret_arn)
        rds_dq_viewer_secret_value = get_secret(
            secret_id=user_viewer_secret_arn, region_name=region_name
        )
        # database user dq-viewer
        rds_dq_viewer_secret_dict = json.loads(rds_dq_viewer_secret_value)
        rds_dq_viewer_username = rds_dq_viewer_secret_dict["username"]
        rds_dq_viewer_password = rds_dq_viewer_secret_dict["password"]
        create_dq_viewer_db_user(
            host=dbhost,
            port=db_port,
            dbname=self.init_dbname,
            dbuser=dbusername,
            password=dbpassword,
            dq_viewer_username=rds_dq_viewer_username,
            dq_viewer_userpwd=rds_dq_viewer_password,
        )

        # generate databse maintainer secret
        user_maintainer_secret_arn = generate_secret(
            secret_name=secret_name_maintainer,
            secret_username=secret_username_maintainer,
            description="DQ maintainer database user with read & write permissions",
        )
        self.user_maintainer_secret_arn = user_maintainer_secret_arn
        rds_dq_maintainer_secret_value = get_secret(
            secret_id=user_maintainer_secret_arn, region_name=region_name
        )
        # database user dq-maintainer
        rds_dq_maintainer_secret_dict = json.loads(rds_dq_maintainer_secret_value)
        rds_dq_maintainer_username = rds_dq_maintainer_secret_dict["username"]
        rds_dq_maintainer_password = rds_dq_maintainer_secret_dict["password"]

        create_dq_maintainer_db_user(
            host=dbhost,
            port=db_port,
            dbname=self.init_dbname,
            dbuser=dbusername,
            password=dbpassword,
            write_db_user_username=rds_dq_maintainer_username,
            write_db_user_userpwd=rds_dq_maintainer_password,
            writable_schemas=rds_dq_maintainer_schema_list,
        )

        # ------------------------------------------------------------------------------
        # DB User & Secret - End
        # ------------------------------------------------------------------------------

        self.vpc = ec2.Vpc.from_lookup(
            self,
            "VPC",
            vpc_id=vpc_id,
        )

        self.private_subnets = []
        for idx, subnet_id in enumerate(private_subnet_ids):
            self.private_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"subnet{idx}", subnet_id=subnet_id
                )
            )

        self.db_cluster_arn = (
            f"arn:{partition}:rds:{region}:{account}:cluster:{rds_cluster_id}"
        )
        print("[INFO] DatabaseCluster.ARN(handmade):", self.db_cluster_arn)

        self.proxy_info = get_rds_proxy_info(rds_proxy_ep)

        self.proxy_ips = ""
        if self.proxy_info:
            self.proxy_ips = self.proxy_info[2]
        print("[INFO] proxy_ips:", self.proxy_ips)

        network_targets = []
        for ip in self.proxy_ips:
            ip_target = elbv2_tgt.IpTarget(ip, db_port)
            network_targets.append(ip_target)
        print("[INFO] The length of network_targets:", len(network_targets))

        network_lb_id_name = lg.get_label(
            resource_type="nlb",
            resource_name=cluster_name,
            include_namespace=True,
            include_stage=True,
            include_resource_type=True,
        )

        nlb = elbv2.NetworkLoadBalancer(
            scope=self,
            id=network_lb_id_name,
            vpc=self.vpc,
            load_balancer_name=network_lb_id_name,
            vpc_subnets=ec2.SubnetSelection(subnets=self.private_subnets),
        )

        network_tg_id_name = lg.get_label(
            resource_type="tg",
            resource_name=cluster_name,
            include_namespace=True,
            include_stage=True,
            include_resource_type=True,
        )

        self.nlb_tg = elbv2.NetworkTargetGroup(
            scope=self,
            id=network_tg_id_name,
            port=db_port,
            protocol=elbv2.Protocol.TCP,
            target_group_name=network_tg_id_name,
            target_type=elbv2.TargetType.IP,
            vpc=self.vpc,
            targets=network_targets,
        )

        nlb.add_listener(
            id=f"{network_lb_id_name}-NLBListener",
            port=db_port,
            default_target_groups=[self.nlb_tg],
        )

        vpc_epsvc_id_name = lg.get_label(
            resource_type="vpcepsvc",
            resource_name=cluster_name,
            include_namespace=True,
            include_stage=True,
            include_resource_type=True,
        )

        self.vpcEPService = ec2.VpcEndpointService(
            scope=self,
            id=vpc_epsvc_id_name,
            vpc_endpoint_service_load_balancers=[nlb],
            acceptance_required=True,
            allowed_principals=[
                iam.ArnPrincipal(
                    f"arn:{partition}:iam::{vpc_epsvc_trust_accountid}:root"
                )
                for vpc_epsvc_trust_accountid in vpc_epsvc_trust_accountids
            ],
            contributor_insights=True,
        )

        self.endpoint_service_role = iam.Role(
            scope=self,
            id=f"{vpc_epsvc_id_name}_role",
            role_name=f"{vpc_epsvc_id_name}_role",
            assumed_by=iam.CompositePrincipal(
                *[
                    iam.AccountPrincipal(vpc_epsvc_trust_accountid)
                    for vpc_epsvc_trust_accountid in vpc_epsvc_trust_accountids
                ]
            ),
        )

        epsvc_role_policy_statement_json_1 = {
            "Effect": "Allow",
            "Action": ["ec2:AcceptVpcEndpointConnections"],
            "Resource": "*",
        }

        self.endpoint_service_role.add_to_principal_policy(
            iam.PolicyStatement.from_json(epsvc_role_policy_statement_json_1)
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

        suppressions = [
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-IAM5",
                    "reason": "Resource access restriced to ADDF resources",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-ELB2",
                    "reason": "The ELB does not have access logs enabled",
                }
            ),
        ]
        NagSuppressions.add_stack_suppressions(self, suppressions)

import json
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import AuroraServerlessV2PostStack


# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
region_name = os.environ["CDK_DEFAULT_REGION"]
account_id = os.environ["CDK_DEFAULT_ACCOUNT"]
namespace = os.getenv(_param("NAMESPACE"), "")
stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")

tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)
environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

vpc_id = os.getenv(_param("VPC_ID"))
private_subnet_ids = json.loads(os.getenv(_param("PRIVATE_SUBNET_IDS")))
db_port = os.getenv(_param("DB_PORT"))
cluster_name = os.getenv(_param("CLUSTER_NAME"))
dbname = os.getenv(_param("DATABASE_NAME"))
rds_cluster_id = os.getenv(_param("RDS_CLUSTER_ID"))
rds_proxy_ep = os.getenv(_param("RDS_PROXY_EP"))
db_secret_arn = os.getenv(_param("DB_SECRET_ARN"))
read_only_db_user_secret_arn = os.getenv(_param("READ_ONLY_DB_USER_SECRET_ARN"))
vpc_epsvc_trust_accountids = json.loads(os.getenv(_param("VPC_EPSVC_TRUST_ACCOUNTIDS")))
service_db_user_username = os.getenv(_param("SERVICE_DB_USER_USERNAME"))
DB_Cluster_Endpoint = os.getenv(_param("DB_CLUSTER_ENDPOINT"), "default")
DB_Engine = os.getenv(_param("DB_ENGINE"), "postgres")

# User secrets
secret_name_viewer = os.getenv(_param("SECRET_USERNAME_VIEWER"))
secret_username_viewer = os.getenv(_param("SECRET_USERNAME_VIEWER"))
if not secret_name_viewer or not secret_username_viewer:
    raise RuntimeError(
        "Input parameter <secret_name_viewer> or <secret_username_viewer> is missing"
    )

secret_name_maintainer = os.getenv(_param("SECRET_USERNAME_MAINTAINER"))
secret_username_maintainer = os.getenv(_param("SECRET_USERNAME_MAINTAINER"))
if not secret_name_maintainer or not secret_username_maintainer:
    raise RuntimeError(
        "Input parameter <SECRET_USERNAME_MAINTAINER> or <SECRET_USERNAME_MAINTAINER> is missing"
    )

rds_dq_maintainer_schema_list_str = os.getenv(_param("RDS_DQ_MAINTAINER_SCHEMA_LIST"))
if not rds_dq_maintainer_schema_list_str:
    raise RuntimeError("Input parameter <rds_dq_maintainer_schema_list> is missing")
rds_dq_maintainer_schema_list = json.loads(rds_dq_maintainer_schema_list_str)

print("[INFO] vpc_id:", vpc_id)
print("[INFO] private_subnet_ids:", private_subnet_ids)
print("[INFO] db_port:", db_port)
print("[INFO] cluster_name:", cluster_name)
print("[INFO] dbname:", dbname)
print("[INFO] rds_cluster_id:", rds_cluster_id)
print("[INFO] rds_proxy_ep:", rds_proxy_ep)
print("[INFO] db_secret_arn:", db_secret_arn)
print("[INFO] read_only_db_user_secret_arn:", read_only_db_user_secret_arn)
print("[INFO] vpc_epsvc_trust_accountids:", vpc_epsvc_trust_accountids)
print("[INFO] service_db_user_username:", service_db_user_username)
print("[INFO] secret_name_viewer:", secret_name_viewer)
print("[INFO] secret_name_maintainer:", secret_name_maintainer)
print("[INFO] rds_dq_maintainer_schema_list_str:", rds_dq_maintainer_schema_list_str)

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
app = cdk.App()
stack = AuroraServerlessV2PostStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    region_name=region_name,
    stage=stage,
    namespace=namespace,
    bu_name=bu_name,
    deployment_name=deployment_name,
    module_name=module_name,
    # Secret & Users Params
    DB_Cluster_Endpoint=DB_Cluster_Endpoint,
    DB_Engine=DB_Engine,
    db_secret_arn=db_secret_arn,
    read_only_db_user_secret_arn=read_only_db_user_secret_arn,
    service_db_user_username=service_db_user_username,
    rds_dq_maintainer_schema_list=rds_dq_maintainer_schema_list,
    secret_name_viewer=secret_name_viewer,
    secret_username_viewer=secret_username_viewer,
    secret_name_maintainer=secret_name_maintainer,
    secret_username_maintainer=secret_username_maintainer,
    #
    vpc_id=vpc_id,
    private_subnet_ids=private_subnet_ids,
    db_port=int(db_port),
    rds_cluster_id=rds_cluster_id,
    cluster_name=cluster_name,
    init_dbname=dbname,
    rds_proxy_ep=rds_proxy_ep,
    vpc_epsvc_trust_accountids=vpc_epsvc_trust_accountids,
    env=environment,
    tags=tag_list,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "VpcEndpointServiceName": stack.vpcEPService.vpc_endpoint_service_name,
            "ReadOnlyUserSecret": read_only_db_user_secret_arn,
            "EPSvcRoleARN": stack.endpoint_service_role.role_arn,
            "ServiceDbUserUsername": service_db_user_username,
            "user_viewer_secret_arn": stack.user_viewer_secret_arn,
            "user_viewer_maintainer_arn": stack.user_maintainer_secret_arn,
        }
    ),
)

app.synth()

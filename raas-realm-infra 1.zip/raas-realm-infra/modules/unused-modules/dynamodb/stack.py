from typing import Any, Dict, Optional

import cdk_nag
from aws_cdk import Aspects, Duration, Stack, Tags
from aws_cdk import aws_dynamodb as dynamodb
from aws_cdk import aws_iam as iam
from cdk_nag import NagPackSuppression, NagSuppressions
from constructs import Construct
from utils import LabelGenerator


class DynamodbStack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        namespace: str,
        construct_id: str,
        config: Dict[str, Any],
        dynamo_table_name: str,
        dynamo_table_partition_key: str,
        dynamo_table_sort_key: str,
        tags: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        for k, v in config.items():
            setattr(self, k, v)

        lg = LabelGenerator(
            prefix=config["deployment_name"],
            namespace=namespace,
            stage=stage,
            aws_env=kwargs["env"],
        )
        self.dynamo_table_name_full = lg.get_label(
            resource_type="dynamodb",
            resource_name=dynamo_table_name,
            include_stage=True,
            include_resource_type=True,
        )

        self.map_meta_table = dynamodb.Table(
            self,
            self.dynamo_table_name_full,
            table_name=self.dynamo_table_name_full,
            partition_key=dynamodb.Attribute(
                name=dynamo_table_partition_key, type=dynamodb.AttributeType.STRING
            ),
            sort_key=dynamodb.Attribute(
                name=dynamo_table_sort_key, type=dynamodb.AttributeType.STRING
            ),
            billing_mode=dynamodb.BillingMode.PAY_PER_REQUEST,
        )

        self.dynamo_table_role_name_full = lg.get_label(
            resource_type="role",
            resource_name=dynamo_table_name,
            include_stage=True,
            include_resource_type=True,
        )

        new_dynamodbtable_user_role = iam.Role(
            scope=self,
            id=f"{self.dynamo_table_role_name_full}",
            role_name=f"{self.dynamo_table_role_name_full}",
            assumed_by=iam.CompositePrincipal(iam.AccountRootPrincipal()),
        )

        new_dynamodbtable_user_role_policy_stmt = {
            "Effect": "Allow",
            "Action": [
                "dynamodb:Scan",
                "dynamodb:Query",
                "dynamodb:GetRecords",
                "dynamodb:BatchGetItem",
                "dynamodb:BatchWriteItem",
                "dynamodb:PutItem",
                "dynamodb:GetItem",
                "dynamodb:Scan",
                "dynamodb:Query",
                "dynamodb:UpdateItem",
                "dynamodb:ListGlobalTables",
                "dynamodb:ListTables",
            ],
            "Resource": [self.map_meta_table.table_arn],
        }

        new_dynamodbtable_sts_policy_stmt = {
            "Effect": "Allow",
            "Action": ["sts:AssumeRole"],
            "Resource": "*",
        }

        new_dynamodbtable_user_role.add_to_principal_policy(
            iam.PolicyStatement.from_json(new_dynamodbtable_user_role_policy_stmt)
        )

        new_dynamodbtable_user_role.add_to_principal_policy(
            iam.PolicyStatement.from_json(new_dynamodbtable_sts_policy_stmt)
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

        bucket_suppression = [
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-IAM5",
                    "reason": "Resource access restriced to ADDF resources",
                }
            )
        ]

        NagSuppressions.add_stack_suppressions(self, bucket_suppression)

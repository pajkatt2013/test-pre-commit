#!/usr/bin/env python3
import json
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import DynamodbStack


# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
stage = os.getenv(_param("STAGE"), "default")
namespace = os.getenv(_param("NAMESPACE"), "")
app_prefix = f"addf-{deployment_name}-{module_name}"

DEFAULT_DYNAMO_TABLE_NAME = "dynamo-table-name-default"
DEFAULT_DYNAMO_TABLE_PARTITION_KEY = "partition-key-default"
DEFAULT_DYNAMO_TABLE_SORT_KEY = "sort-key-default"

tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

config = {"deployment_name": deployment_name, "module_name": module_name}

dynamo_table_name = os.getenv(_param("DYNAMO_TABLE_NAME"), DEFAULT_DYNAMO_TABLE_NAME)
dynamo_table_partition_key = os.getenv(
    _param("DYNAMO_TABLE_PARTITION_KEY"), DEFAULT_DYNAMO_TABLE_PARTITION_KEY
)
dynamo_table_sort_key = os.getenv(
    _param("DYNAMO_TABLE_SORT_KEY"), DEFAULT_DYNAMO_TABLE_SORT_KEY
)

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------

app = cdk.App()
stack = DynamodbStack(
    scope=app,
    construct_id=app_prefix,
    namespace=namespace,
    stage=stage,
    dynamo_table_name=dynamo_table_name,
    dynamo_table_partition_key=dynamo_table_partition_key,
    dynamo_table_sort_key=dynamo_table_sort_key,
    env=environment,
    config=config,
    tags=tag_list,
)

CfnOutput(
    stack,
    "dynamo_table_name",
    value=stack.map_meta_table.table_name,
)

CfnOutput(
    stack,
    "dynamo_table_arn",
    value=stack.map_meta_table.table_arn,
)

app.synth()

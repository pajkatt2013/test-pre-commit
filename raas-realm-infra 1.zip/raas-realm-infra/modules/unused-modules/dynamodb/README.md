# ECR for RPU (ecr4rpus) Module

## Description

This module creates elastic container registry with particular IAM role for the specific user, who should be able to assume the IAM role.

## Inputs/Outputs

### Input Paramenters

#### Required

None

#### Optional

- `repository_name`: Partial name of the ecr repository, it is combined with a label generator to generate a unique name among deployments
- `image_tag_mutability`: Image tag mutability. Defaults to `"IMMUTABLE"`. Possible values: `"IMMUTABLE"` or `"MUTABLE"`
- `lifecycle_max_days`: Max days to store the images in ECR. Defaults to `None`, (no removal of images)
- `lifecycle_max_image_count`: Max images to store the images in ECR. Defaults to `None`, (no removal of images)
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.


### Module Metadata Outputs

- `RepositoryName`: ECR repository name
- `RepositoryARN`: ECR repository ARN

#### Output Example

```json
{
    "RepositoryName": "pytorch-10",
    "RepositoryARN": "arn:aws:ecr:<REGION>:<ACCOUNT_ID>:repository/pytorch-10"
}

```

### Using of ecr4rpus module

#### Import from the same repository
```yaml
path: modules/ecr/ecr4rpus

```

#### Import using git URL

```yaml
# Import head version of specific branch
# Example
path: git::codecommit://raas-seedfarmer-modules.git//modules/ecr/ecr4rpus/?ref=heads/<your-branch-name>

# Import tagged version
# Example
path: git::codecommit://raas-seedfarmer-modules.git//modules/ecr/ecr4rpus/?ref=<your-tag-name>

```

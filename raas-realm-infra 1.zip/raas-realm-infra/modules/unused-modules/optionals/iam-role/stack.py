import os
from typing import Any, Dict, cast

import aws_cdk
from aws_cdk import Aspects, Stack, Tags
from aws_cdk import aws_iam as iam
from constructs import Construct, IConstruct
from utils import LabelGenerator


class IAMStack(Stack):  # type: ignore
    def __init__(
        self,
        scope: Construct,
        id: str,
        namespace: str,
        stage: str,
        bu_name: str,
        config: Dict[str, Any],
        hash: str,
        iam_role_name: str,
        iam_role_trusted_account: str,
        tags: list,
        **kwargs: Any,
    ) -> None:
        # ADDF Env vars

        for k, v in config.items():
            setattr(self, k, v)

        # CDK Env Vars
        account: str = aws_cdk.Aws.ACCOUNT_ID
        region: str = aws_cdk.Aws.REGION

        super().__init__(
            scope,
            id,
            description="This stack deploys empty IAM role for ADDF",
            **kwargs,
        )

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", self.deployment_name)
        add_tag("Module", self.module_name)
        for kv in tags:
            add_tag(kv["key"], kv["value"])

        lg = LabelGenerator(
            prefix=config["deployment_name"],
            namespace=namespace,
            stage=stage,
            bu_name=bu_name,
            aws_env=kwargs["env"],
        )

        # Creates IAM role
        iam_role_name = lg.get_label(
            resource_type="role",
            resource_name=iam_role_name,
            include_bu=True,
            include_namespace=True,
            include_stage=True,
            include_resource_type=True,
        )

        if iam_role_trusted_account:
            trusted_entity = iam.AccountPrincipal(iam_role_trusted_account)
        else:
            trusted_entity = iam.AccountRootPrincipal()

        self.iam_role = iam.Role(
            self, iam_role_name, role_name=iam_role_name, assumed_by=trusted_entity
        )

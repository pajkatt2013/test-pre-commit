import json
import os
import sys

import aws_cdk
from aws_cdk import App, CfnOutput
from stack import IAMStack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
hash = os.getenv("ADDF_HASH", "")

target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")
stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")

namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")

IamRoleName = os.getenv(_param("IAM_ROLE_NAME"), "")

iam_role_trusted_account = os.getenv(_param("IAM_ROLE_TRUSTED_ACCOUNT"))
if iam_role_trusted_account is None:
    print(f"[INFO] Parameter <IAM_ROLE_TRUSTED_ACCOUNT> is None object")

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "target_realm_account_id": target_realm_account_id,
}

app = App()

stack = IAMStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    namespace=namespace,
    stage=stage,
    bu_name=bu_name,
    config=config,
    hash=hash,
    iam_role_name=IamRoleName,
    iam_role_trusted_account=iam_role_trusted_account,
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
    tags=tag_list,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {"RoleName": stack.iam_role.role_name, "RoleArn": stack.iam_role.role_arn}
    ),
)


app.synth(force=True)

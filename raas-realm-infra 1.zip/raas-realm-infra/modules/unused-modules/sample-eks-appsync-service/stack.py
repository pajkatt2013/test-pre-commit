import logging
import os
from typing import Any, Dict, Optional

import cdk_nag
from aws_cdk import Aspects, Aws, CfnJson, Duration, Stack, Tags
from aws_cdk import aws_ecr as ecr
from aws_cdk import aws_events as events
from aws_cdk import aws_iam as iam
from aws_cdk import aws_lambda
from constructs import Construct
from utils import LabelGenerator

IMAGE_MUTABILITY = {
    "IMMUTABLE": ecr.TagMutability.IMMUTABLE,
    "MUTABLE": ecr.TagMutability.MUTABLE,
}

_logger: logging.Logger = logging.getLogger(__name__)


class EKSAppSyncService(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        construct_id: str,
        config: Dict[str, Any],
        iam_AppSyncService_role_name: str,
        eks_serviceaccount_name: str,
        eks_namespace: str,
        OIDCProvider: str,
        tags: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # CDK Env Vars
        partition: str = Aws.PARTITION

        for k, v in config.items():
            setattr(self, k, v)

        for t in tags:
            Tags.of(scope).add(t["key"], t["value"])

        resource_name_prefix = f"raas-{stage}-{self.module_name}"
        lg = LabelGenerator(
            prefix=resource_name_prefix, stage=stage, aws_env=kwargs["env"]
        )

        iam_role_name_eks_appsync_service = lg.get_label(
            iam_AppSyncService_role_name, include_stage=False, include_region=False
        )
        self.service_account_name = lg.get_label(
            eks_serviceaccount_name, include_stage=False, include_region=False
        )
        OIDCProviderARN = f"arn:{partition}:iam::{self.target_realm_account_id}:oidc-provider/{OIDCProvider}"

        self.iam_role_eks_appsync_service = iam.Role(
            self,
            iam_role_name_eks_appsync_service,
            role_name=iam_role_name_eks_appsync_service,
            assumed_by=iam.CompositePrincipal(
                # iam.AccountRootPrincipal(),
                iam.PrincipalWithConditions(
                    iam.WebIdentityPrincipal(OIDCProviderARN),
                    conditions={
                        "StringEquals": CfnJson(
                            self,
                            "ServiceAccountRoleTrustPolicy",
                            value={
                                f"{OIDCProvider}:aud": "sts.amazonaws.com",
                                f"{OIDCProvider}:sub": f"system:serviceaccount:{eks_namespace}:{self.service_account_name}",
                            },
                        )
                    },
                )
            ),
        )

        appsync_stsAssumeRole_policy = {
            "Effect": "Allow",
            "Action": ["sts:AssumeRole"],
            "Resource": [
                f"arn:{partition}:iam::012826682575:role/data-quality-api-access-role-int",
                f"arn:{partition}:iam::549001197339:role/data-products-api-access-role-int",
            ],
        }

        self.iam_role_eks_appsync_service.add_to_principal_policy(
            iam.PolicyStatement.from_json(appsync_stsAssumeRole_policy)
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

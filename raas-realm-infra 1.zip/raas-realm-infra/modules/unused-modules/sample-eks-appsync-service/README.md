# Sample EKS App to access AppSync Service

## Description

This module creates the IAM Role and the EKS service account for the sample application to access the data quality AppSync service.

## Inputs/Outputs

### Input Paramenters

#### Required

None

#### Optional

  - name: TargetEKSClusterName
    value: addf-realm-infra-hy-core-eks-cluster

  - name: EKSNamespace
    value: ns-samples

  - name: HostedZoneID
    valueFrom:
      envVariable: HOSTED_ZONE_ID

  - name: OIDCProviderURL
    value: oidc.eks.eu-central-1.amazonaws.com/id/753F288880E24D19D0E57F3A8DAA2C13

  - name: EKSServiceAccount
    value: sa

  - name: AppSyncServiceRoleName
    value: role

  - name: awstags
    value:
      - key: customer-function
        value: common
      - key: maintainer
        value: raas-devops


- `TargetEKSClusterName`: The cluster name of the cluster, which the sample App will be deployed into.
- `EKSNamespace`: The namespace name within the target cluster, which the sample App will be deployed into.
- `OIDCProviderURL`: The Open ID connect provider URL of the target cluster.
- `EKSServiceAccount`: The service account, which will be used in the IAM Role.
- `AppSyncServiceRoleName`: The IAM Role name for the EKS service.
- `awstags`: The tags for the AWS resources, which will be created by this module.

### Module Metadata Outputs

- `ServiceRoleArn`: IAM Role ARN
- `ServiceRoleName`: IAM Role Name



#### Output Example

```json
{
    "RepositoryName": "raas-dev-appsync-service-sample-appsync-serivce-role",
    "RepositoryARN": "arn:aws:iam::178345759618:role/raas-dev-appsync-service-sample-appsync-serivce-role"
}

```

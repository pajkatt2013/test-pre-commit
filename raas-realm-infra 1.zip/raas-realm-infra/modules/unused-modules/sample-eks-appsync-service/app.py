#!/usr/bin/env python3
import json
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import EKSAppSyncService


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
app_prefix = f"app-raas-{deployment_name}-{module_name}"

target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "target_realm_account_id": target_realm_account_id,
}

DEFAULT_iam_AppSyncService_role_name = "addf-eks-appsync-service-role"
AppSyncServiceRoleName = os.getenv(
    _param("APP_SYNC_SERVICE_ROLE_NAME"), DEFAULT_iam_AppSyncService_role_name
)

DEFAULT_eks_serviceaccount_name = "addf-eks-appsync-service-role"
eks_serviceaccount_name = os.getenv(
    _param("EKS_SERVICE_ACCOUNT"), DEFAULT_eks_serviceaccount_name
)

DEFAULT_eks_namespace = "default"
eks_namespace = os.getenv(_param("EKS_NAMESPACE"), DEFAULT_eks_namespace)

DEFAULT_OIDCProvider = "addf-eks-appsync-service-role"
OIDCProvider = os.getenv(
    _param("OIDC_PROVIDER_URL"), DEFAULT_iam_AppSyncService_role_name
)

DEFAULT_awstags = "[{'key': 'maintainer', 'value': 'raas-devops'}]"
AWSTags = json.loads(os.getenv(_param("AWSTAGS"), DEFAULT_awstags))


app = cdk.App()
stack = EKSAppSyncService(
    scope=app,
    construct_id=app_prefix,
    stage=os.getenv("STAGE", "dev"),
    env=environment,
    config=config,
    iam_AppSyncService_role_name=AppSyncServiceRoleName,
    eks_serviceaccount_name=eks_serviceaccount_name,
    eks_namespace=eks_namespace,
    OIDCProvider=OIDCProvider,
    tags=AWSTags,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "ServiceRoleArn": stack.iam_role_eks_appsync_service.role_arn,
            "ServiceRoleName": stack.iam_role_eks_appsync_service.role_name,
        }
    ),
)


app.synth()

import json
import uuid
from typing import Any, Dict, Optional

import aws_cdk
import cdk_nag
from aws_cdk import Aspects, Duration, RemovalPolicy, Stack, Tags
from aws_cdk import aws_cloudtrail as trail
from aws_cdk import aws_iam as iam
from aws_cdk import aws_s3
from aws_cdk import aws_secretsmanager as secretsmanager
from constructs import Construct
from utils import LabelGenerator


class RDSTrail(Stack):
    def __init__(
        self,
        scope: Construct,
        id: str,
        config: Dict[str, Any],
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys the secret in Secret Manager",
            **kwargs,
        )

        for k, v in config.items():
            setattr(self, k, v)
        tags = self.tag_list
        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        lg = LabelGenerator(
            prefix=self.deployment_name,
            namespace=self.namespace,
            stage=self.stage,
            bu_name=self.bu_name,
            aws_env=kwargs["env"],
        )

        trail_id_name = lg.get_label(
            resource_type="Trail",
            resource_name=self.trail_name,
            include_namespace=True,
            # include_stage=True,
            include_resource_type=True,
        )

        trail_s3_name = lg.get_label(
            resource_type="s3",
            resource_name=self.s3_name,
            include_account=True,
            include_prefix=True,
            include_stage=True,
            include_resource_type=True,
        )

        self.trail_s3 = aws_s3.Bucket(
            self,
            removal_policy=aws_cdk.RemovalPolicy.RETAIN,
            bucket_name=trail_s3_name,
            id=f"addf-{self.deployment_name}-{self.module_name}-bucket",
            encryption=aws_s3.BucketEncryption.S3_MANAGED,
            block_public_access=aws_s3.BlockPublicAccess.BLOCK_ALL,
        )

        trail_s3_policy_stmt_1 = iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            principals=[iam.ServicePrincipal("cloudtrail.amazonaws.com")],
            actions=["s3:GetBucketAcl"],
            resources=[self.trail_s3.bucket_arn],
        )

        trail_s3_policy_stmt_2 = iam.PolicyStatement(
            effect=iam.Effect.ALLOW,
            principals=[iam.ServicePrincipal("cloudtrail.amazonaws.com")],
            actions=["s3:PutObject"],
            resources=[f"{self.trail_s3.bucket_arn}/*"],
        )

        result1 = self.trail_s3.add_to_resource_policy(trail_s3_policy_stmt_1)
        result2 = self.trail_s3.add_to_resource_policy(trail_s3_policy_stmt_2)
        print("[INFO] Trail bucket policies have been configured.")

        print("[INFO] Creating rds trail ...")
        self.rds_trail = trail.CfnTrail(
            scope=self,
            id=trail_id_name,
            is_logging=True,
            s3_bucket_name=trail_s3_name,
            advanced_event_selectors=[
                trail.CfnTrail.AdvancedEventSelectorProperty(
                    field_selectors=[
                        trail.CfnTrail.AdvancedFieldSelectorProperty(
                            field="eventCategory",
                            equal_to=["Data"],
                        ),
                        trail.CfnTrail.AdvancedFieldSelectorProperty(
                            field="resources.type",
                            equal_to=["AWS::RDS::DBCluster"],
                        ),
                        trail.CfnTrail.AdvancedFieldSelectorProperty(
                            field="resources.ARN",
                            ends_with=[self.target_rds_cluster_arn],
                        ),
                    ],
                    name="DQ RDS Data API Event",
                )
            ],
            is_multi_region_trail=False,
            is_organization_trail=False,
            trail_name=trail_id_name,
        )

        self.rds_trail.node.add_dependency(self.trail_s3)

        # Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

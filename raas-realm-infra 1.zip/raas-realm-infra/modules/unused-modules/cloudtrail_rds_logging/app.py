#!/usr/bin/env python3
import json
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import RDSTrail


# ------------------------------------------------------------------------------
def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


# ------------------------------------------------------------------------------

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
stage = os.getenv(_param("STAGE"), "defaultStage")
namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")
tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

trail_name = os.getenv(_param("TRAIL_NAME"))
if not trail_name:
    raise RuntimeError("Input parameter <trail_name> is missing")

s3_name = os.getenv(_param("S3_NAME"))
if not s3_name:
    raise RuntimeError("Input parameter <s3_name> is missing")

target_rds_cluster_arn = os.getenv(_param("TARGET_RDS_CLUSTER_ARN"))
if not target_rds_cluster_arn:
    raise RuntimeError("Input parameter <target_rds_cluster_arn> is missing")

enable_cloudwatch = os.getenv(_param("ENABLE_CLOUDWATCH"), "false")
enable_multi_region_trail = os.getenv(_param("ENABLE_MULTI_REGION_TRAIL"), "false")

# DB_Init_Name = os.getenv(_param("DB_INIT_NAME"), "default")
# DB_Engine = os.getenv(_param("DB_ENGINE"), "postgres")
# include_namespace_str = os.getenv(_param("INCLUDE_NAMESPACE"), "False")
# include_namespace = True if str.lower(include_namespace_str) == "true" else False
config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "stage": stage,
    "namespace": namespace,
    "bu_name": bu_name,
    "tag_list": tag_list,
    "trail_name": trail_name,
    "s3_name": s3_name,
    "target_rds_cluster_arn": target_rds_cluster_arn,
    "enable_cloudwatch": enable_cloudwatch,
    "enable_multi_region_trail": enable_multi_region_trail,
}

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

app_id = f"addf-{deployment_name}-{module_name}-{trail_name}"

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
app = cdk.App()
stack = RDSTrail(scope=app, id=app_id, config=config, env=environment)

CfnOutput(stack, id="TrailS3Name", value=stack.rds_trail.s3_bucket_name)

app.synth()

#!/usr/bin/env python3
import json
import os
import sys

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import Lambda_S3_Event_Stack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
app_prefix = f"app-raas-{deployment_name}-{module_name}"

target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")

namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")
event_publisher_lambda = os.getenv(_param("EVENT_PUBLISHER_LAMBDA"))
bucket_name = os.getenv(_param("BUCKET_NAME"))
ecr_repo = os.getenv(_param("ECR_REPO"))
ecr_repo_event_filter = os.getenv(_param("ECR_REPO_EVENT_FILTER"), "")
bucket_event_filter = os.getenv(_param("BUCKET_EVENT_FILTER"), "")

if ecr_repo_event_filter != "":
    ecr_repo_event_filter = json.loads(ecr_repo_event_filter)
if bucket_event_filter != "":
    bucket_event_filter = json.loads(bucket_event_filter)

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "target_realm_account_id": target_realm_account_id,
}

DEFAULT_LAMBDA_NAME = "addf-rpu-event-lambda-test"
lambda_name = os.getenv(_param("LAMBDA_NAME"), DEFAULT_LAMBDA_NAME)
oao_event_type = os.getenv(_param("OAO_EVENT_TYPE"))
bu_access_role = os.getenv(_param("BU_ACCESS_ROLE"))
tenant = os.getenv(_param("TENANT_NAME"))
realm_name = os.getenv(_param("REALM_INSTANCE_ALIAS"))
source_stage = os.getenv(_param("REALM_ACCOUNT_STAGE"))

app = cdk.App()
stack = Lambda_S3_Event_Stack(
    scope=app,
    construct_id=app_prefix,
    namespace=namespace,
    stage=stage,
    bu_name=bu_name,
    bucket_name=bucket_name,
    ecr_repo=ecr_repo,
    ecr_repo_event_filter=ecr_repo_event_filter,
    bucket_event_filter=bucket_event_filter,
    event_publisher_lambda=event_publisher_lambda,
    env=environment,
    config=config,
    lambda_func_name=lambda_name,
    oao_event_type=oao_event_type,
    bu_access_role=bu_access_role,
    tenant=tenant,
    realm_name=realm_name,
    source_stage=source_stage,
    tags=tag_list,
)

CfnOutput(
    stack,
    "LambdaFunctionARN",
    value=stack.eventbridge_lambda.lambda_function.function_arn,
)

app.synth()

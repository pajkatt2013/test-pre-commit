# Event-trigger Module

## Description

This module creates event triggers for S3 bucket and ECR repo.

## Inputs/Outputs

### Input Paramenters

#### Required

None

#### Optional

- `lambda-name`: Partial name of the lambda name, it is combined with a label generator to generate a unique name among deployments
- `oao-event-type`: detail-type of oao event (reference: https://asc.bmwgroup.net/wiki/display/ORIONPRODUCTS/Overarching+Orchestration+-+User+Handbook)
- `event-publisher-lambda`: Event publisher lambda function ARN
- `bu-access-role`: Bucket and ECR repo access role ARN
- `bucket-name`: bucket name created in S3-bucket module
- `bu_name`: business unit name (e.g, aptiv)
- `tenant-name`: tenant name (e.g, Orion)
- `realm-instance-alias`: realm name
- `realm-account-stage`: Account stage (e.g, Dev)
- `namespace`: Namespace used in config
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.
- `ecr-repo-event-filter`: Optional, if used - this must be a list! Stores list of the ECR repositories that events from should be forwarded to the target. Ex. ["repo1", "repo2"]
- `bucket-event-filter`: Optional, if used - this must be a list! Stores list of the S3 buckets that events from should be forwarded to the target. Ex. ["bucket1", "bucket2"]

### Module Metadata Outputs

- `LambdaFunctionARN`: ARN of lambda function created as target to eventbridge

import json
import os
import uuid

import boto3

OAO_EVENT_TYPE = os.environ["OAO_EVENT_TYPE"]
BU_ACCESS_ROLE = os.environ["BU_ACCESS_ROLE"]

STAGE = os.environ["STAGE"]
REALM_NAME = os.environ["REALM_NAME"]
TENANT = os.environ["TENANT"]
NAMESPACE = os.environ["NAMESPACE"]
PUBLISH_LAMBDA = os.environ["PUBLISH_LAMBDA"]

context_id = str(uuid.uuid4())
context_source = f"{TENANT}#{REALM_NAME}#{STAGE}#{NAMESPACE}"
print("loading function")


def lambda_handler(event, context):
    print("Received event: " + json.dumps(event))

    custom_event = {
        "detail": {
            "context-descriptor": {
                "context-id": context_id,
                "context-source": context_source,
            },
            "additional-details": {
                "BUAccessRole": BU_ACCESS_ROLE,
                "originalRpuEvent": event,
            },
        },
        "detail-type": OAO_EVENT_TYPE,
        "source": "",
    }

    print("Sent custom event: " + json.dumps(custom_event))

    client = boto3.client("lambda")
    response = client.invoke(
        FunctionName=PUBLISH_LAMBDA, Payload=json.dumps(custom_event)
    )

    return custom_event

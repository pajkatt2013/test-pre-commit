import logging
import os
from typing import Any, Dict, Optional

import aws_cdk
import aws_solutions_constructs.aws_eventbridge_lambda as eventbridge_lambda
import cdk_nag
from aws_cdk import Aspects, Aws, Duration, Stack, Tags
from aws_cdk import aws_ecr as ecr
from aws_cdk import aws_events as events
from aws_cdk import aws_iam as iam
from aws_cdk import aws_lambda
from constructs import Construct
from utils import LabelGenerator

# IMAGE_MUTABILITY = {
#     "IMMUTABLE": ecr.TagMutability.IMMUTABLE,
#     "MUTABLE": ecr.TagMutability.MUTABLE,
# }

_logger: logging.Logger = logging.getLogger(__name__)


class Lambda_S3_Event_Stack(Stack):
    def __init__(
        self,
        scope: Construct,
        namespace: str,
        stage: str,
        bu_name: str,
        bucket_name: str,
        ecr_repo: str,
        ecr_repo_event_filter: list,
        bucket_event_filter: list,
        event_publisher_lambda: str,
        construct_id: str,
        config: Dict[str, Any],
        lambda_func_name: str,
        oao_event_type: str,
        bu_access_role: str,
        tenant: str,
        realm_name: str,
        source_stage: str,
        tags: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # CDK Env Vars
        partition: str = aws_cdk.Aws.PARTITION
        region: str = aws_cdk.Aws.REGION

        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        for k, v in config.items():
            setattr(self, k, v)

        # parse event_publisher_lambda ARN to get lambda name
        publish_lambda_name = event_publisher_lambda.split(":")[-1]

        lambda_src_code_path = os.path.join(
            os.path.dirname(__file__), "src/event_processor"
        )

        lg = LabelGenerator(
            prefix=config["deployment_name"],
            namespace=namespace,
            stage=stage,
            bu_name=bu_name,
            aws_env=kwargs["env"],
        )

        lambda_s3_event_processor_name = lg.get_label(
            resource_type="lambda",
            resource_name=lambda_func_name,
            include_bu=True,
            include_namespace=True,
            include_stage=True,
            include_resource_type=True,
        )

        event_detail_type = [
            "Object Created",
            "Object Deleted",
            "Object Tags Added",
            "Object Tags Deleted",
            "ECR Image Action",
        ]
        event_source = ["aws.s3", "aws.ecr"]
        if bucket_event_filter and ecr_repo_event_filter:
            event_detail_filter = {
                "$or": [
                    {"bucket": {"name": bucket_event_filter}},
                    {"repository-name": ecr_repo_event_filter},
                ]
            }
        elif ecr_repo_event_filter:
            event_detail_filter = {"repository-name": ecr_repo_event_filter}
        elif bucket_event_filter:
            event_detail_filter = {"bucket": {"name": bucket_event_filter}}
        else:
            event_detail_filter = None

        event_bus_name = "default"
        event_bus = events.EventBus.from_event_bus_name(
            self, "event-bus", event_bus_name
        )

        self.eventbridge_lambda = eventbridge_lambda.EventbridgeToLambda(
            self,
            "eventbridge-lambda",
            lambda_function_props=aws_lambda.FunctionProps(
                function_name=lambda_s3_event_processor_name,
                runtime=aws_lambda.Runtime.PYTHON_3_10,
                handler="main.lambda_handler",
                code=aws_lambda.Code.from_asset(lambda_src_code_path),
                environment={
                    "REGION": self.region,
                    "OAO_EVENT_TYPE": oao_event_type,
                    "BU_ACCESS_ROLE": bu_access_role,
                    "STAGE": source_stage,
                    "REALM_NAME": realm_name,
                    "TENANT": tenant,
                    "NAMESPACE": namespace,
                    "PUBLISH_LAMBDA": publish_lambda_name,
                },
                timeout=Duration.minutes(15),
                # memorySize=1024
            ),
            event_rule_props=events.RuleProps(
                description=f"Event rule for event processor {lambda_s3_event_processor_name=} and event bus {event_bus.event_bus_name=}",
                event_pattern=events.EventPattern(
                    detail_type=event_detail_type,
                    source=event_source,
                    detail=event_detail_filter,
                ),
            ),
            existing_event_bus_interface=event_bus,
        )

        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=[
                    "logs:PutLogEvents",
                    "logs:CreateLogGroup",
                    "logs:CreateLogStream",
                ],
                resources=[f"arn:{partition}:logs:*:*:*"],
                effect=iam.Effect.ALLOW,
            )
        )

        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=["s3:Get*", "s3:List*"],
                resources=[f"arn:{partition}:s3:::{bucket_name}/*"],
                effect=iam.Effect.ALLOW,
            )
        )

        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=[
                    "ecr:DescribeImages",
                    "ecr:BatchGetImage",
                    "ecr:GetLifecyclePolicyPreview",
                    "ecr:DescribeRegistry",
                    "ecr:DescribeRepositories",
                ],
                resources=[
                    f"arn:{partition}:ecr:{region}:{self.target_realm_account_id}:repository/{ecr_repo}"
                ],
                effect=iam.Effect.ALLOW,
            )
        )

        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=[
                    "lambda:InvokeFunction",
                    "lambda:GetFunction",
                    "lambda:GetFunctionConfiguration",
                    "lambda:ListFunctionEventInvokeConfigs",
                    "lambda:ListTags",
                    "lambda:GetFunctionEventInvokeConfig",
                ],
                resources=[event_publisher_lambda],
                effect=iam.Effect.ALLOW,
            )
        )

        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=["lambda:ListFunctions", "lambda:ListLayers"],
                resources=["*"],
                effect=iam.Effect.ALLOW,
            )
        )

        cdk_nag.NagSuppressions.add_resource_suppressions(
            self.eventbridge_lambda.lambda_function.role,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-IAM4",
                    reason="Lambda basic execution role allowing for cloudwatch logs",
                )
            ],
        )

        cdk_nag.NagSuppressions.add_stack_suppressions(
            self,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-IAM5",
                    reason="This lambda should get permission to execute DescribeRepositories on all repositories",
                )
            ],
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

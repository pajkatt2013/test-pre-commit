# ECR Permissions Module

## Description

This module adds defined resource based policy to the list of ECR repositories

## Inputs/Outputs

### Input Paramenters

#### Required

- `repository_names`: JSON list of names of the ecr repositories
- `ecr-crossaccount-pull-resource`: Resource arn, used for cross account pull of images from the specified ECR repos e.g, raas codebuild project service role arn to pull images from supplier realm to raas realm ECRs
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.

#### Optional

#### Input Example

```yaml
parameters:

  - name: repository-names
    valueFrom:
      moduleMetadata:
        group: ecr4rpu
        name: ecr-rpu-images
        key: RepositoryName

  - name: ecr-crossaccount-pull-resource
    valueFrom:
      envVariable: ECR_CROSSACCOUNT_PULL_RESOURCE

  - name: cost-allocation-tag
    value:
      - key: customer_function
        value: common
      - key: maintainer
        value: raas_devops

```

### Module Metadata Outputs


#### Output Example


### Using of ecr4rpus module

#### Import from the same repository
```yaml
path: modules/ecr/ecr-permissions

```

#### Import using git URL

```yaml
# Import head version of specific branch
# raas-seedfarmer-modules
path: git::codecommit://raas-seedfarmer-modules.git//modules/ecr/ecr-permissions/?ref=heads/<your-branch-name>

# Import tagged version
# raas-seedfarmer-modules
path: git::codecommit://raas-seedfarmer-modules.git//modules/ecr/ecr-permissions/?ref=<your-tag-name>

```

import json
from typing import Any, Dict

import boto3
import cdk_nag
from aws_cdk import Aspects, Stack, Tags
from constructs import Construct


class EcrPermissionsStack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        namespace: str,
        bu_name: str,
        construct_id: str,
        config: Dict[str, Any],
        repository_names: list[str],
        ecr_crossaccount_pull_resource: list[str],
        tags: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        for k, v in config.items():
            setattr(self, k, v)

        # ECR repository policy statement
        policy_statement_json = {
            "Sid": "AllowCrossAccountPull",
            "Effect": "Allow",
            "Action": [
                "ecr:BatchCheckLayerAvailability",
                "ecr:BatchGetImage",
                "ecr:GetDownloadUrlForLayer",
            ],
            "Principal": {"AWS": ecr_crossaccount_pull_resource},
        }

        # Add the policy statement to the repository's resource policy
        for repository_name in repository_names:
            ecr_client = boto3.client("ecr")
            ecr_client.set_repository_policy(
                repositoryName=repository_name,
                policyText=json.dumps({"Statement": [policy_statement_json]}),
            )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

#!/usr/bin/env python3
import json
import os

import aws_cdk as cdk
from stack import EcrPermissionsStack

# ------------------------------------------------------------------------------


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


# ------------------------------------------------------------------------------

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
stage = os.getenv(_param("STAGE"), "defaultStage")
namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")
app_prefix = f"addf-{deployment_name}-{module_name}"

tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

config = {"deployment_name": deployment_name, "module_name": module_name}

repository_names_str = os.getenv(_param("REPOSITORY_NAMES"))
if repository_names_str is None:
    raise RuntimeError("[ERROR]: Repository Names is None object")

repository_names = json.loads(repository_names_str)

ecr_crossaccount_pull_resource_str = os.getenv(_param("ECR_CROSSACCOUNT_PULL_RESOURCE"))
if ecr_crossaccount_pull_resource_str is None:
    raise RuntimeError("[ERROR]: ECR Cross-account Pull Resource is None object")

ecr_crossaccount_pull_resource = json.loads(ecr_crossaccount_pull_resource_str)

app = cdk.App()
stack = EcrPermissionsStack(
    scope=app,
    construct_id=app_prefix,
    stage=stage,
    bu_name=bu_name,
    namespace=namespace,
    repository_names=repository_names,
    ecr_crossaccount_pull_resource=ecr_crossaccount_pull_resource,
    env=environment,
    config=config,
    tags=tag_list,
)

app.synth()

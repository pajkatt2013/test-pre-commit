import json


def lambda_handler(event, context):
    print("[INFO]: Implementation is in progress ...")

    return {
        "statusCode": 200,
        "body": json.dumps("SUCCEEDED: Insert record into dynamodb"),
    }

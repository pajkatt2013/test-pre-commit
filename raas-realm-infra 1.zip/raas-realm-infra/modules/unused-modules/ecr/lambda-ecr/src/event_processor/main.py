"""This lambda function will be triggered by CloudTrail Events: PutImage, InitiateLayerUpload
"""
# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------

import json
import logging
import os
import sys
from typing import Dict

import boto3

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# ------------------------------------------------------------------------------
# Constant
# ------------------------------------------------------------------------------
C_EVENT_NAME_PutImage = "PutImage"
C_EVENT_NAME_InitiateLayerUpload = "InitiateLayerUpload"

C_EVENT_ERROR_CODE_NO_REPO = "RepositoryNotFoundException"

C_EVENT_ATTR_detail_userIdentity = "userIdentity"
C_EVENT_ATTR_detail_resources = "resources"

C_EVENT_ATTR_detail = "detail"

C_EVENT_ATTR_detail_eventName = "eventName"
C_EVENT_ATTR_detail_errorCode = "errorCode"
C_EVENT_ATTR_detail_requestParameters = "requestParameters"
C_EVENT_ATTR_detail_requestParameters_registryId = "registryId"
C_EVENT_ATTR_detail_requestParameters_repositoryName = "repositoryName"

C_ECR_REPO_PROP_imageTagMutability = "IMMUTABLE"
C_ECR_REPO_PROP_imageScanningConfiguration = {"scanOnPush": True}
C_ECR_REPO_PROP_encryptionConfiguration = {"encryptionType": "AES256"}


# ------------------------------------------------------------------------------
# Helper function
# ------------------------------------------------------------------------------
def get_event_info(event: Dict):
    """
    This function gets the relevant event information for PutImage, InitiateLayerUpload

    Args:
        event: Dict - Lambda trigger event in JSON object

    Returns:
        event_name: str - Event name (PutImage/InitiateLayerUpload)
        registry_id: str - ECR registry ID
        tgt_repo_name: str - Target repo of the image Push Event
    """
    event_elem_detail = event[C_EVENT_ATTR_detail]

    event_name = event_elem_detail[C_EVENT_ATTR_detail_eventName]
    registry_id = event_elem_detail[C_EVENT_ATTR_detail_requestParameters][
        C_EVENT_ATTR_detail_requestParameters_registryId
    ]
    tgt_repo_name = event_elem_detail[C_EVENT_ATTR_detail_requestParameters][
        C_EVENT_ATTR_detail_requestParameters_repositoryName
    ]

    return event_name, registry_id, tgt_repo_name


def get_event_errorCode(event: Dict):
    event_elem_detail = event[C_EVENT_ATTR_detail]

    error_code = None

    if C_EVENT_ATTR_detail_errorCode in event_elem_detail:
        error_code = event_elem_detail[C_EVENT_ATTR_detail_errorCode]

    return error_code


def generate_new_repo(regi_id: str, repo_name: str):
    """
    This function generates the new repository based on the input variable

    Args:
        regi_id: str - ECR registry ID
        repo_name: str - Target repo of the image Push Event

    Returns:
        None
    """

    ecr_client = boto3.client("ecr")

    try:
        ecr_client.create_repository(
            registryId=regi_id,
            repositoryName=repo_name,
            imageTagMutability=C_ECR_REPO_PROP_imageTagMutability,
            imageScanningConfiguration=C_ECR_REPO_PROP_imageScanningConfiguration,
            encryptionConfiguration=C_ECR_REPO_PROP_encryptionConfiguration,
            tags=[],
        )
        logger.info("created %s repository", repo_name)
    except Exception as e:
        logger.error("failed to create repository %s: %s", repo_name, e)
        sys.exit(1)


# ------------------------------------------------------------------------------
# Lambda handler
# ------------------------------------------------------------------------------
def lambda_handler(event, context):
    """
    This is entry point function for Lambda
    """
    print("---------------------- Start ECR Event Processor -------------------")
    print("trigger-event: ", event)
    print("---------------------- ------------------------- -------------------")
    # init boto3 ECR client
    ecr_client = boto3.client("ecr")

    # get target repository name of ECR event
    event_name, registry_id, target_repo_name = get_event_info(event)

    # process event
    if event_name == C_EVENT_NAME_PutImage:
        logger.info("ECR PushEvent to repository <%s> succeeded", target_repo_name)
    elif event_name == C_EVENT_NAME_InitiateLayerUpload:
        error_code = get_event_errorCode(event)

        if error_code is not None:
            logger.warning("ECR PushEvent to repository <%s> FAILED", target_repo_name)
            if error_code == C_EVENT_ERROR_CODE_NO_REPO:
                generate_new_repo(regi_id=registry_id, repo_name=target_repo_name)
            else:
                logger.warning(
                    "Unexpected ERROR <%s> occured.", error_code
                )  # notifications can be utilized for future development

    return {"statusCode": 200, "body": json.dumps("SUCCEEDED: ECR Event Processor!")}


# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

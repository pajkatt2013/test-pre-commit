import logging
import os
from typing import Any, Dict, Optional

import aws_solutions_constructs.aws_eventbridge_lambda as eventbridge_lambda
import cdk_nag
from aws_cdk import Aspects, Aws, Duration, Stack, Tags
from aws_cdk import aws_ecr as ecr
from aws_cdk import aws_events as events
from aws_cdk import aws_iam as iam
from aws_cdk import aws_lambda
from constructs import Construct
from utils import LabelGenerator

IMAGE_MUTABILITY = {
    "IMMUTABLE": ecr.TagMutability.IMMUTABLE,
    "MUTABLE": ecr.TagMutability.MUTABLE,
}

_logger: logging.Logger = logging.getLogger(__name__)


class Lambda_ECR_Event_Stack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        construct_id: str,
        config: Dict[str, Any],
        lambda_func_name: str,
        tags: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # CDK Env Vars
        partition: str = Aws.PARTITION
        region: str = Aws.REGION

        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        for k, v in config.items():
            setattr(self, k, v)

        lambda_src_code_path = os.path.join(
            os.path.dirname(__file__), "src/event_processor"
        )

        # lg = LabelGenerator(prefix="app-raas", stage=stage, aws_env=kwargs["env"])
        lambda_ecr_event_processor_name = (
            f"app-raas-{self.deployment_name}-{self.module_name}-{lambda_func_name}"
        )

        event_detail_type = "AWS API Call via CloudTrail"
        event_source = "aws.ecr"
        event_detail = {
            "eventSource": ["ecr.amazonaws.com"],
            "eventName": ["InitiateLayerUpload", "PutImage"],
            # "errorCode": ["RepositoryNotFoundException"]
        }

        # event_bus_name = f"app-raas-{self.deployment_name}-{self.module_name}-eventbus"
        # event_bus = events.EventBus(self, "bus", event_bus_name=event_bus_name)

        event_bus_name = "default"
        event_bus = events.EventBus.from_event_bus_name(
            self, "event-bus", event_bus_name
        )

        self.eventbridge_lambda = eventbridge_lambda.EventbridgeToLambda(
            self,
            "eventbridge-lambda",
            lambda_function_props=aws_lambda.FunctionProps(
                function_name=lambda_ecr_event_processor_name,
                runtime=aws_lambda.Runtime.PYTHON_3_10,
                handler="main.lambda_handler",
                code=aws_lambda.Code.from_asset(lambda_src_code_path),
                environment={"REGION": self.region, "ECR_REG": ""},
                layers=[
                    aws_lambda.LayerVersion.from_layer_version_arn(
                        self,
                        "powertools-layer",
                        # Official AWS powertools layer per https://awslabs.github.io/aws-lambda-powertools-python/2.10.0/
                        f"arn:{partition}:lambda:{region}:017000801446:layer:AWSLambdaPowertoolsPythonV2:24",
                    )
                ],
                timeout=Duration.minutes(15),
                # memorySize=1024
            ),
            event_rule_props=events.RuleProps(
                description=f"Event rule for event processor {lambda_ecr_event_processor_name=} and event bus {event_bus.event_bus_name=}",
                event_pattern=events.EventPattern(
                    detail_type=[event_detail_type],
                    source=[event_source],
                    detail=event_detail,
                ),
            ),
            existing_event_bus_interface=event_bus,
        )

        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=[
                    "ecr:PutLifecyclePolicy",
                    "ecr:PutImageTagMutability",
                    "ecr:StartImageScan",
                    "ecr:GetLifecyclePolicyPreview",
                    "ecr:CreateRepository",
                    "ecr:DescribeRegistry",
                    "ecr:PutImageScanningConfiguration",
                    "ecr:UploadLayerPart",
                    "ecr:BatchDeleteImage",
                    "ecr:PutRegistryScanningConfiguration",
                    "ecr:CreatePullThroughCacheRule",
                    "ecr:PutImage",
                    "ecr:BatchImportUpstreamImage",
                    "ecr:CompleteLayerUpload",
                    "ecr:DescribeRepositories",
                    "ecr:StartLifecyclePolicyPreview",
                    "ecr:InitiateLayerUpload",
                    "ecr:ReplicateImage",
                    "ecr:PutReplicationConfiguration",
                ],
                resources=[
                    f"arn:{partition}:ecr:{region}:{self.target_realm_account_id}:repository/*"
                ],
                effect=iam.Effect.ALLOW,
            )
        )

        cdk_nag.NagSuppressions.add_resource_suppressions(
            self.eventbridge_lambda.lambda_function.role,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-IAM4",
                    reason="Lambda basic execution role allowing for cloudwatch logs",
                )
            ],
        )

        cdk_nag.NagSuppressions.add_stack_suppressions(
            self,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-IAM5",
                    reason="This lambda should get permission to execute DescribeRepositories on all repositories",
                )
            ],
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

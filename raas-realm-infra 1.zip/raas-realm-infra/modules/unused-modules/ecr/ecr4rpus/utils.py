class LabelGenerator:
    def __init__(
        self,
        *,
        prefix: str,
        aws_env: dict,
        namespace: str,
        stage: str,
        bu_name: str = None,
        delim: str = "-"
    ):
        self.prefix = prefix  # deployment_name := <deployment-prefix>-<deployment-suffix>    deployment-suffix := namespace
        self.bu_name = bu_name
        self.namespace = namespace
        self.stage = stage  # e.g. dev | int | prod
        self.region = aws_env.region
        self.account = aws_env.account
        self.delim = delim

    def get_label(
        self,
        resource_type: str,
        resource_name: str,
        delim: str = None,
        include_prefix=False,
        include_bu=False,
        include_region=False,
        include_namespace=False,
        include_stage=False,
        include_account=False,
        include_resource_type=False,
        replace_underline=True,
        replace_delim=True,
        replace_slash=True,
        lowercase_only=False,
    ):
        stageeqns = False
        if len(self.namespace.strip()) > 1:
            if self.stage.strip() == self.namespace.strip()[1:]:
                stageeqns = True

        if delim is None:
            delim = self.delim

        parts = []
        if include_prefix and self.prefix is not None:
            parts.append(self.prefix)
        if include_bu and self.bu_name is not None:
            parts.append(self.bu_name)
        if include_namespace and self.namespace is not None:
            parts.append(self.namespace.strip()[1:])
        if include_stage and not stageeqns:
            parts.append(self.stage)
        if include_region:
            parts.append(self.region)
        if include_account:
            parts.append(self.account)
        if include_resource_type:
            parts.append(resource_type)

        parts.append(resource_name)

        # Format [deployment_name with namespace or bu_name]-[stage]-[region]-[account]-[resource_type]-[resource_name]
        concatted_parts = delim.join(parts)
        if replace_underline:
            concatted_parts = concatted_parts.replace("_", delim)
        if replace_delim:
            concatted_parts = concatted_parts.replace(delim, "_")
        if replace_slash:
            concatted_parts = concatted_parts.replace("/", delim)
            concatted_parts = concatted_parts.replace("\\", delim)
        if concatted_parts.startswith("-"):
            concatted_parts = concatted_parts[1:]
        if lowercase_only:
            concatted_parts = str.lower(concatted_parts)
        return concatted_parts

"""This is lambda function can be triggered by event create new feature branch within a particular repository.
After the triggering the lambda function will create a codepipeline based on information from the trigger event,
like source repository name, the new feature branch name, and so on.
"""
import json
import logging
import os
import re

import boto3
from constants import *

# ------------------------------------------------------------------------------
# init logger
# ------------------------------------------------------------------------------
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# ------------------------------------------------------------------------------
# helper function
# ------------------------------------------------------------------------------
def get_eventName(event: dict):
    """
    This function gets the eventName of event CreateBranch

    Args:
      event: Dict - Lambda trigger event in JSON object

    Returns:
      eventName: str - the name of the CreateBranch event.
    """
    if C_EVENT_KEY_eventName in event:
        return event[C_EVENT_KEY_eventName]
    else:
        raise RuntimeError(
            f"[RuntimeError]: No Key {C_EVENT_KEY_eventName} found in event dictionary"
        )


# ------------------------------------------------------------------------------
def get_requestParameters(event: dict):
    """
    This function gets the relevant information for event CreateBranch

    Args:
      event: Dict - Lambda trigger event in JSON object

    Returns:
      requestParameters: dict - the element event.requestParameters in the CreateBranch event object.
    """
    if C_EVENT_KEY_requestParameters in event:
        return event[C_EVENT_KEY_requestParameters]
    else:
        raise RuntimeError(
            f"[RuntimeError]: No Key {C_EVENT_KEY_requestParameters} found in event dictionary"
        )


# ------------------------------------------------------------------------------
def get_requestParameters_repositoryName(requestParameters: dict):
    """
    This function gets the relevant information for event CreateBranch

    Args:
      requestParameters: dict - the element event.requestParameters in the CreateBranch event object.

    Returns:
      ret_repoName: str - the element event.requestParameters.repositoryName in the CreateBranch event object.
    """
    if C_EVENT_KEY_requestParameters_repositoryName in requestParameters:
        return requestParameters[C_EVENT_KEY_requestParameters_repositoryName]
    else:
        raise RuntimeError(
            f"[RuntimeError]: No Key {C_EVENT_KEY_requestParameters_repositoryName} found in requestParameters dictionary"
        )


# ------------------------------------------------------------------------------
def get_requestParameters_branchName(requestParameters: dict):
    """
    This function gets the relevant information for event CreateBranch

    Args:
      requestParameters: dict - the element event.requestParameters in the CreateBranch event object.

    Returns:
      ret_branchName: str - the element event.requestParameters.branchName in the CreateBranch event object.
    """
    if C_EVENT_KEY_requestParameters_branchName in requestParameters:
        return requestParameters[C_EVENT_KEY_requestParameters_branchName]
    else:
        raise RuntimeError(
            f"[RuntimeError]: No Key {C_EVENT_KEY_requestParameters_branchName} found in requestParameters dictionary"
        )


# ------------------------------------------------------------------------------
def get_event_resources(event: dict):
    """
    This function gets the relevant information for event CreateBranch

    Args:
      event: dict - Lambda trigger event in JSON object.

    Returns:
      resources: list - the element event.resources in the CreateBranch event object.
    """
    if C_EVENT_KEY_resources in event:
        return event[C_EVENT_KEY_resources]
    else:
        raise RuntimeError(
            f"[RuntimeError]: No Key {C_EVENT_KEY_resources} found in event dictionary"
        )


# ------------------------------------------------------------------------------
def get_event_resource_arn(resources: list, resouce_index: int):
    """
    This function gets the relevant information for event CreateBranch

    Args:
      resources: dict - Lambda trigger event in JSON object.
      resouce_index: int - element index in resources list.
    Returns:
      resource_arn: str - the element event.resources[index].arn in the CreateBranch event object.
    """
    return resources[resouce_index][C_EVENT_KEY_resources_arn]


# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
def get_list_iam_policy_names_arns(
    scope: str = "All",
    onlyAttached: bool = False,
    pathPrefix: str = "/",
    policyUsageFilter: str = "PermissionsPolicy",
    maxItems: int = 1000,
    policy_name_pattern: str = "",
):
    """
    Get the name and ARN pair list of the existing IAM policies, which match the policy name pattern.

    Args:
      scope: str - The scope of the IAM policies, possible values are {'All'|'AWS'|'Local'}, default value <'All'>.
      onlyAttached: bool - the flag parameter to filter the results to only the attached policies, default value <False>.
      pathPrefix: str - The path prefix for filtering the results, default value <'/'>.
      policyUsageFilter: str - The policy usage method to use for filtering the results, default value <'PermissionsPolicy'>.
      maxItems: int - Use this only when paginating results to indicate the maximum number of items you want in the response, max value 1000 as default value.
      policy_name_pattern: str - The policy name pattern to filter the results, default value '' (empty string) means no pattern, allow all names.

    Returns:
      list_policy_names_arns: list - The found policies with the filter.
    """
    # init iam client
    iam_client = boto3.client("iam")

    res_list_policies = iam_client.list_policies(
        Scope=scope,
        OnlyAttached=onlyAttached,
        PathPrefix=pathPrefix,
        PolicyUsageFilter=policyUsageFilter,
        # Marker='string',
        MaxItems=maxItems,
    )

    list_policies = res_list_policies[C_RESPONSE_KEY_list_Policies]
    # print("[DEBUG]:", list_policies)

    list_policy_names_arns = {}

    for policy in list_policies:
        if bool(
            re.match(policy_name_pattern, policy[C_RESPONSE_KEY_RolePolicy_PolicyName])
        ):
            list_policy_names_arns.update(
                {
                    policy[C_RESPONSE_KEY_RolePolicy_PolicyName]: policy[
                        C_RESPONSE_KEY_Arn
                    ]
                }
            )

    return list_policy_names_arns


# ------------------------------------------------------------------------------
def get_list_iam_roles(
    pathPrefix: str = "/",
    # marker: str = '',
    maxItems: int = 1000,
    role_name_pattern: str = "",
):
    """
    Get the existing IAM roles, which match the role name pattern.

    Args:
      pathPrefix: str - The path prefix for filtering the results, default value <'/'>.
      maxItems: int - Use this only when paginating results to indicate the maximum number of items you want in the response, max value 1000 as default value.
      role_name_pattern: str - The role name pattern to filter the results, default value '' (empty string) means no pattern, allow all names.

    Returns:
      dict_role_names_arns: list - The found roles with the filter.
    """
    # init iam client
    iam_client = boto3.client("iam")

    #
    res_list_roles = iam_client.list_roles(
        PathPrefix=pathPrefix,
        # Marker= marker,
        MaxItems=maxItems,
    )

    list_roles = res_list_roles[C_RESPONSE_KEY_list_Roles]

    dict_role_names_arns = {}
    for role in list_roles:
        if bool(re.match(role_name_pattern, role[C_RESPONSE_KEY_Role_RoleName])):
            dict_role_names_arns.update(
                {role[C_RESPONSE_KEY_Role_RoleName]: role[C_RESPONSE_KEY_Arn]}
            )

    return dict_role_names_arns


# ------------------------------------------------------------------------------
def create_if_not_exist_codebuild_iam_policy(
    policy_name: str,
    policy_doc: dict,
    policy_tags: list = [],
    policy_description: str = "",
):
    """
    Create the IAM policy with particular policy name and policy definition statement, if the policy with the same name does not exist.

    Args:
      policy_name: str - The policy name.
      policy_doc: dict - The policy definition statement.
      policy_tags: list - The tags for the policy.
      policy_description: str - The description of the IAM policy.

    Returns:
      dict_policy_names_arns: dict - The name and ARN pair of the new created policy.
    """
    existing_policy_names_arns = get_list_iam_policy_names_arns(
        scope="Local", policy_name_pattern=policy_name
    )
    # print(len(existing_policy_names_arns))
    # print("[Debug]:", existing_policy_names_arns)

    # init iam client
    iam_client = boto3.client("iam")
    #
    if policy_name not in existing_policy_names_arns:
        res_codepipeline_role_policy = iam_client.create_policy(
            PolicyName=policy_name,
            PolicyDocument=policy_doc,
            Description=policy_description,
            Tags=policy_tags,
        )
        logger.info(
            "Policy %s has been created.",
            C_NAME_PATTERN_codepipeline_iam_policy_sts_permissions,
        )
        return {
            policy_name: res_codepipeline_role_policy[C_RESPONSE_KEY_RolePolicy_Policy][
                C_RESPONSE_KEY_Arn
            ]
        }
    else:
        logger.info("The Policy with name <%s> does exist already.", policy_name)
        return {policy_name: existing_policy_names_arns[policy_name]}


# ------------------------------------------------------------------------------
def create_if_not_exist_codebuild_iam_role(
    role_name: str,
    assumeRolePolicyDocument: str,
    role_path: str = "/",
    role_Description: str = "",
    # role_PermissionsBoundary: str = None,
    role_tags: list = [],
):
    """
    Create a role for the codebuild, which defines the permissions.

    Args:
      role_name: str - The name of the role.
      assumeRolePolicyDocument: str - The trust relationship policy document that grants an entity permission to assume the role.
      role_path: str - The path to the role.
      role_Description: str - A description of the role.
      role_tags: list - A list of tags that you want to attach to the new role. Each tag consists of a key name and an associated value.
    Returns:
      response: dict - The new created or existing role name(as key) and arn(as value).
    """
    existing_roles = get_list_iam_roles(role_name_pattern=role_name)

    # init iam client
    iam_client = boto3.client("iam")

    #
    if role_name not in existing_roles:
        role = iam_client.create_role(
            Path=role_path,
            RoleName=role_name,
            AssumeRolePolicyDocument=assumeRolePolicyDocument,  # json.dumps(C_TRUST_POLICY_codebuild_role)
            Description=role_Description,
            # PermissionsBoundary= role_PermissionsBoundary,
            Tags=role_tags,
        )
        return {role_name: role[C_RESPONSE_KEY_Role][C_RESPONSE_KEY_Arn]}
    else:
        return {role_name: existing_roles[role_name]}


# ------------------------------------------------------------------------------
def add_policies_to_role(
    role_name: str, aws_policy_arns: list, custom_policy_arns: list
):
    """
    Attach the AWS managed policies and the custome managed policies to IAM role.

    Args:
      role_name: str - The name of the role.
      aws_policy_arns: list - The ARNs list of AWS managed policies.
      custom_policy_arns: list - The ARNs list of the custom managed policies.
    Returns:
      No return.
    """
    # init iam client
    iam_client = boto3.client("iam")

    #
    for ap in aws_policy_arns:
        res1 = iam_client.attach_role_policy(RoleName=role_name, PolicyArn=ap)
        logger.info("AWS managed policy %s is attached to %s", ap, role_name)
        logger.info(res1)

    #
    for cp in custom_policy_arns:
        res2 = iam_client.attach_role_policy(RoleName=role_name, PolicyArn=cp)
        logger.info("User managed policy %s is attached to %s", cp, role_name)
        logger.info(res2)


# ------------------------------------------------------------------------------
def get_existing_s3_buckets():
    """
    Get the existing s3 buckets within the same account.

    Args:
      No input parameter required.
    Returns:
      list_s3_names: list - The name list of existing s3 buckets.
    """
    # init iam client
    s3_client = boto3.client("s3")
    res_list_s3 = s3_client.list_buckets()

    list_s3_buckets = res_list_s3[C_RESPONSE_KEY_list_S3_Buckets]
    list_s3_names = [b[C_RESPONSE_KEY_Name] for b in list_s3_buckets]

    return list_s3_names


# ------------------------------------------------------------------------------
def create_if_not_exist_s3_bucket(
    bucket_name: str,
    createBucketConfiguration: dict,
    acl: str = "private",
    grantFullControl: str = "",
    grantRead: str = "",
    grantReadACP: str = "",
    grantWrite: str = "",
    grantWriteACP: str = "",
    objectLockEnabledForBucket: bool = False,
    objectOwnership: str = "BucketOwnerPreferred",
):
    """
    Create s3 bucket with specific name and configurations.

    Args:
      bucket_name: str - The name of the bucket to create.
      createBucketConfiguration: dict - The configuration information for the bucket.
      acl: str - The canned ACL to apply to the bucket. Default value 'private'.
      grantFullControl: str - Allows grantee the read, write, read ACP, and write ACP permissions on the bucket. Default value ''.
      grantRead: str -  Allows grantee to list the objects in the bucket. Default value ''.
      grantReadACP: str - Allows grantee to read the bucket ACL. Default value ''.
      grantWrite: str - Allows grantee to create new objects in the bucket. Default value ''.
      grantWriteACP: str - Allows grantee to write the ACL for the applicable bucket. Default value ''.
      objectLockEnabledForBucket: bool - Specifies whether you want S3 Object Lock to be enabled for the new bucket. Default value False.
      objectOwnership: str - The container element for object ownership for a bucket's ownership controls. Default value 'BucketOwnerPreferred'.
    Returns:
      bucket_name: str - if bucket does exist already. or res_create_s3_bucket_location: str - if new s3 bucket is created.
    """
    list_existing_buckets = get_existing_s3_buckets()

    if bucket_name not in list_existing_buckets:
        s3_client = boto3.client("s3")
        res_create_s3 = s3_client.create_bucket(
            ACL=acl,
            Bucket=bucket_name,
            CreateBucketConfiguration=createBucketConfiguration,
            GrantFullControl=grantFullControl,
            GrantRead=grantRead,
            GrantReadACP=grantReadACP,
            GrantWrite=grantWrite,
            GrantWriteACP=grantWriteACP,
            ObjectLockEnabledForBucket=objectLockEnabledForBucket,
            ObjectOwnership=objectOwnership,
        )
        return res_create_s3[C_RESPONSE_KEY_create_s3_bucket]
    else:
        return bucket_name


# ------------------------------------------------------------------------------
def generate_s3_bucket_name(
    name_pattern_s3_bucket: str,
    # repo_name: str,
    branch_name: str,
):
    """
    Generate the s3 bucket name with the input bucket name pattern and replace the invalid chars.

    Args:
      name_pattern_s3_bucket: str - The name pattern of the bucket to create.
      branch_name: str - The feature branch name from the trigger event.
    Returns:
      ret_bname: str - The valid bucket name.
    """
    ret_bname = name_pattern_s3_bucket % (branch_name)
    ret_bname = ret_bname.replace("_", "-")
    ret_bname = ret_bname.replace("/", "-")

    return ret_bname.lower()


# ------------------------------------------------------------------------------
def generate_cb_project_name(
    name_pattern_cb_project: str,
    # repo_name: str,
    branch_name: str,
):
    """
    Generate the codebuild project name with the input name pattern and replace the invalid chars.

    Args:
      name_pattern_cb_project: str - The name pattern of the bucket to create.
      branch_name: str - The feature branch name from the trigger event.
    Returns:
      ret_name: str - The valid bucket name.
    """
    ret_name = name_pattern_cb_project % (branch_name)
    ret_name = ret_name.replace("_", "-")
    ret_name = ret_name.replace("/", "-")

    return ret_name.lower()


# ------------------------------------------------------------------------------
def get_existing_codebuild_project():
    """
    Get the existing codebuild project within the same account.

    Args:
      No input parameter required.
    Returns:
      list_cb_project_names: list - The list of build project names.
    """
    cb_client = boto3.client("codebuild")
    res_list_cb_projects = cb_client.list_projects()
    return res_list_cb_projects[C_RESPONSE_KEY_list_cb_projects]


# ------------------------------------------------------------------------------
def create_if_not_exist_codebuild_project(
    cbp_name: str,
    cbp_source: dict,
    cbp_artifacts: dict,
    cbp_environment: dict,
    cbp_serviceRole: str,
    cbp_timeoutInMinutes: int = 360,
    cbp_queuedTimeoutInMinutes: int = 480,
    cbp_tags: list = C_TAGS_basic2,
):
    """
    Generate the codebuild project name with the input name pattern and replace the invalid chars.

    Args:
      cbp_name: str - The name of the build project.
      cbp_source: dict - A description that makes the build project easy to identify.
      cbp_artifacts: dict - Information about the build output artifacts for the build project.
      cbp_environment: dict - Information about the build environment for the build project.
      cbp_serviceRole: str - The ARN of the IAM role that enables CodeBuild to interact with dependent Amazon Web Services services on behalf of the Amazon Web Services account.
      cbp_timeoutInMinutes: int - How long, in minutes, from 5 to 480 (8 hours). Default value = 360.
      cbp_queuedTimeoutInMinutes: int -  The number of minutes a build is allowed to be queued before it times out. Default value = 480.
      cbp_tags: list - A list of tag key and value pairs associated with this build project. Default value = C_TAGS_basic2 from constants.py.
    Returns:
      response: dict - The response information of the codebuild project creation.
    """
    list_existing_cb_projects = get_existing_codebuild_project()

    if cbp_name not in list_existing_cb_projects:
        # init codebuild client
        cb_client = boto3.client("codebuild")

        #
        res_create_cb_project = cb_client.create_project(
            name=cbp_name,
            description="string",
            source=cbp_source,
            artifacts=cbp_artifacts,
            environment=cbp_environment,
            serviceRole=cbp_serviceRole,
            timeoutInMinutes=cbp_timeoutInMinutes,
            queuedTimeoutInMinutes=cbp_queuedTimeoutInMinutes,
            tags=cbp_tags,
        )
        logger.info("The codebuild project <%s> has been created", cbp_name)
        return res_create_cb_project
    else:
        logger.info("The codebuild project <%s> does exist already", cbp_name)
        return {"Response": "The codebuild project does exist already"}


# ------------------------------------------------------------------------------
def create_code_pipeline(pipeline_info: dict):
    """
    Create the codepipeline with the pipeline configuration.

    Args:
      pipeline_info: dict - The pipeline configuration.
    Returns:
      response: dict - The response information of the codepipeline creation.
    """
    codepipeline_client = boto3.client("codepipeline")
    response = codepipeline_client.create_pipeline(pipeline=pipeline_info)
    logger.info("Codepipeline has been created.")
    return response


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# lambda handler
# ------------------------------------------------------------------------------
def lambda_handler(event, context):
    print("[DEBUG]:", event)

    if C_EVENT_KEY_eventDetail in event:
        event = event[C_EVENT_KEY_eventDetail]

    selected_repo = os.environ.get(C_ENV_VAR_GIT_REPO_NAME)

    ename = get_eventName(event)
    logger.info("Event name is: %s", ename)

    params = get_requestParameters(event)
    logger.info("The RequestParameters of Event are: %s", params)

    repoName = get_requestParameters_repositoryName(params)
    logger.info("The RepositoryName of <CreateBranch> event is: %s", repoName)

    branch_name = get_requestParameters_branchName(params)
    logger.info("The branch name of <CreateBranch> event  is: %s", branch_name)

    if repoName == selected_repo:
        if branch_name.startswith(C_PREFIX_Branch_Feature):
            repoName = get_requestParameters_repositoryName(params)
            logger.info("The RepositoryName of <CreateBranch> event is: %s", repoName)

            event_resources = get_event_resources(event)
            logger.info("The resources of Event are: %s", event_resources)

            event_resource_arn = get_event_resource_arn(
                resources=event_resources, resouce_index=0
            )
            logger.info("The ResourceARN of Event is: %s", event_resource_arn)

            list_existing_cb_project = get_existing_codebuild_project()
            logger.info(
                "The Existing Codebuild projects are: %s", list_existing_cb_project
            )

            res_cb_policy = create_if_not_exist_codebuild_iam_policy(
                policy_name=C_NAME_PATTERN_codepipeline_iam_policy_sts_permissions,
                policy_doc=json.dumps(C_POLICY_sts_assumeRole),
                policy_tags=C_TAGS_basic1,
                policy_description="Policy for sts:permissions",
            )

            #
            res_cb_role = create_if_not_exist_codebuild_iam_role(
                role_name=C_NAME_PATTERN_codepipeline_iam_role,
                assumeRolePolicyDocument=json.dumps(C_TRUST_POLICY_codebuild_role),
                role_Description=f"IAM Role for the codepipeline related to repository: {repoName} - branch: {branch_name}",
                role_tags=C_TAGS_basic1,
            )
            logger.info(
                "IAM role %s has been created.", C_NAME_PATTERN_codepipeline_iam_role
            )

            #
            aws_managed_policies = [C_POLICY_ARN_AdministratorAccess]
            user_managed_policies = [
                res_cb_policy[C_NAME_PATTERN_codepipeline_iam_policy_sts_permissions]
            ]

            #
            add_policies_to_role(
                role_name=C_NAME_PATTERN_codepipeline_iam_role,
                aws_policy_arns=aws_managed_policies,
                custom_policy_arns=user_managed_policies,
            )
            logger.info(
                "The policies has been attached to the role %s.",
                C_NAME_PATTERN_codepipeline_iam_role,
            )

            source = {
                "type": "CODECOMMIT",
                "location": event_resource_arn,
            }

            artifacts = {
                "type": "NO_ARTIFACTS",
                # 'location': 'string',
                # 'path': 'string',
                # 'namespaceType': 'NONE|BUILD_ID',
                # 'name': 'string',
                # 'packaging': 'NONE|ZIP',
                # 'overrideArtifactName': 'True|False',
                # 'encryptionDisabled': 'True|False',
                # 'artifactIdentifier': 'string',
                # 'bucketOwnerAccess': 'NONE|READ_ONLY|FULL'
            }

            environment = {
                "type": "LINUX_CONTAINER",
                "image": "aws/codebuild/standard:6.0",
                "computeType": "BUILD_GENERAL1_MEDIUM",
            }

            cbpname = generate_cb_project_name(
                name_pattern_cb_project=C_NAME_PATTERN_cb_project,
                branch_name=branch_name,
            )
            cbpServiceRole = res_cb_role[C_NAME_PATTERN_codepipeline_iam_role]

            create_if_not_exist_codebuild_project(
                cbp_name=cbpname,
                cbp_source=source,
                cbp_artifacts=artifacts,
                cbp_environment=environment,
                cbp_serviceRole=cbpServiceRole,
            )

            cb_pipeline_stages = [
                {
                    "name": "source",
                    "actions": [
                        {
                            "name": "source",
                            "actionTypeId": {
                                "category": "Source",
                                "owner": "AWS",
                                "provider": "CodeCommit",
                                "version": "1",
                            },
                            "configuration": {
                                "RepositoryName": repoName,
                                "BranchName": branch_name,
                            },
                            "outputArtifacts": [
                                {"name": "Artifact_Source_Source"},
                            ],
                        },
                    ],
                },
                {
                    "name": "build",
                    "actions": [
                        {
                            "name": "build",
                            "actionTypeId": {
                                "category": "Build",
                                "owner": "AWS",
                                "provider": "CodeBuild",
                                "version": "1",
                            },
                            "configuration": {"ProjectName": cbpname},
                            "inputArtifacts": [
                                {"name": "Artifact_Source_Source"},
                            ],
                        },
                    ],
                },
            ]

            bname = generate_s3_bucket_name(
                name_pattern_s3_bucket=C_NAME_PATTERN_codepipeline_s3_bucket,
                # repo_name = repoName,
                branch_name=branch_name,
            )
            logger.info("The codepipeline S3 bucket is %s", bname)

            res_creat_bucket = create_if_not_exist_s3_bucket(
                bucket_name=bname, createBucketConfiguration=C_BUCKET_configuration
            )
            logger.info("The codepipeline S3 bucket <%s> has been created.", bname)

            cb_artifactStore = {"type": "S3", "location": bname}

            cb_pipeline = {
                "name": bname,
                "roleArn": res_cb_role[C_NAME_PATTERN_codepipeline_iam_role],
                "artifactStore": cb_artifactStore,
                "stages": cb_pipeline_stages,
            }

            codebuild_pipeline = create_code_pipeline(pipeline_info=cb_pipeline)
            logger.info("The codepipeline has been created: %s", codebuild_pipeline)

        else:
            logger.info(
                "The <CreatBranch> event is unrelated to feature branch, no additional action is necessary."
            )
    else:
        logger.info(
            "The <CreatBranch> event is unrelated to repository <%s>, no additional action is necessary.",
            selected_repo,
        )
    # ----------------------------------------------------------------------------
    #
    # ----------------------------------------------------------------------------
    return {"statusCode": 200, "body": json.dumps("SUCCEEDED: codepipline creator")}


# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Constants
# ------------------------------------------------------------------------------
C_ENV_VAR_GIT_REPO_NAME = "GIT_REPO_NAME"

# ------------------------------------------------------------------------------
C_EVENT_KEY_eventDetail = "detail"

C_EVENT_KEY_eventName = "eventName"
C_EVENT_KEY_requestParameters = "requestParameters"
C_EVENT_KEY_requestParameters_repositoryName = "repositoryName"
C_EVENT_KEY_requestParameters_branchName = "branchName"

C_EVENT_KEY_resources = "resources"
C_EVENT_KEY_resources_arn = "ARN"

C_RESPONSE_KEY_Role = "Role"
C_RESPONSE_KEY_Role_RoleName = "RoleName"
C_RESPONSE_KEY_Arn = "Arn"

C_RESPONSE_KEY_list_Roles = "Roles"
C_RESPONSE_KEY_list_Policies = "Policies"
C_RESPONSE_KEY_RolePolicy_Policy = "Policy"
C_RESPONSE_KEY_RolePolicy_PolicyName = "PolicyName"

C_RESPONSE_KEY_list_S3_Buckets = "Buckets"
C_RESPONSE_KEY_Name = "Name"
C_RESPONSE_KEY_create_s3_bucket = "Location"

C_RESPONSE_KEY_list_cb_projects = "projects"

# ------------------------------------------------------------------------------
C_PREFIX_Branch_Reference = "refs/heads/"
C_PREFIX_Branch_Feature = "feature/"

# ------------------------------------------------------------------------------
C_POLICY_ARN_AdministratorAccess = "arn:aws:iam::aws:policy/AdministratorAccess"

C_TRUST_POLICY_codebuild_role = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {"Service": "codepipeline.amazonaws.com"},
            "Action": "sts:AssumeRole",
        },
        {
            "Effect": "Allow",
            "Principal": {"Service": "codebuild.amazonaws.com"},
            "Action": "sts:AssumeRole",
        },
    ],
}

C_POLICY_sts_assumeRole = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "stsPermissions",
            "Effect": "Allow",
            "Action": [
                "sts:GetSessionToken",
                "sts:AssumeRole",
                "sts:TagSession",
                "sts:GetFederationToken",
                "sts:GetAccessKeyInfo",
                "sts:GetCallerIdentity",
                "sts:GetServiceBearerToken",
            ],
            "Resource": "*",
        }
    ],
}

# ------------------------------------------------------------------------------
C_NAME_PATTERN_codepipeline_iam_role = f"raas_app_codepipeline_iam_role_101"
C_NAME_PATTERN_codepipeline_iam_policy_sts_permissions = (
    f"raas_app_codepipeline_role_policy_sts_permissions_101"
)

C_TAGS_basic1 = [
    {"Key": "owner", "Value": "raas"},
    {"Key": "deployment", "Value": "cicd"},
]

C_TAGS_basic2 = [
    {"key": "owner", "value": "raas"},
    {"key": "deployment", "value": "cicd"},
]


# ------------------------------------------------------------------------------
C_NAME_PATTERN_cb_project = "raas-app-cbp-%s"

# ------------------------------------------------------------------------------
C_ARN_PREFIX_s3_bucket = "arn:aws:s3:::"
C_NAME_PATTERN_codepipeline_s3_bucket = "raas-pipeline-%s"

C_BUCKET_configuration = {
    "LocationConstraint": "eu-central-1",
}

# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

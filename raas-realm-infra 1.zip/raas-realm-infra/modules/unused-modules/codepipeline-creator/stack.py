import logging
import os
from typing import Any, Dict, Optional

import aws_solutions_constructs.aws_eventbridge_lambda as eventbridge_lambda
import cdk_nag
from aws_cdk import Aspects, Aws, Duration, Stack, Tags
from aws_cdk import aws_ecr as ecr
from aws_cdk import aws_events as events
from aws_cdk import aws_iam as iam
from aws_cdk import aws_lambda
from constructs import Construct
from utils import LabelGenerator

IMAGE_MUTABILITY = {
    "IMMUTABLE": ecr.TagMutability.IMMUTABLE,
    "MUTABLE": ecr.TagMutability.MUTABLE,
}

_logger: logging.Logger = logging.getLogger(__name__)


C_TAGS_basic1 = [
    {"Key": "owner", "Value": "raas"},
    {"Key": "deployment", "Value": "cicd"},
]


class Lambda_CodepipelineCreator_Stack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        construct_id: str,
        config: Dict[str, Any],
        lambda_func_name: str,
        git_repo_name: str,
        tags: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # CDK Env Vars
        partition: str = Aws.PARTITION
        region: str = Aws.REGION

        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        for k, v in config.items():
            setattr(self, k, v)

        lambda_src_code_path = os.path.join(
            os.path.dirname(__file__), "src/codepipeline_creator"
        )

        # lg = LabelGenerator(prefix="app-raas", stage=stage, aws_env=kwargs["env"])
        # lambda_codepipeline_creator_name = f"app-raas-{self.deployment_name}-{self.module_name}-{lambda_func_name}"
        lambda_codepipeline_creator_name = (
            f"app-raas-{self.deployment_name}-{lambda_func_name}"
        )
        event_detail_type = "AWS API Call via CloudTrail"
        event_source = "aws.codecommit"
        event_detail = {
            "eventSource": ["codecommit.amazonaws.com"],
            "eventName": ["CreateBranch"],
        }

        event_bus_name = "default"
        event_bus = events.EventBus.from_event_bus_name(
            self, "event-bus", event_bus_name
        )

        self.eventbridge_lambda = eventbridge_lambda.EventbridgeToLambda(
            self,
            "eventbridge-lambda",
            lambda_function_props=aws_lambda.FunctionProps(
                function_name=lambda_codepipeline_creator_name,
                runtime=aws_lambda.Runtime.PYTHON_3_10,
                handler="main.lambda_handler",
                code=aws_lambda.Code.from_asset(lambda_src_code_path),
                environment={"REGION": self.region, "GIT_REPO_NAME": git_repo_name},
                timeout=Duration.minutes(15),
                memory_size=1024,
                # tags = C_TAGS_basic1
            ),
            event_rule_props=events.RuleProps(
                description=f"Event rule for event processor {lambda_codepipeline_creator_name} and event bus {event_bus.event_bus_name}",
                event_pattern=events.EventPattern(
                    detail_type=[event_detail_type],
                    source=[event_source],
                    detail=event_detail,
                ),
            ),
            existing_event_bus_interface=event_bus,
        )

        lambda_permissions_sts = {
            "Effect": "Allow",
            "Action": ["sts:AssumeRole"],
            "Resource": "*",
        }
        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement.from_json(lambda_permissions_sts)
        )

        lambda_permissions_iam = {
            "Effect": "Allow",
            "Action": [
                "iam:PutRolePolicy",
                "iam:CreatePolicyVersion",
                "iam:SetDefaultPolicyVersion",
                "iam:AttachRolePolicy",
                "iam:UpdateAssumeRolePolicy",
                "iam:PutRolePermissionsBoundary",
                "iam:UpdateRole",
                "iam:GetRole",
                "iam:CreatePolicy",
                "iam:TagRole",
                "iam:PassRole",
                "iam:CreateRole",
                "iam:TagPolicy",
                "iam:GetPolicy",
                "iam:ListPolicies",
                "iam:ListRoles",
            ],
            "Resource": [
                f"arn:{partition}:iam::{self.target_realm_account_id}:policy/*",
                f"arn:{partition}:iam::{self.target_realm_account_id}:role/*",
            ],
        }
        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement.from_json(lambda_permissions_iam)
        )

        lambda_permissions_codepipeline = {
            "Effect": "Allow",
            "Action": [
                "codepipeline:GetPipelineState",
                "codepipeline:GetPipeline",
                "codepipeline:CreatePipeline",
                "codepipeline:ListPipelines",
            ],
            "Resource": f"arn:{partition}:codepipeline:eu-central-1:{self.target_realm_account_id}:*",
        }
        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement.from_json(lambda_permissions_codepipeline)
        )

        lambda_permissions_codebuild = {
            "Effect": "Allow",
            "Action": [
                "codebuild:ListProjects",
                "codebuild:CreateProject",
            ],
            "Resource": "*",
        }
        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement.from_json(lambda_permissions_codebuild)
        )

        lambda_permissions_s3 = {
            "Effect": "Allow",
            "Action": [
                "s3:BypassGovernanceRetention",
                "s3:CreateBucket",
                "s3:DescribeJob",
                "s3:GetBucketAcl",
                "s3:GetBucketCORS",
                "s3:GetBucketLocation",
                "s3:GetBucketLogging",
                "s3:GetBucketNotification",
                "s3:GetBucketObjectLockConfiguration",
                "s3:GetBucketOwnershipControls",
                "s3:GetBucketPolicy",
                "s3:GetBucketPolicyStatus",
                "s3:GetBucketPublicAccessBlock",
                "s3:GetBucketTagging",
                "s3:GetBucketVersioning",
                "s3:GetMetricsConfiguration",
                "s3:InitiateReplication",
                "s3:ListAllMyBuckets",
                "s3:ListBucket",
                "s3:ListBucketMultipartUploads",
                "s3:ListBucketVersions",
                "s3:PutBucketAcl",
                "s3:PutBucketCORS",
                "s3:PutBucketLogging",
                "s3:PutBucketNotification",
                "s3:PutBucketObjectLockConfiguration",
                "s3:PutBucketOwnershipControls",
                "s3:PutBucketPolicy",
                "s3:PutBucketPublicAccessBlock",
                "s3:PutBucketRequestPayment",
                "s3:PutBucketTagging",
                "s3:PutBucketVersioning",
                "s3:PutEncryptionConfiguration",
                "s3:PutIntelligentTieringConfiguration",
                "s3:PutInventoryConfiguration",
                "s3:PutJobTagging",
                "s3:PutLifecycleConfiguration",
                "s3:PutMetricsConfiguration",
                "s3:PutMultiRegionAccessPointPolicy",
                "s3:PutObjectAcl",
                "s3:PutObjectRetention",
                "s3:PutObjectTagging",
                "s3:PutObjectVersionAcl",
                "s3:PutObjectVersionTagging",
                "s3:PutReplicationConfiguration",
                "s3:PutStorageLensConfiguration",
                "s3:PutStorageLensConfigurationTagging",
                "s3:ReplicateTags",
            ],
            "Resource": f"arn:{partition}:s3:::*",
        }
        self.eventbridge_lambda.lambda_function.add_to_role_policy(
            iam.PolicyStatement.from_json(lambda_permissions_s3)
        )

        cdk_nag.NagSuppressions.add_resource_suppressions(
            self.eventbridge_lambda.lambda_function.role,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-IAM4",
                    reason="Lambda basic execution role allowing for cloudwatch logs",
                )
            ],
        )

        cdk_nag.NagSuppressions.add_stack_suppressions(
            self,
            [
                cdk_nag.NagPackSuppression(
                    id="AwsSolutions-IAM5",
                    reason="This lambda should get permission to execute DescribeRepositories on all repositories",
                )
            ],
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

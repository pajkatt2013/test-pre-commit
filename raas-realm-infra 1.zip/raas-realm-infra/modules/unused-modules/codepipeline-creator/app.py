#!/usr/bin/env python3
import json
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import Lambda_CodepipelineCreator_Stack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
app_prefix = f"app-raas-{deployment_name}-{module_name}"

target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "target_realm_account_id": target_realm_account_id,
}

DEFAULT_LAMBDA_NAME = "default-codepipeline-creator"
lambda_name = os.getenv(_param("LAMBDA_NAME"), DEFAULT_LAMBDA_NAME)

DEFAULT_GIT_REPO_NAME = "raas-seedfarmer-modules"
git_repo_name = os.getenv(_param("GIT_REPO_NAME"), DEFAULT_GIT_REPO_NAME)

app = cdk.App()
stack = Lambda_CodepipelineCreator_Stack(
    scope=app,
    construct_id=app_prefix,
    stage=os.getenv("STAGE", "default"),
    env=environment,
    config=config,
    lambda_func_name=lambda_name,
    git_repo_name=git_repo_name,
    tags=tag_list,
)

CfnOutput(
    stack,
    "LambdaFunctionARN",
    value=stack.eventbridge_lambda.lambda_function.function_arn,
)

app.synth()

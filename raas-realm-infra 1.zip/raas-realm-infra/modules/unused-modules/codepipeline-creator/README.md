# Lambda Codepipeline Creator

## Description

This module creates codepipeline for the application, for that if feature branch is created.

## Inputs/Outputs

### Input Parameters

#### Required

None

#### Optional

- `lambda-name`: Partial name of the lambda function, it is combined with a label generator to generate a unique name among deployments. Default value = "default-codepipeline-creator".

- `git-repo-name`: Git repository name, in that the feature branch located. Default value = "raas-seedfarmer-modules".
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.

### Module Metadata Outputs

- `LambdaFunctionARN`: The ARN of the Lambda Function

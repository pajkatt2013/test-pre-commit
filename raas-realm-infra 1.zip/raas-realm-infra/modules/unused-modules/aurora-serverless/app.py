import json
import os
import sys

import aws_cdk
from aws_cdk import App, CfnOutput
from stack import AuroraServerlessStack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

# ADDF vars
deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")

# target_realm_account_id = os.getenv("AWS_ACCOUNT_ID", "")
stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")

vpc_id = os.getenv(_param("VPC_ID"))
private_subnet_ids = json.loads(os.getenv(_param("PRIVATE_SUBNET_IDS")))
cluster_name = os.getenv(_param("CLUSTER_NAME"))
sg_name = os.getenv(_param("SG_NAME"))
database_name = os.getenv(_param("DATABASE_NAME"))
table_name = os.getenv(_param("TABLE_NAME"))

namespace = os.getenv(_param("NAMESPACE"), "")
DBIamRoleName = os.getenv(_param("IAM_ROLE_NAME"), "")

app = App()

stack = AuroraServerlessStack(
    scope=app,
    id=f"addf-{deployment_name}-{module_name}",
    stage=stage,
    namespace=namespace,
    deployment_name=deployment_name,
    module_name=module_name,
    vpc_id=vpc_id,
    private_subnet_ids=private_subnet_ids,
    database_name=database_name,
    cluster_name=cluster_name,
    sg_name=sg_name,
    table_name=table_name,
    iam_role_name=DBIamRoleName,
    env=aws_cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ["CDK_DEFAULT_REGION"],
    ),
    tags=tag_list,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "DBClusterId": stack.db_cluster.cluster_identifier,
            "TableName": stack.table_name,
            "DBClusterSecretArn": stack.db_cluster.secret.secret_arn,
            "DBSecurityGroupId": stack.db_security_group.security_group_id,
        }
    ),
)


app.synth(force=True)

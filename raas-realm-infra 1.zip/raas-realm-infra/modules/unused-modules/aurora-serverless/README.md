# Aurora serverless

## Description

This module creates a serverless Aurora cluster with a Postgres engine with an IAM role for access to the DB cluster


## Inputs/Outputs

### Input Paramenters

#### Required

- `vpc-id`: VPC Id where the Aurora cluster will be deployed
- `private-subnet-ids`: List of Private Subnets Ids where the Aurora cluster will be deployed
- `cluster-name`: Name of the table created in the database
- `sg-name`: Name of the security group to be associated with the DB cluster
- `database-name`: Name of the database created inside the Aurora cluster
- `table-name`: Name of the table created in the database
- `iam-role-name`: IAM role name, which will be created by this module to provide access to the DB cluster
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.



#### Input Example
```yaml
parameters:
parameters:
  - name: vpc-id
    valueFrom:
      parameterStore: /orionadp/blueprint/vpc/network-awsrouted-vpc/vpc-id
  - name: private-subnet-ids
    valueFrom:
      parameterStore: /orionadp/blueprint/vpc/network-awsrouted-vpc/private-subnets
  - name: database-name
    value: testdb
  - name: table-name
    value: testtable


```

### Module Metadata Outputs

- `DBClusterId`: name of the S3 Bucket configured to store MWAA Environment DAG artifacts
- `TableName`: name of the path in the S3 Bucket configured to store MWAA Environment DAG artifacts
- `DBClusterSecretArn`: ARN of the MWAA Execution Role created by the Stack
- `DBSecurityGroupId`: Id of the security group of the cluster

#### Output Example

```json
{
    "DBClusterId": "",
    "TableName": "",
    "DBClusterSecretArn": "",
    "DBSecurityGroupId": ""
}
```

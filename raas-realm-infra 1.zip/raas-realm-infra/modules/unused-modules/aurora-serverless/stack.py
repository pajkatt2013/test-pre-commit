import os
from typing import Any, Dict, List, Optional, cast

import aws_cdk
import aws_cdk.aws_ecr as ecr
import cdk_nag
from aws_cdk import Aspects, CfnOutput, Duration, RemovalPolicy, Stack, StackProps, Tags
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_iam as iam
from aws_cdk import aws_rds as rds
from aws_cdk import custom_resources as cr
from cdk_nag import NagPackSuppression, NagSuppressions
from constructs import Construct, IConstruct
from utils import LabelGenerator


class AuroraServerlessStack(Stack):
    def __init__(
        self,
        scope: Construct,
        stage: str,
        deployment_name: str,
        module_name: str,
        namespace: str,
        id: str,
        *,
        vpc_id: str,
        private_subnet_ids: list,
        database_name: str,
        cluster_name: str,
        sg_name: str,
        table_name: str,
        iam_role_name: str,
        tags: list,
        **kwargs: Any,
    ) -> None:
        # ADDF Env vars
        self.deployment_name = deployment_name
        self.module_name = module_name
        self.table_name = table_name
        # CDK Env Vars
        partition: str = aws_cdk.Aws.PARTITION
        region: str = aws_cdk.Aws.REGION
        account: str = aws_cdk.Aws.ACCOUNT_ID

        super().__init__(
            scope,
            id,
            description="This stack deploys serverless cluster with Postgres",
            **kwargs,
        )

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        add_tag("Deployment", self.deployment_name)
        add_tag("Module", self.module_name)
        for kv in tags:
            add_tag(kv["key"], kv["value"])

        lg = LabelGenerator(
            prefix=deployment_name,
            namespace=namespace,
            stage=stage,
            aws_env=kwargs["env"],
        )

        self.vpc = ec2.Vpc.from_lookup(
            self,
            "VPC",
            vpc_id=vpc_id,
        )
        self.private_subnets = []
        for idx, subnet_id in enumerate(private_subnet_ids):
            self.private_subnets.append(
                ec2.Subnet.from_subnet_id(
                    scope=self, id=f"subnet{idx}", subnet_id=subnet_id
                )
            )

        # Create a Serverless Cluster
        db_security_group_name = lg.get_label(
            resource_type="sg",
            resource_name=sg_name,
            include_stage=True,
            include_region=True,
            include_resource_type=True,
        )

        self.db_security_group = ec2.SecurityGroup(
            self,
            db_security_group_name,
            security_group_name=db_security_group_name,
            vpc=self.vpc,
            allow_all_outbound=False,
        )

        cluster_id_name = lg.get_label(
            resource_type="db",
            resource_name=cluster_name,
            include_stage=True,
            include_resource_type=True,
        )

        self.db_cluster = rds.ServerlessCluster(
            self,
            cluster_id_name,
            engine=rds.DatabaseClusterEngine.aurora_postgres(
                version=rds.AuroraPostgresEngineVersion.VER_13_6
            ),
            cluster_identifier=cluster_id_name,
            parameter_group=rds.ParameterGroup.from_parameter_group_name(
                self, "ParameterGroup", "default.aurora-postgresql13"
            ),
            enable_data_api=True,
            default_database_name=database_name,
            security_groups=[self.db_security_group],
            vpc=self.vpc,
            vpc_subnets=ec2.SubnetSelection(subnets=self.private_subnets),
            removal_policy=RemovalPolicy.DESTROY,
        )

        create_table_name = lg.get_label(
            resource_type="table",
            resource_name=table_name,
            include_stage=True,
            include_resource_type=True,
            include_region=True,
        )

        create_table = cr.AwsCustomResource(
            self,
            create_table_name,
            on_create=cr.AwsSdkCall(
                service="RDSDataService",
                action="executeStatement",
                physical_resource_id=cr.PhysicalResourceId.of(
                    self.db_cluster.cluster_identifier
                ),
                parameters={
                    "resourceArn": self.db_cluster.cluster_arn,
                    "secretArn": self.db_cluster.secret.secret_arn,
                    "sql": f"CREATE TABLE {self.table_name} (col1 VARCHAR (250), col2 VARCHAR (250));",
                    "database": database_name,
                },
            ),
            policy=cr.AwsCustomResourcePolicy.from_sdk_calls(
                resources=cr.AwsCustomResourcePolicy.ANY_RESOURCE
            ),
        )

        # Add dependency and grant permissions
        create_table.node.add_dependency(self.db_cluster)
        self.db_cluster.secret.grant_read(create_table)

        # # Allow traffic to the database from within the cluster
        # self.db_cluster.connections.allow_default_port_from(
        #     self.db_cluster,
        #     "Allow traffic on 5432 for any resource with this sec grp attached",
        # )

        # Creates IAM role for Aurora postgres
        db_role_name = lg.get_label(
            resource_type="role",
            resource_name=iam_role_name,
            include_stage=True,
            include_resource_type=True,
        )

        db_role = iam.Role(
            self,
            db_role_name,
            role_name=db_role_name,
            assumed_by=iam.AccountRootPrincipal(),
        )

        db_role_policy_statement_json_1 = {
            "Effect": "Allow",
            "Action": [
                "rds:Describe*",
                "rds:StartDBCluster",
                "rds:AddRoleToDBCluster",
                "rds:RemoveRoleFromDBCluster",
                "rds:FailoverDBCluster",
                "rds:RebootDBCluster",
                "rds:ApplyPendingMaintenanceAction",
                "rds:BacktrackDBCluster",
                "rds:CreateDBClusterEndpoint",
                "rds:ModifyDBClusterEndpoint",
                "rds:StopDBCluster",
                "rds:RestoreDBClusterFromS3",
                "rds:ModifyDBCluster",
                "rds:CreateDBClusterSnapshot",
                "rds:PromoteReadReplicaDBCluster",
                "rds:RestoreDBClusterFromSnapshot",
                "rds:ModifyCurrentDBClusterCapacity",
                "rds:RestoreDBClusterToPointInTime",
                "rds:CreateDBClusterParameterGroup",
                "rds:ModifyDBClusterParameterGroup",
                "rds:AddTagsToResource",
                "rds:ListTagsForResource",
                "rds:RemoveTagsFromResource",
                "rds:StartActivityStream",
                "rds:ModifyActivityStream",
                "rds:StopActivityStream",
                "rds:CreateDBInstance",
                "rds:StartDBInstance",
                "rds:StopDBInstance",
                "rds:CreateDBInstanceReadReplica",
                "rds:CreateDBParameterGroup",
                "rds:CreateDBSecurityGroup",
                "rds:CreateDBSnapshot",
                "rds:CreateDBSubnetGroup",
                "rds:CreateEventSubscription",
                "rds:AuthorizeDBSecurityGroupIngress",
                "rds:RevokeDBSecurityGroupIngress",
                "rds:ModifyCertificates",
                "rds:AddSourceIdentifierToSubscription",
            ],
            "Resource": [
                f"arn:{partition}:rds:{region}:{account}:cluster:{self.db_cluster.cluster_identifier}"
            ],
        }

        db_role.add_to_principal_policy(
            iam.PolicyStatement.from_json(db_role_policy_statement_json_1)
        )

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

        suppressions = [
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-SMG4",
                    "reason": "The secret does not have automatic rotation scheduled",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-RDS6",
                    "reason": "The RDS Aurora MySQL/PostgresSQL cluster does not have IAM Database Authentication enabled",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-RDS10",
                    "reason": "The RDS instance or Aurora DB cluster does not have deletion protection enabled",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-RDS11",
                    "reason": "The RDS instance or Aurora DB cluster uses the default endpoint port",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-RDS15",
                    "reason": "The RDS DB instance or Aurora DB cluster does not have deletion protection enabled",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-IAM4",
                    "reason": "The IAM user, role, or group uses AWS managed policies",
                }
            ),
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-IAM5",
                    "reason": "The IAM entity contains wildcard permissions",
                }
            ),
        ]

        NagSuppressions.add_stack_suppressions(self, suppressions)

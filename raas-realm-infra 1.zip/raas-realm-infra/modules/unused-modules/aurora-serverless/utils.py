class LabelGenerator:
    def __init__(
        self,
        *,
        prefix: str,
        aws_env: dict,
        namespace: str,
        stage: str,
        delim: str = "-"
    ):
        self.prefix = prefix  # deployment_name := <deployment-prefix>-<deployment-suffix>    deployment-suffix := namespace
        self.namespace = namespace
        self.stage = stage  # e.g. dev | int | prod
        self.region = aws_env.region
        self.account = aws_env.account
        self.delim = delim

    def get_label(
        self,
        resource_type: str,
        resource_name: str,
        delim: str = None,
        include_region=False,
        include_stage=False,
        include_account=False,
        include_resource_type=False,
    ):
        stageeqns = False
        if len(self.namespace.strip()) > 1:
            if self.stage.strip() == self.namespace.strip()[1:]:
                stageeqns = True

        if delim is None:
            delim = self.delim
        parts = [self.prefix]

        if include_stage and not stageeqns:
            parts.append(self.stage)
        if include_region:
            parts.append(self.region)
        if include_account:
            parts.append(self.account)
        if include_resource_type:
            parts.append(resource_type)

        parts.append(resource_name)

        # Format [deployment_name with namespace]-[stage]-[region]-[account]-[resource_type]-[resource_name]
        return self.delim.join(parts).replace("_", self.delim)

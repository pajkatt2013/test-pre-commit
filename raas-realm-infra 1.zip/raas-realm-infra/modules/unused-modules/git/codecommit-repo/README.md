# CodeCommit repo creator

## Description

This module creates CodeCommit repository in an automated way

## Inputs/Outputs

### Input Parameters

#### Required

None

#### Optional

- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.

### Module Metadata Outputs

- `CodeCommitRepositoryUrl`: The URL of the CodeCommit repositoy

from aws_cdk import CfnOutput, Stack, Tags
from aws_cdk import aws_codecommit as codecommit
from aws_cdk import aws_iam as iam
from constructs import Construct


class CodecommitRepoStack(Stack):
    def __init__(
        self, scope: Construct, construct_id: str, tags: list, **kwargs
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        # Creates a CodeCommit repository
        repo = codecommit.Repository(
            self,
            "CICD_CodeCommitRepo",
            repository_name="CICD_CodeCommitRepo",
            description="Repository for my application code and infrastructure",
        )

        CfnOutput(self, "CodeCommitRepositoryUrl", value=repo.repository_clone_url_http)

        # Creates IAM role for allowing direct pushes only to features branches for CodeCommit module
        codecommit_role = iam.Role(
            self, "codecommit_restricted_role", assumed_by=iam.AccountRootPrincipal()
        )

        codecommit_restricted_role_policy_statement_json_1 = {
            "Effect": "Allow",
            "Action": [
                "codecommit:AssociateApprovalRuleTemplateWithRepository",
                "codecommit:BatchAssociateApprovalRuleTemplateWithRepositories",
                "codecommit:BatchDisassociateApprovalRuleTemplateFromRepositories",
                "codecommit:BatchGet*",
                "codecommit:BatchDescribe*",
                "codecommit:Create*",
                "codecommit:DeleteBranch",
                "codecommit:DeleteFile",
                "codecommit:Describe*",
                "codecommit:DisassociateApprovalRuleTemplateFromRepository",
                "codecommit:EvaluatePullRequestApprovalRules",
                "codecommit:Get*",
                "codecommit:List*",
                "codecommit:Merge*",
                "codecommit:OverridePullRequestApprovalRules",
                "codecommit:Put*",
                "codecommit:Post*",
                "codecommit:TagResource",
                "codecommit:Test*",
                "codecommit:UntagResource",
                "codecommit:Update*",
                "codecommit:GitPull",
                "codecommit:GitPush",
            ],
            "Resource": [
                "arn:aws:codecommit:eu-central-1:503803885491:raas-seedfarmer-modules",
                "arn:aws:codecommit:eu-central-1:503803885491:CICD_CodeCommitRepo",
            ],
        }

        codecommit_restricted_role_policy_statement_json_2 = {
            "Effect": "Deny",
            "Action": [
                "codecommit:GitPush",
                "codecommit:DeleteBranch",
                "codecommit:PutFile",
                "codecommit:MergeBranchesByFastForward",
                "codecommit:MergeBranchesBySquash",
                "codecommit:MergeBranchesByThreeWay",
                "codecommit:MergePullRequestByFastForward",
                "codecommit:MergePullRequestBySquash",
                "codecommit:MergePullRequestByThreeWay",
            ],
            "Resource": [
                "arn:aws:codecommit:eu-central-1:503803885491:raas-seedfarmer-modules",
                "arn:aws:codecommit:eu-central-1:503803885491:CICD_CodeCommitRepo",
            ],
            "Condition": {
                "StringEqualsIfExists": {
                    "codecommit:References": [
                        "refs/heads/main",
                        "refs/heads/dev",
                        "refs/heads/int",
                        "refs/heads/prod",
                    ]
                },
                "Null": {"codecommit:References": "false"},
            },
        }

        codecommit_role.add_to_principal_policy(
            iam.PolicyStatement.from_json(
                codecommit_restricted_role_policy_statement_json_1
            )
        )
        codecommit_role.add_to_principal_policy(
            iam.PolicyStatement.from_json(
                codecommit_restricted_role_policy_statement_json_2
            )
        )

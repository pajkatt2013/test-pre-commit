import json
import uuid
from typing import Any, Dict, Optional

import cdk_nag
from aws_cdk import Aspects, Duration, RemovalPolicy, Stack, Tags
from aws_cdk import aws_secretsmanager as secretsmanager
from constructs import Construct
from utils import LabelGenerator


class SecretGeneration(Stack):
    def __init__(
        self,
        scope: Construct,
        id: str,
        config: Dict[str, Any],
        **kwargs,
    ) -> None:
        super().__init__(
            scope,
            id,
            description="This stack deploys the secret in Secret Manager",
            **kwargs,
        )

        for k, v in config.items():
            setattr(self, k, v)
        tags = self.tag_list
        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        lg = LabelGenerator(
            prefix=self.deployment_name,
            namespace=self.namespace,
            stage=self.stage,
            bu_name=self.bu_name,
            aws_env=kwargs["env"],
        )
        # random_suffix = str(uuid.uuid4()).split('-')[0]
        secret_id_name = lg.get_label(
            resource_type="secret",
            resource_name=self.secret_name,
            include_namespace=True,
            # include_stage=True,
            include_resource_type=True,
        )
        # secret_id_name = f'{secret_id_name}-{random_suffix}'

        if self.DB_Cluster_ID == "default":
            print("[INFO] Creating standard secret ...")
        else:
            print("[INFO] Creating rds postgres secret ...")
            db_endpoint = json.loads(self.DB_Cluster_Endpoint)
            db_username = self.secret_username
            db_cluster_id = self.DB_Cluster_ID
            db_name = self.DB_Init_Name
            db_engine = self.DB_Engine
            db_host = db_endpoint["hostname"]
            db_port = db_endpoint["port"]
            db_secret_template = {
                "username": db_username,
                "dbClusterIdentifier": db_cluster_id,
                "dbname": db_name,
                "engine": db_engine,
                "host": db_host,
                "port": db_port,
            }

            db_secret_template_str = json.dumps(db_secret_template)

            self.db_user_secret = secretsmanager.Secret(
                scope=self,
                id=secret_id_name,
                secret_name=secret_id_name,
                description="Secret",
                generate_secret_string=secretsmanager.SecretStringGenerator(
                    secret_string_template=db_secret_template_str,
                    generate_string_key="password",
                    password_length=30,
                    exclude_punctuation=True,
                ),
            )

        # Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

#!/usr/bin/env python3
import json
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import SecretGeneration


# ------------------------------------------------------------------------------
def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


# ------------------------------------------------------------------------------

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
stage = os.getenv(_param("STAGE"), "defaultStage")
namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")
tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

secret_name = os.getenv(_param("SECRET_NAME"))
if not secret_name:
    raise RuntimeError("Input parameter <secret_name> is missing")

secret_username = os.getenv(_param("SECRET_USERNAME"))
if not secret_username:
    raise RuntimeError("Input parameter <secret_username> is missing")

DB_Cluster_ID = os.getenv(_param("DB_CLUSTER_ID"), "default")
DB_Cluster_Endpoint = os.getenv(_param("DB_CLUSTER_ENDPOINT"), "default")
DB_Init_Name = os.getenv(_param("DB_INIT_NAME"), "default")
DB_Engine = os.getenv(_param("DB_ENGINE"), "postgres")


# include_namespace_str = os.getenv(_param("INCLUDE_NAMESPACE"), "False")
# include_namespace = True if str.lower(include_namespace_str) == "true" else False
config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
    "stage": stage,
    "namespace": namespace,
    "bu_name": bu_name,
    "tag_list": tag_list,
    "secret_name": secret_name,
    "secret_username": secret_username,
    "DB_Cluster_ID": DB_Cluster_ID,
    "DB_Cluster_Endpoint": DB_Cluster_Endpoint,
    "DB_Init_Name": DB_Init_Name,
    "DB_Engine": DB_Engine,
}

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

app_id = f"addf-{deployment_name}-{module_name}"

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
app = cdk.App()
stack = SecretGeneration(scope=app, id=app_id, config=config, env=environment)

CfnOutput(
    stack,
    id="metadata",
    value=stack.to_json_string({"SecretARN": stack.db_user_secret.secret_arn}),
)

app.synth()

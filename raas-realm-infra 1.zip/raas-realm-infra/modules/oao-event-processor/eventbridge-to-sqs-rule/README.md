# Eventbridge to SQS Module

## Description

This module creates an Eventbridge Rule targeting an SQS queue and creates new SQS queue if does not already exist

## Inputs/Outputs

### Input Parameters

#### Required

- `event_name` - detailType of the EventBridge event that will be forwarded to the queue
- `sqs-queue-name` - SQS queue name used for label generation
- `event_bus_name`- realm-local name of EventBus where EventBridge Rule will be created for
- `new_queue`- boolean variable, True when target queue does not exist, False if queue exists
- `cost-allocation-tag`- The tags for the AWS resources, which will be created by this module.
- `bu_name`- business unit name (e.g, aptiv)
- `namespace`: Namespace used in config
- `full_name_inclue_deployment_prefix`: Flag boolean variale to enable/disable the inclusion of the name component "deployment name" as prefix.
- `full_name_include_bu`: Flag boolean variale to enable/disable the inclusion of the name component "bu_name".
- `full_name_include_ns`: Flag boolean variale to enable/disable the inclusion of the name component "namespace".
- `sqs_visibility_timeout`: visibility timeout (in seconds).
- `sqs_retention_period`: message rentention period (in days).

#### Optional

### Module Metadata Outputs

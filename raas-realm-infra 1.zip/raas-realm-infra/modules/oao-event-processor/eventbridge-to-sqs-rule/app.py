#!/usr/bin/env python3
import json
import os

import aws_cdk as cdk
from stack import EventbridgeToSqsRuleStack


def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
app_prefix = f"addf-{deployment_name}-{module_name}"

namespace = os.getenv(_param("NAMESPACE"), "")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")

stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

event_name = os.getenv(_param("EVENT_NAME"))
sqs_queue_name = os.getenv(_param("SQS_QUEUE_NAME"))
event_bus_name = os.getenv(_param("EVENT_BUS_NAME"))
new_queue_str = os.getenv(_param("NEW_QUEUE"))
new_queue = True if str.lower(new_queue_str) == "true" else False

visibility_timeout = int(os.getenv(_param("SQS_VISIBILITY_TIMEOUT"), 30))
retention_period = int(os.getenv(_param("SQS_RETENTION_PERIOD"), 4))

full_name_inclue_deployment_prefix_str = os.getenv(
    _param("FULL_NAME_INCLUE_DEPLOYMENT_PREFIX"), "False"
)
full_name_inclue_deployment_prefix = (
    True if str.lower(full_name_inclue_deployment_prefix_str) == "true" else False
)

full_name_include_bu_str = os.getenv(_param("FULL_NAME_INCLUDE_BU"), "False")
full_name_include_bu = True if str.lower(full_name_include_bu_str) == "true" else False

full_name_include_ns_str = os.getenv(_param("FULL_NAME_INCLUDE_NS"), "False")
full_name_include_ns = True if str.lower(full_name_include_ns_str) == "true" else False


app = cdk.App()
stack = EventbridgeToSqsRuleStack(
    scope=app,
    construct_id=app_prefix,
    stage=stage,
    namespace=namespace,
    bu_name=bu_name,
    deployment_name=deployment_name,
    event_name=event_name,
    sqs_queue_name=sqs_queue_name,
    event_bus_name=event_bus_name,
    new_queue=new_queue,
    visibility_timeout=visibility_timeout,
    retention_period=retention_period,
    full_name_inclue_deployment_prefix=full_name_inclue_deployment_prefix,
    full_name_include_bu=full_name_include_bu,
    full_name_include_ns=full_name_include_ns,
    tags=tag_list,
    env=environment,
)

app.synth()

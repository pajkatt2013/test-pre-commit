from typing import cast

import cdk_nag
from aws_cdk import Aspects, Aws, Duration, Stack, Tags
from aws_cdk import aws_events as events
from aws_cdk import aws_events_targets as targets
from aws_cdk import aws_sqs as sqs
from aws_solutions_constructs.aws_eventbridge_sqs import EventbridgeToSqs
from cdk_nag import NagPackSuppression, NagSuppressions
from constructs import Construct, IConstruct
from utils import LabelGenerator


class EventbridgeToSqsRuleStack(Stack):
    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        stage: str,
        bu_name: str,
        namespace: str,
        deployment_name: str,
        event_bus_name: str,
        event_name: str,
        sqs_queue_name: str,
        new_queue: bool,
        visibility_timeout: int,
        retention_period: int,
        full_name_inclue_deployment_prefix: bool,
        full_name_include_bu: bool,
        full_name_include_ns: bool,
        tags: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        region = kwargs["env"].region
        account = kwargs["env"].account
        partition = Aws.PARTITION

        def add_tag(key, value):
            Tags.of(scope=cast(IConstruct, self)).add(key=key, value=value)

        for kv in tags:
            add_tag(kv["key"], kv["value"])

        event_bus = events.EventBus.from_event_bus_name(
            self, "event-bus", event_bus_name
        )

        existing_sqs = sqs.Queue.from_queue_arn(
            self,
            "existing_sqs",
            queue_arn=f"arn:{partition}:sqs:{region}:{account}:{sqs_queue_name}",
        )

        lg = LabelGenerator(
            prefix=deployment_name,
            namespace=namespace,
            stage=stage,
            bu_name=bu_name,
            aws_env=kwargs["env"],
        )

        event_rule_id_name = lg.get_label(
            resource_type="eventrule",
            resource_name=event_name,
            include_namespace=full_name_include_ns,
            include_stage=True,
            include_resource_type=True,
        )

        if new_queue:
            self.eventbridge2sqs = EventbridgeToSqs(
                self,
                "eventbridge-sqs",
                event_rule_props=events.RuleProps(
                    event_pattern=events.EventPattern(detail_type=[event_name])
                ),
                existing_event_bus_interface=event_bus,
                queue_props=sqs.QueueProps(
                    queue_name=lg.get_label(
                        resource_name=sqs_queue_name,
                        resource_type="sqs",
                        include_resource_type=True,
                        include_prefix=full_name_inclue_deployment_prefix,
                        include_bu=full_name_include_bu,
                        include_namespace=full_name_include_ns,
                        include_stage=True,
                    ),
                    visibility_timeout=Duration.seconds(visibility_timeout),
                    retention_period=Duration.days(retention_period),
                ),
                dead_letter_queue_props=sqs.QueueProps(
                    queue_name=f"{lg.get_label(resource_name=sqs_queue_name,resource_type='sqs',include_prefix=full_name_inclue_deployment_prefix,include_bu=full_name_include_bu,include_resource_type=True,include_namespace=full_name_include_ns,include_stage=True)}-dlq",
                ),
            )
        else:
            event_rule = events.Rule(
                scope=self,
                id=event_rule_id_name,
                rule_name=event_rule_id_name,
                event_bus=event_bus,
                event_pattern=events.EventPattern(detail_type=[event_name]),
            )
            event_rule.add_target(targets.SqsQueue(existing_sqs))

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())

        suppressions = [
            NagPackSuppression(
                **{
                    "id": "AwsSolutions-SQS3",
                    "reason": "The SQS queue does not have a dead-letter queue (DLQ) enabled",
                }
            )
        ]

        NagSuppressions.add_stack_suppressions(self, suppressions)

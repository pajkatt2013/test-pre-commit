#!/usr/bin/env python3
import json
import os

import aws_cdk as cdk
from aws_cdk import CfnOutput
from stack import Eventbridge_Lambda_Stack


# ------------------------------------------------------------------------------
def _param(name: str) -> str:
    return f"ADDF_PARAMETER_{name}"


# ------------------------------------------------------------------------------


tag_pairs = os.getenv(_param("COST_ALLOCATION_TAG"), "")
tag_list = json.loads(tag_pairs)

deployment_name = os.getenv("ADDF_DEPLOYMENT_NAME", "")
module_name = os.getenv("ADDF_MODULE_NAME", "")
app_prefix = f"addf-{deployment_name}-{module_name}"

environment = cdk.Environment(
    account=os.environ["CDK_DEFAULT_ACCOUNT"],
    region=os.environ["CDK_DEFAULT_REGION"],
)

stage = os.getenv(_param("STAGE"))
if len(stage.strip()) < 1:
    raise Exception("STAGE env var not set!")

namespace = os.getenv(_param("NAMESPACE"), "defaultNS")
bu_name = os.getenv(_param("BU_NAME"), "defaultBU")
event_publisher_lambda = os.getenv(_param("EVENT_PUBLISHER_LAMBDA"))
eventbus_name = os.getenv(_param("EVENTBUS_NAME"))
orchestration_account_id = os.getenv(_param("ORCHESTRATION_ACCOUNT_ID"))

config = {
    "deployment_name": deployment_name,
    "module_name": module_name,
}

rule_name = os.getenv(_param("RULE_NAME"), "defaultRule")
oao_event_type_str = os.getenv(_param("OAO_EVENT_TYPE"))
if oao_event_type_str is None:
    raise RuntimeError("[ERROR]: No value found for the parameter <oao_event_type>")
oao_event_type = json.loads(oao_event_type_str)

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
app = cdk.App()
stack = Eventbridge_Lambda_Stack(
    scope=app,
    construct_id=app_prefix,
    namespace=namespace,
    stage=stage,
    bu_name=bu_name,
    event_publisher_lambda=event_publisher_lambda,
    env=environment,
    config=config,
    rule_name=rule_name,
    oao_event_type=oao_event_type,
    eventbus_name=eventbus_name,
    orchestration_account_id=orchestration_account_id,
    tags=tag_list,
)

CfnOutput(
    scope=stack,
    id="metadata",
    value=stack.to_json_string(
        {
            "RuleArn": stack.event_rule.rule_arn,
        }
    ),
)

app.synth()

# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

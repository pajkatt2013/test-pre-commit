# Eventbridge to Lambda Module

## Description

This module creates event rule to forward events with specific detail-type(s) from local event bus to target lambda function

## Inputs/Outputs
### Input Paramenters
#### Required

- `oao-event-type`: detail-type of events to forward from local event bus
- `stage`: Target stage of deployment.

#### Optional

- `event-publisher-lambda`: Event publisher lambda function ARN
- `eventbus-name`: event bus name to create event rule in
- `orchestration-account-id`: Account ID of central orchestration realm
- `rule-name`: Event rule name created in the module
- `bu_name`: business unit name (e.g, supplier name)
- `namespace`: Namespace used in config
- `cost-allocation-tag`: The tags for the AWS resources, which will be created by this module.


#### Input Example
```yaml
parameters:
  - name: oao-event-type
    valueFrom:
      envVariable: OAO_EVENT_DETAIL_TYPES

  - name: rule-name
    value: forward-oao-events

  - name: event-publisher-lambda
    valueFrom:
      moduleMetadata:
        group: oao-event-publish-receive
        name: event-publisher
        key: EventPublisherLambdaArn

  - name: stage
    valueFrom:
      envVariable: STAGE

  - name: namespace
    valueFrom:
      envVariable: NAMESPACE

  - name: bu_name
    valueFrom:
      envVariable: BU_NAME

  - name: cost-allocation-tag
    value:
      - key: customer_function
        value: common
      - key: maintainer
        value: raas_devops

  - name: eventbus-name
    valueFrom:
      moduleMetadata:
        group: oao-event-publish-receive
        name: event-receiver
        key: RealmEventBusName

  - name: orchestration-account-id
    valueFrom:
      parameterStore: /${ADP_PREFIX}/app/data-platform/orchestration/account-id

```

### Module Metadata Outputs

- `RuleArn`: ARN of event rule created

# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
import logging
from typing import Any, Dict

import cdk_nag
from aws_cdk import Aspects, Stack, Tags
from aws_cdk import aws_events as events
from aws_cdk import aws_events_targets as targets
from aws_cdk import aws_lambda
from constructs import Construct
from utils import LabelGenerator

_logger: logging.Logger = logging.getLogger(__name__)


# ------------------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
class Eventbridge_Lambda_Stack(Stack):
    def __init__(
        self,
        scope: Construct,
        namespace: str,
        stage: str,
        bu_name: str,
        event_publisher_lambda: str,
        construct_id: str,
        config: Dict[str, Any],
        rule_name: str,
        oao_event_type: list,
        eventbus_name: str,
        orchestration_account_id: str,
        tags: list,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        for kv in tags:
            Tags.of(scope).add(key=kv["key"], value=kv["value"])

        for k, v in config.items():
            setattr(self, k, v)

        lg = LabelGenerator(
            prefix=config["deployment_name"],
            namespace=namespace,
            stage=stage,
            bu_name=bu_name,
            aws_env=kwargs["env"],
        )

        event_rule_id_name = lg.get_label(
            resource_type="eventrule",
            resource_name=rule_name,
            include_prefix=True,
            include_stage=True,
            include_resource_type=True,
        )

        event_bus_name = eventbus_name
        event_bus = events.EventBus.from_event_bus_name(
            self, "event-bus", event_bus_name
        )

        existing_lambda = aws_lambda.Function.from_function_arn(
            self, "event_publisher_lambda", function_arn=event_publisher_lambda
        )

        self.event_rule = events.Rule(
            self,
            id=event_rule_id_name,
            rule_name=event_rule_id_name,
            event_bus=event_bus,
            event_pattern=events.EventPattern(
                detail_type=oao_event_type,
                account=events.Match.anything_but(orchestration_account_id),
            ),
        )

        self.event_rule.add_target(targets.LambdaFunction(existing_lambda))

        Aspects.of(self).add(cdk_nag.AwsSolutionsChecks())


# ------------------------------------------------------------------------------
# END
# ------------------------------------------------------------------------------

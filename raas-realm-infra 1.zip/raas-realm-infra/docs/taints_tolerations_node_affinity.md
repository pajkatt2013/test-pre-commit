# Using Taints and Tolerations with AWS EKS

This guide will walk you through the process of using taints and tolerations with AWS Elastic Kubernetes Service (EKS). Taints and tolerations are useful when you want to control which pods can be scheduled on specific nodes in your EKS cluster.
## Prerequisites
Before you begin, make sure you have the following prerequisites:
- An active AWS EKS cluster deployed
- kubectl command-line tool installed and configured to access your EKS cluster.

## Understanding Taints and Tolerations
Taints are applied to nodes and indicate that the node should not accept pods unless they have a matching toleration. A taint consists of a key, value, and effect. The key-value pair uniquely identifies the taint, and the effect determines how pods without a matching toleration will be treated. The three possible effects are:
- NoSchedule: Pods without a matching toleration will not be scheduled on the tainted node.
- PreferNoSchedule: The scheduler will try to avoid scheduling pods without a matching toleration on the tainted node but may do so if necessary.
- NoExecute: Existing pods on the tainted node without a matching toleration will be evicted.

Tolerations, on the other hand, are applied to pods and specify the taints they can tolerate. A pod can have multiple tolerations, each specifying a key-value pair. If a pod has a toleration that matches a taint on a node, it will be able to be scheduled on that node.

## Tainting Nodes
To taint a node in your EKS cluster, follow these steps:
1. List the nodes in your cluster using the kubectl get nodes command.
```
kubectl get nodes
```
2. Choose the node(s) on which you want to apply a taint.

3. Apply the taint using the kubectl taint command. Replace NODE_NAME with the name of the node and provide the desired KEY, VALUE, and EFFECT for the taint.
```
kubectl taint nodes NODE_NAME KEY=VALUE:EFFECT
```
For example, to apply a taint with the key app and value backend and the effect NoSchedule to a node named node-1, use the following command:
```
kubectl taint nodes node-1 app=backend:NoSchedule
```
Note: The taint key and value can be any string that uniquely identifies the taint.

## Adding Tolerations to Pods
To add tolerations to pods, modify the pod specification YAML file and include the tolerations section. Here's an example YAML snippet:
```
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
spec:
  tolerations:
  - key: app
    operator: Equal
    value: backend
    effect: NoSchedule
  containers:
  - name: my-container
    image: my-image
```
In the example above, the pod has a toleration that matches the taint applied to the node with the key app, value backend, and effect NoSchedule. This allows the pod to be scheduled on the tainted node.

## Taints and EKS Managed Node Groups

If you are using EKS managed node groups, you can add Taints to node groups using, i.e. AWS CLI. Such Taints are automatically applied to the nodes when you scale the node group. Here is example how to create a node group with Taints:
```
aws eks create-nodegroup \
 --cli-input-json '
{
  "clusterName": "my-cluster",
  "nodegroupName": "node-taints-example",
  "subnets": [
     "subnet-1234567890abcdef0",
     "subnet-abcdef01234567890",
     "subnet-021345abcdef67890"
   ],
  "nodeRole": "arn:aws:iam::111122223333:role/AmazonEKSNodeRole",
  "taints": [
     {
         "key": "dedicated",
         "value": "gpuGroup",
         "effect": "NO_SCHEDULE"
     }
   ]
}'
```

## Node Affinity
Node affinity is a concept in Kubernetes that allows you to define rules or preferences for pod placement based on node labels. In simpler terms, it lets you specify how pods should be scheduled onto specific nodes based on certain criteria.

With node affinity, you can tell Kubernetes that you want your pods to be scheduled on nodes that have specific labels. This helps you achieve better control over where your pods run.

There are two types of node affinity rules you can define:

- **requiredDuringSchedulingIgnoredDuringExecution**: This rule specifies that a pod must be scheduled on a node that satisfies the defined labels. If there are no nodes that meet the criteria, the pod won't be scheduled at all.

- **preferredDuringSchedulingIgnoredDuringExecution**: This rule specifies a preference for scheduling a pod on nodes that have the defined labels. If there are multiple nodes that meet the criteria, Kubernetes will try to schedule the pod on the node with the highest preference. However, if no nodes match the criteria, the pod will still be scheduled on other nodes.

Here is example yaml with Node Affinity:
```
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
spec:
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
        - matchExpressions:
          - key: zone
            operator: In
            values:
            - us-west-1a
  containers:
  - name: my-container
    image: my-image
```
In this example, the pod has a node affinity rule that specifies requiredDuringSchedulingIgnoredDuringExecution. It states that the pod should be scheduled only on nodes that have the label zone=us-west-1a. If there are no nodes with that label, the pod won't be scheduled.

## Docs
For more information on taints and tolerations, refer to the Kubernetes documentation [Taints and Tolerations](https://kubernetes.io/docs/concepts/scheduling-eviction/taint-and-toleration/) and AWS documentation [Node taints on managed node groups](https://docs.aws.amazon.com/eks/latest/userguide/node-taints-managed-node-groups.html).
For Node Affinity, refer to Kubernetes documentation [Assign Pods to Nodes using Node Affinity](https://kubernetes.io/docs/tasks/configure-pod-container/assign-pods-nodes-using-node-affinity/)
